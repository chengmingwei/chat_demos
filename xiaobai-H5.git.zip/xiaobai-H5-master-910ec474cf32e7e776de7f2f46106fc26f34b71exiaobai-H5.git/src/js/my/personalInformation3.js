/**
 * 加载用户信息
 *
 *
 * */

$(function () {
    //$("#flagPath").parent().css("display","none");

    var name=$(".list li").eq(1).children("input:last-child");
    var district=$(".list li").eq(2).children(".arrow");
    $$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                district.html(data.datas.address);
                console.log(data);

                name.val(data.datas.account);
                if (data.datas.userStatus === 2 && data.datas.mtype === 4){
                    name.val(data.datas.rname == null?data.datas.account:data.datas.rname);
                }else{
                    name.val(data.datas.phone == null?data.datas.account:data.datas.phone);
                }

                if((data.datas.imgPath==null)||(data.datas.imgPath==="")){
                    $(".arrow img").attr("src","../../images/my/defaultImg.png");
                }else {
                    $(".arrow img").attr("src", data.datas.imgPath);
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });






    /*上传头像*/
    $('.arrow:eq(0)').click(()=>{
        $('#flagFile').click();
    });
    $('#flagFile').change(()=>{
        var file=$('#flagFile')[0].files[0];

        //文件类型
        var fileType=file.type;
        var type=getFileType(fileType);
        //文件大小
        var fileSize=(file.size/ 1024).toFixed(2);
        if(type!="jpg"&&type!="gif"&&type!="jpeg"&&type!="png"){
            $$.layerToast('请上传图片');
            return false;
        }
        if(fileSize>10240){//定义不能超过10MB
            $$.layerToast('请上传不超过10M的图片');
            return false;
        }
        lrz(file).then(function (resultObj) {
            $('#flagPath').attr("src",resultObj.base64);
            $('#flagPath').parent().css('display','block')
            $('#flagPath').css('display','block');
            $('.upload').css('display','none');
            $('.upload img').attr('src',resultObj.base64);
            flagPathBtn();
        });
        if (fileSize>10240&&type=="jpg"||type=="gif"||type=="jpeg"||type=="png"){
            uploadFlag();
        }
    });

  check();

  function check(){
      $$.request({
          url: UrlConfig.member_checkVerification,
          loading: true,
          sfn: function (data) {
              console.log(data)
              $$.closeLoading();
              /*if (data.datas==2||data.datas==1||data.datas==4){
                  $(name).on("click",function () {
                      let html = `<div class="pop-up">
                        <img class="close" src="../../images/appraisal/close.png" />
                        <div class="date"><p>当前审核状态无法修改昵称</p></div>
                        <div class="know">我知道了</div>
                    </div>`;
                      layer.open({
                          content: html,
                          type: 1
                      });
                      $('.close,.know').click(() => {
                          layer.closeAll();
                      })
                  })
              }else if (data.datas==0||data.datas==3){*/
                  $(name).attr("contenteditable","true");
                  let userName="";
                  $(name).focus(function () {
                      name.removeClass("arrow");
                      userName=$(this).val();
                  })
                  $(name).blur(function () {
                      name.addClass("arrow");
                      var name_value=name.val();
                      const verify = new $Valid.validComment({})
                      if(!verify.checkNameForRegex(name_value)) {
                          $$.throwTips("请输入有效的姓名！");
                      } else{
                          console.log(name_value)
                          $$.request({
                              url: UrlConfig.member_modifierUserName,
                              loading: true,
                              pars: {userName: name_value},
                              sfn: function (data) {
                                  $$.closeLoading();
                                  if (data.success){
                                      $$.layerToast("修改成功");
                                  }else {
                                      $$.layerToast(data.msg)
                                  }
                              },
                              ffn: function (data) {
                                  $$.errorHandler();
                              }
                          });
                      }
                  })
              /*}*/

          },
          ffn: function (data) {
              $$.errorHandler();
          }
      });
  }



  $(name).on("click",function () {

    })

    /**
     * 省市级联动
     *
     * */
    function weuiPicker(){
        weui.picker(chinaArea, {
            //此处编写各种属性和事件
            onConfirm: function(result) {
                console.log(result.length);
                let address="";
                for (var i=0;i<result.length;i++){
                    address+=result[i].label;

                }
                console.log(address)
                $$.request({
                    url: UrlConfig.member_modifierDistrict,
                    loading: true,
                    pars:{address:address},
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success) {
                            console.log(data);
                            $(".list li").eq(2).children(".arrow").html(data.datas);
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            }
        });
    }

    /**
     * 点击时调用
     *
     * */
    $(district).click(function () {
        weuiPicker();
    })


})


function getFileType(filePath) {
    var startIndex=filePath.lastIndexOf("/");
    if(startIndex!=-1){
        return filePath.substring(startIndex+1,filePath.length).toLowerCase();
    }else {
        return "";
    }
}

function uploadFlag(){
    let file = $('#flagFile')[0].files[0];
    console.log(file);
    if (file) {
        let formData = new window.FormData();
        formData.append('file', file);
        formData.append('formType', '10011');
        console.log(formData);
        $$.request({
            url: UrlConfig.upload_attachment_upload,
            loading: true,
            pars:formData,
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $('#flagPath').attr('src',data.datas.filePath);
                    let imgPath=$("#flagPath").attr("src");
                    console.log(imgPath);
                    $$.request({
                        url: UrlConfig.member_member_modifierRealName,
                        loading:true,
                        pars: {
                            "imgPath": imgPath,
                        },
                        sfn: function(data) {
                            if(data.success) {
                                $$.closeLoading();
                                $('#flagPath').parent().css('display','none')
                                $('#flagPath').css('display','none');
                                $('.upload').css('display','block');
                            }else{
                                $$.layerToast("更换图片失败");
                            }
                }
            });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
}

function flagPathBtn() {
    $('#flagPath').off('click');
    $('#flagPath').on('click',function(){
        $('#flagFile').click();
    });
}

window.onload = function(){
    countAction("xb_2058");
}