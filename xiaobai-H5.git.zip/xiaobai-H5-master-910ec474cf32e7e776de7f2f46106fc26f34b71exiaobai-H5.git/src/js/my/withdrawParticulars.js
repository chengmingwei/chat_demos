let bankId = 0;
let cardNames;
window.onload = function () {
    //loadBankCard();
    $$.changeVersion();
    //加载显示用户数据
    $$.request({
        url: UrlConfig.member_bankcard_getMemberWithdraw,
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                $('.name > .right > input').val(data.datas.rname);
                $('.idCard > .right > input').val(data.datas.cardno);
                $('.selectBank > div').text(data.datas.bankName);
                $('.bankNumber > .right > input').val(data.datas.bankNum);
                bankId = data.datas.bankId;
            }else{
                $$.layerToast("查询失败");
            }
        }
    });


    $('.submit').click(()=>{
        let name = $('.name > .right > input').val().trim();
        let idCard = $('.idCard > .right > input').val().trim();
        let bankNumber = $('.bankNumber > .right > input').val().trim();
        let selectBank = $('.selectBank > div').text();
        const dateUtil = new $Valid.validComment({});


        /*提交验证输入框内的内容信息*/
        if(name.length == 0 || idCard.length == 0 || bankNumber.length == 0){
            $$.layerToast("输入内容不能为空");
        }else if(selectBank.trim().substring(0,2) == "请选择"){
            $$.layerToast("请选择银行");
        }else if(name.length > 10){
            $$.layerToast("姓名输入有误,请重新输入");
            //$('.name > .right > input').val("");
        }else if(dateUtil.isIdCard(idCard)){
            $$.layerToast("身份证号输入有误,请重新输入");
            //$('.idCard > .right > input').val("");
        }else if(!luhnCheck(bankNumber)){
            $$.layerToast("银行卡号输入有误,请重新输入");
            //$('.bankNumber > .right > input').val("");
        }else if (checkBank(bankNumber)){
            return false;
        }else{
            $$.request({
                url: UrlConfig.bankCard_insert,
                loading: true,
                pars:{
                    rname:name,
                    cardno:idCard,
                    bankNum:bankNumber,
                    bankId:bankId,
                    bankName:cardNames,
                },
                requestBody:true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        $$.alert("绑定成功！",function () {
                            $$.push("my/personalInformation",{
                            });
                        })
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        }
    })

  //  loadBank();
    //银行卡列表
    $('.bank > .right').click(() => {
        $$.request({
            url: UrlConfig.bankType_getBankTypeList,
            pars: {},
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    let resultHtml = "";
                    const  bank =  data.datas.map((Item,Index)=>{
                        let json = {
                            label : Item.fullName,
                            value : Item.id
                        }
                        return json;

                    })

                    //console.log('--------->');
                    //console.log(bank);
                    weui.picker(bank,{
                        defaultValue : [bankId ? bankId : 0],
                        onConfirm: function (result) {
                            cardNames = result[0].label;
                            bankId = result[0].value;
                            $(".selectBank > div").text(result[0].label).css("color","rgb(138, 125, 164)");
                        },
                        //id:'1'
                    })
                } else {
                    $$.layerToast(`获取失败！[${data.msg}]`);
                }
            }
        });
    })

    countAction("xb_2060");
}
function loadBank() {
    $$.request({
        url: UrlConfig.bankType_getBankTypeList,
        pars: {},
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                let resultHtml = "";
                weui.picker(data.datas,{
                    defaultValue : [0],
                    onConfirm: function (result) {
                        //console.log(result[0].fullName);
                        $(".selectBank > div").text(result[0].fullName).css("color","rgb(138, 125, 164)");
                    }
                })
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
//银行卡号码检测
function luhnCheck(bankno) {
    var lastNum = bankno.substr(bankno.length - 1, 1); //取出最后一位（与luhn进行比较）
    var first15Num = bankno.substr(0, bankno.length - 1); //前15或18位
    var newArr = new Array();
    for (var i = first15Num.length - 1; i > -1; i--) { //前15或18位倒序存进数组
        newArr.push(first15Num.substr(i, 1));
    }
    var arrJiShu = new Array(); //奇数位*2的积 <9
    var arrJiShu2 = new Array(); //奇数位*2的积 >9
    var arrOuShu = new Array(); //偶数位数组
    for (var j = 0; j < newArr.length; j++) {
        if ((j + 1) % 2 == 1) { //奇数位
            if (parseInt(newArr[j]) * 2 < 9) arrJiShu.push(parseInt(newArr[j]) * 2);
            else arrJiShu2.push(parseInt(newArr[j]) * 2);
        } else //偶数位
            arrOuShu.push(newArr[j]);
    }

    var jishu_child1 = new Array(); //奇数位*2 >9 的分割之后的数组个位数
    var jishu_child2 = new Array(); //奇数位*2 >9 的分割之后的数组十位数
    for (var h = 0; h < arrJiShu2.length; h++) {
        jishu_child1.push(parseInt(arrJiShu2[h]) % 10);
        jishu_child2.push(parseInt(arrJiShu2[h]) / 10);
    }

    var sumJiShu = 0; //奇数位*2 < 9 的数组之和
    var sumOuShu = 0; //偶数位数组之和
    var sumJiShuChild1 = 0; //奇数位*2 >9 的分割之后的数组个位数之和
    var sumJiShuChild2 = 0; //奇数位*2 >9 的分割之后的数组十位数之和
    var sumTotal = 0;
    for (var m = 0; m < arrJiShu.length; m++) {
        sumJiShu = sumJiShu + parseInt(arrJiShu[m]);
    }

    for (var n = 0; n < arrOuShu.length; n++) {
        sumOuShu = sumOuShu + parseInt(arrOuShu[n]);
    }

    for (var p = 0; p < jishu_child1.length; p++) {
        sumJiShuChild1 = sumJiShuChild1 + parseInt(jishu_child1[p]);
        sumJiShuChild2 = sumJiShuChild2 + parseInt(jishu_child2[p]);
    }
    //计算总和
    sumTotal = parseInt(sumJiShu) + parseInt(sumOuShu) + parseInt(sumJiShuChild1) + parseInt(sumJiShuChild2);

    //计算luhn值
    var k = parseInt(sumTotal) % 10 == 0 ? 10 : parseInt(sumTotal) % 10;
    var luhn = 10 - k;

    if (lastNum == luhn) {
        return true;
    } else {
        return false;
    }
}
function checkBank(bankno) {
    $$.request({
        url: UrlConfig.bankCard_getBankName,
        loading: true,
        pars:{
            cardNumber:bankno
        },
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            console.log(data)
            if (data.validated) {
               return true;
            }else {
                return false;
                $$.layerToast('银行卡验证失败');
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function loadBankCard() {
    $$.request({
        url: UrlConfig.bankcard_data,
        loading: true,
        pars:{},
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            console.log(data);
            $('.name > .right > input').val(data.bankCard[0].rname);
            $('.idCard > .right > input').val(data.bankCard[0].cardno);
            $('.bankNumber > .right > input').val("**** **** **** "+data.bankCard[0].banknum);
            bankName(data.bankCard[0].bankid);
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function  bankName(id) {
    $$.request({
        url: UrlConfig.bankType_getBankTypeList,
        loading: true,
        pars:{
            id:id
        },
        sfn: function (data) {
            $$.closeLoading();
            console.log(data)
            $('.selectBank > div').html(data.datas[0].fullName);
            $(".submit").hide();
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
