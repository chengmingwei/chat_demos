/**
 * 文章-新手指引 JS
 * @Author 吴成林
 * @Date 2020-3-3 10:11:23
 */
let isShare;
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        isShare = $$.getUrlParam("isShare");
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        weChatShare();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        if ($$.isValidObj(isShare) && isShare) {
            $('.confirm').hide();
            WE_CHAT_MENU_FLAG = false;
            weChatMenuHandler();
        } else {
            //-- 返回上一页 - 转载文章
            $('.confirm').on('click', function () {
                history.go(-1);
            });
        }
    }

    function weChatShare() {
        let _lineLink = $$.getFullHost() + "/src/pages/my/newbieGuide.html";
        _lineLink += $$.jsonToUrlParams({
            isShare: true
        });
        weChatJSTool.share({
            _imgUrl: $Constant.shareLogo,
            _lineLink: _lineLink,
            _shareTitle: '如何使用【自定义文章编辑器】攻略',
            _descContent: '轻松转发，自定义自己的美篇、美文，引爆朋友圈，做话题的引导者，快来看我吧！',
            _sfn: function () {
                console.log("成功注册分享链接："+_lineLink);
            }
        });
    }
};
