let memberId;
let isOldMembers;
window.onload = function(){
	$$.loading();
	/* 加载用户信息状态 */
	$$.request({
		url: UrlConfig.member_Detailspage,
		loading: true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				const {id, isOldMember, imgPath, rname, phone, account, cardno, userStatus, licenseId} = data.datas;
				memberId = id;
				isOldMembers = isOldMember;
				if ($$.isValidObj(imgPath)) {
					$(".picture").css("background", `url("${imgPath}") no-repeat center / contain`);
				} else {
					$(".picture").css("background", `url("../../images/my/defaultImg.png") no-repeat center / contain`);
				}
				if ($$.isValidObj(rname)){
					$(".realName .rName span").html(rname);
				} else {
					$(".realName .rName span").html('无');
					$('.fillIn').show().on("click", function () {
						$$.push("my/basicInformation");
					});
				}

				$(".phone span").html(!$$.isValidObj(phone) ? account : phone);

				if ($$.isValidObj(cardno)){
					$(".cardno .idCard span").html(cardno);
				} else {
					$(".cardno .idCard span").html('无');
					$('.fillIn').show().on("click", function () {
						$$.push("my/basicInformation");
					});
				}
				if(userStatus === 2){
					$(".isverify span").html("审核通过");

					//-- 签署开放后显示
					$('.bottom').show();
					extsignResult();
				} else {
					$$.closeLoading();
				}

				detailsPageMemberDetail(licenseId);		// 获取用户执业编号状态
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
	countAction("xb_2059");

	//-- 获取用户执业编号状态
	function detailsPageMemberDetail(licenseId){
		$$.request({
			url: UrlConfig.memberdetail_detailsPageMemberDetail,
			sfn: function(data){
				$$.closeLoading();
				if (data.success) {
					const {licenseRegTime, licenseIssueTime, licenseIsSubmit} = data.datas;
					if ($$.isValidObj(licenseRegTime) && $$.isValidObj(licenseIssueTime) && licenseIsSubmit == 1) {
						$('.licenseId .number').html(licenseId);
					} else{
						$('.licenseId .number').html(`<span style="color: #FF7052">编号审核中，详情请联系小白客服~</span>`);
					}
				}
			}
		});
	}
};
function getFadadaInfo() {
	$$.request({
		url: UrlConfig.member_fadada_getFadadaInfo,
		pars: {
			memberId: memberId
		},
		requestBody:true,
		sfn: function(data) {
			$$.closeLoading();
			if(data.success) {
				let customer_id = data.customer_id;
				let auth_certStatus = data.auth_certStatus;
				if (customer_id != null && auth_certStatus === 1) {
					let view1Html = '';
					let selector = null;
					let contract_id = data.fadada_contract_id;
					let fadada_extsign_tran_id_a = data.fadada_extsign_tran_id_a;
					let fadada_extsign_tran_id_b = data.fadada_extsign_tran_id_b;
					let fadada_contractFilling = data.fadada_contractFilling;
					if (contract_id == null) {
						view1Html = '合同生成';
						selector = function() {
							fadada_generateContract(customer_id);
						};
					} else if (fadada_extsign_tran_id_a == null) {
						view1Html = '公司签署';
						selector = function() {
							fadada_extsignAuto(customer_id);
						};
					} else if (fadada_extsign_tran_id_b == null) {
						view1Html = '用户签署';
						selector = function() {
							fadada_extsign(customer_id);
						};
					} else if (fadada_contractFilling === 0) {
						view1Html = '合同归档';
						selector = function() {
							fadada_contractFiling(customer_id);
						};
					}
					if (selector == null) {
						let download_url = data.fadada_download_url;
						let viewpdf_url = data.fadada_viewpdf_url;
						fadada_finish(download_url,viewpdf_url);
					} else {
						$('#view1 span').html(view1Html);
						$('#view1').on('click',selector);
					}
				} else {
					if (isOldMembers) {
						$('#view1 span').html('补充认证信息');
						$('#view1').css('width','100px').on('click',function () {
							$$.push("my/basicInformation");
						});
					} else {
						$('.statusDesc').html('请先通过执业认证');
						$('#view1').hide();
					}
				}
			} else {
				$$.layerToast(data.msg);
				$('#view1').hide();
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function fadada_generateContract(customer_id) {
	$$.loading('合同生成中');
	$$.request({
		url: UrlConfig.member_fadada_generateContract,
		pars: {
			customer_id: customer_id
		},
		requestBody:true,
		sfn: function(data) {
			$$.closeLoading();
			if(data.success) {
				fadada_extsignAuto(customer_id);
			} else {
				$$.alert(data.msg);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function fadada_extsignAuto(customer_id) {
	$$.loading('公司签署中');
	$$.request({
		url: UrlConfig.member_fadada_extsignAuto,
		pars: {
			customer_id: customer_id
		},
		requestBody:true,
		sfn: function(data) {
			$$.closeLoading();
			if(data.success) {
				fadada_extsign(customer_id);
			} else {
				getFadadaInfo();
				$$.alert(data.msg);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function fadada_extsign(customer_id) {
	$$.loading('用户签署中');
	$$.request({
		url: UrlConfig.member_fadada_extsign,
		pars: {
			customer_id: customer_id,
			notify_url: UrlConfig.member_fadada_extsignNotify,//法大大签署结果异步回调
			return_url: $$.getBasePath() + "/src/pages/my/passed.html"
		},
		requestBody:true,
		sfn: function(data) {
			if(data.success) {
				window.location.href = data.sign_url;
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function fadada_contractFiling(customer_id) {
	$$.loading('合同归档中');
	$$.request({
		url: UrlConfig.member_fadada_contractFiling,
		pars: {
			customer_id: customer_id
		},
		requestBody:true,
		sfn: function(data) {
			$$.closeLoading();
			if(data.success) {
				let download_url = data.fadada_download_url;
				let viewpdf_url = data.fadada_viewpdf_url;
				fadada_finish(download_url,viewpdf_url);
			} else {
				getFadadaInfo();
				$$.alert(data.msg);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function fadada_finish(download_url,viewpdf_url) {
	$('#view1 span').html('下载合同');
	$('#view1').on('click',function() {
		window.location.href = download_url;
	});
	$('#view2').show().on('click',function () {
		window.location.href = viewpdf_url;
	});
}
function extsignResult() {
	let msg_digest = $$.getUrlParam("msg_digest");
	if (msg_digest) {
		let transaction_id = $$.getUrlParam("transaction_id");
		let timestamp = $$.getUrlParam("timestamp");
		$$.request({
			url: UrlConfig.member_fadada_extsignResult,
			pars: {
				msg_digest: msg_digest,
				transaction_id: transaction_id,
				timestamp: timestamp
			},
			requestBody:true,
			sfn: function(data) {
				$$.closeLoading();
				if(data.success) {
					let result_code = $$.getUrlParam("result_code");
					if (result_code === '3000') {
						let customer_id = $$.getUrlParam("customer_id");
						fadada_contractFiling(customer_id);
					} else {
						$$.alert('签章失败',function () {
							getFadadaInfo();
						});
					}
				} else {
					$$.alert(data.msg,function () {
						getFadadaInfo();
					});
				}
			},
			ffn: function(data) {
				$$.errorHandler();
			}
		});
	} else {
		getFadadaInfo();
	}
}
