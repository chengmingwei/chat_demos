//微信用户ID
//const wechatID = $$.getUrlParam('wechatID');
//微信用户名称
//const wechatName = decodeURIComponent($$.getUrlParam('wechatName'));
//用户可提现的余额
//const redBagMoney = $$.getUrlParam('redBagMoney');

let lineLink = $$.getFullHost() + "/src/pages/my/newGiftBagRedirect.html";
window.onload = function () {
    $$.changeVersion();
    $$.request({
        url: UrlConfig.member_red_account,
        loading: true,
        sfn: function (data) {
            ShawHandler.closeLoading();
            let redBagMoneyTotal;
            if (data.success) {
                redBagMoneyTotal = data.datas.useAmount;
            } else {
                redBagMoneyTotal = 0.00;
            }
            $('.money').text(redBagMoneyTotal);
            if (redBagMoneyTotal == null || redBagMoneyTotal === 0.00) {
                $('.withdraw').click(() => {
                    $$.alert("红包余额不足！");
                });
            } else {
                $('.withdraw').click(() => {
                    $$.push('my/redBagWithdraw');
                });
            }
        }
    });

    getDetailList();
    getShareUrl();

    //-- 列表切换
    $(".detail>div").on("click", function(){
        $(this).addClass("listUnit").siblings().removeClass("listUnit");
        let type = $(this).attr("data-type");
        if (type == "1"){
            getDetailList();
            countAction("xb_3032");
        } else if (type == "2"){
            getInviteeList();
            countAction("xb_3033");
        }
    });

    $('.tips').click(() => {
        let html = `<div class="pop-up">
                            <div class="title">提现说明</div>
                            <div class="text">
                                <div>1.活动提现：</div>
                                活动提现主要为小额提现，需满足一定条件
                                （如：新人红包需成功邀请1位好友完成并通过执业认证）
                                才可以提现,目前仅支持提现至微信钱包。
                            </div>
                            <div class="text">
                                 <div>2.活动提现：</div>
                                通常情况下提交提现后48小时到账，请小白兔们耐心等待哦。
                            </div>
                            以上解释权归小白保险所有。
                            <div class="know">我知道了</div>
                        </div>`;
        layer.open({
            content: html,
            type: 1
        });
        $('.know').click(() => {
            layer.closeAll();
        });
        countAction("xb_3031");
    });

    function getDetailList() {
        //类型 --- 1(增加)/2(减少)
        let type;
        //细节说明
        let detail;
        //操作金额
        let redBagMoney;
        //操作时间
        let date;
        $$.request({
            url: UrlConfig.member_redRecords_personList,
            sfn: function (data) {
                if (data.success) {
                    let html = "";
                    if (data.datas.length > 0) {
                        data.datas.forEach((Item, Index) => {
                            type = Item.fromType;
                            //1:新人红包,2:早起打卡红包,3:其它"
                            if (Item.bussType === 1) {
                                detail = '新人红包';
                            } else if (Item.bussType === 2) {
                                detail = '早起打卡红包';
                            } else {
                                detail = '其它';
                            }
                            if (type === 1) {
                                redBagMoney = parseFloat(Item.redAmount).toFixed(2);
                            } else if (type === 2) {
                                redBagMoney = parseFloat(Item.incomeAmount).toFixed(2);
                            }
                            date = Item.createTime;

                            console.log(type + detail + redBagMoney + date);
                            if (type === 2) {
                                html +=
                                    `<li>
                                        <div class="particulars">
                                            <div class="vertical_1">
                                                </div>${detail}</div>
                                            <div class="number_1">-${redBagMoney}</div>
                                        <div class="date">${date}</div>
                                    </li>`;
                            } else if (type === 1) {
                                html +=
                                    `<li>
                                        <div class="particulars">
                                            <div class="vertical_2">
                                                </div>${detail}</div>
                                            <div class="number_2">+${redBagMoney}</div>
                                        <div class="date">${date}</div>
                                    </li>`;
                            }
                            $('.list').html(html);
                        });
                    } else {
                        $('.list').html(html);
                    }
                } else {
                    $$.alert("获取红包明细失败")
                }
            }
        });
    }

    function getInviteeList() {
        /*let datas = [{        // 模拟数据
            rname : '测试',
            imgPath : 'https://pic.xiaobaibao.com/app/appHomePic/2020/3/dbd62c9179ca4fa9924fc08e14f762eb.jpg',
            account : "15912345611",
            userStatus : 0,
            mtype : 0,
            createTime: '2020-03-17 16:17:46'
        }];*/
        let html = "";
        $$.request({
            url: UrlConfig.member_userrelationship_getInviteeList,
            pars:{
                formType: 4,
            },
            sfn: function (data) {
                if (data.success) {
                    if (data.datas.length > 0){
                        data.datas.forEach((item, index) => {
                            let account = item.account.replace(/^(\d{3})\d{4}(\d+)/, "$1****$2"); //手机号159****1111
                            let name = "";
                            $$.isValidObj(item.rname) ? name = item.rname : name = item.account;
                            let imgPath = '';
                            $$.isValidObj(item.imgPath) ? imgPath = item.imgPath : imgPath = '../../images/my/mituLogo.png';
                            let createTime = new Date(item.createTime.replace(/\-/g, "/").replace("00:00:00.0", ""));
                            let invitationTime = createTime.getFullYear() + '年' + (createTime.getMonth() + 1) + '月' + createTime.getDate() + '日';
                            if (item.userStatus == 2 && item.mtype == 4) {
                                html +=
                                    `<li class="unit">
                                        <div class="photo"><img src="${imgPath}"></div>
                                        <div class="unitContent">
                                            <div class="unitContentTop">
                                                <div class="topName">${name}</div>
                                                <div class="authentication">已认证</div>
                                            </div>
                                            <div class="unitContentBottom">
                                                <div>${account}</div>
                                                <div>${invitationTime}</div>
                                            </div>
                                        </div>
                                    </li>`;
                            } else {
                                html +=
                                    `<li class="unit">
                                        <div class="photo"><img src="${imgPath}"></div>
                                        <div class="unitContent">
                                            <div class="unitContentTop">
                                                <div class="topName">${name}</div>
                                                <div class="noAuthentication">未认证</div>
                                            </div>
                                            <div class="unitContentBottom">
                                                <div>${account}</div>
                                                <div>${invitationTime}</div>
                                            </div>
                                        </div>
                                        <div class="remind">提醒ta</div>
                                    </li>`;
                            }
                            $('.list').html(html);
                        });
                    } else {
                        $('.list').html(html);
                    }


                    $('.remind').click(() => {
                        $$.showShareView('点击右上角,分享新人礼包给好友！');
                        return false;
                    })
                }
            }
        });
    }

    function getShareUrl() {
        $$.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: "my/friendRequest.html",
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_3,
                otherParams: JSON.stringify({"_checkLogin": true})
            },
            loading: true,
            checkLogin: true,
            sfn: function (data) {
                ShawHandler.closeLoading();
                if (data.success) {
                    newGifBagShare(data.datas);
                } else ShawHandler.alert(data.msg);
            }
        });
    }

    function newGifBagShare(url) {
        if (!$$.weChat.isWx() && !url) return;

        $$.request({
            url: UrlConfig.member_getMemberName,
            sfn: function (data) {
                let name = '';
                if (data.success) {
                    if ($$.isValidObj(data.userName)){
                        name = '我是' + data.userName + ',';
                    } else {
                        name = '';
                    }
                }
                weChatJSTool.share({
                    _imgUrl: $$.getFullHost() + "/src/images/my/successAuthentication.png",
                    _lineLink: lineLink + '?redirectUrl=' + encodeURIComponent(url),
                    _shareTitle: 'hi！' + name + '我来给你送礼啦！',
                    _descContent: '新人注册即可领取优惠大礼包一份哦！'
                });
            }
        });
    }
    countAction('xb_2082', null);
    countAction("xb_3032");
}

