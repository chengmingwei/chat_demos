/*判断是否注册*/
/*const isCreat = true;*/

let lineLink = $$.getFullHost() + "/src/pages/my/newGiftBagRedirect.html";

/*if (lineLink !== window.location.href) // 二次分享处理
{
    window.location.href = lineLink;
}*/

window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_74', null);
    } catch (error) {
        console.log(error);
    }

    let shareDatums = {
        url: '',
        image: $Constant.shareLogo,
        title: 'hi！我来给你送礼啦！',
        content: "新人注册即可领取优惠大礼包一份哦！"
    }

    getShareUrl();

    function getShareUrl() {
        $$.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: "my/friendRequest.html",
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_3,
                otherParams: JSON.stringify({"_checkLogin": true})
            },
            loading: true,
            checkLogin: true,
            sfn: function (data) {
                ShawHandler.closeLoading();
                if (data.success) {
                    newGifBagShare(data.datas);
                } else ShawHandler.alert(data.msg);
            }
        });
    }

    function newGifBagShare(url) {
        if (!$$.weChat.isWx() && !url && !PAGE_APP) return;

        $$.request({
            url: UrlConfig.member_getMemberName,
            sfn: function (data) {
                let name = '';
                if (data.success) {
                    if ($$.isValidObj(data.userName)){
                        name = '我是' + data.userName + ',';
                    } else {
                        name = '';
                    }
                }

                shareDatums.url = lineLink + '?redirectUrl=' + encodeURIComponent(url);
                shareDatums.image = $$.getFullHost() + "/src/images/my/successAuthentication.png";
                shareDatums.title = 'hi！' + name + '我来给你送礼啦！';

                weChatJSTool.share({
                    _imgUrl: $$.getFullHost() + "/src/images/my/successAuthentication.png",
                    _lineLink: lineLink + '?redirectUrl=' + encodeURIComponent(url),
                    _shareTitle: 'hi！' + name + '我来给你送礼啦！',
                    _descContent: '新人注册即可领取优惠大礼包一份哦！'
                });
            }
        });
    }

    //点击分享新人礼包
    $('.invite').on('click', () => {
        if(PAGE_APP){
            //-- APP
            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            countAction("xb_2078");
            $$.showShareView('点击右上角,分享新人礼包给好友！');
            return false;
        }
    });
};

/**点击好友邀请按钮提示**/
