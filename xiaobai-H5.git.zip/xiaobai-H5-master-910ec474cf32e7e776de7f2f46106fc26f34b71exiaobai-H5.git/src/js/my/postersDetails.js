/**
 * 海报详情 JS
 * @Author 吴成林
 * @Date 2020-2-26 15:03:15
 */
let postersId;
let memberId;
let memberImg;
let memberPhone;
let memberName;
let wxQRCode;
let bgImgUrl;                               // 当前海报背景图
let postersList = {};                       // 海报列表
let postersSynthesisList = {};              // 海报合成列表
let timeOutEvent = 0;
const PAGE_STATE = {
    switchState: true,                      // 是否显示名片
    whetherVIP: false,                      // 是否是VIP
    postersId: [],                          // 海报ID列表
    currIndex: 0,                           // 当前海报索引
    viewWidth: 0,                           // 视图宽度
    viewHeight: 0,                          // 视图高度
    shareDatums: {                          // 分享参数
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: '海报分享'
    }
};
let domainName1 = "https://pic.xiaobaibao.com";
let domainName2 = "https://pic.xiaobaibao.com";
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**addEventListener
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        //-- 适配移动端 全屏宽高
        PAGE_STATE.viewWidth = window.innerWidth || document.documentElement.clientWidth;
        PAGE_STATE.viewHeight = window.innerHeight || document.documentElement.clientHeight;

        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        let filtrate = decodeURI($$.getUrlParam("filtrate"));
        let title = decodeURI($$.getUrlParam("title"));
        let share = $$.getUrlParam("share");
        let id = $$.getUrlParam("id");
        let gvid = $$.getUrlParam("gvid");
        if (title !== "我的海报"){
            loadPostersList(title,id)
        }else {
            let type = "1";
            if (filtrate === "热门" || filtrate === "海报作品"){
                type = "1";
            }else {
                type = "2";
            }
            loadMyPostersList(title,id,type)
        }
        loadCollectionState(id);
        if (share === "false"){
            loadMyBusinessCard()
        }
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 是否 - 显示名片
        $(".switch").on("click", function(){
            if (PAGE_STATE.switchState){
                $('.visitingCard').hide();
                $('.synthesisPosters').hide();
                $(".switch").css("background-color","#999999");
                $(".switch").children("div.switchNo").removeClass("switchNo").addClass("switchYes");
                PAGE_STATE.switchState = false;
            } else {
                $('.visitingCard').show();
                $('.synthesisPosters').show();
                $(".switch").css("background-color","#EF5B09");
                $(".switch").children("div.switchYes").removeClass("switchYes").addClass("switchNo");
                PAGE_STATE.switchState = true;
                makePoster();
            }
        });

        //-- 收藏
        $(".postersCollecting").on("click", function(){
            if ($(this).children("div").hasClass("postersCollectingNo")){
                $(this).children("div.postersCollectingNo").removeClass("postersCollectingNo").addClass("postersCollectingYes");
                insertCollection(postersId,memberId);
            } else {
                $(this).children("div.postersCollectingYes").removeClass("postersCollectingYes").addClass("postersCollectingNo");
                cancelCollection(postersId,memberId);
            }
        });
        //-- 分享
        $(".share").on("click", function(){
            if (PAGE_STATE.switchState){
                makePoster();
            }
            sharePosters();         // 分享参数配置
            shareHandler();
        });

        //-- 上一个海报
        $(".previous").on("click", function(){
            let lis = $('.postersDetailsList').find("li:visible");
            let baseid = parseInt(lis.prev().attr("data-baseid"));   // 海报图索引

            if ($$.isValidObj(baseid)){
                lis.attr("hidden", "hidden").prev().removeAttr("hidden");
                postersId = lis.prev().attr("data-id");              // 上一张海报ID
                loadCollectionState(postersId);                             // 加载是否收藏
                $(".next").show();

                PAGE_STATE.currIndex = baseid;
                if (baseid === 0) $(".previous").hide();                    // 第一张图片隐藏向前按钮

                bgImgUrl = lis.prev().children("img")[0].src;              // 保存海报图路径

                if (PAGE_STATE.switchState){
                    makePoster();
                } else {
                    $('.synthesisPosters').hide();
                }
            }
        });

        //-- 下一个海报
        $(".next").on("click", function(){
            let lis = $('.postersDetailsList').find("li:visible");
            let baseid = parseInt(lis.next().attr("data-baseid"));   // 海报图索引

            if ($$.isValidObj(baseid)){
                lis.attr("hidden", "hidden").next().removeAttr("hidden");
                postersId = lis.next().attr("data-id");                   // 下一张海报ID
                loadCollectionState(postersId);                                 // 加载是否收藏
                $(".previous").show();

                PAGE_STATE.currIndex = baseid;
                if (baseid === postersList.length-1) $(".next").hide();        // 最后一张图片隐藏向后按钮

                let lastBaseid = parseInt($('.postersDetailsList>li:last').attr("data-baseid"));
                if (lastBaseid !== postersList.length-1) nextPoster(parseInt(lastBaseid+1));

                bgImgUrl = lis.next().children("img")[0].src;              // 保存海报图路径

                if (PAGE_STATE.switchState){
                    makePoster();
                } else {
                    $('.synthesisPosters').hide();
                }
            }

        });

    }

    //-- 加载下一张海报
    function nextPoster(i) {
        const {picpath, id} = postersList[i];
        let resultHtml = `<li class="unit" data-baseid="${i}" data-id="${id}" hidden><img src="${picpath}" class="postersContent"></li>`;

        $(".postersDetailsList").append(resultHtml);
    }

    //-- 后台合成图片
    function mergePoster(value) {
        const content = "咨询保险就找我";
        //$$.loading('合成中，请稍后');
        $$.request({
            url: UrlConfig.upload_attachment_mergePoster,
            pars:{
                "bgImgUrl":bgImgUrl,	    // 海报背景图
                "xbLogoUrl":memberImg,	    // 海报用户头像图
                "qrCode":wxQRCode,	        // 海报底部用户二维码
                "name":memberName,	        // 用户姓名
                "content":content,	        // 咨询保险就找我
                "phone":memberPhone,	    // 用户手机号
                "formId":postersId,	        // 海报ID
                "memberId":memberId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let filePath = data.datas.filePath;
                    if ($$.isValidObj(filePath)) {
                        postersSynthesisList[PAGE_STATE.currIndex] = filePath;
                        $('.postersDetailsList>li:nth-child('+ value +')>.postersContent').attr('src',filePath);
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 前台合成图片
    function makePoster(){
        let postersListLength = postersList.length;
        if ($$.isValidObj(postersSynthesisList[PAGE_STATE.currIndex])){
            $('.synthesisPosters').attr('src', postersSynthesisList[PAGE_STATE.currIndex]);
        } else {
            $('.previous').hide();
            $('.next').hide();
            const opts = {useCORS: true};
            const posterEle = document.getElementById("postersDetailsList");
            html2canvas(posterEle,opts).then(function(canvas) {
                const width = canvas.width;
                const height = canvas.height-70;
                const image = Canvas2Image.convertToPNG(canvas, width, height);
                $('.synthesisPosters').attr('src', image.src);
                postersSynthesisList[PAGE_STATE.currIndex] = image.src;

                if (PAGE_STATE.currIndex == 0){
                    $('.next').show();
                } else if (PAGE_STATE.currIndex+1 == postersListLength){
                    $('.previous').show();
                } else {
                    $('.previous').show();
                    $('.next').show();
                }
            });
        }
    }
    /**
     * 分享海报
     */
    function sharePosters() {
        if (!$WeChat.isWx() && !PAGE_APP) {
            return;
        }
        let _lineLink = $$.getFullHost() + '/src/pages/my/sharePosters.html';
        const switchState = PAGE_STATE.switchState;
        let params = {
            id:postersId,
            memberId:memberId,
            switchState:switchState
        };
        /* 是否带参 */
        if (switchState){
            params = {
                ...params,
                memberImg:memberImg,
                memberPhone:memberPhone,
                memberName:encodeURI(encodeURI(memberName)),
                wxQRCode:wxQRCode
            };
        }
        _lineLink += $$.jsonToUrlParams(params);
        PAGE_STATE.shareDatums = {      //-- 保存分享参数
            image: $Constant.shareLogo,
            url: _lineLink,
            title: '我在用这个功能设计精美海报',
            content: '想你所想，快来设计你的专属独家海报吧！',
        };
        weChatJSTool.share({
            _imgUrl:  $Constant.shareLogo,
            _lineLink:  _lineLink,
            _shareTitle: '我在用这个功能设计精美海报',
            _descContent: '想你所想，快来设计你的专属独家海报吧！',
            _sfn: function () {
                $$.layerToast("分享成功~");
                $$.share(postersId,1);
            }
        });
    }
    /**
     * 描述信息：加载 列表
     * @author 覃创斌
     * @date 2020/2/27
     */
    function loadPostersList(title,id) {
        $$.request({
            url: UrlConfig.market_getPosterDetailsList,
            pars:{
                name:title,
                id:id
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = ``;
                    if (data.datas.length !== 0){
                        if (data.datas.length === 1){
                            $(".next").hide();
                        }
                        postersList = data.datas;
                        for (let i in postersList){
                            let {picpath, id} = postersList[i];
                            if (new RegExp(domainName1).test(picpath)) picpath = picpath.replace(domainName1,"");
                            if (new RegExp(domainName2).test(picpath)) picpath = picpath.replace(domainName2,"");
                            i = parseInt(i);

                            if (i === 0){
                                resultHtml += `<li class="unit" data-baseid="${i}" data-id="${id}"><img src="${picpath}" class="postersContent"></li>`;
                                postersId = id;
                                bgImgUrl = picpath;
                                $(".previous").hide();
                            } else if (i === 1){
                                resultHtml += `<li class="unit" data-baseid="${i}" data-id="${id}" hidden><img src="${picpath}" class="postersContent"></li>`;
                            } else {
                                break;
                            }
                        }
                        $(".postersDetailsList").html(resultHtml);
                    }
                    longPressSave();    // APP长按保存
                    loadMember();       // 加载用户数据
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 描述信息：加载我的海报列表
     * @author 覃创斌
     * @date 2020/2/27
     */
    function loadMyPostersList(title,id,type) {
        $$.request({
            url: UrlConfig.market_getMyPosterList,
            pars:{
                id:id,
                type:type
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    if (data.datas.length !== 0){
                        if (data.datas.length === 1){
                            $(".next").hide();
                        }
                        postersList = data.datas;
                        for (let i in postersList){
                            let {picpath, id} = postersList[i];
                            if (new RegExp(domainName1).test(picpath)) picpath = picpath.replace(domainName1,"");
                            if (new RegExp(domainName2).test(picpath)) picpath = picpath.replace(domainName2,"");
                            i = parseInt(i);

                            if (i === 0){
                                resultHtml += `<li class="unit" data-baseid="${i}" data-id="${id}"><img src="${picpath}" class="postersContent"></li>`;
                                postersId = id;
                                bgImgUrl = picpath;
                                $(".previous").hide();
                            } else if (i === 1){
                                resultHtml += `<li class="unit" data-baseid="${i}" data-id="${id}" hidden><img src="${picpath}" class="postersContent"></li>`;
                            }
                        }
                        $(".postersDetailsList").html(resultHtml);
                    } else if (data.datas.length === 1){
                        $(".previous").hide();
                        $(".next").hide();
                    }
                    loadMember();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：加载是否收藏
     * @author 覃创斌
     * @date 2020/2/28
    */
    function loadCollectionState(id) {
        $$.request({
            url: UrlConfig.market_getCollectionByPosterID,
            pars:{
                id:id,
            },
            requestBody:true,
            sfn: function (data) {
                if (data.success) {
                    if (data.datas.length !== 0){
                        $(".postersCollecting").children("div.postersCollectingNo").removeClass("postersCollectingNo").addClass("postersCollectingYes");
                    }else {
                        $(".postersCollecting").children("div.postersCollectingYes").removeClass("postersCollectingYes").addClass("postersCollectingNo");
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：加载我的名片
     * @author 覃创斌
     * @date 2020/2/28
    */
    function loadMyBusinessCard() {
        $$.request({
            url: UrlConfig.myBusines_getMyBusinessCard,
            pars:{},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if ($$.isValidObj(data.entity)){
                        if($$.isValidObj(data.entity.wxQRCode)){
                            let wxQRCodes = data.entity.wxQRCode;
                            if (new RegExp(domainName1).test(wxQRCodes)) wxQRCode = wxQRCodes.replace(domainName1,"");
                            if (new RegExp(domainName2).test(wxQRCodes)) wxQRCode = wxQRCodes.replace(domainName2,"");
                            wxQRCode = PAGE_STATE.whetherVIP ? wxQRCodes : '../../images/teams/creat/QRCode.png';
                            $(".postersQrCode").css("background-image","url("+wxQRCode+")");
                        }else{
                            wxQRCode = "";
                        }
                    }
                } else {
                    $(".visitingCard").hide();
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：加载用户数据
     * @author 覃创斌
     * @date 2020/3/3
    */
    function loadMember() {
        $$.request({
            url: UrlConfig.member_Detailspage,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    getVipData(data.datas);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：添加收藏
     * @author 覃创斌
     * @date 2020/3/2
    */
    function insertCollection(postersId,memberId) {
        $$.request({
            url: UrlConfig.market_addMyPoster,
            pars:{
                posterId:postersId,
                type:"2"
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：取消收藏
     * @author 覃创斌
     * @date 2020/3/2
    */
    function cancelCollection(postersId,memberId) {
        $$.request({
            url: UrlConfig.market_deleteMyPoster,
            pars:{
                id:postersId,
                memberId:memberId,
                type:"2"
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-5-15 10:38:07
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;
            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            //-- 分享
            $$.showShareView('点击右上角,分享海报给好友！');
        }
    }

    /**
     * APP长按保存
     * @Author 吴成林
     * @Date 2020-5-28 14:36:11
     */
    function longPressSave(){
        if (!PAGE_APP) return;
        $(".postersDetailsList .postersContent, .synthesisPosters").on({
            touchstart: function(e){
                timeOutEvent = setTimeout(function(){
                    let src = $(e.currentTarget).attr("src");
                    const params = {
                        imageUrl: src,
                        imageType: PAGE_STATE.switchState?"2":"1",
                    };
                    $$.postAPP(10007, params);
                },500);
            },
            touchmove: function(e){
                clearTimeout(timeOutEvent);
                timeOutEvent = 0;
                e.preventDefault();
            },
            touchend: function(e){
                clearTimeout(timeOutEvent);
                return false;
            }
        });
    }

    //-- 获取当前用户的VIP信息
    function getVipData({imgPath, phone, rname, account, id, mtype}) {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType !== 0;

                    memberImg = $Constant.shareLogo;
                    if(PAGE_STATE.whetherVIP && $$.isValidObj(imgPath)){
                        if (new RegExp(domainName1).test(imgPath)) memberImg = imgPath.replace(domainName1,"");
                        if (new RegExp(domainName2).test(imgPath)) memberImg = imgPath.replace(domainName2,"");
                    }
                    memberPhone = $$.isValidObj(phone) ? phone : account;
                    memberName = $$.isValidObj(rname) ? rname : "你还没有用户名";
                    memberPhone = PAGE_STATE.whetherVIP ? memberName : '020-83274011';
                    memberName = PAGE_STATE.whetherVIP ? memberName : '小白保险';
                    memberId = id;
                    $(".member-name").html(memberName);
                    $(".member-img").html();
                    $(".member-phone").html(memberPhone);
                    $(".userPortraits").css("background-image","url("+memberImg+")");

                    if (PAGE_STATE.switchState) makePoster();
                    if ($$.isValidObj(mtype) && mtype == 4) $('.xiaoBaiAuthentication').show();

                    sharePosters();     // 分享参数配置
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
