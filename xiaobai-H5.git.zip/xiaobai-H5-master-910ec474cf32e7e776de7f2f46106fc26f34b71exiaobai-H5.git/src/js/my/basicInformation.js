let memberId = null;
let educationDataSource = null;

window.onload = function () {
	$$.changeVersion();
	countAction("xb_3022");
	/* 用户信息 */
	$$.request({
		url: UrlConfig.member_Detailspage,
		loading: true,
		sfn: function(data) {
			$$.closeLoading();
			if(data.success) {
				$(".phone").val(data.datas.phone);
				$(".name").val(data.datas.rname);
				$(".idCard").val(data.datas.cardno);
				memberId = data.datas.id;

				//-- 获取用户地址
				detailsPageMemberDetail();

				//-- 显示清除按钮
				showButton(data);

				//-- 清除按钮显示事件
				clearContent();
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});

	loadEducationList();		// 加载学历列表

	//-- 获取用户地址
	function detailsPageMemberDetail(){
		$$.request({
			url: UrlConfig.memberdetail_detailsPageMemberDetail,
			sfn: function(data){
				$$.closeLoading();
				if (data.success) {
					$(".detailedAddress").val(data.datas.address);
				}
			}
		});
	}

	/**----- 性别-男  事件绑定 ----**/
	$(".male").on("click", function() {
		if(!($(this).children().is(':checked'))) {
			$(this).children().attr("checked", "checked");
			$(this).removeClass("male-off").addClass("male-on");
			$(this).next().children().removeAttr("checked");
			$(this).next().removeClass("female-on").addClass("female-off");
		}
	});
	/**----- 性别-女  事件绑定 ----**/
	$(".female").on("click", function() {
		if(!($(this).children().is(':checked'))) {
			$(this).children().attr("checked", "checked");
			$(this).removeClass("female-off").addClass("female-on");
			$(this).prev().children().removeAttr("checked");
			$(this).prev().removeClass("male-on").addClass("male-off");
		}
	});


	/**----- 学历弹窗  事件绑定 ----**/
	$(".education").on("click", function() {
		let value = $(this).val().trim();
		let index = $(this).attr('data-index');
		let id = $(this).attr('data-id');
		let values = value, indexs = index, ids = id;
		if ($$.isValidObj(index)) index = parseInt(index);
		if ($$.isValidObj(index)) id = parseInt(id);

		if(educationDataSource){
			let html = ``;
			for (let i in educationDataSource){
				const {id, name} = educationDataSource[i];
				html += `<div data-index="${i}" data-id="${id}">${name}</div>`;
			}
			$('.promptContent').html(html);

			if (value) {
				$(`.promptContent>div:eq(${index})`).addClass('selection');
			} else{
				$('.promptContent>div:nth-child(1)').addClass('selection');
				values = $('.promptContent>div:nth-child(1)').text();
				indexs = $('.promptContent>div:nth-child(1)').attr('data-index');
				ids = $('.promptContent>div:nth-child(1)').attr('data-id');
			}
			$('.prompt').addClass('show');
		} else{
			loadEducationList();
		}

		//-- 选择学历
		$(".promptContent div").off().click(function () {
			$(this).addClass('selection').siblings().removeClass('selection');
			values = $(this).text();
			indexs = $(this).attr('data-index');
			ids = $(this).attr('data-id');
		});

		//-- 学历弹窗 确认
		$(".promptConfirm").off().click(function () {
			$(".prompt").removeClass('show');
			$(".education").val(values).attr({'data-index' : indexs, "data-id" : ids});
		});

		//-- 学历弹窗 点击背景/取消 关闭
		$(".prompt .bg, .promptCancel").off().click(function () {
			$(".prompt").removeClass('show');
			$(".education").val(value).attr({'data-index' : index, "data-id" : id});
		});
	});

	/**----- 市区定位  事件绑定 ----**/
	$(".downtown").on("click", function() {
		/* 需要用地图选点，市区只获取省、市、区，其他地址信息保存到详细地址栏 */
	    let point;
	    // 获取微信地理位置
	    weChatJSTool.getLocation(function (res) {
	    	let longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
	        let latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
	        console.log(longitude);
			console.log(latitude);

			//创建点坐标
			point = new BMap.Point(longitude, latitude);
			//根据微信地理位置转换百度详细地址
			locations(point,"");
	    });

	});

	/**----- 协议 事件绑定 ----**/
	$(".protocol span").on("click", function() {
	    //获取执业认证协议PDF信息
        $$.request({
            url: UrlConfig.management_reporttemp_getTemp,
            method: "POST",
            pars: {
                token: 'PROFESSIONAL_CERTIFICATION',
                type: 2,
            },
            requestBody:true,
            sfn: function (data) {
                if(data.success){
                    console.log(data);
                    const filePath = data.datas.filePath;
                    location.href = 'http://imagestest.xiaobaibao.com/pdfnew/pdf.html?path=' + filePath;
                } else {
                    $$.layerToast(data.msg);
                }
            }
        });
	});

	/**----- 单选框选中  事件绑定 ----**/
	$(".unselected-status,.consent>span:first").off().on("click", function() {
		const readStatus = $(".unselected-status"),
			hasActive = readStatus.hasClass("readed");

		readStatus.toggleClass("readed");
	});
	/**----- 开始答题  事件绑定 ----**/
	$(".answering").on("click", function() {
		$$.loading();
		/* 真实姓名  */
		const name = $(".name").val();
		/* 性别 */
		let sex = $('input:radio[name="sex"]:checked').val();
		console.log(sex+"-checked");
		/* 身份证号码 */
		const idCard = $(".idCard").val();
		/* 获取身份证第17位数字，识别用户性别  */
		const idCardNumber = idCard[16];
		/* 手机号码 */
		const phone = $(".phone").val();
		/* 学历 */
		const education = $(".education").attr("data-id");
		/* 详细地址 */
		const detailedAddress = $(".detailedAddress").val();
		/* 是否勾选 */
		const hasActive = $(".unselected-status").hasClass("readed");

		datum = {
            name,
            idCard,
            phone
        };
        let checkMsgArr = [];
		for(const key in datum){
            let type;
            let msg;
            switch (key) {
                case 'name':
                    type = "中文姓名";
                    msg = "姓名格式不正确~";
                    break;
                case 'idCard':
                    type = "身份证号码";
                    msg = "身份证号码格式有误~";
                    break;
                case 'phone':
                    type = "手机号码";
                    msg = "手机号码格式不正确~";
                    break;
                default:
                    break;
            }
            const checkMsg = new $Valid.validComment({
                "type": type,
                "isEmpty": false,
                "value": datum[key],
                "errorMsg": msg
            }).check();
            checkMsgArr.push(checkMsg);
		}

		if(checkMsgArr[0] != true){
            $$.throwTips(checkMsgArr[0]);
        } else if(checkMsgArr[1] != true){
            $$.throwTips(checkMsgArr[1]);
        } else if(checkMsgArr[2] != true){
            $$.throwTips(checkMsgArr[2]);
        } else if(idCardNumber % 2 != 0 && sex === "2"){
        	if(!($(".male").children().is(':checked'))) {
				$(".male").children().attr("checked", "checked");
				$(".male").removeClass("male-off").addClass("male-on");
				$(".male").next().children().removeAttr("checked");
				$(".male").next().removeClass("female-on").addClass("female-off");
			}
        	$$.layerToast("身份证性别为男生");
		} else if(idCardNumber % 2 === 0 && sex === "1"){
			if(!($(".female").children().is(':checked'))) {
				$(".female").children().attr("checked", "checked");
				$(".female").removeClass("female-off").addClass("female-on");
				$(".female").prev().children().removeAttr("checked");
				$(".female").prev().removeClass("male-on").addClass("male-off");
			}
			$$.layerToast("身份证性别为女生");
		} else if(!$$.isValidObj(education)) {
			$$.layerToast("学历不能为空");
			$(".education").focus();
		} else if(!$$.isValidObj(detailedAddress)) {
			$$.layerToast("详细地址不能为空");
			$(".detailedAddress").focus();
		} else if(!hasActive) {
			$$.layerToast("请勾选我已阅读并同意");
		} else {
            //更新会员基本信息
			$$.request({
				url: UrlConfig.member_member_modifierRealName,
				pars: {
					"rname": name,
					"sex": sex,
					"cardno": idCard,
					"phone": phone
				},
                sfn: function(data) {
                    if(data.success) {
                        //更新会员详细信息
                        $$.request({
                            url: UrlConfig.member_memberdetail_modifierDetailedAddress,
                            pars: {
                                "educationId": education,
                                "adderss": detailedAddress
                            },
                            sfn: function(data) {
                                if(data.success) {
                                    countAction("xb_4003");
                                    /* 跳转签署页面 */
                                    getFadadaInfo(memberId);
                                    // $$.push("my/qualificationTest");
                                }
                            },
                            ffn: function(data) {
                                $$.errorHandler();
                            }
                        });
                    } else {
                        $$.errorHandler(data.msg);
                    }
                },
                ffn: function(data) {
                    $$.errorHandler(data.msg);
                }
			});
	    }
	});

	//-- 加载学历列表
	function loadEducationList() {
		/* 学历列表 */
		$$.request({
			url: UrlConfig.sysbase_gvlist_restype,
			method: "GET",
			sfn: function(data) {
				if(data.success) {
					educationDataSource = data.datas;
				}
			}
		});
	}

	/* 获取GPS定位wgs84（经度,纬度）转换百度 坐标BD09 加载地图*/
    function locations(point,search){
    	// 创建地图实例
		let map = new BMap.Map("map");
		//地图初始化
		map.centerAndZoom(point, 15);

        //坐标转换完之后的回调函数
        translateCallback = function (data){
	        if(data.status === 0) {
	        	//添加三角坐标
		        /*let marker = new BMap.Marker(data.points[0]);
		        map.addOverlay(marker);
		       	map.setCenter(data.points[0]);*/

		        //开启加载层
				$$.loading();
		        //获取坐标位置的省市并返回
		        let geoc = new BMap.Geocoder();
		        geoc.getLocation(data.points[0], function(rs){
			        let addComp = rs.addressComponents;
			        let detailedAddress = addComp.province + addComp.city + addComp.district + addComp.street + addComp.streetNumber;

			        $('.detailedAddress').val(detailedAddress);
			        $$.closeLoading();
				});
	        }
	    };
	    //GPS坐标wgs84 转 百度 坐标BD09
	    setTimeout(function(){
	        let convertor = new BMap.Convertor();
	        let pointArr = [];
	        pointArr.push(point);
	        convertor.translate(pointArr, 1, 5, translateCallback);

	    }, 1000);
    }
};
//法大大注册账号
function fadada_regAccount(memberId) {
	$$.request({
		url: UrlConfig.member_fadada_regAccount,
		pars: {
			memberId: memberId
		},
		requestBody:true,
		sfn: function(data) {
			if(data.success) {
				let customer_id = data.customer_id;
				fadada_getAuthUrl(customer_id,memberId);
			} else {
				$$.alert(data.msg);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
//法大大获取实名认证地址
function fadada_getAuthUrl(customer_id,memberId) {
	$$.request({
		url: UrlConfig.member_fadada_getAuthUrl,
		pars: {
			customer_id: customer_id,
			notify_url: UrlConfig.member_fadada_authNotify,//法大大实名认证异步回调
			return_url: $$.getBasePath() + "/src/pages/my/authResult.html"
		},
		requestBody:true,
		sfn: function(data) {
			if(data.success) {
			    if ($$.isValidObj(data.code) && data.code === 1601) {
                    fadada_regAccount(memberId);//法大大注册账号
                } else {
                    window.location.href = data.url;
                }
			} else {
				$$.alert(data.msg);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}

//-- 获取法大大信息
function getFadadaInfo(memberId) {
    $$.request({
        url: UrlConfig.member_fadada_getFadadaInfo,
        pars: {
            memberId: memberId
        },
        requestBody:true,
        sfn: function(data) {
            $$.closeLoading();
            if(data.success) {
                let customer_id = data.customer_id;
                if ($$.isValidObj(customer_id)) {
					fadada_getAuthUrl(customer_id,memberId);//法大大获取实名认证地址
                } else {
					fadada_regAccount(memberId);//法大大注册账号
				}
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function(data) {
            $$.errorHandler();
        }
    });
}
function showButton(data){
	if (data.datas.rname){
		$(".clearName").show();

		$(".clearName").on('click', function(){
			$(".name").val("");
			$(".clearName").hide();
			$(".name").focus();
		});
	}
	if (data.datas.cardno) {
		$(".clearIdCard").show();

		$(".clearIdCard").on('click', function(){
			$(".idCard").val("");
			$(".clearIdCard").hide();
			$(".idCard").focus();
		});
	}
	if (data.datas.phone) {
		$(".clearPhone").show();

		$(".clearPhone").on('click', function(){
			$(".phone").val("");
			$(".clearPhone").hide();
			$(".phone").focus();
		});
	}
	if (data.datas.address) {
		$(".clearDetailedAddress").show();

		$(".clearDetailedAddress").on('click', function(){
			$(".detailedAddress").val("");
			$(".clearDetailedAddress").hide();
			$(".detailedAddress").focus();
		});
	}

}

function clearContent(){
	$(".name").on('input', function(){
		if ($(this).val().trim() != ""){
			$(".clearName").show();

			$(".clearName").on('click', function(){
				$(".name").val("");
				$(".clearName").hide();
				$(".name").focus();
			});
		} else {
			$(".clearName").hide();
		}
	})

	$(".idCard").on('input', function(){
		if ($(this).val().trim() != ""){
			$(".clearIdCard").show();

			$(".clearIdCard").on('click', function(){
				$(".idCard").val("");
				$(".clearIdCard").hide();
				$(".idCard").focus();
			});
		} else {
			$(".clearIdCard").hide();
		}
	})

	$(".phone").on('input', function(){
		if ($(this).val().trim() != ""){
			$(".clearPhone").show();

			$(".clearPhone").on('click', function(){
				$(".phone").val("");
				$(".clearPhone").hide();
				$(".phone").focus();
			});
		} else {
			$(".clearPhone").hide();
		}
	})

	$(".detailedAddress").on('input', function(){
		if ($(this).val().trim() != ""){
			$(".clearDetailedAddress").show();

			$(".clearDetailedAddress").on('click', function(){
				$(".detailedAddress").val("");
				$(".clearDetailedAddress").hide();
				$(".detailedAddress").focus();
			});
		} else {
			$(".clearDetailedAddress").hide();
		}
	})
}
