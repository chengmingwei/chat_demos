window.onload = function () {
    $$.changeVersion();
    let redirectUrl = $$.getUrlParam("redirectUrl");
    window.location.href = redirectUrl;
};
