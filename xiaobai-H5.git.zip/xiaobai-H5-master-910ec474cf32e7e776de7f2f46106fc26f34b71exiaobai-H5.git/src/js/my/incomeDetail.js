//获取当前年份
let myDate = new Date();
let year = myDate.getFullYear(); //获取当前年
let mon = myDate.getMonth() + 1; //获取当前月
let yearsMonth = year + "-" + mon;	//年-月
const pars = {
    incomeContent:{},
    recordContent:{}
};
window.onload = function () {
    $$.changeVersion();
    $(".nav ul li").click(function () {
        $(".nav ul li").removeClass("active");
        let className = $(this).attr('class');
        $(this).addClass("active");
        if (className === 'income') {
            $(".incomeContent").css('display','block');
            $(".recordContent").css('display','none');
            countAction("xb_3023");
        } else {
            $(".recordContent").css('display','block');
            $(".incomeContent").css('display','none');
            countAction("xb_3024");
        }
    });
    getMember();
    countAction("xb_2065");
    countAction("xb_3023");
};

function createIncomeContent(list) {
    let html = [];
    if(list && typeof(list) != 'undefined') {
        for (let i = 0; i < list.length; i++) {
            const xpro = list[i];
            const score = xpro.score;
            const createTime = xpro.createTime;
            const type = xpro.type;
            const xstatus = xpro.xstatus;
            let typeText = '';
            let title = '';
            if (xpro.ipname) {
                title = xpro.ipname;
            }
            switch (type) {
                case 1:
                    typeText = '推广奖励';
                    break;
                case 2:
                    typeText = '管理津贴';
                    title = title + '管理津贴';
                    break;
                case 3:
                    typeText = '育成津贴';
                    title = title + '育成津贴';
                    break;
            }
            let xstatusText = '';
            switch (xstatus) {
                case 0:
                    xstatusText = '结算中';
                    break;
                case 1:
                    xstatusText = '已结算';
                    break;
                case 3:
                    xstatusText = '已结算';
                    break;
                case 4:
                    xstatusText = '扣回';
                    break;
            }
            html[i] = [
                '<li>',
                    '<p class="top">',
                        '<span class="title">' + typeText + '</span>',
                        '<span class="status">' + xstatusText + '</span>',
                    '</p>',
                    '<div class="bottom">',
                        '<div class="title">',
                            '<span>' + title + '</span>',
                            '<span class="price">' + score + '元</span>',
                        '</div>',
                        '<p class="date">' + createTime + '</p>',
                    '</div>',
                '</li>'].join('');
        }
    }
    $('.incomeContent .list').html(html.join(''));
}

function getIncomeContent() {
    $$.request({
        url: UrlConfig.member_userscoreinfo_getIncomeContent,
        loading: true,
        pars:pars.incomeContent,
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                $('.incomeContent .selectWrapper .money > span').html(data.scoreTotal);
                createIncomeContent(data.list);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function createRecordContent(list) {

    let html = [];
    if(list && typeof(list) != 'undefined') {
        for (let i = 0; i < list.length; i++) {
            const xpro = list[i];
            const zamount = xpro.zamount;
            const createTime = xpro.createTime;
            const bankName = xpro.bankName;
            const bankNum = xpro.bankNum;
            html[i] = [
                '<li>',
                    '<p class="top">',
                        '<span class="title">提现</span>',
                        '<span class="status">' + zamount + '元</span>',
                    '</p>',
                    '<div class="bottom">',
                        '<div class="title">',
                            '<span>' + bankName + '</span>',
                            '<span class="bankID">' + bankNum + '</span>',
                        '</div>',
                        '<p class="date">' + createTime + '</p>',
                    '</div>',
                '</li>'].join('');
        }
    }
    $('.recordContent .list').html(html.join(''));
}

function getRecordContent() {
    $$.request({
        url: UrlConfig.member_withdraw_getRecordContent,
        loading: true,
        pars:pars.recordContent,
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                $('.recordContent .totalMoney .right > span').html(data.withdrawTotal);
                createRecordContent(data.list);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function getMember() {
    $$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let createTime = data.datas.createTime;
                setIncomeMonth(createTime);
                getIncomeContent();//我的收入
                getRecordContent();//提现记录
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function setIncomeMonth(createTime) {
    //分类数据
    const type = [
        {label:"全部",value:0},
        {label:"推广奖励",value:1},
        {label:"管理津贴",value:2},
        {label:"育成津贴",value:3}];
    //我的收入 分类 点击绑定事件
    $('.incomeContent .type').click(function () {
        weui.picker(type, {
            defaultValue: [0,"全部"],
            onConfirm: function (result) {
                $('.incomeContent .type span').text(result[0].label);

                console.log('分类=》' + result);
                pars.incomeContent.type = result[0].value;
                getIncomeContent();
            },
            title: '分类'
        });
    });

    //我的收入 月份 点击绑定事件
    $('.incomeContent .month').click(function () {
        let start, end;
        createTime.length == 7 ? start = createTime+"-01":createTime;
        createTime.length > 10 ? start = createTime.substring(0, 10):createTime;
        yearsMonth.length <= 7 ? end = yearsMonth+"-01":yearsMonth;
        weui.datePicker({
            id: 1,
            depth : 2,
            start: start,
            end : end,
            defaultValue : yearsMonth,
            onConfirm: function(result){
                let month = String(result[1].value);
                if(month.length === 1){
                    month = month.padStart(2,"0");	//字符串补全
                }
                let time = result[0] +"-"+ month;
                $('.incomeContent .month span').html(time);
                pars.incomeContent.month = time;
                getIncomeContent();
            }
        });
    });

    //状态数据
    const xstatus = [
        {label:"全部",value:0},
        {label:"结算中",value:1},
        {label:"已结算",value:2},
        {label:"扣回",value:3}];
    //我的收入 状态 点击绑定事件
    $('.incomeContent .xstatus').click(function () {
        weui.picker(xstatus, {
            defaultValue: [0,"全部"],
            onConfirm: function (result) {
                $('.incomeContent .xstatus span').text(result[0].label);

                console.log('状态=》' + result);
                pars.incomeContent.xstatus = result[0].value;
                getIncomeContent();
            },
            title: '状态'
        });
    });

    //提现记录 月份 点击绑定事件
    $('.recordContent .left').click(function () {
        let start, end;
        createTime.length == 7 ? start = createTime+"-01":createTime;
        createTime.length > 10 ? start = createTime.substring(0, 10):createTime;
        yearsMonth.length <= 7 ? end = yearsMonth+"-01":yearsMonth;
        weui.datePicker({
            id: 2,
            start: start,
            depth : 2,
            end : end,
            defaultValue : yearsMonth,
            onConfirm: function(result){
                let month = String(result[1].value);
                if(month.length === 1){
                    month = month.padStart(2,"0");	//字符串补全
                }
                let time = result[0] +"-"+ month;
                $('.recordContent .left span').html(time);
                pars.recordContent.month = time;
                getRecordContent();
            }
        });
    });

}


