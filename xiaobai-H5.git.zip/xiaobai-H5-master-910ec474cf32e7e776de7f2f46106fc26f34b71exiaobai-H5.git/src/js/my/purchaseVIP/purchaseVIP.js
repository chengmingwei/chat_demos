/**
 * 订单详情 JS
 * @Author 肖家添
 * @Date 2019/10/6 16:13
 */

ShawHandler.loaderRes({
    scripts: [
        //-- Order helper
        `js/product/orderHelper.js`,
    ]
});
/**
 * 购买VIP（会员VIP和团队VIP） JS
 * @Author 吴成林
 * @Date
 */
window.onload = function() {
    countAction('xb_6015');
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    function loop(orderToken, loopIndex = 0) {
        loopIndex++;
        $$.request({
            url: UrlConfig.member_vipPayRecords_wx_getPayStatus,
            pars: { vipPayRecordId:orderToken },
            sfn: function(data){
                if(data.success){
                    const payStatus = data.payStatus;
                    if(payStatus === 1){
                        $$.closeLoading();
                        let msg = '恭喜你支付成功！';
                        const expireTime = data.expireTime;
                        if (expireTime) {
                            msg += '<br />有效期至' + expireTime;
                        }
                        $$.alert(msg);
                    }else if(payStatus === 0){
                        //-- 待支付状态
                        if(loopIndex >= 10){
                            $$.closeLoading();
                            $$.alert("似乎没支付成功！");
                        }else{
                            setTimeout(function(){
                                loop(orderToken, loopIndex);
                            }, 1000);
                        }
                    }else {
                        $$.closeLoading();
                        $$.alert("支付失败！");
                    }
                }else{
                    $$.closeLoading();
                }
            }
        });
    }

    function verifyPaymentSuccess() {
        const paymentCbk = $$.getUrlParam("paymentCbk");
        const orderToken = $$.getUrlParam("orderToken");
        if(paymentCbk){
            $$.loading("支付处理中");
            //-- 支付完成
            $$.pushHistory();
            window.addEventListener("popstate", function() {
                const backUrl = localStorage.getItem('backUrl');
                if(!$$.isValidObj(backUrl) || backUrl.indexOf(".html") === -1){
                    return;
                }
                window.location.href = backUrl;
                // localStorage.removeItem('backUrl');
            }, false);
            loop(orderToken);
        } else {
            localStorage.setItem('backUrl',document.referrer);
        }
        if($$.getUrlParam("appPayment")){
            this.openPaymentModelForApp();
        }
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();

        verifyPaymentSuccess();

        sharePurchaseVIP();
    }

    /**
     * 支付处理
     */
    function paymentHandler(vipPayRecordId) {
        localStorage.setItem("PAYMENT_TOKEN_VIP", vipPayRecordId);
        const returnUrl = encodeURIComponent('my/purchaseVIP/purchaseVIP');
        const fileRelativePath = "product/payment",
            params = {
                paymentType: 'weChatPay',
                doComplexFormType: OrderHelper.payDoComplexFormType.FORM_TYPE_10004,
                otherParams: JSON.stringify({
                    orderToken:vipPayRecordId,
                    returnUrl:returnUrl,
                    successPayUrl:returnUrl
                })
        };
        $$.push(fileRelativePath, params);
    }

    function gotoBuyVip(vipPriceId) {
        $$.request({
            url: UrlConfig.member_memberVip_wx_buyVip,
            pars:{
                vipPriceId:vipPriceId
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    const vipPayRecordId = data.vipPayRecordId;
                    if (vipPayRecordId) {
                        paymentHandler(vipPayRecordId);
                    } else {
                        let msg = '恭喜你成功领取';
                        const expireTime = data.expireTime;
                        if (expireTime) {
                            msg += '<br />有效期至' + expireTime;
                        }
                        $$.alert(msg);
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    function getVipPrice(vipType = 1) {
        $$.request({
            url: UrlConfig.member_vipPrice_wx_list,
            pars:{
                vipType:vipType
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    const freeEnd = data.freeEnd;
                    let listZone = 'membershipLimitedGratis';
                    let buyBtnZone = 'membershipGratisBuy';
                    if (vipType === 2) {
                        listZone = 'teamsLimitedGratis';
                        buyBtnZone = 'teamsGratisBuy';
                    }
                    if (freeEnd) {
                        listZone = 'payMembership';
                        buyBtnZone = 'membershipBuy';
                        if (vipType === 2) {
                            listZone = 'payTeams';
                            buyBtnZone = 'teamsBuy';
                        }
                        $('.membershipLimitedGratis').hide();
                        $('.payMembership').show();
                        $('.teamsLimitedGratis').hide();
                        $('.payTeams').show();
                    }
                    const vipPriceList = data.list;
                    createList(vipPriceList,freeEnd,listZone);
                    //默认
                    const def = $("." + listZone + " div.payUnit>div:first-child");
                    def.addClass("choosePrice");
                    if (freeEnd) {
                        let buyingPrice = '￥' + def.find('.buyingPrice').html();
                        if (vipType === 2) {
                            buyingPrice = '';
                        }
                        $('.' + buyBtnZone + ' > span').html(buyingPrice);
                    }

                    const payUnit_div = $("." + listZone + " div.payUnit>div");
                    const visualize = $('.visualize.freeEnd');

                    payUnit_div.parent().removeClass('flex-center').addClass('space-between');
                    payUnit_div.removeAttr('style');
                    visualize.hide();
                    if (vipPriceList && typeof(vipPriceList) != 'undefined' && vipPriceList.length === 1) {
                        payUnit_div.parent().removeClass('space-between').addClass('flex-center');
                        payUnit_div.css('flex', 'none');
                        visualize.show();
                    }

                    //-- 选择支付会员 - 月/年
                    payUnit_div.off().on("click", function() {
                        $(this).addClass("choosePrice").siblings().removeClass("choosePrice");
                        if (freeEnd) {
                            let buyingPrice = '￥' + $(this).find("span.buyingPrice").text();
                            if (vipType === 2) {
                                buyingPrice = '';
                            }
                            $("." + buyBtnZone + " > span").text(buyingPrice);
                        }
                    });
                    //-- 限时免费/付费 - 会员/团队功能包领取
                    $("." + buyBtnZone).off().on("click", function() {
                        let check = $(this).siblings(".consent").children("input[name='check']").is(":checked");        // 协议勾选
                        let choosePrice = $(this).siblings(".payUnit").children("div.choosePrice").attr("data-value");  // 1：月卡， 2：年卡
                        let price = $(this).children("span").text();                                                    // 价格拿到的是字符串
                        if (check) {
                            gotoBuyVip(choosePrice);
                        } else {
                            $$.layerToast('你没同意协议内容！');
                        }
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        let themeHeight = $(".theme").height();
        $(".content").css("top", themeHeight*0.763);
        getVipPrice();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 标题切换
        $(".unitTitle>div").on("click", function() {
            $(this).addClass("choose").siblings().removeClass("choose");
            let href = $(this).attr("href");
            $(href).show().siblings().hide();
            const vipType = parseInt($(this).attr('vipType'));
            getVipPrice(vipType);
            let functional_src = 'purchaseVIP-4.png';
            if (vipType === 2) {
                functional_src = 'purchaseVIP-5.png';
            }
            $('.functional').attr('src', '../../../images/my/purchaseVIP/' + functional_src);
        });
        //-- 勾选
        $(".consent input").on("click", function() {
            $(this).siblings("input").click();
        });

        /**----- 协议 事件绑定 ----**/
        /*$(".protocol").on("click", function(e) {
            e.stopPropagation();
            //-- 固定路径跳转
            const filePath = "https://pic.xiaobaibao.com/system/reportTemp/2020/3/02dda9fb53694c479aff366ad1b7191e.pdf";
            location.href = filePath;
        });*/
        $(".agreement").on("click", function(){
            const pafUrl = "https://pic.xiaobaibao.com/system/reportTemp/2020/3/02dda9fb53694c479aff366ad1b7191e.pdf";
            if(PAGE_APP){
                InsuranceAPP.postMessage(JSON.stringify({
                    formType: 10004,
                    datas: {
                        url: pafUrl
                    }
                }));
            }else{
                window.open(pafUrl);
            }
        });
        (function(){
            const vipType = $$.getUrlParam("viptype");
            if(vipType){
                $(`.unitTitle>div[viptype=${vipType}]`).click();
            }
        })();
    }

    function createList(list,freeEnd,zone) {
        if(!list || typeof(list) == 'undefined') {
            return;
        }
        let htmlArr = [];
        for(let i = 0;i < list.length;i++){
            let xpro = list[i];
            if (freeEnd) {
                htmlArr[i] = getHtmlByListFreeEnd(xpro);
            } else {
                htmlArr[i] = getHtmlByList(xpro);
            }
        }
        let htmlCodes = htmlArr.join("");
        $('.' + zone + ' .payUnit').html(htmlCodes);
    }

    function getHtmlByList(xpro) {
        const longTime = xpro.longTime;
        const longTimeType = xpro.longTimeType;
        let longTimeText = '';
        switch (longTimeType) {
            case 2:
                longTimeText = '个月';
                break;
            case 3:
                longTimeText = '年';
                break;
            default:
                longTimeText = '天';
        }
        longTimeText = longTime + longTimeText;
        if (longTime === 1) {
            if (longTimeType === 2) {//月
                longTimeText = '月';
            } else if (longTimeType === 3) {//年
                longTimeText = '年';
            }
        }
        const html = [
            '<div data-value="' + xpro.id + '">',
                '<div>',
                    '<div>' + longTimeText + '卡</div>',
                '</div>',
            '</div>'];
        return html.join('');
    }

    function getHtmlByListFreeEnd(xpro) {
        const longTime = xpro.longTime;
        const longTimeType = xpro.longTimeType;
        const oriPrice = xpro.oriPrice;
        const nowPrice = xpro.nowPrice;
        let longTimeText = '';
        switch (longTimeType) {
            case 2:
                longTimeText = '个月';
                break;
            case 3:
                longTimeText = '年';
                break;
            default:
                longTimeText = '天';
        }
        longTimeText = longTime + longTimeText;
        if (longTime === 1) {
            if (longTimeType === 2) {//月
                longTimeText = '月';
            } else if (longTimeType === 3) {//年
                longTimeText = '年';
            }
        }
        const html = [
            '<div data-value="' + xpro.id + '">',
                '<div>',
                    '<div>' + longTimeText + '卡</div>',
                    '<div>￥<span class="buyingPrice">' + nowPrice + '</span></div>',
                    '<div style="text-decoration: line-through;">' + oriPrice + '元/' + longTimeText + '</div>',
                '</div>',
            '</div>'];
        return html.join('');
    }

    function sharePurchaseVIP() {
        if (!$WeChat.isWx()) {
            return;
        }
        const _lineLink = $$.getFullHost() + "/src/pages/my/purchaseVIP/purchaseVIP.html";
        weChatJSTool.share({
            _imgUrl:  $Constant.shareLogo,
            _lineLink:  _lineLink,
            _shareTitle: '增值功能包限时免费领取，速来！！',
            _descContent: '价值199元会员功能包/5000元团长功能包，尊享更多超值功能，体验自由职业生态！',
            _sfn: function () {
                $$.layerToast("分享成功~");
            }
        });
    }
};

/**
 * 打开支付完窗口 APP专用
 * @Author 肖家添
 * @Date 2020/4/21 16:55
 */
function openPaymentModelForApp(){
    $$.confirm({
        title: "请确认微信支付是否已经完成",
        onOkLabel: "已支付",
        onCancelLabel: "未支付",
        onOk: function(){
            const vipPayRecordId = localStorage.getItem("PAYMENT_TOKEN_VIP");
            location.replace(`${location.origin}/${location.pathname}?orderToken=${vipPayRecordId}&paymentCbk=true`);
        }
    });
}
