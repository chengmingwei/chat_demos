let ids = new Array();
let timeOutEvent = 0;
let memberId;
let shareMemberId;
const PAGE_STATE = {
    whetherVIP: false,                  // 是否是VIP
};
window.onload = function() {
    countAction('xb_6014');
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        memberId = $$.getUrlParam('memberId');
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        loadData();
        loadList();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){

        //文件上传
        $('.gotoUpload').on("click",function () {
            if (!PAGE_STATE.whetherVIP) {
                $$.confirm({
                    title: "使用此功能需先开通团长功能包，点击确认即前往开通！",
                    onOkLabel: "确认",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
                return;
            }
            $(this).find('input')[0].click();
        });
        $('.uploadCloud').on("click",function () {
            $(this).prev().find('input')[0].click();
        });
        //文件检测
        $('.gotoUpload > input').on('change',function () {
            const _this = $(this);
            let file=_this[0].files[0];
            //文件类型
            let fileType=file.name;
            let type= fileType.substring(fileType.lastIndexOf(".") + 1, fileType .length);
            //文件大小
            let fileSize=(file.size/ 1024).toFixed(2);
            //.xls,.xlsx,.doc,.docx,.pdf
            if(type !== "xls"&&type!=="xlsx"&&type!=="doc"&&type!=="docx"&&type!=="pdf"){
                $$.layerToast('请上传正确的文档格式！');
                return false;
            }
            if(fileSize>10240){//定义不能超过10MB
                $$.layerToast('请上传不超过10M的文档');
                return false;
            }
            let formData = new window.FormData();
            formData.append('file', file);
            console.log(file);
            $$.confirm({
                title: "确定是否要上传"+file.name+"文件吗？",
                onOkLabel: "确定",
                onCancelLabel: "取消",
                onOk: function(){
                    $$.request({
                        url: UrlConfig.upload_userCloudRecord,
                        loading: true,
                        pars: formData,
                        requestBody: true,
                        sfn: function(data) {
                            $$.closeLoading();
                            if(data.success) {
                                $$.layerToast("文件上传成功！");
                                loadList();
                            } else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function(data) {
                            $$.errorHandler();
                        }
                    });
                }
            });
        });
        //取消选中
        $(".cancel").click(function () {
            $(".shareImg").css("margin-left","21px");
            $(".clickEvent").hide();
            $(".selected").hide();
            $(".selected>img").attr("src","../../../images/my/cloudDisk/noSelected.png");
            $(".selected").attr("data-selected","false");
            ids = new Array();
        });
        //点击确定删除
        $(".confirm").click(function () {
            if (ids.length === 0){
                $$.alert("请选择你要删除的文件");
                return;
            }
            $$.confirm({
                title: "确定要删除吗？",
                onOkLabel: "确定",
                onCancelLabel: "取消",
                onOk: function(){
                    $$.request({
                        url: UrlConfig.upload_deleteCloudFileById,
                        pars:{
                            ids:ids.join(",")
                        },
                        requestBody:true,
                        loading: true,
                        sfn: function (data) {
                            $$.closeLoading();
                            if (data.success) {
                                loadList();
                            } else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });
                }
            });
        });
        $(".search").change(function () {
            let docName = $(this).val();
            $$.request({
                url: UrlConfig.upload_getMyCloudDiskList,
                pars:{
                    docName: docName,
                    memberId:memberId
                },
                requestBody:true,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        unitList(data.datas);
                        if (data.datas.length === 0){
                            $(".noData").show();
                            $$.showNoResultView({
                                parentJqSelector: ".noData" ,
                                msg: "暂无内容",
                            });
                        }else {
                            $(".noData").hide();
                        }
                        $(".clickEvent").hide();
                        $(".selected").hide();
                        longPress();
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        });
        $(".middle-left>div").click(function () {
           $(this).addClass("choose").siblings().removeClass("choose");
           let text =  $(this).html();
            if (text === "我的分享"){
                loadShareList();
            }else {
                loadList();
            }
        });
        $('.shareMyCloud').on('click',function () {
            $$.showShareView('点击右上角,分享云空间给好友！');
            shareMyCloud();
        });
    }

    //长按事件
    function longPress() {
        // 查找指定的元素在数组中的位置
        Array.prototype.indexOf = function (val) {
            for (let i = 0; i < this.length; i++) {
                if (this[i] === val) {
                    return i;
                }
            }
            return -1;
        };
        // 通过索引删除数组元素
        Array.prototype.remove = function (val) {
            const index = this.indexOf(val);
            if (index > -1) {
                this.splice(index, 1);
            }
        };

        if (!$$.isValidObj(memberId)) {
            //选中和取消选中
            $(".selected").click(function () {
                let selectedState = $(this).attr("data-selected");
                if (selectedState === "false"){
                    ids.push($(this).parent().attr("data-id"));
                    console.log(ids);
                    $(this).attr("data-selected", "true");
                    $(this).children("img").attr("src", "../../../images/my/cloudDisk/selected.png");
                } else {
                    let id =  $(this).parent().attr("data-id");
                    ids.remove(id);
                    $(this).attr("data-selected", "false");
                    $(this).children("img").attr("src", "../../../images/my/cloudDisk/noSelected.png");
                    console.log(ids);
                }
            });

            // 分享
            $(".shareImg").on("click",function () {
                $$.showShareView('点击右上角,分享文档给好友！');
                const id = $(this).prev().attr("data-id");
                let docName = $(this).prev().find('.text-overflow').html();
                docName = docName.substring(0,docName.lastIndexOf('.'));
                share(id,docName);
            });
        } else {
            WE_CHAT_MENU_FLAG = false;
            weChatMenuHandler();
        }

        $(".unitContent").on({
            touchstart: function(e) {
                // 长按事件触发
                timeOutEvent = setTimeout(function () {
                    timeOutEvent = 0;
                    if (!$$.isValidObj(memberId)) {
                        $(".clickEvent").show();
                        $(".selected").show();
                        $(".shareImg").css("margin-left", "0px");
                    }
                }, 500);
            },
            touchmove: function() {
                clearTimeout(timeOutEvent);
                timeOutEvent = 0;
            },
            touchend: function(e) {

                clearTimeout(timeOutEvent);
                if (timeOutEvent !== 0) {
                    $$.push("my/cloudDisk/imm",{
                        id:$(e.currentTarget).attr("data-id")
                    });
                }
                return false;
            }
        });

    }
    //加载头部
    function loadData() {
        $$.request({
            url: UrlConfig.upload_getMyCloudSize,
            pars:{memberId:memberId},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $(".name").html(data.datas.rname);
                    $(".bar>div").css("width",data.datas.surplus < 1 ? "1%" : data.datas.surplus +"%");
                    $(".headImg").attr("src",data.datas.imgPath !== undefined ? data.datas.imgPath : $Constant.shareLogo);
                   let total = data.datas.total;
                    $(".used").html(data.datas.cloudSize);
                    $(".surplus").html(data.datas.usableGB);
                    shareMemberId = data.datas.memberId;
                    shareMyCloud();
                    getVipData();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //加载云列表
    function loadList() {
        $$.request({
            url: UrlConfig.upload_getMyCloudDiskList,
            pars:{memberId:memberId},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    unitList(data.datas);
                    if ($$.isValidObj(memberId)) {
                        $('.middle-left .myShare').hide();
                        $('.gotoUpload').hide();
                        $(".uploadCloud").hide();
                        $(".shareMyCloud").hide();
                        if (data.datas.length === 0){
                            $('.middle-right').hide();
                            $(".noData").show();
                            $$.showNoResultView({
                                parentJqSelector: ".noData" ,
                                msg: "暂无内容",
                            });
                        }
                    } else {
                        if (data.datas.length === 0){
                            $(".gotoUpload").hide();
                            $(".uploadCloud").show();
                        }else {
                            $(".uploadCloud").hide();
                            $(".gotoUpload").show();
                        }
                    }
                    longPress();
                    $(".clickEvent").hide();
                    $(".selected").hide();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //加载分享列表
    function loadShareList() {
        $$.request({
            url: UrlConfig.upload_getMyShareRecordList,
            pars:{},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (data.datas.length > 0){
                        $(".uploadCloud").hide();
                    }
                    let resultHtml = "";
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "<li class=\"unit\" data-id='"+data.datas[i].id+"'>";
                        resultHtml += "	<div class=\"selected\" data-selected=\"false\"><img src=\"../../../images/my/cloudDisk/noSelected.png\"></div>";

                        let fileType = data.datas[i].fileExtension;
                        if (fileType === "pdf" ){
                            resultHtml += "	<div class=\"fileImg\"><img src=\"../../../images/my/cloudDisk/PDF.png\" class=\"unitImg1\"></div>";
                        }else if (fileType === "doc"|| fileType === "docx"){
                            resultHtml += "	<div class=\"fileImg\"><img src=\"../../../images/my/cloudDisk/wor.png\" class=\"unitImg1\"></div>";
                        }else if (fileType === "xlsx" || fileType === "xls" ){
                            resultHtml += "	<div class=\"fileImg\"><img src=\"../../../images/my/cloudDisk/XIS.png\" class=\"unitImg1\"></div>";
                        }
                        resultHtml += "	<div class=\"unitContent\" data-id='"+data.datas[i].id+"'>";
                        resultHtml += "		<div class=\"text-overflow\">"+data.datas[i].docName+"</div>";
                        resultHtml += "		<div class=\"info space-between\"><span>"+getDate(data.datas[i].createTime)+"</span><span><img class='look' src='../../../images/my/cloudDisk/look.png'>&nbsp;&nbsp;"+data.datas[i].browse+"</span></div>";
                        resultHtml += "	</div>";
                        resultHtml += "</li>";
                    }
                    $(".unitList").html(resultHtml);
                    $(".clickEvent").hide();
                    $(".selected").hide();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 得到文件类型
     */
    /*function getFileType(filePath) {
        let startIndex=filePath.lastIndexOf("/");
        if(startIndex!==-1){
            return filePath.substring(startIndex+1,filePath.length).toLowerCase();
        }else {
            return "";
        }
    }*/
    /**
     * 分享名片 (加载数据成功后调用)
     */
    function share(id,docName) {

        if (!$WeChat.isWx()) {
            return;
        }
        //添加数据
        $$.request({
            url: UrlConfig.upload_insertMyShareRecord,
            pars:{
                id:id
            },
            requestBody:true,
            sfn: function (data) {
                if (data.success) {
                    let _lineLink = $$.getFullHost() + '/src/pages/my/cloudDisk/imm.html';
                    /* 是否带参 */
                    _lineLink += $$.jsonToUrlParams({
                        id:id,
                        shareId:data.shareId
                    });
                    console.log(_lineLink);
                    weChatJSTool.share({
                        _imgUrl:  $(".headImg").attr("src"),
                        _lineLink:  _lineLink,
                        _shareTitle: docName,
                        _descContent: '叮咚，你已收到一份文档，请速速点击查看',
                        _sfn: function () {
                            $$.layerToast("分享成功~");
                        }
                    });
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

    }
    //字符串转换为时间戳
    function getDateTimeStamp (dateStr) {
        return Date.parse(dateStr.replace(/-/gi,"/"));
    }
    function getDate(old) {
        let returnText = "";
        const nowDate = new Date().getTime();   //当前时间
        const setDate = new Date(old).getTime();
        const times = Math.floor((nowDate - setDate) / 1000);
        if (times > 60*60*24*30){
            returnText= old.substring(0,10);
        } else if(times > 60*60*24){
            returnText=Math.floor(times / (60*60*24))+"天前";
        }else if(times > 60*60){
            returnText=Math.floor(times / (60*60))+"小时前";
        }else if(times > 60){
            returnText=Math.floor(times / (60))+"分钟前";
        }else if(times > 0){
            returnText=Math.floor(times / 1)+"秒前";
        }else{
            returnText="刚刚";
        }
        return returnText;
    }

    function unitList(datas) {
        let resultHtml = "";
        for (let i = 0; i < datas.length; i++) {
            resultHtml += "<li class=\"unit\" data-id='"+datas[i].id+"'>";
            resultHtml += "	<div class=\"selected\" data-selected=\"false\"><img src=\"../../../images/my/cloudDisk/noSelected.png\"></div>";

            let fileType = datas[i].fileExtension;
            if (fileType === "pdf" ){
                resultHtml += "	<div class=\"fileImg\"><img src=\"../../../images/my/cloudDisk/PDF.png\" class=\"unitImg1\"></div>";
            }else if (fileType === "doc"|| fileType === "docx"){
                resultHtml += "	<div class=\"fileImg\"><img src=\"../../../images/my/cloudDisk/wor.png\" class=\"unitImg1\"></div>";
            }else if (fileType === "xlsx" || fileType === "xls" ){
                resultHtml += "	<div class=\"fileImg\"><img src=\"../../../images/my/cloudDisk/XIS.png\" class=\"unitImg1\"></div>";
            }
            resultHtml += "	<div class=\"unitContent\" data-id='"+datas[i].id+"'>";
            resultHtml += "		<div class=\"text-overflow\">"+datas[i].docName+"</div>";
            resultHtml += "		<div class=\"info space-between\"><span>"+getDate(datas[i].createTime)+"</span><span>"+datas[i].fileSize+"KB</span></div>";
            resultHtml += "	</div>";
            if (!$$.isValidObj(memberId)) {
                resultHtml += "	<div class=\"shareImg\"><img src=\"../../../images/my/cloudDisk/share.png\" class=\"unitImg2\"></div>";
            }
            resultHtml += "</li>";
        }
        $(".unitList").html(resultHtml);
    }

    function shareMyCloud() {
        if (!$WeChat.isWx()) {
            return;
        }
        let _lineLink = $$.getFullHost() + '/src/pages/my/cloudDisk/myCloud.html';
        _lineLink += $$.jsonToUrlParams({
            memberId:shareMemberId
        });
        weChatJSTool.share({
            _imgUrl:  $(".headImg").attr("src"),
            _lineLink:  _lineLink,
            _shareTitle: $(".name").html() + '的云空间',
            _descContent: '这个秘密基地，我只与你分享，快来看看吧！',
            _sfn: function () {
                $$.layerToast("分享成功~");
            }
        });
    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType === 2;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
