window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_20', null);
    } catch (error) {
        console.log(error);
    }
    setGrowVal();

    $('.explain').click(()=>{
        const html =
            `<div class="pop-up">
                <div class="close">
                    <img src="../../images/my/close.png" />
                </div>
                <div>独立经济人成长值说明</div>
                未成团独立经纪人可按照成交额累计成长值，
                累计成交额20万以下为普通级别，
                完成20万后晋升金牌经纪人，
                完成100万后晋升钻石经纪人，
                由平台荣誉认证客户更放心，
                促进成交。
            </div>`;

        layer.open({
            type : 1,
            content : html
        })

        $('.close').click(()=>{
            layer.closeAll();
        });
    });

};


/*根据成长值改变进度条和等级*/
function setGrowVal() {
    $$.request({
        url: UrlConfig.market_growthrule_wx_getBrokerLevelDataByLogin,
        pars:{},
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let member = data.member;
                if(null != member.memberName){
                    $('.name').text(member.memberName);
                }else{
                    $('.name').text(member.memberAccount);
                }
                let imgPath = member.imgPath;
                if(imgPath){
                    $('.photo img').attr('src',imgPath);
                }
                changeHtml(data);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function changeHtml(data) {
    let growthRule = data.growthRule;
    let nextGrowthRule = data.nextGrowthRule;
    //账户当前成长值
    let growVal = data.orderPayMoney;
    let code = growthRule.code;
    let gname = growthRule.gname;
    $('.rootMsg').text(gname + `特权`);
    let isFull = data.isFull;
    if (isFull) {
        $('.grow,#notFull').hide();
        $('#isFull').css('display','flex');
        $('#isFull').css('height','auto');
        $('#isFull > img').attr('src','../../images/my/level/broker/diamond.png');
        $('.photo').css('margin-top',25);

    } else {
        let maxAmount = growthRule.maxAmount;
        let nextGname = nextGrowthRule.gname;
        //将当前的成长值显示到页面
        $('.now').text(growVal);
        $('.all').text(maxAmount);
        $('.growTitle > div:eq(0)').text(gname);
        $('.growTitle > div:eq(2)').text(nextGname);
        let percent = data.percent;
        $('.number').css('width', `${percent}%`);
    }
    if (code == 'b2') {
        $('.upper').css('background', 'url("../../images/my/gold.png") no-repeat center center /100% 100%');
        $('.left').html(`<img src="../../images/my/goldLevel.png" />`);
        $('.right').html(`<img src="../../images/my/diamondLevel.png" />`);
        $('.number').css('background-color', 'rgb(189, 155, 99)');
        $('.icon').css('background-color', 'rgb(189, 155, 99)');
    } else if (code == 'b3') {
        $('.upper').css('background', 'url("../../images/my/diamond.png") no-repeat center center /100% 100%');
        $('.left').html(`<img src="../../images/my/goldLevel.png" />`);
        $('.right').html(`<img src="../../images/my/diamondLevel.png" />`);
        $('.number').css('background-color', 'rgb(96, 55, 183)');
        $('.icon').css('background-color', 'rgb(96, 55, 183)');
    }
}
