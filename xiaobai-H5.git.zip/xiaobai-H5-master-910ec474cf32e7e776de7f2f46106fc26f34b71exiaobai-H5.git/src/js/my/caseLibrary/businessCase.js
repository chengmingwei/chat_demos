/**
 *  行业案例 JS
 * @Author 吴成林
 * @Date 2020-2-19 10:28:13
 */
let timeOutEvent = 0;
window.onload = function() {
    const PAGE_STATE = {
        whetherVIP: false,                  // 是否是VIP
    };
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        getVipData();
        //案例库前4
        $$.request({
            url: UrlConfig.caseLibrary_getCaseLibraryList,
            pars:{
                state:1
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    for (let i = 0; i < 4; i++) {
                        if (data.datas[i] !== undefined){
                            resultHtml += "<li style='background-image: url("+data.datas[i].coverImg+")' data-id="+data.datas[i].id+" data-caseUrl="+data.datas[i].caseUrl+" data-casePDF="+data.datas[i].casePDF+">";
                            resultHtml += "	<div class=\"business overflow\">"+data.datas[i].title+"</div>";
                            resultHtml += "	<div class=\"attribute\"></div>";
                            resultHtml += "</li>";
                        }
                    }
                $(".caseList").html(resultHtml);
                    if (data.datas.length === 0){
                        $$.showNoResultView({
                            parentJqSelector: ".caseList" ,
                            msg: "暂无内容",
                        })
                    }

                $(".caseList li").on("click", function(){
                    if (!PAGE_STATE.whetherVIP) {
                        $$.confirm({
                            title: "此案例仅供已开通了展业功能包的老师们查看、使用！",
                            onOkLabel: "确认",
                            onCancelLabel: "取消",
                            onOk: function () {
                                $$.push('my/purchaseVIP/purchaseVIP');
                            }
                        });
                        return;
                    }
                    let id = $(this).attr("data-id");
                    let caseUrl = $(this).attr("data-caseUrl");
                    let casePDF = $(this).attr("data-casePDF");
                    if (caseUrl !== "undefined"){
                        $$.push("my/caseLibrary/shareCaseLibrary",{
                            id:id,
                            caseUrl:caseUrl,
                            shareCase:false
                        })
                    }
                    if (casePDF !== "undefined"){
                        $$.push("my/caseLibrary/shareCaseLibrary",{
                            id:id,
                            casePDF:casePDF,
                            shareCase:false
                        })
                    }
                });

                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
        //我的案例库
        $$.request({
            url: UrlConfig.myCaseLibrary_getMyCaseLibraryList,
            pars:{},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "<li class=\"caseContent space-between\" data-mid="+data.datas[i].mid+" data-cid="+data.datas[i].cid+" data-caseUrl="+data.datas[i].caseUrl+" data-casePDF="+data.datas[i].casePDF+">";
                        resultHtml += "	<div style='background-image: url("+data.datas[i].coverimg+")' long-tap='1'>";
                        resultHtml += "		<div class=\"business overflow\">"+data.datas[i].ctitle+"</div>";
                        resultHtml += "		<div class=\"attribute\" hidden></div>";
                        resultHtml += "	</div>";
                        resultHtml += "	<div>";
                        resultHtml += "		<div long-tap='2' class=\"caseContentTitle\"><span class=\"overflow\">"+data.datas[i].mtitle+"</span></div>";
                        resultHtml += "		<div long-tap='2' class=\"flex-start font12\">";
                        resultHtml += "			<img src=\"../../../images/my/caseLisrary/businessCase-4.png\">";
                        resultHtml += "			<span>"+data.datas[i].createtime+"</span>";
                        resultHtml += "		</div>";
                        resultHtml += "		<div long-tap='2' class=\"font12 flex-start \">";
                        resultHtml += "			<div class=\"flex-start\">";
                        resultHtml += "				<img src=\"../../../images/my/caseLisrary/businessCase-6.png\">";
                        resultHtml += "				<span>&nbsp;"+data.datas[i].browse+"次</span>";
                        resultHtml += "			</div>";
                        resultHtml += "			<div long-tap='2' class=\"flex-start browse\">";
                        resultHtml += "				<img src=\"../../../images/my/caseLisrary/businessCase-5.png\">";
                        resultHtml += "				<span>&nbsp;"+data.datas[i].forward+"次</span>";
                        resultHtml += "			</div>";
                        resultHtml += "";
                        resultHtml += "		</div>";
                        resultHtml += "		<div class=\"shareCase\">";
                        resultHtml += "			<span data-id="+data.datas[i].cid+" data-title="+data.datas[i].ctitle+">分享案例</span>";
                        resultHtml += "		</div>";
                        resultHtml += "	</div>";
                        resultHtml += "</li>";
                    }
                    if (data.datas.length === 0){
                        $$.showNoResultView({
                                parentJqSelector: ".myContentList" ,
                                msg: "暂无内容",
                            })
                    }
                    $(".myContentList").html(resultHtml);
                    //-- 分享我的案例 （按钮判断是否用户为VIP）
                    //长按删除
                    var longClick =0;
                    $(".myContentList li [long-tap]").on({
                        touchstart: function(e){
                            longClick=0;//设置初始为0
                            timeOutEvent = setTimeout(function(){
                                //此处为长按事件-----在此显示遮罩层及删除按钮
                                longClick=1;//假如长按，则设置为1
                                let index = $(e.currentTarget).attr("long-tap");
                                let mid;
                                if (index === 1){
                                    mid= $(e.currentTarget).parent().attr("data-mid");
                                }else if (index === 2){
                                    mid=$(e.currentTarget).parent().parent().attr("data-mid");
                                }

                                $$.confirm({
                                    title: "是否真的删除我的案例？",
                                    onOkLabel: "删掉",
                                    onCancelLabel: "取消",
                                    onOk: function () {
                                        $$.request({
                                            url: UrlConfig.myCaseLibrary_deleteMyCaseLibrary,
                                            pars:{
                                                id:mid
                                            },
                                            requestBody:true,
                                            loading: true,
                                            sfn: function (data) {
                                                $$.closeLoading();
                                                if (data.success) {
                                                    window.location.reload();
                                                } else {
                                                    $$.layerToast(datas.msg);
                                                }
                                            },
                                            ffn: function (data) {
                                                $$.errorHandler();
                                            }
                                        });
                                    }
                                });


                            },500);
                        },
                        touchmove: function(e){
                            clearTimeout(timeOutEvent);
                            timeOutEvent = 0;
                        },
                        touchend: function(e){
                            clearTimeout(timeOutEvent);
                            if(timeOutEvent !== 0 && longClick === 0){//点击
                                let index = $(e.currentTarget).attr("long-tap");
                                let id ;
                                let caseUrl;
                                let casePDF;
                                if (index === 1){
                                    id= $(e.currentTarget).parent().attr("data-cid");
                                    caseUrl= $(e.currentTarget).parent().attr("data-caseUrl");
                                    casePDF= $(e.currentTarget).parent().attr("data-casePDF");
                                }else if (index === 2){
                                    id=$(e.currentTarget).parent().parent().attr("data-cid");
                                    caseUrl=$(e.currentTarget).parent().parent().attr("data-caseUrl");
                                    casePDF=$(e.currentTarget).parent().parent().attr("data-casePDF");
                                }
                                if (caseUrl !== "undefined"){
                                    $$.push("my/caseLibrary/shareCaseLibrary",{
                                        id:id,
                                        caseUrl:caseUrl,
                                        shareCase:false
                                    })
                                }
                                if (casePDF !== "undefined"){
                                    $$.push("my/caseLibrary/shareCaseLibrary",{
                                        id:id,
                                        casePDF:casePDF,
                                        shareCase:false
                                    })
                                }
                            }
                            return false;
                        }
                    });
                    $(".shareCase").on("click", function(){
                        console.log($(this).find("span").attr("data-id"));
                        $$.push("my/caseLibrary/shareCase", {
                            "id" : $(this).find("span").attr("data-id"),
                            "title":encodeURI(encodeURI($(this).find("span").attr("data-title")))
                        });
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 查看更多
        $(".more").on("click", function(){
            $$.push("my/caseLibrary/moreCase");
        });

        //-- 新增我的案例 （按钮判断是否用户为VIP）
        $(".addCase").on("click", function(){
            $$.push("my/caseLibrary/caseLibrary");
        });

        //-- 分享我的案例 （按钮判断是否用户为VIP）
        $(".shareCase").on("click", function(){
            $$.push("my/caseLibrary/shareCase", {
                "switchState" : true
            });
        });

    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType !== 0;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
