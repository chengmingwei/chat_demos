/**
 *  分享案例 JS
 * @Author 吴成林
 * @Date 2020-2-19 17:23:37
 */

let id ;
let uuid;
const PAGE_STATE = {
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: '案例分享'
    }
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
         id = $$.getUrlParam("id");
        let title =  decodeURI($$.getUrlParam("title"));
        PAGE_STATE.shareDatums.title = title;
        $(".title").val(title);

        $$.request({
            url: UrlConfig.caseLibrary_getCaseLibrary,
            pars:{
                id:id
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let _lineLink = $$.getFullHost() + '/src/pages/my/caseLibrary/shareCaseLibrary.html?id='+data.Caselibrary.id+"&casePDF="+data.Caselibrary.casePDF+"&caseUrl="+data.Caselibrary.caseUrl+"&shareCase="+"true"+"&uuid="+data.uuid;
                    PAGE_STATE.shareDatums.url = _lineLink;
                    uuid = data.uuid;
                    share();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 保存分享
        $(".share").on("click", function(){
            let shareTitle = $(".title").val();
            if (shareTitle.trim() != ""){
                shareHandler();
            }else{
                $$.alert("请输入分享标题~~")
            }

        });
    }

    /**
     * 分享
     */
    function share() {
        if (!$WeChat.isWx()) {
            return;
        }
        const { url, image, title, content } = PAGE_STATE.shareDatums;
        weChatJSTool.share({
            _imgUrl: image,
            _lineLink:  url,
            _shareTitle: title,
            _descContent: content,
            _sfn: function () {
                shareAfter();
            }
        });

        //-- 分享后续
        function shareAfter() {
            $$.alert("分享成功~",function () {
                $$.request({
                    url: UrlConfig.myCaseLibrary_insertMyCaseLibrary,
                    pars:{
                        title:$(".title").val().trim(),
                        caseLibraryId:id,
                        forward:1,
                        browse:0,
                        UUID:uuid
                    },
                    requestBody:true,
                    loading: true,
                    sfn: function (datas) {
                        $$.closeLoading();
                        if (datas.success) {
                            $$.push("my/caseLibrary/businessCase")
                        } else {
                            $$.layerToast(datas.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            });
        }
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-4-20 14:24:46
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;
            console.log(shareDatums);
            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            //-- 分享showShareView
            $$.showShareView('点击右上角,分享案例给好友！');
        }
    }


}
