/**
 *  案例库 查看更多 JS
 * @Author 吴成林
 * @Date 2020-2-19 14:26:39
 */
let industryId;
let sort;
const PAGE_STATE = {
    whetherVIP: false,                  // 是否是VIP
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        getVipData();
        //下拉框
        $$.request({
            url: UrlConfig.industry_getList,
            pars:{},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "	<option value="+data.datas[i].id+">"+data.datas[i].industryName+"</option>";
                    }
                    $("#industry").html(resultHtml);
                    $('#industry').change(function(){
                        let id = $(this).val();
                        industryId = id;
                        $$.request({
                            url: UrlConfig.caseLibrary_getCaseLibraryList,
                            pars:{
                                industryId:id,
                                sort:sort,
                                state:1
                            },
                            requestBody:true,
                            loading: true,
                            sfn: function (data) {
                                $$.closeLoading();
                                $$.hideNoResultView("body");
                                if (data.success) {
                                    let resultHtml = "";
                                    for (let i = 0; i < data.datas.length; i++) {
                                        resultHtml += "<li style='background-image: url("+data.datas[i].coverImg+")' data-id="+data.datas[i].id+" data-caseUrl="+data.datas[i].caseUrl+" data-casePDF="+data.datas[i].casePDF+">";
                                        resultHtml += "	<div class=\"business overflow\">"+data.datas[i].title+"</div>";
                                        resultHtml += "	<div class=\"attribute\"></div>";
                                        resultHtml += "</li>";
                                    }
                                    if (data.datas.length == 0){
                                        $$.showNoResultView({
                                            msg: "搜索不到该产品"
                                        });
                                    }
                                    $(".caseList").html(resultHtml);
                                    jumpUrl();
                                } else {
                                    $$.layerToast(data.msg);
                                }
                            },
                            ffn: function (data) {
                                $$.errorHandler();
                            }
                        });
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
        //列表
        $$.request({
            url: UrlConfig.caseLibrary_getCaseLibraryList,
            pars:{
                state:1
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "<li style='background-image: url("+data.datas[i].coverImg+")' data-id="+data.datas[i].id+" data-caseUrl="+data.datas[i].caseUrl+" data-casePDF="+data.datas[i].casePDF+">";
                        resultHtml += "	<div class=\"business overflow\">"+data.datas[i].title+"</div>";
                        resultHtml += "	<div class=\"attribute\"></div>";
                        resultHtml += "</li>";
                    }
                    $(".caseList").html(resultHtml);
                    jumpUrl()
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

    }

    /**
     * 事件绑定
     */
    function eventBinding(){

    }
    $('#sort').change(function(){
        let selectSort = $(this).val();
        if (selectSort == 1){
            sort = null;
        }else {
            sort = "2"
        }

        $$.request({
            url: UrlConfig.caseLibrary_getCaseLibraryList,
            pars:{
                industryId:industryId,
                sort:sort,
                state:1
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                $$.hideNoResultView("body");
                if (data.success) {
                    let resultHtml = "";
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "<li style='background-image: url("+data.datas[i].coverImg+")' data-id="+data.datas[i].id+" data-caseUrl="+data.datas[i].caseUrl+" data-casePDF="+data.datas[i].casePDF+">";
                        resultHtml += "	<div class=\"business overflow\">"+data.datas[i].title+"</div>";
                        resultHtml += "	<div class=\"attribute\"></div>";
                        resultHtml += "</li>";
                    }
                    if (data.datas.length == 0){
                        $$.showNoResultView({
                            msg: "搜索不到该产品"
                        });
                    }
                    $(".caseList").html(resultHtml);
                    jumpUrl();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType !== 0;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
function jumpUrl() {
    $(".caseList li").on("click", function(){
        if (!PAGE_STATE.whetherVIP) {
            $$.confirm({
                title: "此案例仅供已开通了展业功能包的老师们查看、使用！",
                onOkLabel: "确认",
                onCancelLabel: "取消",
                onOk: function () {
                    $$.push('my/purchaseVIP/purchaseVIP');
                }
            });
            return;
        }
        let id = $(this).attr("data-id");
        let caseUrl = $(this).attr("data-caseUrl");
        let casePDF = $(this).attr("data-casePDF");
        if (caseUrl != "undefined"){
            $$.push("my/caseLibrary/shareCaseLibrary",{
                id:id,
                caseUrl:caseUrl,
                shareCase:false
            })
        }
        if (casePDF != "undefined"){
            $$.push("my/caseLibrary/shareCaseLibrary",{
                id:id,
                casePDF:casePDF,
                shareCase:false
            })
        }
    });
}
