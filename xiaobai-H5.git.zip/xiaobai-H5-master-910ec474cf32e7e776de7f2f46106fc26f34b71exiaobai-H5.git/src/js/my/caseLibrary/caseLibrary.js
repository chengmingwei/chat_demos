/**
 *  案例库 JS
 * @Author 吴成林
 * @Date 2020-2-19 14:26:39
 */
let id;
let title;
window.onload = function() {
    countAction('xb_6016');
    const PAGE_STATE = {
        whetherVIP: false,                  // 是否是VIP
    };
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        $$.request({
            url: UrlConfig.caseLibrary_getCaseLibraryList,
            pars:{},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "<li style='background-image: url("+data.datas[i].coverImg+")' data-id="+data.datas[i].id+" data-caseUrl="+data.datas[i].caseUrl+" data-casePDF="+data.datas[i].casePDF+">";
                        resultHtml += "	<div class=\"business overflow\">"+data.datas[i].title+"</div>";
                        resultHtml += "	<div class=\"attributeNo\"></div>";
                        resultHtml += "</li>";
                    }
                    $(".caseList").html(resultHtml);
                    //-- 选择案例 - 改变图标
                    $(".caseList li").on("click", function(){
                         id = $(this).attr("data-id");
                        title =$(this).find("div").html();
                        $(this).find("div.attributeNo").removeClass("attributeNo").addClass("attributeYes");
                        $(this).siblings().find("div.attributeYes").removeClass("attributeYes").addClass("attributeNo");
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){

        //-- 已选 - 跳转分享页
        $(".choose").on("click", function(){
            if (!PAGE_STATE.whetherVIP) {
                $$.confirm({
                    title: "此案例仅供已开通了展业功能包的老师们查看、使用！",
                    onOkLabel: "确认",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
                return;
            }
            if (id != undefined){
                $$.push("my/caseLibrary/shareCase",{
                    id:id,
                    title:encodeURI(encodeURI(title))
                })
            }else {
                $$.alert("请选择一个案例！")
            }
        });
    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType !== 0;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
