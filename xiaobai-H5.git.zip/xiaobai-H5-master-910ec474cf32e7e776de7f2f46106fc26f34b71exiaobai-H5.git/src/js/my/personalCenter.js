let id;
window.onload = function () {
    $$.changeVersion();
    //TO DO ...
    /**----- 工具项事件绑定 ----**/
    EvtMgr.bindToLi('tools-group');
    load();
    /**----- 关于我们，意见反馈 事件绑定 ----**/
    EvtMgr.bindToLi('list');
    $(".withdraw-btn").on("click",function () {
        $$.push("my/withdraw",{
            id:id
        });
    });


    $(".header").click(function () {
        //window.location.href = "../../pages/my/personalInformation.html";
        //$$.push('my/personalInformation');
        $$.push("my/personalInformation",{
            id:id
        });
    })
    $(".bank").click(function () {
        $$.push("my/personalInformation4.html",{
            id:id
        });
       // window.location.href = "../../pages/my/personalInformation4.html";

    })
    $("#manageMoney").click(function () {
        $$.push("my/ManageMoney");
    });
    $("#callCenter").click(function () {
        $$.push("my/callCenter");
    });
}
/**
 * 描述信息：加载用户数据
 * @author
 * @date 2019-09-23
*/
function load() {
    if (!ShawHandler.checkLogin()){
        ShawHandler.gotoLogin();
    }
    $$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                console.log(data);
                id = data.datas.id;
                $(".username").html(data.datas.rname);
                $(".logo").attr("src",data.datas.imgPath);
                var userStatus = data.datas.userStatus;
                var mtype = data.datas.mtype;
                if (!(userStatus === 1 && mtype === 4)) {
                	gotoMyTeam();
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function gotoMyTeam(){
    $$.request({
        url: UrlConfig.market_teammember_getTeamMemberByLogin,
        loading: true,
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	console.log(data);
                var url = "../teams/index.html";
                var teamId = data.teamId;
                if (teamId != null) {
                	var teamStatus = data.teamStatus;
                	if (teamStatus == 0 || teamStatus == 1) {
                		url = "../teams/addDetails.html?teamId=" + teamId;
                	} else if (teamStatus == 2) {
                		url = "../teams/colonel.html?teamId=" + teamId;
                	}
                }
//              var applyStatus = data.datas.applyStatus;
//              var teamMemberId = data.datas.teamMemberId;
//          	var isTeamLeader = data.datas.isTeamLeader;
//          	var isTeamMember = data.datas.isTeamMember;
//          	if (applyStatus == 1) {//申请中
//          		url = '../teams/application.html?teamMemberId=' + teamMemberId;
//          	} else if (applyStatus == 2) {//申请失败
//          		url = '../teams/notpass.html';
//          	} else if (applyStatus == 3) {//入团
//          		if (isTeamLeader) {//团长（主团团员、子团团长）
//	            		url = "../teams/colonel.html";
//	            		url = '../teams/addDetails.html';
//	            		if (isTeamMember) {//主团团员、子团团长
//	            			url += '?isTeamMember=' + isTeamMember;
//	            		}
//	            	} else {//团员
//	            		url = "../teams/clustering.html";
//	            	}
//          	}
			    $('#myTeam').attr('url',url);
            	$('.tools-group li.tools-group1').css('display','none');
            	$('.tools-group li.tools-group2').css('display','inline');
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
