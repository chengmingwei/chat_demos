let noContent = ()=>{
    const html = `<div class="none">
                  <img src="../../images/my/noContent.png" />
                  <div class="tex">暂无内容</div>
                  </div>`;
    return html;
}