window.onload = function () {
    $$.changeVersion();
    let posterId = $$.getUrlParam("posterId");
    let memberId = $$.getUrlParam("memberId");
    let posterQRCode = $$.getUrlParam("posterQRCode");
    if (posterId && memberId) {
        buildPosterQRCode(posterId, memberId, posterQRCode);
    }
};

function buildPosterQRCode(posterId, memberId, posterQRCode) {
    $$.request({
        url: UrlConfig.market_poster_buildPosterQRCode,
        pars: {
            posterId: posterId,
            memberId: memberId,
            posterQRCode: posterQRCode
        },
        requestBody: true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                if ($$.isValidObj(data.posterQRCode)) {
                    posterQRCode = data.posterQRCode;
                }
                let detailHtml = [
                    '<ul class="imageContainer">',
                    '<li>',
                    '<img src="' + posterQRCode + '" />',
                    '<span class="savePic">长按保存图片</span>',
                    '<span class="send">分享给好友</span>',
                    '</li>',
                    '</ul>'];
                $('.detail').html(detailHtml.join(''));

                $Listener.onTap(".send", function (e) {
                    if(PAGE_APP){
                        const { _imgUrl, _lineLink, _shareTitle, _descContent } = getShareDatums(posterId, memberId, posterQRCode);
                        const shareDatums = {
                            url: _lineLink,
                            image: _imgUrl,
                            title: _shareTitle,
                            content: _descContent
                        };
                        const params = {...shareDatums};
                        $$.postAPP(10002, params);
                        return;
                    }
                    $$.showShareView('点击右上角，发送给好友~');
                });
                sharePosterDetails(posterId, memberId, posterQRCode);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function sharePosterDetails(posterId, memberId, posterQRCode) {
    if(PAGE_APP) return;
    weChatJSTool.share(getShareDatums(posterId, memberId, posterQRCode));
}

function getShareDatums(posterId, memberId, posterQRCode){
    let _lineLink = $$.getFullHost() + "/src/pages/my/posterDetails.html";
    let jsonToUrlParams = {
        posterId:posterId,
        memberId:memberId,
        posterQRCode:posterQRCode
    };
    _lineLink += $$.jsonToUrlParams(jsonToUrlParams);
    return {
        _imgUrl: $Constant.shareLogo,
        _lineLink: _lineLink,
        _shareTitle: '我在用这个功能设计精美海报',
        _descContent: '想你所想，快来设计你的专属独家海报吧！',
        _sfn: function () {
            $$.layerToast("分享成功");
        }
    };
}
