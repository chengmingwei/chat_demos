/**
 *  分享案例 JS
 * @Author 吴成林
 * @Date 2020-2-19 17:23:37
 */

let id ;
let memberId;
let switchState;
let memberImg;
let memberPhone;
let memberName;
let wxQRCode;
let domainName = "https://pic.xiaobaibao.com";
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        id = $$.getUrlParam("id");
        memberId =  $$.getUrlParam("memberId");
        switchState =  $$.getUrlParam("switchState");
        //-- 是否显示名片
        if (switchState == "true"){
            memberImg=  $$.getUrlParam("memberImg");
            memberPhone=  $$.getUrlParam("memberPhone");
            memberName=  $$.getUrlParam("memberName");
            wxQRCode=  $$.getUrlParam("wxQRCode");
            $(".member-name").html(decodeURI(memberName));
            $(".member-phone").html(memberPhone);
            $(".userPortraits").css("background-image","url("+domainName+memberImg+")");
            $(".postersQrCode").css("background-image","url("+domainName+wxQRCode+")");
        }else {
            $(".visitingCard").hide();
        }
        loadData();
        sharePosters();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){

    }

    function loadData() {
        $$.request({
            url: UrlConfig.market_getPoster,
            pars:{
                id:id
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $(".postersImg").attr('src', data.datas.picPath);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 分享海报
     */
    function sharePosters() {
        if (!$WeChat.isWx() && !PAGE_APP) {
            return;
        }
        let _lineLink = $$.getFullHost() + '/src/pages/my/sharePosters.html';
        let params = {
            id:id,
            memberId:memberId,
            switchState:switchState
        };
        /* 是否带参 */
        if (switchState == "true"){
            params = {
                ...params,
                memberImg:memberImg,
                memberPhone:memberPhone,
                memberName:memberName,
                wxQRCode:wxQRCode
            };
        }
        _lineLink += $$.jsonToUrlParams(params);
        weChatJSTool.share({
            _imgUrl:  $Constant.shareLogo,
            _lineLink:  _lineLink,
            _shareTitle: '我在用这个功能设计精美海报',
            _descContent: '想你所想，快来设计你的专属独家海报吧！',
            _sfn: function () {
                $$.layerToast("分享成功~");
            }
        });
    }
};
