/**
 * 发布新动态 JS
 * @Author 吴成林
 * @Date 2020-6-30 14:52:12
 */
window.onload = function() {
    $$.changeVersion();

    const PAGE_STATE = {
        id: 0,                                                                  // 名片Id
        selectedImg: '../../../images/my/newMyVisitingCard/selected.png',       // 选中状态图片
        unselectedImg: '../../../images/my/newMyVisitingCard/unselected.png',   // 未选中状态图片
        selectiveType: 0,                                                       // 动态类型 [0：个人动态， 1：团队动态]
        dynamicPic: null,                                                       // 上传OSS的动态图片
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        PAGE_STATE.id = $$.getUrlParam("id");

        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        //-- 加载团队状态
        $$.request({
            url: UrlConfig.market_teammember_getTeamMemberByLogin,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let {teamId, teamStatus, mType} = data;
                    if (!$$.isValidObj(teamId) || teamStatus != 2 || mType != 1) {
                        $('.selectiveType').children('div:nth-child(2)').hide();
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 选择动态类型
        $('.selectiveType>div').on("click", function () {
            const type = $(this).attr('data-type');
            const state = $(this).attr('data-state');
            if (state === "0"){
                $(this).attr('data-state', '1');
                $(this).children('img').attr('src', PAGE_STATE.selectedImg);

                $(this).siblings().attr('data-state', '0');
                $(this).siblings().children('img').attr('src', PAGE_STATE.unselectedImg);
            }
            PAGE_STATE.selectiveType = type;
        });

        //-- 监控输入框内容长度
        $(".dynamicContent textarea").on('input', function(){
            let content = $(this).val();
            if (content.trim() != ""){
                $('.contentLength').text(content.length);
            } else {
                $('.contentLength').text(0);
            }
        });

        //-- 上传图片 - 背景图片
        $('.dynamicPictures>img').on("click", function() {
            $('#pictures').click();
        });

        //-- 选择上传图片
        $('#pictures').on('change', function () {
            let name = $(this).siblings('img');
            let the = $(this);

            files(name, the);
        });

        //-- 提交发布
        $('.release').on("click", function() {
            const dynamicPictures = $('#pictures')[0].files[0];
            uploadPictures(dynamicPictures);
        });
    }

    //-- 上传图片封装
    function files(name, the) {
        let file = the[0].files[0];
        //文件类型
        let fileType = file.type;
        let type = getFileType(fileType);
        //文件大小
        let fileSize = (file.size / 1024).toFixed(2);
        if(type !== "jpg" && type !== "gif" && type !== "jpeg" && type !== "png") {
            $$.layerToast('请上传图片');
            return false;
        }
        if(fileSize > 5120) { //定义不能超过5MB
            $$.layerToast('请上传不超过5M的图片');
            return false;
        }
        lrz(file).then(function(resultObj) {
            name.attr("src", resultObj.base64);
        });
    }

    //-- 获取文件类型
    function getFileType(filePath) {
        let startIndex = filePath.lastIndexOf("/");
        if(startIndex !== -1) {
            return filePath.substring(startIndex + 1, filePath.length).toLowerCase();
        } else {
            return "";
        }
    }

    //-- 上传图片
    function uploadPictures(picturesUrl) {
        if (!$$.isValidObj(picturesUrl)) {
            verification();
            return false;
        }

        let formData = new window.FormData();
        formData.append('file', picturesUrl);
        formData.append('formType', '10028');

        $$.request({
            url: UrlConfig.upload_attachment_upload,
            loading: true,
            pars: formData,
            requestBody: true,
            sfn: function(data) {
                $$.closeLoading();
                if(data.success) {
                    PAGE_STATE.dynamicPic = data.datas.filePath;
                    verification();
                } else {
                    $$.layerToast(data.msg);
                    return null;
                }
            },
            ffn: function(data) {
                $$.errorHandler();
                return null;
            }
        });
    }

    //-- 发布动态
    function verification() {
        let dynamicContent = $('.dynamicContent textarea').val().trim(),
            {id, selectiveType, dynamicPic} = PAGE_STATE;

        if (!$$.isValidObj(dynamicContent)) $$.throwTips(`动态内容未填写，请输入再发布~`);

        //-- 新增我的名片动态
        $$.request({
            url: UrlConfig.management_mybusinesscarddyn_save,
            pars: {
                businessCardId: id,
                dynamicContent: dynamicContent,
                dynamicPic: dynamicPic,
                dynamicType: selectiveType
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $$.alert("发布成功",function () {
                        history.go(-1);
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }


}