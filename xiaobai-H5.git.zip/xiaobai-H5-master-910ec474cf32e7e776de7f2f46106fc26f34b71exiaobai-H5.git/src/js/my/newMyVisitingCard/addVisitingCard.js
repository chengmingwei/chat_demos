/**
 * 个人资料 JS
 * @Author 吴成林
 * @Date 2020-6-30 14:52:12
 */
window.onload = function() {
    $$.changeVersion();

    const PAGE_STATE = {
        nickName: '',                               // 姓名
        selectedLabelNumber: 0,                     // 已选择标签数量
        labelList: {},                              // 已选标签列表
        phone: '',                                  // 手机号
        email: '',                                  // 邮箱
        popupLogin: false,                          // 弹窗调用页面状态参数
        params: {},                                 // 提交参数
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        PAGE_STATE.popupLogin = $$.getUrlParam("popupLogin");
        const memberId = $$.getUrlParam("memberId");
        PAGE_STATE.params['memberId'] = memberId;

        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        //-- 加载我的名片
        $$.request({
            url: UrlConfig.mybusinesscard_getBusinessCardScreen,
            pars: {
                "memberId": PAGE_STATE.params.memberId
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    loadVisitingCard(data);                          // 加载名片内容
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 选择印象标签
        $('.labelList>div').on("click", function () {
            const state = $(this).attr('data-state');
            const indexes = $(this).attr('data-indexes');

            if (PAGE_STATE.selectedLabelNumber >= 6 && state === '0') {
                $$.layerToast('标签最多只能选择6个');
                return false;
            }

            $(this).attr('data-state', `${state === '0' ? '1' : '0'}`);
            $(this).css('background-color', `${state === '0' ? '#EF5B09' : '#DDDDDD'}`);
            state === '0' ? (PAGE_STATE.selectedLabelNumber += 1) : (PAGE_STATE.selectedLabelNumber -= 1);
            state === '0' ? PAGE_STATE.labelList[indexes] = $(this).text() : delete PAGE_STATE.labelList[indexes];
        });

        //-- 选择从业年限
        $('#yearsOfWorking').on("click", function() {
            const years = ["不到1年", "1年", "2年", "3年", "4年", "5年", "6年", "7年", "8年", "9年", "10年", "11年", "12年", "13年", "14年", "15年", "16年", "17年", "18年", "19年", "20年以上"];
            weui.picker(years, {
                id:"yearsOfWorking",
                defaultValue: ["不到1年"],
                onConfirm: (result) => {
                    $(this).val(result[0].label);
                }
            });
        });

        //-- 上传图片 [头像, 背景图片, 微信二维码, 照片墙]
        $('.uploadPictures, .uploadPhoto').on("click", function() {
            $(this).siblings('input').click();
        });

        //-- 选择上传图片
        $('#portraits, #backgroundPicture, #weChatQrCode, .photoWallList input').on("change", function() {
            let name = $(this).siblings('.uploadPictures');
            let the = $(this);

            files(name, the);
        });

        //-- 提交保存
        $('.save').on("click", function() {
            verification();
        });
    }

    /**
     * 加载名片内容
     * @Author 吴成林
     * @Date 2020-7-7 10:24:34
     */
    function loadVisitingCard(data){
        const labeList = data.datas.labeList;             // 标签列表
        const entity = data.datas.entity;                 // 名片列表
        let {
            backgroundPic,                  // 背景图片
            headPortrait,                   // 用户头像
            nickName,                       // 昵称
            years,                          // 从业年限
            profession,                     // 从事职业
            companyName,                    // 公司名称
            companyAddress,                 // 公司地址
            wxQRCode,                       // 微信二维码
            synopsis,                       // 简介
            id,                             // 名片Id
            photo1,                         // 照片墙1
            photo2,                         // 照片墙2
            photo3,                         // 照片墙3
            photo4,                         // 照片墙4
            photo5,                         // 照片墙5
            photo6,                         // 照片墙6
            showTeam,                       // 参团团员是否显示团长动态
        } = entity;

        PAGE_STATE.params['id'] = id;
        if ($$.isValidObj(backgroundPic)) $('.background').css('background', `url(${backgroundPic}) center center / contain no-repeat rgb(255, 255, 255)`);
        if ($$.isValidObj(headPortrait)) $('.headPortrait').css('background', `url(${headPortrait}) center center / contain no-repeat rgb(255, 255, 255)`);
        $('#name').val(nickName);
        $('#yearsOfWorking').val(years);
        $('#occupation').val(profession);
        $('#companyName').val(companyName);
        $('.companyAddress textarea').val(companyAddress);
        $('.individualResume textarea').val(synopsis);
        if ($$.isValidObj(wxQRCode)) $('.qrCode').css('background', `url(${wxQRCode}) center center / contain no-repeat rgb(255, 255, 255)`);
        if ($$.isValidObj(photo1)) $('.photoWall_1').css('background', `url(${photo1}) center center / contain no-repeat rgb(255, 255, 255)`);
        if ($$.isValidObj(photo2)) $('.photoWall_2').css('background', `url(${photo2}) center center / contain no-repeat rgb(255, 255, 255)`);
        if ($$.isValidObj(photo3)) $('.photoWall_3').css('background', `url(${photo3}) center center / contain no-repeat rgb(255, 255, 255)`);
        if ($$.isValidObj(photo4)) $('.photoWall_4').css('background', `url(${photo4}) center center / contain no-repeat rgb(255, 255, 255)`);
        if ($$.isValidObj(photo5)) $('.photoWall_5').css('background', `url(${photo5}) center center / contain no-repeat rgb(255, 255, 255)`);
        if ($$.isValidObj(photo6)) $('.photoWall_6').css('background', `url(${photo6}) center center / contain no-repeat rgb(255, 255, 255)`);
        if (showTeam == 1) $('#switch').prop("checked", false);

        //-- 加载标签列表
        const labelNameList = {};
        let labelNameStringList = $(".labelList").find("div").map(function(index,elem) {
            labelNameList[index+1] = $(elem).text();
            return $(elem).text();
        }).get().join(',');

        if ($$.isValidObj(labeList)){
            for (let i in labeList){
                let labelName = labeList[i].labelName;
                if (labelNameStringList.includes(labelName)){
                    for (let j in labelNameList){
                        if (labelNameList[j] == labelName){
                            $(`.labelList>div:eq(${j-1})`).attr('data-state', '1').css('background-color', '#EF5B09');
                            PAGE_STATE.selectedLabelNumber += 1;
                            PAGE_STATE.labelList[j] = labelNameList[j];
                        }
                    }
                }
            }
        }

        loadUserInfo(nickName);
    }

    /**
     * 加载用户信息
     * @Author 吴成林
     * @Date 2020-7-7 10:24:34
     */
    function loadUserInfo(nickName) {
        $$.request({
            url: UrlConfig.market_growthrule_wx_getBrokerLevelData,
            pars: {
                "memberId": PAGE_STATE.params.memberId
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let {rname, phone, email} = data.member;
                    if (!$$.isValidObj(nickName)) if ($$.isValidObj(rname)) $('#name').val(rname);
                    if ($$.isValidObj(phone)) $('#contactNumber').val(phone);
                    if ($$.isValidObj(email)) $('#email').val(email);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 上传图片封装
    function files(name, the) {
        let file = the[0].files[0];
        //文件类型
        let fileType = file.type;
        let type = getFileType(fileType);
        //文件大小
        let fileSize = (file.size / 1024).toFixed(2);
        if(type !== "jpg" && type !== "gif" && type !== "jpeg" && type !== "png") {
            $$.layerToast('请上传图片');
            return false;
        }
        if(fileSize > 5120) { //定义不能超过5MB
            $$.layerToast('请上传不超过5M的图片');
            return false;
        }
        lrz(file).then(function(resultObj) {
            name.css('background', `url(${resultObj.base64}) center center / contain no-repeat rgb(255, 255, 255)`);
        });
    }

    //-- 获取文件类型
    function getFileType(filePath) {
        let startIndex = filePath.lastIndexOf("/");
        if(startIndex !== -1) {
            return filePath.substring(startIndex + 1, filePath.length).toLowerCase();
        } else {
            return "";
        }
    }

    //-- 验证提交信息
    function verification() {
        let verify = new $Valid.validComment({}),
            pictureList = [],
            nickName = $('#name').val(),                            // 姓名
            phone = $('#contactNumber').val(),                      // 电话
            email = $('#email').val(),                              // 邮箱

            profession = $('#occupation').val(),                    // 职业
            years = $('#yearsOfWorking').val(),                     // 年限
            companyName = $('#companyName').val(),                  // 公司
            companyAddress = $('.companyAddress textarea').val(),   // 公司地址
            synopsis = $('.individualResume textarea').val(),       // 简介
            headPortrait = $('#portraits')[0].files[0],             // 头像
            backgroundPic = $('#backgroundPicture')[0].files[0],    // 背景
            wxQRCode = $('#weChatQrCode')[0].files[0],              // 微信二维码
            photo1 = $('#photoWall_1')[0].files[0],                 // 图片墙1
            photo2 = $('#photoWall_2')[0].files[0],                 // 图片墙2
            photo3 = $('#photoWall_3')[0].files[0],                 // 图片墙3
            photo4 = $('#photoWall_4')[0].files[0],                 // 图片墙4
            photo5 = $('#photoWall_5')[0].files[0],                 // 图片墙5
            photo6 = $('#photoWall_6')[0].files[0],                 // 图片墙6
            checkbox = $('#switch').prop('checked');          // 是否显示团队动态

        //-- 字段判断
        (function () {
            if (!$$.isValidObj(nickName)) $$.throwTips("姓名未填写~");
            if (!$$.isValidObj(phone)) $$.throwTips("联系电话未填写~");
            if (!$$.isValidObj(email)) $$.throwTips("电子邮箱未填写~");
            /*if (!$$.isValidObj(profession)) $$.throwTips("从事职业未填写~");*/
            /*if (!$$.isValidObj(years)) $$.throwTips("从业年限未选择~");
            if (!$$.isValidObj(companyName)) $$.throwTips("公司名称未填写~");
            if (!$$.isValidObj(companyAddress)) $$.throwTips("公司地址未填写~");
            if (!$$.isValidObj(synopsis.trim())) $$.throwTips("个人简介未填写~");
            if (PAGE_STATE.selectedLabelNumber == 0) $$.throwTips("请选择至少一个印象标签~");*/
            if ($$.isValidObj(phone) && !verify.checkPhoneForRegex(phone)) $$.throwTips(`请输入有效的手机号~`);
            if ($$.isValidObj(email) && !verify.checkEmailForRegex(email)) $$.throwTips(`请输入有效的电子邮箱~`);
        })();

        //-- 提交参数赋值
        (function () {
            PAGE_STATE.phone = phone;
            PAGE_STATE.email = email;

            PAGE_STATE.params['nickName'] = nickName;
            PAGE_STATE.params['profession'] = profession;
            PAGE_STATE.params['years'] = years;
            PAGE_STATE.params['companyName'] = companyName;
            PAGE_STATE.params['companyAddress'] = companyAddress;
            PAGE_STATE.params['synopsis'] = synopsis;
            PAGE_STATE.params['isComplete'] = 1;

            let labelName = [];
            for (let i in PAGE_STATE.labelList){
                labelName.push(PAGE_STATE.labelList[i]);
            }
            if ($$.isValidObj(labelName)) {
                PAGE_STATE.params['labelName'] =  labelName.join(',');
                PAGE_STATE.params['backLabelName'] = labelName.join(',');
            }

            PAGE_STATE.params['showTeam'] = checkbox ? 0 : 1;
        })();

        //-- 上传图片本地路径获取
        (function () {
            if ($$.isValidObj(backgroundPic)) pictureList.push({'file': backgroundPic, 'formType': '10030', 'identify': 'backgroundPic'});
            if ($$.isValidObj(headPortrait)) pictureList.push({'file': headPortrait, 'formType': '10031', 'identify': 'headPortrait'});
            if ($$.isValidObj(wxQRCode)) pictureList.push({'file': wxQRCode, 'formType': '10032', 'identify': 'wxQRCode'});
            let photoList = [photo1, photo2, photo3, photo4, photo5, photo6];
            for(let i in photoList){
                if ($$.isValidObj(photoList[i])){
                    pictureList.push({'file': photoList[i], 'formType': '10029', 'identify': 'photo'+(parseInt(i)+1)});
                }
            }
        })();

        updateEmailAndPhone();          // 上传手机号和邮箱到会员信息
        uploadPictures(pictureList);    // 上传图片到OSS
    }

    //-- 上传图片
    function uploadPictures(pictureList) {
        if (!$$.isValidObj(pictureList)) {
            submit();
            return null;
        }

        $$.loading('图片上传中');
        for(let i in pictureList){
            const {file, formType, identify} = pictureList[i];
            let formData = new window.FormData();
            formData.append('file', file);
            formData.append('formType', formType);

            $$.request({
                url: UrlConfig.upload_attachment_upload,
                pars: formData,
                requestBody: true,
                sfn: function(data) {
                    if(data.success) {
                        headPath = data.datas.filePath;
                        PAGE_STATE.params[`${identify}`] = headPath;

                        if ((parseInt(i)+1) == pictureList.length) {
                            submit();       // 保存提交
                        }
                    } else {
                        $$.layerToast(data.msg);
                        return null;
                    }
                },
                ffn: function(data) {
                    $$.errorHandler();
                    return null;
                }
            });
        }
    }

    /**
     * 保存 会员手机号和邮箱
     * @Author 吴成林
     * @Date 2020-7-7 15:23:15
     */
    function updateEmailAndPhone() {
        const {email, phone, params} = PAGE_STATE;
        $$.request({
            url: UrlConfig.market_growthrule_updateEmailAndPhone,
            pars: {
                email: email,
                phone: phone,
                memberId: params.memberId
            },
            requestBody:true,
            sfn: function (data) {
                if (data.success){

                }else {
                    $$.alert("手机号/邮箱保存失败");
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 提交保存
     * @Author 吴成林
     * @Date 2020-7-7 15:23:15
     */
    function submit() {
        $$.request({
            url: UrlConfig.mybusinesscard_insertOrUpdateBusinessCard,
            pars: PAGE_STATE.params,
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success){
                    //-- 弹窗调用登录 - 登录成功关闭弹窗
                    if (PAGE_STATE.popupLogin){
                        ShawHandler.layerToast("保存成功");
                        setTimeout(function(){
                            $(window.parent.document).find(".preview").hide();
                        }, 1000);
                    } else {
                        $$.alert("保存成功", function () {
                            history.go(-1);
                        });
                    }
                }else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
}