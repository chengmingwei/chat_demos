
/**
 * 新我的名片 JS
 * @Author 吴成林
 * @Date 2020-6-29 12:25:31
 */
window.onload = function() {
    countAction("xb_6001");
    $$.changeVersion();

    const PAGE_STATE = {
        shareState: 'true',         // 是否分享状态
        memberId: '',               // 用户Id
        visitorId: '',              // 访客Id
        memberType: 0,              // 访客会员类型
        visitingCardId: 0,          // 名片Id
        wxQRCode: '',               // 微信二维码
        touchmoveTime: 0,           // 滑动次数
        moveDistance: 0,            // 滑动距离
        personalDynamicList: [],    // 个人动态列表
        teamDynamicList: [],        // 团队动态列表
        commentsList: {},           // 提交评论参数列表
        swiperState: 0,             // 轮播图初始化状态
        photoWallList: [],          // 照片墙集合
        shareDatums: {              // 分享参数
            url: '',
            image: $Constant.shareLogo,
            title: '',
            content: '万水千山总是缘，很高兴认识您，点击可查看我名片介绍~'
        },
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        PAGE_STATE.memberId = $$.getUrlParam("memberId");
        let isPageHide = false;
        window.addEventListener('pageshow', function () {
            if (isPageHide) {
                window.location.reload();
            }
        });
        window.addEventListener('pagehide', function () {
            isPageHide = true;
        });

        //-- 登录状态下，非本人名片页面
        if ($$.checkLogin()){
            $$.request({
                url: UrlConfig.member_Detailspage,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        memberId = data.datas.id;
                        if (memberId == PAGE_STATE.memberId){
                            PAGE_STATE.shareState = "false";
                        } else{
                            PAGE_STATE.shareState = "true";
                            PAGE_STATE.visitorId = memberId;
                            $('.makeBusinessCards').show();
                        }
                        gotoMyTeam();
                        pageInit();
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        } else{
            pageInit();
            /*if ($WeChat.isWx() || PAGE_APP){
                //getSpenID();        //-- 微信授权登录
                pageInit();
            } else{
                $$.confirmLogin();
            }*/
        }
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();
        eventBinding();

    }

    /**
     * 数据加载
     */
    function dataLoading(){
        //-- 加载我的名片
        $$.request({
            url: UrlConfig.mybusinesscard_getBusinessCardScreen,
            pars: {
                "memberId": PAGE_STATE.memberId
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    loadVisitingCard(data);   // 加载名片内容
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        let startY, moveEndY;
        //-- 内容滑动效果
        $('.content').on({
            touchstart: function(e){
                if (PAGE_STATE.touchmoveTime < 1) e.preventDefault();
                startY = e.originalEvent.changedTouches[0].pageY;
            },
            touchmove: function(e){
                if (PAGE_STATE.touchmoveTime < 1) e.preventDefault();
                moveEndY = e.originalEvent.changedTouches[0].pageY;
                PAGE_STATE.moveDistance = moveEndY - startY;

                if (PAGE_STATE.moveDistance < 0 && PAGE_STATE.touchmoveTime < 1) $('.bottomEffects').show();
            },
            touchend: function(e){
                let {touchmoveTime, swiperState, shareState} = PAGE_STATE;
                if (touchmoveTime < 1) e.preventDefault();
                $('.bottomEffects').hide();

                //-- 向上滑动
                if (PAGE_STATE.moveDistance < 0){
                    if (touchmoveTime == 0) {
                        PAGE_STATE.touchmoveTime = 1;
                        if (shareState == 'false'){
                            $('.functionBlock').show();
                        }
                        $('.moduleTwo').show();
                        $('.nextBottom').hide();
                        $('.content').css({'top': '50vh', 'animation': 'contentTwo 0.3s'});
                        $('.wrapper').css('overflow-y', 'auto');
                        if (swiperState == '1') swiper();
                    }
                //-- 向下滑动
                } else if (PAGE_STATE.moveDistance > 0){
                    setTimeout(function(){
                        if ($('div').scrollTop() < 40 && touchmoveTime == 1){
                            PAGE_STATE.touchmoveTime = 0;
                            $('.content').css({'top': '72vh', 'animation': 'contentReverseOne 0.3s'});
                            $('.moduleTwo').hide();
                            $('.functionBlock').hide();
                            $('.nextBottom').show();

                            $('.wrapper').css('overflow-y', 'hidden');
                        }
                    }, 300);


                }
            },
        });

        //-- 背景图片滑动效果 - 禁止点击和滚动
        $('.backgroundPicture').on({
            touchstart: (e) => e.preventDefault(),
            touchmove: (e) => e.preventDefault(),
            touchend: (e) => e.preventDefault(),
        });

        //-- 公司地址弹窗 （后续添加调用手机地图APP）
        $('.companyAddress').on("click", function() {
            let text = $(this).children('.address').text();
            $$.alert(text);
        });

        //-- 跳转 - 新增动态
        $('.releaseDynamic, .personalDynamicContent>.emptyContent, .teamDynamicContent>.emptyContent').on("click", function() {
            if ($$.checkLogin()){
                if (PAGE_STATE.shareState == 'false'){
                    $$.push("my/newMyVisitingCard/releaseNewDynamic", {id: PAGE_STATE.visitingCardId});
                }
            } else{
                //$$.confirmLogin();
            }
        });

        //-- 跳转 - 修改名片
        $('.modifiedVisitingCard, .resumeContent>.emptyContent, .photoWallContent>.emptyContent').on("click", function() {
            if ($$.checkLogin()){
                if (PAGE_STATE.shareState == 'false'){
                    $$.push("my/newMyVisitingCard/addVisitingCard", {memberId: PAGE_STATE.memberId,});
                }
            } else{
                //$$.confirmLogin();
            }
        });

        //-- 添加二维码 绑定事件
        $(".weChatQrCode").off().on("click", function(){
            const {wxQRCode} = PAGE_STATE;
            if ($$.isValidObj(wxQRCode)){
                layer.open({
                    content:
                        `<div class="popupContent">
                    <div class="question">
                        <b>扫描下方二维码，添加微信</b>
                        <img src="${wxQRCode}" />
                        <span>长按识别二维码</span>
                    </div>
                </div>`
                });
            } else{
                if (PAGE_STATE.shareState == 'false'){
                    $$.confirm({
                        title: "您还未添加微信二维码，是否前往添加",
                        onOk: function () {
                            $$.push("my/newMyVisitingCard/addVisitingCard", {memberId: PAGE_STATE.memberId});
                        }
                    });
                } else{
                    $$.layerToast("该用户暂未设置微信二维码~");
                }
            }
        });

        //-- 发给客户 右上角分享
        $(".share").on("click", function(){
            shareHandler();
        });

        //-- 关闭评论
        $(".inputComments").on("click", function(){
            $(this).hide();
        });

        //-- 评论 - 阻止冒泡事件
        $(".comments, .photoWall").on("click", function(e){
            e.stopPropagation();
        });

        //-- 获取 textarea输入框提交数据
        $(".comments>textarea").on('keypress',function(e) {
            let keycode = e.keyCode;
            let commentsContent = $(this).val().trim();
            if(keycode=='13') {
                e.preventDefault();
                $(".inputComments").hide();
                PAGE_STATE.commentsList['commentContent'] = commentsContent;

                //-- 提交评论
                submitComments();
            }
        });
        //-- 发送评论
        $(".comments>.send").on("click", function(e){
            e.stopPropagation();
            let commentsContent = $('.comments>textarea').val().trim();
            PAGE_STATE.commentsList['commentContent'] = commentsContent;
            $(".inputComments").hide();

            //-- 提交评论
            submitComments();
        });

        //-- 个人动态 显示更多
        $(".personalShowMore").on("click", function(){
            $('.personalDynamicContent>div').show();
            $(this).hide();
        });

        //-- 团队动态 显示更多
        $(".teamShowMore").on("click", function(){
            $('.teamDynamicContent>div').show();
            $(this).hide();
        });

        //-- 点击空白 链接 跳转 填写名片页面
        $('.unitTwo a').on("click", function(){
            if (PAGE_APP) return false;
            const href = $(this).attr('href');
            if (href == '#'){
                $$.push("my/newMyVisitingCard/addVisitingCard", {memberId: PAGE_STATE.memberId});
            }
        });

        //-- 跳转 邀请新人得红包页面
        $(".redPacket").on("click", function(){
            if ($$.checkLogin()){
                $$.push('my/newGiftBag');
            } else{
                $$.confirmLogin();
            }
        });

        //-- 跳转 访客 名片页面（访客未登录 => 登录 => 我的页面， 已登录 => 访客的名片页面）
        $(".makeBusinessCards").on("click", function(){
            if ($$.checkLogin()){
                $$.push("my/newMyVisitingCard/myVisitingCard",{memberId : PAGE_STATE.visitorId});
            } else{
                $$.push("login/login", {
                    returnUrl: encodeURIComponent(window.location.href)
                });
            }
        });

        //-- 关闭 查看图片
        $(".viewImage, .previewCommentImage").on("click", function(){
            $(this).hide();
            $('.wrapper').css('overflow','auto');
        });

        //-- 点击 向上图标
        $(".nextBottom").on("click", function(){
            $(this).hide();
            PAGE_STATE.touchmoveTime = 1;
            if (PAGE_STATE.shareState == 'false'){
                $('.functionBlock').show();
            }
            $('.moduleTwo').show();
            $('.content').css({'top': '50vh', 'animation': 'contentTwo 0.3s'});
            $('.wrapper').css('overflow-y', 'auto');
            if (PAGE_STATE.swiperState == '1') swiper();
        });

        //-- input 失去焦点事件 - 解决IOS软键盘关闭后页面不回弹问题
        $("input").blur(function(){
            setTimeout(function() {
                let scrollHeight = document.documentElement.scrollTop || document.body.scrollTop || 0;
                window.scrollTo(0, Math.max(scrollHeight - 1, 0));
            }, 300);
        });
    }

    /**
     * 文字横向滚动
     * @Author 吴成林
     * @Date 2020-7-14 10:24:58
     */
    /*function scrollText(text = null, clickFunction){
        if ($$.isValidObj(text)) {
            $('#scroll_begin').html(text);
        }
        const announcement = $('.announcement');
        announcement.css('display','block');
        announcement.on("click",clickFunction);

        (function () {
            let speed=50;//初始化速度 也就是字体的整体滚动速度
            // let MyMar = null;//初始化一个变量为空 用来存放获取到的文本内容
            let scroll_begin = document.getElementById("scroll_begin");//获取滚动的开头id
            let scroll_end = document.getElementById("scroll_end");//获取滚动的结束id
            let scroll_div = document.getElementById("scroll_div");//获取整体的开头id
            scroll_end.innerHTML=scroll_begin.innerHTML;//滚动的是html内部的内容,原生知识!

            //定义一个方法
            function Marquee(){
                if(scroll_end.offsetWidth-scroll_div.scrollLeft<=0) {
                    scroll_div.scrollLeft-=scroll_begin.offsetWidth;
                } else {
                    scroll_div.scrollLeft++;
                }
            }
            setInterval(Marquee,speed);
        })();
    }*/

    /**
     * 加载名片内容
     * @Author 吴成林
     * @Date 2020-5-14 20:56:12
     */
    function loadVisitingCard(data){
        let backgroundPicImg = '../../../images/my/newMyVisitingCard/myVisitingCard-0.png';
        let headPortraitImg = '../../../images/my/defaultImg.png';

        const dynList = data.datas.dynList;               // 动态列表
        const labeList = data.datas.labeList;             // 标签列表
        const entity = data.datas.entity;                 // 名片列表
        let {
            backgroundPic,                  // 背景图片
            headPortrait,                   // 用户头像
            nickName,                       // 昵称
            years,                          // 从业年限
            profession,                     // 从事职业
            companyName,                    // 公司名称
            companyAddress,                 // 公司地址
            wxQRCode,                       // 微信二维码
            synopsis,                       // 简介
            id,                             // 名片Id
            photo1,                         // 照片墙1
            photo2,                         // 照片墙2
            photo3,                         // 照片墙3
            photo4,                         // 照片墙4
            photo5,                         // 照片墙5
            photo6,                         // 照片墙6
            showTeam,                       // 是否显示团队动态
        } = entity;
        PAGE_STATE.visitingCardId = id;

        //-- 加载名片消息
        $('.backgroundPicture').css("background", `url(${$$.isValidObj(backgroundPic) ? backgroundPic : backgroundPicImg}) center center / cover no-repeat rgb(255, 255, 255)`);
        $('.portraits').css({"background": `url(${$$.isValidObj(headPortrait) ? headPortrait : headPortraitImg}) no-repeat center / 100% 100%`, 'display': 'inline-block'});
        $('.nickName').text($$.isValidObj(nickName) ? nickName : "小白");
        $('.years').text(`从业${$$.isValidObj(years) && years.includes("年") ? years : "1年"} | `);
        $('.profession').text($$.isValidObj(profession) ? profession : "职业经纪人");
        $('.company').text($$.isValidObj(companyName) ? companyName : "");
        $('.address').text($$.isValidObj(companyAddress) ? companyAddress : "暂未填写");

        PAGE_STATE.shareDatums.image = $$.isValidHeadImg(headPortrait);
        if ($$.isValidObj(wxQRCode)) PAGE_STATE.wxQRCode = wxQRCode;
        if ($$.isValidObj(synopsis)) {
            $('.resumeContent').html(`<div class="contentContainer"><p>${synopsis}</p></div>`);
        };

        //-- 加载照片墙
        let photoWallList = [];
        if ($$.isValidObj(photo1)) photoWallList.push(photo1);
        if ($$.isValidObj(photo2)) photoWallList.push(photo2);
        if ($$.isValidObj(photo3)) photoWallList.push(photo3);
        if ($$.isValidObj(photo4)) photoWallList.push(photo4);
        if ($$.isValidObj(photo5)) photoWallList.push(photo5);
        if ($$.isValidObj(photo6)) photoWallList.push(photo6);
        if ($$.isValidObj(photoWallList)) loadPhotoWall(photoWallList);

        //-- 加载个人和团队动态
        if ($$.isValidObj(dynList)) {
            loadDynamic(dynList, showTeam);
        } else if (showTeam == 1){
            $('.teamDynamic').hide();
        }

        //-- 加载标签
        if ($$.isValidObj(labeList) && labeList.length > 0) {
            $('.contentContainer').append(`<div class="labelList flex-wrap"></div>`);
            let html = ``;
            for (let i in labeList){
                const {id, labelName, praiseCount} = labeList[i];
                html += `<div data-id="${id}">
                            <span class="labelName">${labelName}</span>
                            <span class="praiseCount">${praiseCount}</span>
                        </div>`;
            }
            $('.labelList').html(html);

            /* 标签点赞 +1 */
            $(".labelList>div").on("click", function(){
                if ($$.checkLogin()){
                    const id = $(this).attr('data-id');
                    const likesSum = $(this).children('.praiseCount').text();
                    if (localCache(labelKey = 'label'+id)) {
                        $$.layerToast('已点赞喔~');
                        return false;
                    }

                    $$.request({
                        url: UrlConfig.management_mybusinesscardlabel_updateLabelPraiseCount,
                        pars: {id},
                        requestBody: true,
                        loading: true,
                        sfn: (data) => {
                            $$.closeLoading();
                            if (data.success) {
                                $$.layerToast("感谢您的点赞~");
                                $(this).children('.praiseCount').text(parseInt(likesSum)+1);
                            } else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });
                } else{
                    $$.confirmLogin();
                }
            });
        }

        loadUserInfo(nickName);             // 加载用户信息
        getCardVisitList();                 // 根据名片id查询访客记录
        // 新增访客记录
        if (PAGE_STATE.shareState == 'true' && PAGE_STATE.visitorId != '') saveVisitorRecord();
    }

    //-- 加载个人和团队动态
    function loadDynamic(data, showTeam) {
        PAGE_STATE.personalDynamicList = [];
        PAGE_STATE.teamDynamicList = [];
        const {personalDynamicList, teamDynamicList, shareState, memberId} = PAGE_STATE;
        for (let i in data){
            const item = data[i];
            const commentList = item.commentList;
            let html = `<div class="personalDynamicUnit" data-id="${item.dynid}">
                            <div class="flex-start personalDynamicUserInfo">
                                <img src='${$$.isValidObj(item.imgPath) ? item.imgPath : `../../../images/my/defaultImg.png`}'>
                                <div>
                                    <div class="dynamicRname">${$$.isValidObj(item.rname) ? item.rname : `小白`}</div>
                                    <div class="publicationTime space-between">
                                        <div>
                                            <span style="color: #EF5B09">发表于 </span>
                                            <span>${item.createTime}</span>
                                        </div>
                                        ${shareState == 'false' ? `<div class="removeDynamic">删除</div>` : ``}
                                    </div>
                                </div>
                            </div>
                            <div class="personalDynamicIntroduction">
                                <div class="dynamicContent">${item.dynamicContent}</div>
                                ${$$.isValidObj(item.dynamicPic) ? `<div class="dynamicPic" data-url="${item.dynamicPic}" style="background: url(${item.dynamicPic}) center center / contain no-repeat rgb(255, 255, 255);"></div>` : ``}
                                <div class="flex-end functionalBlock">
                                    <div class="comment">
                                        <img src="../../../images/my/newMyVisitingCard/comment.png">
                                        <span>${$$.isValidObj(item.dynamicComCt) ? item.dynamicComCt : 0}</span>
                                    </div>
                                    <div class="praise" data-id="${item.dynid}">
                                        <img src="${localCache(labelKey = 'dynamic'+item.dynid, imgState = true) ? `../../../images/my/newMyVisitingCard/like.png` : `../../../images/my/newMyVisitingCard/dislike.png`}">
                                        <span>${$$.isValidObj(item.dynamicPraiseCt) ? item.dynamicPraiseCt : 0}</span>
                                    </div>
                                </div>
                            </div>
                            ${commentList.length > 0 ? `<div class="commentList">${commentLists(commentList)}</div>` : ``}
                            ${commentList.length > 2 ? `<div class="expandAll">—— 展开${commentList.length - 2}条回复 ——</div>` : ``}
                        </div>`;

            if (item.dynamicType == 0){
                personalDynamicList.push(html);     // 个人动态
            } else if (showTeam == 0 || memberId == item.memberId){
                teamDynamicList.push(html);         // 团队动态
            }
        }

        if (personalDynamicList.length > 0) {
            $('.personalDynamicContent').html(personalDynamicList.join(""));
            if (personalDynamicList.length > 2){
                $('.personalShowMore').show().text(`—— 展开${personalDynamicList.length-2}条动态 ——`);
            }
        }

        if (teamDynamicList.length > 0) {
            $('.teamDynamicContent').html(teamDynamicList.join(""));
            if (teamDynamicList.length > 2){
                $('.teamShowMore').show().text(`—— 展开${teamDynamicList.length-2}条动态 ——`);
            }
        }

        //-- 删除动态
        $('.removeDynamic').on('click', function () {
            const obj = $(this).parents('.personalDynamicUnit');
            $$.confirm({
                title: "确定删除动态？",
                onOk: function () {
                    removeDynamic(obj);
                }
            });
        });

        //-- 点赞动态
        $('.praise').on('click', function () {
            if ($$.checkLogin()){
                let id = $(this).attr('data-id');
                if (localCache(labelKey = 'dynamic'+id)) {
                    $$.layerToast("已点赞喔~");
                    return false;
                }
                const obj = $(this);
                praiseDynamic(obj);
            } else{
                $$.confirmLogin();
            }
        });

        //-- 点赞评论
        $('.commentPraise').on('click', function (e) {
            e.stopPropagation();
            if ($$.checkLogin()){
                let id = $(this).attr('data-id');
                if (localCache(labelKey = 'comment'+id)) {
                    $$.layerToast("已点赞喔~");
                    return false;
                }
                const obj = $(this);
                praiseComment(obj);
            } else{
                $$.confirmLogin();
            }
        });

        //-- 评论动态
        $('.comment').on('click', function () {
            if ($$.checkLogin()){
                $('.inputComments').show();
                $('.replyName').text('动态');
                const id = $(this).parents('.personalDynamicUnit').attr('data-id');

                const {shareState, memberId, visitorId, memberType} = PAGE_STATE;
                const params = {
                    commentId: 0,
                    commentPraiseCount: 0,
                    memberId: shareState == 'true' ? visitorId : memberId,
                    memberType: memberType,
                    dynamicId: id,
                    parentCommentid: 0
                };
                PAGE_STATE.commentsList = {...params};
                $('.comments>textarea').focus();
            } else{
                $$.confirmLogin();
            }
        });

        //-- 回复 评论
        $('.commentUnit').on('click', function (e) {
            if ($$.checkLogin()){
                e.stopPropagation();
                $('.inputComments').show();
                $('.replyName').text(`${$(this).find('.commentRname:nth-child(1)').attr('data-rname')}`);

                let parentCommentid = '';
                const id = $(this).parents('.personalDynamicUnit').attr('data-id');
                const commentId = $(this).attr('data-id');
                const commentState = $(this).attr('data-state');
                parentCommentid = commentState == '1' ? commentId : $(this).parents('.commentUnit').attr('data-id');

                const {shareState, memberId, visitorId, memberType} = PAGE_STATE;
                const params = {
                    commentId: commentId,
                    commentPraiseCount: 0,
                    memberId: shareState == 'true' ? visitorId : memberId,
                    memberType: memberType,
                    dynamicId: id,
                    parentCommentid: parentCommentid
                };
                PAGE_STATE.commentsList = {...params};
                $('.comments>textarea').focus();
            } else{
                $$.confirmLogin();
            }
        });

        //-- 展开全部评论
        $('.expandAll').on('click', function () {
            $('.commentList>div').css('display', 'flex');
            $(this).hide();
        });

        //-- 预览图片
        $('.dynamicPic').on('click', function () {
            let url = $(this).attr('data-url');
            $('.previewCommentImage>div').css('background', `url(${url}) center center / contain no-repeat rgb(255, 255, 255)`);
            $('.previewCommentImage').show();
            $('.wrapper').css('overflow','hidden');
        });

        //-- 一级评论
        function commentLists(commentList) {
            let html = ``;
            for (let i in commentList){
                const item = commentList[i];
                const comList = item.comList;
                const rname = $$.isValidObj(item.rname) ? item.rname : `小白`;
                html += `<div class="flex-start commentUnit" data-id="${item.id}" data-state="1">
                            <img src='${$$.isValidObj(item.imgPath) ? item.imgPath : `../../../images/my/defaultImg.png`}'>
                            <div>
                                <div><span class="commentRname" data-rname="${rname}">${rname}</span></div>
                                <div class="replyTime" style="color: #CCCCCC">
                                    <span>回复于 </span>
                                    <span>${item.createTime}</span>
                                </div>
                                <div class="space-between">
                                    <div class="commentContent">${item.commentContent}</div>
                                    <div class="commentPraise" data-id="${item.id}">
                                        <img src="${localCache(labelKey = 'comment'+item.id, imgState = true) ? `../../../images/my/newMyVisitingCard/like.png` : `../../../images/my/newMyVisitingCard/dislike.png`}">
                                        <div style="color: #999999">${item.commentPraiseCount}</div>
                                    </div>
                                </div>
                                ${$$.isValidObj(comList) ? comLists(item.comList) : ``}
                            </div>
                        </div>`;
            }
            return html;
        }

        //-- 二级回复
        function comLists(comList) {
            let html = ``;
            for (let i in comList){
                const item = comList[i];
                const rname = $$.isValidObj(item.rname) ? item.rname : `小白`;
                html += `<div class="flex-start commentUnit" data-id="${item.id}" data-state="2">
                            <img src='${$$.isValidObj(item.imgPath) ? item.imgPath : `../../../images/my/defaultImg.png`}' style="width: 22px; height: 22px;">
                            <div>
                                <div>
                                    <span class="commentRname" data-rname="${rname}">${rname}</span>
                                    <span style="color: #CCCCCC; font-size: 12px">回复</span>
                                    <span>${$$.isValidObj(item.toMemberName) ? item.toMemberName : `小白`}</span>
                                </div>
                                <div class="replyTime" style="color: #CCCCCC">
                                    <span>回复于 </span>
                                    <span>${item.createTime}</span>
                                </div>
                                <div class="space-between">
                                    <div class="commentContent">${item.commentContent}</div>
                                    <div class="commentPraise" data-id="${item.id}">
                                        <img src="${localCache(labelKey = 'comment'+item.id, imgState = true) ? `../../../images/my/newMyVisitingCard/like.png` : `../../../images/my/newMyVisitingCard/dislike.png`}">
                                        <div style="color: #999999">${item.commentPraiseCount}</div>
                                    </div>
                                </div>
                            </div>
                        </div>`;
            }
            return html;
        }
    }

    /**
     * 加载用户信息
     * @Author 吴成林
     * @Date 2020-7-7 10:24:34
     */
    function loadUserInfo(nickName) {
        $$.request({
            url: UrlConfig.market_growthrule_wx_getBrokerLevelData,
            pars: {
                "memberId": PAGE_STATE.memberId
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let {rname, phone, email} = data.member;
                    if (!$$.isValidObj(nickName)) {
                        if ($$.isValidObj(rname)) {
                            $('.nickName').text(rname);
                            PAGE_STATE.shareDatums.title = 'hello，我是' + rname;
                        } else{
                            PAGE_STATE.shareDatums.title = 'hello，我是小白';
                        }
                    } else {
                        PAGE_STATE.shareDatums.title = 'hello，我是' + nickName;
                    }
                    if ($$.isValidObj(phone)) {
                        $('.phone').text(phone);
                        if(PAGE_APP){
                            $("#phone").on("click", function () {
                                let params = {};
                                params["phone"] = phone;
                                $$.postAPP(10003, params);
                            });
                        } else{
                            $("#phone").attr("href", 'tel:'+ phone);
                        }
                    } else {
                        $('.phone').text('暂未填写');
                    }

                    if ($$.isValidObj(email)) {
                        $('.email').text(email);
                        if(PAGE_APP){
                            $("#email").on("click", function () {
                                let params = {};
                                params["email"] = email;
                                $$.postAPP(10003, params);
                            });
                        } else{
                            $('#email').attr('href', 'Mailto:'+ email);
                        }
                    } else {
                        $('.email').text('暂未填写');
                    }

                    shareWeeklyLuckyDraw();             // 分享名片
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 加载图片墙
     * @Author 吴成林
     * @Date 2020-7-9 19:04:41
     */
    function loadPhotoWall(photoWallList) {
        let html = ``;
        if (photoWallList.length == 1){
            $('.photoWallContent').html(`<div class="photoWallContainer"><img src="${photoWallList[0]}" class="sole" /></div>`);
        } else{
            html += `<div class="photoWallContainer swiper-container">
                        <div class="swiper-wrapper" id="photoWall">
                            ${eachUnit(photoWallList)}
                        </div>
                    </div>`;
            $('.photoWallContent').html(html);
            PAGE_STATE.swiperState = '1';
        }

        //-- 查看图片墙 照片
        $(".photoWallContent img").on("click", function(){
            const index = parseInt($(this).attr('data-index'));
            let html = ``;
            for (let i in photoWallList){
                html += `<li data-index="${i}" style="background: url(${photoWallList[i]}) center center / contain no-repeat rgb(255, 255, 255);" hidden></li>`;
            }

            $('.viewImage').html(html).show();
            $(`.viewImage>li:nth-child(${index})`).show();
            $('.wrapper').css('overflow','hidden');

            touchmove();
        });

        function eachUnit(photoWallList) {
            PAGE_STATE.photoWallList = photoWallList;
            let html = ``;
            for (let i in photoWallList){
                html += `<div class="swiper-slide" ><img src="${photoWallList[i]}" data-index="${parseInt(i)+1}" /></div>`;
            }
            return html;
        }

        function touchmove() {
            let startX, moveEndX, moveDistance;
            $('.viewImage>li').on({
                touchstart: function(e){
                    e.preventDefault();
                    startX = e.originalEvent.changedTouches[0].pageX;
                },
                touchmove: function(e){
                    e.preventDefault();
                    moveEndX = e.originalEvent.changedTouches[0].pageX;
                    moveDistance = moveEndX - startX;
                },
                touchend: function(e){
                    e.preventDefault();
                    let index = parseInt($(this).attr('data-index'));
                    let length = $('.viewImage>li').length;

                    if (moveDistance > 0){               //-- 向左滑动
                        if (index == 0) return;
                        $(this).hide().prev().show();
                    } else if (moveDistance < 0){        //-- 向右滑动
                        if (index == length-1) return;
                        $(this).hide().next().show();
                    }
                },
            });
        }
    }

    /**
     * 根据名片id查询访客记录
     * @Author 吴成林
     * @Date 2020-7-8 15:06:14
     */
    function getCardVisitList() {
        $$.request({
            url: UrlConfig.management_mybusinesscardvisit_getCardVisitList,
            pars: {
                businessCardId: PAGE_STATE.visitingCardId
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    const visitList = data.datas.visitList;
                    if ($$.isValidObj(visitList)){
                        $(".visitor").css('display', 'flex');
                        let html = ``;
                        for (let i in visitList){
                            if (parseInt(i) < 3){
                                html += `<img src="${visitList[i].imgPath ? visitList[i].imgPath : `../../../images/my/defaultImg.png`}" style="z-index: ${100+parseInt(i)}; left: ${2+parseInt(i)*8}%;" />`;
                            }
                        }
                        $('.visitorHeadPortrait').html(html);
                        if (PAGE_STATE.memberId === 'uRS0KHybBDo=') {
                            visitList.length = 2000;
                        }
                        $('.visitorNumber').text(visitList.length);
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 删除动态
     * @Author 吴成林
     * @Date 2020-7-8 15:06:14
     */
    function removeDynamic(obj) {
        const id = $(obj).attr('data-id');
        $$.request({
            url: UrlConfig.management_mybusinesscarddyn_updateCardDynIsenabled,
            pars: {id},
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.reload();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 点赞动态
     * @Author 吴成林
     * @Date 2020-7-8 15:06:14
     */
    function praiseDynamic(obj) {
        const id = $(obj).parents('.personalDynamicUnit').attr('data-id');
        const praiseSum = $(obj).children('span').text();
        $$.request({
            url: UrlConfig.management_mybusinesscarddyn_updateCardDynPraiseCount,
            pars: {id},
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $$.layerToast("感谢您的点赞~");
                    $(obj).children('img').attr('src', '../../../images/my/newMyVisitingCard/like.png');
                    $(obj).children('span').text(parseInt(praiseSum)+1);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 点赞评论
     * @Author 吴成林
     * @Date 2020-7-9 12:10:58
     */
    function praiseComment(obj) {
        const id = $(obj).parents('.commentUnit').attr('data-id');
        const praiseSum = $(obj).children('div').text();
        $$.request({
            url: UrlConfig.management_mybusinesscardcomment_updateCommentPraiseCount,
            pars: {id},
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $$.layerToast("感谢您的点赞~");
                    $(obj).children('img').attr('src', '../../../images/my/newMyVisitingCard/like.png');
                    $(obj).children('div').text(parseInt(praiseSum)+1);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 新增动态评论
     * @Author 吴成林
     * @Date 2020-7-8 21:17:23
     */
    function submitComments() {
        const {commentsList} = PAGE_STATE
        $$.request({
            url: UrlConfig.management_mybusinesscardcomment_save,
            pars: {...commentsList},
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $('.comments>textarea').val('');
                    dataLoading();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 图片墙 - swiper轮播视图
     * @Author 吴成林
     * @Date 2020-7-9 12:10:58
     */
    function swiper() {
        new Swiper('.photoWallContainer', {
            observer: true,
            observeParents: true,
            watchSlidesProgress: true,
            slidesPerView: 'auto',
            centeredSlides: true,
            loop: true,
            autoplay: {
                disableOnInteraction: false,
                delay: 2000,
            },
            loopedSlides: 5,
            on: {
                progress: function(progress) {
                    for (i = 0; i < this.slides.length; i++) {
                        let slide = this.slides.eq(i);
                        let slideProgress = this.slides[i].progress;
                        modify = 1;
                        if (Math.abs(slideProgress) > 1) {
                            modify = (Math.abs(slideProgress) - 1) * 0.3 + 1;
                        }
                        translate = slideProgress * modify * 20 + '%';
                        scale = 1 - Math.abs(slideProgress) / 5;
                        zIndex = 999 - Math.abs(Math.round(10 * slideProgress));
                        slide.transform('translateX(' + translate + ') scale(' + scale + ')');
                        slide.css('zIndex', zIndex);
                        slide.css('opacity', 1);
                        if (Math.abs(slideProgress) > 3) {
                            slide.css('opacity', 0);
                        }
                    }
                },
                setTransition: function(transition) {
                    for (let i = 0; i < this.slides.length; i++) {
                        let slide = this.slides.eq(i)
                        slide.transition(transition);
                    }
                }
            }
        });
    }

    /**
     * 分享名片 (加载数据成功后调用)
     */
    function shareWeeklyLuckyDraw() {
        if (!$WeChat.isWx() && !PAGE_APP) {
            return;
        }
        const {memberId, shareDatums} = PAGE_STATE;
        let _lineLink = $$.getFullHost() + '/src/pages/my/newMyVisitingCard/myVisitingCard.html';
        /* 是否带参 */
        _lineLink += $$.jsonToUrlParams({
            memberId: memberId
        });

        PAGE_STATE.shareDatums.url = _lineLink;      //-- 保存分享参数

        weChatJSTool.share({
            _imgUrl:  $$.isValidHeadImg(shareDatums.image),
            _lineLink:  _lineLink,
            _shareTitle: shareDatums.title,
            _descContent: shareDatums.content,
            _sfn: function () {
                $$.share(entityId,2);
                $$.layerToast("分享成功~");
            }
        });
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-5-14 20:56:12
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;
            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            //-- 分享
            $$.showShareView('点击右上角,分享名片给好友！');
        }
    }

    /**
     * 页面授权 获取微信用户opanID
     */
    function getSpenID(){
        //-- 根据weChatOpenId查询用户状态 {有：自动登录，没有：用户授权获取用户微信消息保存并去注册}
        const weChatOpenId = $$.getUrlParam("weChatOpenId");
        if($$.isValidObj(weChatOpenId)){
            $$.request({
                url: UrlConfig.member_weixinbase_findOpenId,
                pars:{
                    openId: weChatOpenId
                },
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        const {totalCount, weixinId, memberId, responseEntity} = data.datas;
                        if(totalCount === 0){
                            //-- 微信页面授权
                            weChatAuthorize();
                        }else{
                            if ($$.isValidObj(responseEntity)){
                                //-- 自动登录后，保存token和memberId，清除手动退出登录的Key
                                const token = responseEntity.body[ShawHandler.constant.tokenKey];

                                if(ShawHandler.isValidObj(token)){
                                    localStorage.setItem(ShawHandler.constant.tokenKey, token);
                                }
                                localStorage.removeItem($Constant.weChatUserManualExitKey);
                            }

                            if ($$.isValidObj(memberId)){
                                PAGE_STATE.visitorId = memberId;
                                PAGE_STATE.memberType = 0;
                            } else{
                                PAGE_STATE.visitorId = weixinId;
                                PAGE_STATE.memberType = 1;
                            }

                            $('.makeBusinessCards').show();
                            PAGE_STATE.shareState = 'true';
                            gotoMyTeam();
                            pageInit();                 // 加载页面
                        }
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
            return;
        } else {
            //-- 静默授权获取openID
            $$.loading('授权中~')
            $$.request({
                url: UrlConfig.weChat_authorize,
                pars: {
                    authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10001,
                    returnUrl: "my/newMyVisitingCard/myVisitingCard.html?memberId=" + PAGE_STATE.memberId,
                    businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_4
                },
                sfn: function(data){
                    ShawHandler.closeLoading();
                    if(data.success){
                        location.href = data.datas;
                    }else {
                        ShawHandler.alert(data.msg);
                    }
                }
            });
        }

        //-- 微信页面授权
        function weChatAuthorize() {
            $$.request({
                url: UrlConfig.weChat_authorize,
                pars: {
                    authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                    returnUrl: "my/newMyVisitingCard/myVisitingCard.html?memberId=" + PAGE_STATE.memberId,
                    businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_2,
                },
                loading: true,
                sfn: function(data){
                    ShawHandler.closeLoading();
                    if(data.success){
                        location.href = data.datas;
                    }else {
                        ShawHandler.alert(data.msg);
                    }
                }
            });
        }

    }

    /**
     * 新增访客记录
     * @Author 吴成林
     * @Date 2020-7-13 15:06:49
     */
    function saveVisitorRecord() {
        const {visitorId, memberType, visitingCardId} = PAGE_STATE;
        $$.request({
            url: UrlConfig.management_mybusinesscardvisit_save,
            pars: {
                memberId: visitorId,
                memberType: memberType,
                businessCardId: visitingCardId
            },
            requestBody: true,
            sfn: function (data) {
                if (data.success) {

                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 加载团队状态
     * @Author 吴成林
     * @Date 2020-7-14 15:36:24
     */
    function gotoMyTeam(){
        $$.request({
            url: UrlConfig.market_teammember_getTeamMember,
            pars:{
                memberId: PAGE_STATE.memberId
            },
            requestBody:true,
            sfn: function (data) {
                if (data.success) {
                    let teamId = data.teamId;
                    if (!$$.isValidObj(teamId)) $('.teamDynamic').hide();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 判断缓存是否是当天
     * @Params (String) labelKey = keyName+id, imgState
     * @Author 吴成林
     * @Date 2020-7-16 17:40:16
     */
    let localCache = (labelKey, imgState) => {
        //-- 本地缓存
        let returnValue = false;
        const cacheKey = "WX_VISITING_CARD_TIME_" + labelKey;
        const defaultValue = $Date.dateFormat(new Date());

        let cacheTime = localStorage.getItem(cacheKey);
        const hasCache = $$.isValidObj(cacheTime);
        if (hasCache){
            if (cacheTime === defaultValue){
                returnValue = true;
            } else {
                if (!imgState) localStorage.setItem(cacheKey, defaultValue);
            }
        } else{
            if (!imgState) localStorage.setItem(cacheKey, defaultValue);
        }
        return returnValue;
    };
}
