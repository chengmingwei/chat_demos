//var id;
window.onload = function(){
	//数据统计
	try {
		countAction('xb_81', null);
	} catch (error) {
		console.log(error);
	}

	/* 加载日期控件 */
	dateControls();

	window.addEventListener('pageshow', function(event) {
		console.log("PageShow Event  " + event.persisted);
		console.log(event)
	})
	
	/* 获取当前时间和星期 */
	var myDate = localTime();
	var week = getMyDay(myDate);
	$('.week').html(week);
	
};

/* 日期控件 */
function dateControls(){
    $$.request({
        url: UrlConfig.member_logcontet_logListAll,
        method: "GET",
        sfn: function (data) {
            if (data.success) {
            	console.log(data);
            	let arr = {};
            	/* 插入日志内容标点 */
            	for(let i=0; i<data.datas.length; i++){
			  		let key = `${data.datas[i].logDate}`;
					let value = '';
	        		arr[key] = value;
				}
            	/* 日期组件 */
               	laydate.render({
				  	elem: '.dateControls'
				  	,position: 'static'
				  	,theme: '#5677FC'
				  	,showBottom: false
				  	,format: 'yyyy.MM.dd'
				  	,circleMark: true
				  	,mark: arr
				  	,ready: function(date){
        				addContent(data,date);
					}
				  	,change: function(value, date){ //监听日期被切换
				  		console.log(value +date);
				    	lay('.date').html(value);
				    	let week = getMyDay(new Date(value));
				    	lay('.week').html(week);
				    	addContent(data,date);
				  	}
				});
            } else {
                $$.layerToast(`获取日志内容失败！[${data.msg}]`);
            }
        }
    });
    /* 插入日志内容 */
   	function addContent(data,date){
    	if($(".layui-this").children().hasClass("laydate-day-mark")){
			for(let i=0; i<data.datas.length; i++){
		  		let dates = data.datas[i].logDate;
		  		let present_dates = date.year +"-"+ (date.month<10?"0"+date.month:date.month) +"-"+ (date.date<10?"0"+date.date:date.date);
		  		if(present_dates == dates){
		  			let id = data.datas[i].id;
		  			let workLogId = data.datas[i].workLogId;
		  			$(".wrapper").attr("data-id",workLogId);
		  			$(".content").text(data.datas[i].content);
					$(".writeLog").css("display","none");
					$(".editLog").css("display","block");
					
					let content_have = $(".content").text();
					let date_have = $(".date").text();
					let week_have = $(".week").text();

					//-- 本地缓存
					const cacheKey = "WX_workLog_DATA";
					localStorage.setItem(cacheKey, content_have);
					
					/* 编辑日志 绑定点击页面跳转事件 */
					$(".editLog").on("click",function(){
						$$.push("my/editLog",{"id":id,"workLogId":workLogId,"date":date_have,"week":encodeURI(encodeURI(week_have)), "contentStatus":"true"});
					})
				}
			}
		}else{
			$(".content").text("无");
			$(".writeLog").css("display","block");
			$(".editLog").css("display","none");
			let content_have = $(".content").text();
			let date_have = $(".date").text();
			let week_have = $(".week").text();
			for(let i=0; i<data.datas.length; i++){
				let workLogId = data.datas[i].workLogId;
		  		$(".wrapper").attr("data-id",workLogId);
		  		/* 写日志 绑定点击页面跳转事件 */
				$(".writeLog").on("click",function(){
					$$.push("my/editLog",{"workLogId":workLogId,"date":date_have,"week":encodeURI(encodeURI(week_have))});
				})
			}
		}
    }
}
function localTime(){
	let myDate = new Date();
    let year = myDate.getFullYear(); 														//获取当前年
    let mon = myDate.getMonth()+1<10 ? "0"+(myDate.getMonth()+1) : (myDate.getMonth()+1); 	//获取当前月
	let date = myDate.getDate()<10 ? "0"+myDate.getDate() : myDate.getDate();               //获取当前日
	let h = myDate.getHours()<10 ? "0"+myDate.getHours() : myDate.getHours();       		//获取当前小时数(0-23)
	let m = myDate.getMinutes()<10 ? "0"+myDate.getMinutes() : myDate.getMinutes(); 		//获取当前分钟数(0-59)
	let s = myDate.getSeconds()<10 ? "0"+myDate.getSeconds() : myDate.getSeconds(); 		//获取当前秒
    
    let now = year+"."+mon+"."+date;	//当前时间 (2019.10.08)
    $('.date').html(now);		
    
    return myDate;
}
function getMyDay(date){
	let week;
	if(date.getDay()==0) week="周日"
	if(date.getDay()==1) week="周一"
	if(date.getDay()==2) week="周二"
	if(date.getDay()==3) week="周三"
	if(date.getDay()==4) week="周四"
	if(date.getDay()==5) week="周五"
	if(date.getDay()==6) week="周六"
	return week;
}