window.onload = function () {
    $$.changeVersion();
    fadadaAuthResult();
};
function fadadaAuthResult() {
    // let fadadaName = $$.getUrlParam("personName");
    // if (!fadadaName) {
    //     fadadaName = $$.getUrlParam("companyName");
    // }
    // fadadaName = decodeURIComponent(fadadaName);
    let transactionNo = $$.getUrlParam("transactionNo");
    let authenticationType = $$.getUrlParam("authenticationType");
    let status = $$.getUrlParam("status");
    let statusStr = '';
    if (authenticationType === '1') {
        statusStr = personStatusStr(status);
    } else {
        statusStr = companyStatusStr(status);
    }
    if ((authenticationType === '1' && status === '2') ||
        (authenticationType === '2' && status === '4')) {
        fadada_applyCert(transactionNo);
    } else {
        let onOk = function() {
            if (PAGE_APP){
                $$.pushAPP("/main", {
                    "defaultPageIndex": 3,
                });
            } else {
                $$.push("my/personalCenter-verified");
            }
        };
        if ((authenticationType === '1' && status === '4') ||
            (authenticationType === '2' && status === '5')) {
            onOk = function() {
                if (PAGE_APP){
                    $$.pushAPP("/certification/userInfoPage");
                } else {
                    $$.push("my/basicInformation");
                }
            }
        } else {
            statusStr = statusStr + '，请稍后再去认证';
            $('.content').html(statusStr);
            $('.remark').html('&nbsp;');
        }
        $('.bg').css('display','flex');
        $('.btn').on('click',onOk);
    }
}
function personStatusStr(status) {
    let statusStr = '未激活';
    switch (status) {
        case '1':
            statusStr = '未认证';
            break;
        case '2':
            statusStr = '审核通过';
            break;
        case '3':
            statusStr = '已提交待审核';
            break;
        case '4':
            statusStr = '审核不通过';
            break;
    }
    return statusStr;
}
function companyStatusStr(status) {
    let statusStr = '未认证';
    switch (status) {
        case '1':
            statusStr = '管理员资料已提交';
            break;
        case '2':
            statusStr = '企业基本资料(没有申请表)已提交';
            break;
        case '3':
            statusStr = '已提交待审核';
            break;
        case '4':
            statusStr = '审核通过';
            break;
        case '5':
            statusStr = '审核不通过';
            break;
        case '6':
            statusStr = '人工初审通过';
            break;
    }
    return statusStr;
}
function fadada_applyCert(transactionNo) {
    $$.request({
        url: UrlConfig.member_fadada_applyCert,
        pars: {
            transactionNo: transactionNo
        },
        requestBody:true,
        sfn: function(data) {
            let content = '申请证书失败，请重新申请';
            let onOk = function () {
                if (PAGE_APP){
                    $$.pushAPP("/certification/userInfoPage");
                } else {
                    $$.push("my/basicInformation");
                }
            };
            if(data.success) {//成功申请证书
                content = '基本信息认证成功';
                onOk = function () {
                    if (PAGE_APP){
                        $$.pushAPP("/certification/qualificationTestPage");
                    } else {
                        $$.push("my/qualificationTest");
                    }
                };
                $('.remark').html('&nbsp;');
                $('.btn').html('开始答题');
                $('.icon').attr('src','../../images/my/authTrueIcon.png');
            }
            $('.content').html(content);
            $('.bg').css('display','flex');
            $('.btn').on('click',onOk);
        },
        ffn: function(data) {
            $$.errorHandler();
        }
    });
}
