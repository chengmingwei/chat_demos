/**
 * 转载文章详情 JS
 * @Author 吴成林
 * @Date 2020-3-2 10:16:56
 */
const PAGE_STATE = {
    switchState: undefined,                      // 是否显示名片
    id:undefined,
    memberId:undefined,
    wxQRCode:undefined,
    insuranceIds:new Array(), //产品id
    viewWidth: 0,                   // 页面视图宽度
    viewHeight: 0,                  // 页面视图高度
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: 'hi，这篇文章很有意思哦，快来一起学习吧'
    }
};

$(function () {

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        PAGE_STATE.id = $$.getUrlParam("id");
        PAGE_STATE.switchState = $$.getUrlParam("switchState");
        dataLoading();

        eventBinding();
        $(".articleContent").addClass("contentHeight");

        //-- 适配移动端 全屏宽高
        PAGE_STATE.viewWidth = window.innerWidth || document.documentElement.clientWidth;
        PAGE_STATE.viewHeight = window.innerHeight || document.documentElement.clientHeight;
        $('.contentHeight').css("max-height", PAGE_STATE.viewHeight/2+'px');
    }

    /**
     * 数据加载
     */
    function dataLoading(){
       loadData();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){

        $(".unfold").on("click", function(){
            $("#content").removeClass("contentHeight");
            $('.articleContent').css("max-height", "100%");
            $(".unfold").hide()
        });
        //-- 添加推荐产品
        $(".addRecommendedProducts").on("click", function(){
            $(".selectRecommendedProducts").show();
        });


        //-- 添加推荐产品 - 取消
        $(".bottomCancel").on("click", function(){
            $(".selectRecommendedProducts").hide();
        });

        //-- 添加推荐产品 - 选中
        $(".bottomSelected").on("click", function(){

            $(".selectRecommendedProducts").hide();

            //-- 加载推荐产品列表
            const arrays = $(".list li div.selected");
            const ids = new Array();
            for(let i = 0; i < arrays.length; i++){
                ids.push($(arrays[i]).attr("data-sellId"))
            }
            PAGE_STATE.insuranceIds = ids;
            updateProductIds();
            loadProducts();
        });


        //-- 立即分享
        $(".shareImmediately").on("click", function(){
            shareHandler();
        });

    }

    //window.setInterval("", 200);
});
/**
 * 描述信息：加载数据
 * @author 覃创斌
 * @date 2020/3/5
*/
function loadData() {
    $$.request({
        url: UrlConfig.reprintarticle_getReprintArticleById,
        pars:{
            id:PAGE_STATE.id
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                PAGE_STATE.memberId = data.articleMemberId;
                PAGE_STATE.shareDatums.title = data.reprintArticle.articleTitle;
                $('title').html(PAGE_STATE.shareDatums.title);
                const productIds = data.reprintArticle.productIds;
                if ($$.isValidObj(productIds)) {
                    const productIdsArr = productIds.split(',');
                    const ids = new Array();
                    for(let i = 0; i < productIdsArr.length; i++){
                        ids.push(productIdsArr[i]);
                    }
                    PAGE_STATE.insuranceIds = ids;
                }
                if (PAGE_STATE.insuranceIds.length > 0) {
                    loadProducts();
                }
                $(".articleContent").html(data.htmlJson.result);
                $$.closeLoading();
                let switchState = $$.getUrlParam("switchState");
                loadMemberCard();
                if (!(switchState === "true")){
                    $(".articleTop").hide()
                }
                insertReprintRecord();
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

}
function loadMemberCard() {
    $$.request({
        url: UrlConfig.myBusinessCard_getMyBusinessCardByMemberId,
        pars:{
            memberId:PAGE_STATE.memberId
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                PAGE_STATE.wxQRCode = data.wxQRCode;
                if ($$.isValidObj(data.phone) && $$.isValidObj(data.rname) && $$.isValidObj(data.wxQRCode)){
                    /* 找客服 二维码 绑定事件 */
                    $(".weChat").on("click", function(){
                        const index = layer.open({
                            content:
                                `<div class="popupContent">
                                    <div class="question">
                                        <b>扫描下方二维码，添加微信好友</b>
                                        <img src="`+PAGE_STATE.wxQRCode+`" />
                                        <span>长按识别二维码</span>
                                    </div>
                                </div>`
                        });
                    });
                    $(".name").html(data.rname);
                    PAGE_STATE.shareDatums.image = data.imgPath;
                    $(".userIcon").attr("src",data.imgPath);
                    $(".call").parent().attr("href","tel:"+data.phone);
                    sharePosters();
                }else {
                    $(".articleTop").hide()
                }

            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function updateProductIds() {
    let ids = '';
    if (PAGE_STATE.insuranceIds.length > 0){
        ids = PAGE_STATE.insuranceIds.join(",");
    }
    $$.request({
        url: UrlConfig.reprintarticle_updateReprintArticleById,
        pars:{
            id:PAGE_STATE.id,
            ids:ids
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {

            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
/*function setIframeHeight(iframe) {
    if (iframe) {
        let iframeWin = iframe.contentWindow || iframe.contentDocument.parentWindow;
        if (iframeWin.document.body) {
            iframe.height = iframeWin.document.documentElement.scrollHeight || iframeWin.document.body.scrollHeight;
        }
    }
}*/
function insertReprintRecord() {
    $$.request({
        url: UrlConfig.reprintrecord_insertReprintRecord,
        pars:{
            id:PAGE_STATE.id
        },
        requestBody:true,
        sfn: function (data) {
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
/**
 * 分享名片 (加载数据成功后调用)
 */
function sharePosters() {
    if (!$WeChat.isWx() && !PAGE_APP) {
        return;
    }
    let _lineLink = $$.getFullHost() + '/src/pages/my/shareArticleDetails.html';
    /* 是否带参 */
    _lineLink += $$.jsonToUrlParams({
        share:true,
        id:PAGE_STATE.id,
        switchState:PAGE_STATE.switchState,
        ids:PAGE_STATE.insuranceIds.join(","),
        memberId:PAGE_STATE.memberId
    });
    PAGE_STATE.shareDatums.url = _lineLink;
    const {image, title, content } = PAGE_STATE.shareDatums;
    weChatJSTool.share({
        _imgUrl:  image,
        _lineLink:  _lineLink,
        _shareTitle: title,
        _descContent: content,
        _sfn: function () {
            $$.layerToast("分享成功~");
            $$.share(PAGE_STATE.id,3);
        }
    });
}

function loadProducts() {
    $$.request({
        url: UrlConfig.reprintarticle_getInsuranceInfoList,
        pars:{
            insuranceType:1,
            insuranceInfoIds:PAGE_STATE.insuranceIds.join(",")
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let resultHtml = "";
                for (let i = 0; i < data.list.length; i++) {
                    resultHtml += "<li data-id=\"" + data.list[i].insuranceInfoId + "\" data-sellid=\"" + data.list[i].id + "\">";
                    resultHtml += "	<span class=\"left productImage\" style=\"background-image: url(" + data.list[i].listShowCover + "\"></span>";
                    resultHtml += "	<div class=\"right\">";
                    resultHtml += "		<div class=\"top\">";
                    resultHtml += "			<h3>" + data.list[i].name + "</h3>";
                    resultHtml += "			<p class=\"icon\" style=\"\">";
                    // resultHtml += "				<span>线上投保</span><span>智能核保</span>";
                    resultHtml += "			</p>";
                    resultHtml += "			<p class=\"desc\">" + data.list[i].productIntroduce + "</p>";
                    resultHtml += "		</div>";
                    resultHtml += "		<div class=\"bottom\">";
                    resultHtml += "			<p class=\"price\">" + data.list[i].moeny + ".00元起</p>";
                    resultHtml += "			<div class=\"deleteProduct\" data-sellid=\"" + data.list[i].id + "\"><img src=\"../../images/my/posters/articleDetails-4.png\"></div>";
                    resultHtml += "		</div>";
                    resultHtml += "	</div>";
                    resultHtml += "</li>";
                }
                $(".productsList").html(resultHtml);

                //-- 删除推荐产品
                $(".deleteProduct").off().on("click", function (e) {
                    e.stopPropagation();
                    // 查找指定的元素在数组中的位置
                    Array.prototype.indexOf = function (val) {
                        for (let i = 0; i < this.length; i++) {
                            if (this[i] == val) {
                                return i;
                            }
                        }
                        return -1;
                    };
                    // 通过索引删除数组元素
                    Array.prototype.remove = function (val) {
                        let index = this.indexOf(val);
                        if (index > -1) {
                            this.splice(index, 1);
                        }
                    };
                    PAGE_STATE.insuranceIds.remove($(this).attr("data-sellid"));
                    $(this).parent().parent().parent().remove();
                    updateProductIds();
                });

                //-- 查看效果 - 文章详情
                $(".productsList li").off().on("click", function(){
                    const productId = $(this).attr("data-id"),
                        sellId = $(this).attr("data-sellId"),
                        uuid = $$.getTimeStampNow();
                    $$.push("product/productDetail", {productId, sellId, uuid});
                });
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

/**
 * 分享处理(APP和H5)
 * @Author 吴成林
 * @Date 2020-5-14 20:56:12
 */
function shareHandler(){
    if(PAGE_APP){
        //-- APP
        const { shareDatums } = PAGE_STATE;
        console.log(shareDatums);
        const params = {bussType: 10001, ...shareDatums};
        $$.postAPP(10002, params);
    }else{
        //-- 分享
        $$.showShareView();
    }
}
