/**
 * 文章详情 JS
 * @Author 吴成林
 * @Date 2020-3-2 10:16:56
 */
const PAGE_STATE = {
    switchState: undefined,                      // 是否显示名片
    id: undefined,
    memberId: undefined,
    wxQRCode: undefined,
    ids: undefined,
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: 'hi，这篇文章很有意思哦，快来一起学习吧'
    },
    weChatOpenId: undefined,
    articleMemberId: undefined
};
$(function () {

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
        $$.setReadLongTimes();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        PAGE_STATE.id = $$.getUrlParam("id");
        PAGE_STATE.switchState = $$.getUrlParam("switchState");
        PAGE_STATE.ids = $$.getUrlParam("ids");
        PAGE_STATE.weChatOpenId = $$.getUrlParam("weChatOpenId");
        PAGE_STATE.memberId = $$.getUrlParam("memberId");
        PAGE_STATE.share = $$.getUrlParam("share");
        dataLoading();

        eventBinding();
        $(".articleContent").addClass("contentHeight")
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        if ($$.isValidObj(PAGE_STATE.share) && PAGE_STATE.share === 'true'){//点击分享地址后先获取weChatOpenId
            checkShare();
        } else {
            loadData();
        }
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        $(".unfold").on("click", function(){
            $("#content").removeClass("contentHeight");
            $('.articleContent').css("max-height", "100%");
            $(".unfold").hide();
        });

        //-- 立即分享
        $(".shareImmediately").on("click", function(){
            shareHandler();
        });
    }
});
/**
 * 描述信息：加载数据
 * @author 覃创斌
 * @date 2020/3/5
 */
function  loadData() {
    $$.request({
        url: UrlConfig.reprintarticle_getReprintArticleById,
        pars:{
            id: PAGE_STATE.id,
            weChatOpenId: PAGE_STATE.weChatOpenId
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $(".articleContent").html(data.htmlJson.result);
                PAGE_STATE.articleMemberId = data.articleMemberId;
                PAGE_STATE.shareDatums.title = data.reprintArticle.articleTitle;
                $('title').html(PAGE_STATE.shareDatums.title);
                if (!$$.isValidObj(PAGE_STATE.ids) && $$.isValidObj(data.reprintArticle.productIds)) {
                    PAGE_STATE.ids = data.reprintArticle.productIds;
                }
                loadProducts();
                const weChatOpenId = data.weChatOpenId;
                insertBrowse(PAGE_STATE.id,PAGE_STATE.memberId,PAGE_STATE.weChatOpenId,weChatOpenId);//添加浏览记录
                $$.closeLoading();
                let switchState = $$.getUrlParam("switchState");
                const isShow = data.reprintArticle.isShow;
                if (switchState == "true" || ($$.isValidObj(isShow) && isShow === 1)){
                    loadMemberCard();
                }else {
                    $(".articleTop").hide()
                }
                const memberId = data.memberId;//当前用户
                if ($$.isValidObj(memberId)){
                    PAGE_STATE.memberId = memberId;
                    PAGE_STATE.shareDatums.image = data.imgPath;
                } else {
                    if ($$.isValidObj(data.weChatOpenId)) {
                        PAGE_STATE.shareDatums.image = data.headimgurl;
                    }
                }
                sharePosters();
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

}
/**
 * 描述信息：加载名片
 * @author 覃创斌
 * @date 2020/3/5
*/
function loadMemberCard() {
    $$.request({
        url: UrlConfig.myBusinessCard_getMyBusinessCardByMemberId,
        pars:{
            memberId:PAGE_STATE.articleMemberId
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            if (data.success) {
                PAGE_STATE.wxQRCode = data.wxQRCode;
                if (data.phone != undefined && data.rname != undefined && data.wxQRCode != undefined){
                    /* 找客服 二维码 绑定事件 */
                    $(".weChat").on("click", function(){
                        const index = layer.open({
                            content:
                                `<div class="popupContent">
                                    <div class="question">
                                        <b>扫描下方二维码，添加微信好友</b>
                                        <img src="`+PAGE_STATE.wxQRCode+`" />
                                        <span>长按识别二维码</span>
                                    </div>
                                </div>`
                        });
                    });
                    $(".name").html(data.rname);
                    $(".userIcon").attr("src",data.imgPath);
                    $(".call").parent().attr("href","tel:"+data.phone);
                }else {
                    $(".articleTop").hide()
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
/**
 * 描述信息：加载产品
 * @author 覃创斌
 * @date 2020/3/5
*/
function loadProducts() {
    console.log(PAGE_STATE.ids);
    if (PAGE_STATE.ids != undefined || PAGE_STATE.ids != ""  || PAGE_STATE.ids != null){
        $$.request({
            url: UrlConfig.reprintarticle_getInsuranceInfoList,
            pars:{
                insuranceType:1,
                insuranceInfoIds:PAGE_STATE.ids
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    for (let i = 0; i < data.list.length; i++) {
                        resultHtml += "<li data-id=\"" + data.list[i].insuranceInfoId + "\" data-sellid=\"" + data.list[i].id + "\">";
                        resultHtml += "	<span class=\"left productImage\" style=\"background-image: url(" + data.list[i].listShowCover + "\"></span>";
                        resultHtml += "	<div class=\"right\">";
                        resultHtml += "		<div class=\"top\">";
                        resultHtml += "			<h3>" + data.list[i].name + "</h3>";
                        resultHtml += "			<p class=\"icon\" style=\"\">";
                        // resultHtml += "				<span>线上投保</span><span>智能核保</span>";
                        resultHtml += "			</p>";
                        resultHtml += "			<p class=\"desc\">" + data.list[i].productIntroduce + "</p>";
                        resultHtml += "		</div>";
                        resultHtml += "		<div class=\"bottom\">";
                        resultHtml += "			<p class=\"price\">" + data.list[i].moeny + ".00元起</p>";
                     //   resultHtml += "			<div class=\"deleteProduct\" data-sellid=\"" + data.list[i].id + "\"><img src=\"../../images/my/posters/articleDetails-4.png\"></div>";
                        resultHtml += "		</div>";
                        resultHtml += "	</div>";
                        resultHtml += "</li>";
                    }
                    $(".productsList").html(resultHtml);

                    //-- 查看效果 - 文章详情
                    $(".productsList li").on("click", function(){
                        const productId = $(this).attr("data-id"),
                            sellId = $(this).attr("data-sellId"),
                            uuid = $$.getTimeStampNow();
                        $$.push("product/productDetail", {productId, sellId, uuid});
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

}
function setIframeHeight(iframe) {
    if (iframe) {
        var iframeWin = iframe.contentWindow || iframe.contentDocument.parentWindow;
        if (iframeWin.document.body) {
            iframe.height = iframeWin.document.documentElement.scrollHeight || iframeWin.document.body.scrollHeight;
        }
    }
}

//微信授权登录
function checkShare() {
    console.log();
    let url = window.location.search;
    url = url.replace("true",'false');
    url = "my/shareArticleDetails.html"+url;
    console.log('----url',url);
    //type=5：素材库文章
    ShawHandler.request({
        url: UrlConfig.weChat_authorize,
        pars: {
            authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
            returnUrl: url,
            businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_6,
            otherParams: JSON.stringify({
                "objectId": PAGE_STATE.id,
                "type":5,
                "memberId":PAGE_STATE.memberId,
                'shareWeChatOpenId':PAGE_STATE.weChatOpenId
            })
        },
        loading: true,
        sfn: function(data){
            $$.closeLoading();
            location.href = data.datas;
        }
    });
}
/**
 * 分享名片 (加载数据成功后调用)
 */
function sharePosters() {
    if (!$WeChat.isWx() && !PAGE_APP) {
        return;
    }
    let _lineLink = $$.getFullHost() + '/src/pages/my/shareArticleDetails.html';
    /* 是否带参 */
    _lineLink += $$.jsonToUrlParams({
        share: true,
        id: PAGE_STATE.id,
        switchState: PAGE_STATE.switchState,
        ids: PAGE_STATE.ids,
        memberId: PAGE_STATE.memberId,
        weChatOpenId: PAGE_STATE.weChatOpenId
    });
    PAGE_STATE.shareDatums.url = _lineLink;
    const {image, title, content} = PAGE_STATE.shareDatums;
    weChatJSTool.share({
        _imgUrl: image,
        _lineLink: _lineLink,
        _shareTitle: title,
        _descContent: content,
        _sfn: function () {
            $$.layerToast("分享成功~");
            $$.share(PAGE_STATE.id,3);
        }
    });
}

/**
 * 分享处理(APP和H5)
 * @Author 吴成林
 * @Date 2020-5-14 20:56:12
 */
function shareHandler(){
    if(PAGE_APP){
        //-- APP
        const { shareDatums } = PAGE_STATE;
        console.log(shareDatums);
        const params = {bussType: 10001, ...shareDatums};
        $$.postAPP(10002, params);
    }else{
        //-- 分享
        $$.showShareView();
    }
}

/**
 * 描述信息：添加浏览记录
 * @author 覃创斌
 * @date 2019/10/12
 */
function insertBrowse(id,shareUserId,shareWeChatOpenId,weChatOpenId) {
    $$.request({
        url: UrlConfig.viewStatistic_insertViewStatistic,
        pars: {
            shareUserId:shareUserId,//分享用户memberId
            shareWeChatOpenId:shareWeChatOpenId,//分享用户微信OpenId
            weChatOpenId:weChatOpenId,//阅读用户微信OpenId
            type:8,
            objectId:id,
            judge:1
        },
        method: "POST",
        sfn: function (data) {
            console.log('--------------Audio');
            console.log(data);
        }
    });
}
