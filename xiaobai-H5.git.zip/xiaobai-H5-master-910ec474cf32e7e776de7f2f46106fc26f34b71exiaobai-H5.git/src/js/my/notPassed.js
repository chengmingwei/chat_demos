$(function(){
	//-- 匹配后台数据更新-原因
    $$.request({
        url: UrlConfig.memberdetail_detailsPageMemberDetail,
        sfn: function(data){
        	if (data.success) {
				console.log(data);
				data.datas.auditContent == "null"?$(".detail").text('登记信息上传有误'):$(".detail").text(data.datas.auditContent);
		    	//$(".detail").text(data.datas.remark);
		    }
        	/* 重新登记按钮 */
        	let causeDetail = $(".detail").text();
			if(causeDetail == "登记信息上传有误"){
				$(".re-registration").show();
			}
        }
    });
	
	/**----- 重新登记 事件绑定 ----**/
	$(".re-registration").on("click",function(){
		/* 跳转 */
		$$.push("my/professionalCertification");
	});
});
