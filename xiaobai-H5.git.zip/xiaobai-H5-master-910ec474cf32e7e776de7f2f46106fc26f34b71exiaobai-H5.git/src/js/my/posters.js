/**
 * 1.5版海报 JS
 * @Author 吴成林
 * @Date 2020-2-25 18:16:40
 */
let name = "推荐";
let filtrate =  "热门";//条件
let postersFiltrate = "海报作品";
let jsonMap = new Map();
let viewHeight = 0;         // 浏览器高度
let timeOutEvent = 0;
const PAGE_STATE = {
    whetherVIP: false,                  // 是否是VIP
    imgWidth: 0,                        // 图片宽度
    memberId: 0,                        // 用户ID
    imgPath:null,                       // 用户头像
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_6005', null);
    } catch (error) {
        console.log(error);
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        viewHeight = window.innerHeight || document.documentElement.clientHeight;    //-- 浏览器高度
        $('.container').height(viewHeight - 100);                   // 海报列表高度
        $('.leftAppBar').height(viewHeight - 50);                   // 海报左边标题高度
        $(".articleList").height(viewHeight - 130);                 // 文章列表高度
        $(".brochureContent>div").height(viewHeight - 85);          // 文章列表高度
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        $$.request({
            url: UrlConfig.market_getPosterList,
            pars:{
                name:"推荐",
                pvcount:"1"
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    if (data.datas.length !== 0){
                        for (let i = 0; i < data.datas.length; i++) {
                            resultHtml += "<div data-type='"+data.datas[i].type+"' data-id='"+data.datas[i].id+"' data-gvId='"+data.datas[i].gvid+"' data-title='推荐'>";
                            resultHtml += "	<div class=\"securityLayer\"></div>";
                            /*resultHtml += "	<img src=\""+data.datas[i].picpath+"\">";*/
                            /*resultHtml += " <div class='picpath'><img src=\""+data.datas[i].picpath+"\"></div>";*/
                            resultHtml += "<div class='picpath' style='background: #FFFFFF url("+data.datas[i].picpath+") no-repeat center / contain;'></div>";
                            resultHtml += "	<span class=\"overflow\">"+data.datas[i].title+"</span>";
                            resultHtml += "	<div class="+(data.datas[i].type === 1 || !$$.isValidObj(data.datas[i].type)?'freePosters':'vipPosters')+"></div>";
                            resultHtml += "</div>";
                        }
                        $(".postersList").html(resultHtml);
                        PAGE_STATE.imgWidth = $('.picpath').width();
                        $('.picpath').height(PAGE_STATE.imgWidth*1.78);
                        let map = new Map();
                        map.set("热门",data.datas);
                        jsonMap.set(map,map);
                        console.log(jsonMap);
                    }else {
                        $(".postersList").html(`<section class="noContent" style="width: 100%"></section>`);
                        $$.showNoResultView({
                            parentJqSelector: ".noContent",
                            msg: "暂无内容",
                        })
                    }
                    loadClickPush()

                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
        //-- VIP用户隐藏海报 - 免费和vip标识
        if (!PAGE_STATE.whetherVIP) {
            $('.freePosters').show();
            $('.vipPosters').show();
        }

        //-- 获取当前用户的VIP信息
        getVipData();

        //-- 用户信息
        memberDetailsPage();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 海报 - 左边导航栏
        $('.leftAppBar>.appBar').on('click', function () {
            $(this).addClass("appBarBg");
            $(this).siblings().removeClass("appBarBg");
            let ids = $(this).attr("href");
            let title = $(this).find("span").attr("data-title");
            let type = $(".postersTypeSelected").html();
            let top;
            let freeOrMember;
            if (type === "热门"){
                top = 1;
            }
            if (type === "最新"){
                top = "";
            }
            if (type === "免费"){
                freeOrMember = 1;
            }
            if (type === "会员专享"){
                freeOrMember = 2;
            }
            if (title !== "我的海报"){
                loadPostersList(title,top,freeOrMember,type);
            }else {
                let myType = $(".myPostersTypeSelected").html();
                let remark;
                if (myType === "收藏海报"){
                    remark = "2";
                }else {
                    remark = "1";
                }
                loadMyPostersList(remark,type,title);

            }

            $(`${ids}`).show();
            $(`${ids}`).siblings().hide();
        });

        //-- 海报 - 右边属性栏
        $('.postersType>div').on('click', function () {
            $(this).addClass("postersTypeSelected");
            $(this).siblings().removeClass("postersTypeSelected");

            $(this).addClass("myPostersTypeSelected");
            $(this).siblings().removeClass("myPostersTypeSelected");

            let ids = $(this).attr("href");
            let type = $(this).attr("data-name");
            let title = $(".appBarBg").find("span").html();

            let top;
            let freeOrMember;
            if (type === "热门"){
                top =1;
            }
            if (type === "最新"){
                top="";
            }
            if (type === "免费"){
                freeOrMember = 1;
            }
            if (type === "会员专享"){
                freeOrMember = 2;
            }
            if (title !== "我的海报"){
                loadPostersList(title,top,freeOrMember,type);
            }else {
                //查询我的海报
                let remark;
                if (type === "收藏海报"){
                    remark = "2";
                }else {
                    remark = "1";
                }
                loadMyPostersList(remark,type,title);
            }
            filtrate = type;
            $(`${ids}`).show();
            $(`${ids}`).siblings().hide();
        });

        //-- 制作海报
        $('.makePoster').on('click', function () {
            $$.push("my/makePosters");
        });

        //-- 转载文章
        $('.reprintedArticles').on('click', function () {
            $$.push("my/reprintedArticles");headline
        });

        //-- 更多好文
        $('.moreArticles').on('click', function () {
            $$.push("my/moreArticles");
        });

        //-- 分享记录
        $('.shareRecord').on('click', function () {
            $$.push("my/shareRecord");
        });

        //-- 宣传册 - 选择切换
        $('.brochureListSort>div').on('click', function () {
            $(this).css("color", "#334fca").siblings().css("color", "#000000");
            let name = $(this).html();
            if (name === "我的作品"){
                loadBrochureList();
                $(".myWorks").show();
                $(".brochureList").hide();
            }else {
                $(".myWorks").hide();
                $(".brochureList").show();
            }
        });

        //-- 宣传册 - 类型选择
        $('.dropdownContent>div').on('click', function () {
            let value = $(this).text();
            $(".brochureTypeValue").text(value);
            $(".dropdownContent").hide();
        });

        //-- 宣传册 - 类型菜单
        $('.brochureContent>div, .brochureListSort>div').on('click', function () {
            let brochureType = $(this).hasClass("brochureType");
            let dropdownContent = $(".dropdownContent");
            if (!brochureType){
                if (!dropdownContent.is(":hidden")){
                    dropdownContent.hide();
                }
            } else {
                if (!dropdownContent.is(":hidden")){
                    dropdownContent.hide();
                } else {
                    dropdownContent.show();
                }

            }
        });

        //-- 邀请函 - 详情
        $('.brochureUnit').on('click', function () {
            let pageType = $(this).attr("data-type");       //-- 0-邀请函，1-宣传册
            $$.push("my/brochure/brochureDetails", {
                "detailsType": pageType,
            });
        });

        //-- 使用模板
        $('.useTemplate').on('click', function (e) {
            e.stopPropagation();
            let pageType = $(this).parent().attr("data-type");       //-- 0-邀请函，1-宣传册
            $$.push("my/brochure/makeBrochure");
        });

        //-- 主题切换
        $('.headline').on('click', function () {
            $(this).css('font-size', '16px').siblings().css('font-size', '14px');
            let href = $(this).attr("href").toString();
            let index = $(this).attr("data-id");
            if ( index === '2'){
                loadHotArticle();
            }

            $(href).show().siblings().hide();

            sessionStorage.setItem("navigationIndex", index);
        });

        let index = sessionStorage.getItem("navigationIndex");
        if (index){
            index = parseInt(index);
            $(`.topTitle>div:nth-child(${index})`).click();
        }
    }
    /**
     * 描述信息：加载 列表
     * @author 覃创斌
     * @date 2020/2/27
     */
    function loadPostersList(title,top,freeOrMember,type) {
        $$.request({
            url: UrlConfig.market_getPosterList,
            pars:{
                name:title,
                pvcount:top,
                type:freeOrMember
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    if (data.datas.length !== 0){
                        for (let i = 0; i < data.datas.length; i++) {
                            resultHtml += "<div data-type='"+data.datas[i].type+"' data-id='"+data.datas[i].id+"' data-gvId='"+data.datas[i].gvid+"'  data-title='"+title+"'>";
                            resultHtml += "	<div class=\"securityLayer\"></div>";
                            /*resultHtml += "	<img src=\""+data.datas[i].picpath+"\">";
                            resultHtml += " <div class='picpath'><img src=\""+data.datas[i].picpath+"\"></div>";*/
                            resultHtml += "<div class='picpath' style='background: #FFFFFF url("+data.datas[i].picpath+") no-repeat center / contain;'></div>";
                            resultHtml += "	<span class=\"overflow\">"+data.datas[i].title+"</span>";
                            resultHtml += "	<div class="+(data.datas[i].type === 1 || !$$.isValidObj(data.datas[i].type)?"freePosters":"vipPosters")+"></div>";
                            resultHtml += "</div>";
                        }
                        $(".postersList").html(resultHtml);
                        $('.picpath').height(PAGE_STATE.imgWidth*1.78);

                        let map = new Map();
                        map.set(type,data.datas);
                        jsonMap.set(title,map);

                        console.log(jsonMap)
                    }else {
                        $(".postersList").html("");
                        $(".postersList").html(`<section class="noContent" style="width: 100%"></section>`);
                        $$.showNoResultView({
                            parentJqSelector: ".noContent" ,
                            msg: "暂无内容",
                        })
                    }
                } else {
                    $$.layerToast(data.msg);
                }
                loadClickPush();
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：加载我的海报列表
     * @author 覃创斌
     * @date 2020/2/27
     */
    function loadMyPostersList(remark,type,title) {
        $$.request({
            url: UrlConfig.market_getMyPosterList,
            pars:{
                type:remark
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    if (data.datas.length !== 0){
                        for (let i = 0; i < data.datas.length; i++) {
                            resultHtml += "<div data-type='"+data.datas[i].type+"' data-id='"+data.datas[i].id+"' data-gvId='"+data.datas[i].gvid+"' data-title='"+title+"'>";
                            resultHtml += "	<div class=\"securityLayer\"></div>";
                            /*resultHtml += "	<img src=\""+data.datas[i].picpath+"\">";
                            resultHtml += " <div class='picpath'><img src=\""+data.datas[i].picpath+"\"></div>";*/
                            resultHtml += "<div class='picpath' style='background: #FFFFFF url("+data.datas[i].picpath+") no-repeat center / contain;'></div>";
                            resultHtml += "	<span class=\"overflow\">"+data.datas[i].title+"</span>";
                            resultHtml += "	<div class="+(data.datas[i].type === 1 || !$$.isValidObj(data.datas[i].type)?"freePosters":"vipPosters")+"></div>";
                            resultHtml += "</div>";
                        }
                        $(".myPostersList").html(resultHtml);
                        $('.picpath').height(PAGE_STATE.imgWidth*1.78);

                        let map = new Map();
                        map.set(type,data.datas);
                        jsonMap.set(title,map)
                    }else {
                        $(".myPostersList").html("");
                        $(".postersList").html(`<section class="noContent" style="width: 100%"></section>`);
                        $$.showNoResultView({
                            parentJqSelector: ".noContent" ,
                            msg: "暂无内容",
                        })
                    }
                } else {
                    $$.layerToast(data.msg);
                }
                loadClickPush();
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：加载点击跳转和长按删除事件
     * @author 覃创斌
     * @date 2020/2/27
     */
    function loadClickPush() {
        //-- 海报详情 - 查看点击和长按删除事件
        $(".postersUnit>div").on({
            touchstart: function(e) {
                // 长按事件触发
                timeOutEvent = setTimeout(function() {
                    timeOutEvent = 0;
                    console.log($(e.currentTarget).attr("data-id"));
                    // 我的海报
                    let myPosters = $(e.currentTarget).parents("div.rightContent2").find(".myPostersTypeSelected").attr("data-name");
                    let posterId = $(e.currentTarget).attr("data-id");
                    let parentsExists = $(e.currentTarget).parents("div.rightContent2").hasClass("rightContent2");
                    if (parentsExists){
                        if (myPosters === "海报作品") {
                            $$.confirm({
                                title: "确定删除海报作品？",
                                onOkLabel: "确定",
                                onCancelLabel: "取消",
                                onOk: function(){
                                    $$.request({
                                        url: UrlConfig.market_deletePoster,
                                        pars:{
                                            id:posterId,
                                        },
                                        requestBody:true,
                                        loading: true,
                                        sfn: function (data) {
                                            $$.closeLoading();
                                            if (data.success) {
                                                loadMyPostersList("1","海报作品","我的海报");
                                                $$.layerToast(data.msg);
                                            } else {
                                                $$.layerToast(data.msg);
                                            }
                                        },
                                        ffn: function (data) {
                                            $$.errorHandler();
                                        }
                                    });
                                }
                            });

                        }else {
                            $$.confirm({
                                title: "确定取消已收藏？",
                                onOkLabel: "确定",
                                onCancelLabel: "取消",
                                onOk: function(){
                                    $$.request({
                                        url: UrlConfig.market_deleteMyPoster,
                                        pars:{
                                            id:posterId,
                                        },
                                        requestBody:true,
                                        loading: true,
                                        sfn: function (data) {
                                            $$.closeLoading();
                                            if (data.success) {
                                                loadMyPostersList("2","收藏海报","我的海报");
                                                $$.layerToast(data.msg);
                                            } else {
                                                $$.layerToast(data.msg);
                                            }
                                        },
                                        ffn: function (data) {
                                            $$.errorHandler();
                                        }
                                    });
                                }
                            });
                        }
                    }
                }, 500);
            },
            touchmove: function() {
                clearTimeout(timeOutEvent);
                timeOutEvent = 0;
            },
            touchend: function(e) {
                clearTimeout(timeOutEvent);
                if (timeOutEvent !== 0) {
                    let postersType = $(this).attr("data-type");
                    if (!PAGE_STATE.whetherVIP && postersType === "2") {
                        $$.confirm({
                            title: "该海报为会员海报，开通会员即可免费使用全场海量海报，每月定时更新~",
                            onOkLabel: "去开通",
                            onCancelLabel: "取消",
                            onOk: function(){
                                //-- 去开通VIP
                                $$.push('my/purchaseVIP/purchaseVIP');
                            }
                        });
                        return;
                    }
                    let gvid = $(this).attr("data-gvId");
                    let id = $(this).attr("data-id");
                    let title = $(this).attr("data-title");
                    console.log(title);
                    console.log(filtrate);
                    $$.push("my/postersDetails",
                        {
                            id:id,
                            share:false,
                            filtrate:encodeURI(encodeURI(filtrate)),
                            gvid:gvid,
                            title:encodeURI(encodeURI(title))
                        }
                    );
                }
                return false;
            }
        });
    }
    /**
     * 描述信息：加载热门文章
     * @author 覃创斌
     * @date 2020/3/5
     */
    function loadHotArticle() {
        $$.request({
            url: UrlConfig.article_getArticleList,
            pars:{},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                let resultHtml = "";
                if (data.success){
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "<li class=\"articleDetails\">";
                        resultHtml += "	<div class=\"articleContent space-between\" data-id='"+data.datas[i].id+"'>";
                        resultHtml += "		<div>";
                        resultHtml += "			<div class=\"overflow\">"+data.datas[i].title+"</div>";
                        resultHtml += "			<div class=\"articleContentCount flex-start\">";
                        resultHtml += "				<div class=\"articleType\">"+data.datas[i].classifyname+"</div>";
                        resultHtml += "				<div>";
                        resultHtml += "					<img src=\"../../images/my/posters/article-5.png\">";
                        resultHtml += "					<span>"+data.datas[i].ecount+"</span>";
                        resultHtml += "				</div>";
                        resultHtml += "				<div>";
                        resultHtml += "					<img src=\"../../images/my/posters/article-6.png\">";
                        resultHtml += "					<span>"+data.datas[i].vscount+"</span>";
                        resultHtml += "				</div>";
                        resultHtml += "			</div>";
                        resultHtml += "		</div>";
                        resultHtml += "		<div class=\"articleContentRight\">";
                        resultHtml += "			<img src=\""+data.datas[i].coverimgurl+"\">";
                        resultHtml += "		</div>";
                        resultHtml += "	</div>";
                        resultHtml += "	<div class=\"articleShare space-between\">";
                        resultHtml += "		<div>快去做第一个分享的人吧！</div>";
                        resultHtml += "		<div class='jumpDetails' data-id='"+data.datas[i].id+"'>立即分享</div>";
                        resultHtml += "	</div>";
                        resultHtml += "</li>";
                    }
                    $(".articleList>ul").html(resultHtml);

                    //-- 文章详情
                    $('.jumpDetails, .articleContent').on('click', function () {
                        $$.push("newKnow/articleDetails",{
                            id:$(this).attr("data-id")
                        });
                    });
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    /**
     * 描述信息：加载宣传册列表
     * @author 覃创斌
     * @date 2020/3/19
    */
    function loadBrochureList() {
        $$.request({
            url: UrlConfig.brochure_getBrochureList,
            pars:{},
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                let resultHtml = "";
                if (data.success){
                    for (let i = 0; i < data.datas.length; i++) {
                        resultHtml += "<div class=\"myWorksUnit flex-start\" data-id='"+data.datas[i].id+"'>";
                        resultHtml += "	<div class=\"myWorksUnitLeft\">";
                        resultHtml += "		<img src=\""+data.datas[i].imgFilePaths.split(",")[0]+"\">";
                        resultHtml += "	</div>";
                        resultHtml += "	<div class=\"myWorksUnitRight\">";
                        resultHtml += "		<div class=\"myWorksUnitContent\">";
                        resultHtml += "			<div class=\"overflow\">"+data.datas[i].title+"</div>";
                        resultHtml += "			<div class=\"flex-start myWorksUnitTime\">";
                        resultHtml += "				<img src=\"../../images/my/posters/brochure-4.png\">";
                        resultHtml += "				<span>"+data.datas[i].createTime+"</span>";
                        resultHtml += "			</div>";
                        resultHtml += "			<div class=\"myWorksUnitCount flex-start\">";
                        resultHtml += "				<div>";
                        resultHtml += "					<img src=\"../../images/my/posters/brochure-5.png\">";
                        resultHtml += "					<div>"+data.datas[i].viewNum+"人</div>";
                        resultHtml += "				</div>";
                        resultHtml += "				<div>";
                        resultHtml += "					<img src=\"../../images/my/posters/brochure-6.png\">";
                        resultHtml += "					<div>"+data.datas[i].shareNum+"人</div>";
                        resultHtml += "				</div>";
                        resultHtml += "			</div>";
                        resultHtml += "		</div>";
                        resultHtml += "		<div class=\"shareImmediately\" data-id='"+data.datas[i].id+"'>立即分享</div>";
                        resultHtml += "	</div>";
                        resultHtml += "</div>";
                    }

                    $(".myWorks").html(resultHtml);
                    //查询详情
                    $(".myWorksUnit").click(function (e) {
                        $$.push("my/brochure/brochureDetails",{
                            id:$(this).attr("data-id"),
                            detailsType:1
                        });
                    });
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType !== 0;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /* 用户信息 */
    function memberDetailsPage() {
        $$.request({
            url: UrlConfig.member_Detailspage,
            loading: true,
            sfn: function(data) {
                $$.closeLoading();
                if(data.success) {
                    PAGE_STATE.memberId = data.datas.id;
                    PAGE_STATE.imgPath = data.datas.imgPath;
                }
            },
            ffn: function(data) {
                $$.errorHandler();
            }
        });
    }
};
