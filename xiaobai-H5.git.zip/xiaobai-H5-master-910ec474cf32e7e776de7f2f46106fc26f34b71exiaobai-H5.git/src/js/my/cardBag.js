
//是否进行了执业认证
let isPC = true;   //默认为false

//劵的类型
let type;   //0-为失效优惠券(lose);1-为现金券|会员卡(cash);2-为代金劵(kims);3-为已使用的劵;
//劵的金额
let money;
//劵的名称
let name;
//剩余天数
let day;        //当剩余天数为0时则变成失效
//有效时间
let beforeDate;
//是否有小提示
let tips;       //若为null的话则不存在提示
//微信用户ID
let wechatID = "001";
//微信用户名称
let wechatName = "前端小哥哥";
//获得的微信红包金额
let redBagMoney = "0.00";
let disabled=false;
window.onload = function () {
    $$.changeVersion();
    const cardUrl=["https://shop18932265.youzan.com/v2/ump/promocard/fetch?alias=yuai4zvk","https://item.taobao.com/item.htm?spm=a2oq0.12575281.0.0.25911deb8GNgwO&ft=t&id=595963780870","https://j.youzan.com/7dC8AJ"];
    getRedAccount();
    redBagClick();
    changeColor('now');
    changeColor('before');
    changeColor('used');
    isProfessionalCertification();
    bigbag();
    onBirthday();;
    clickLabel();
    getCouponList(0,0);
    countAction('xb_2085', null);
}

function getRedAccount() {
    $$.request({
        url: UrlConfig.member_red_account,
        loading: true,
        sfn: function (data) {
            ShawHandler.closeLoading();
            if (data.success) {
                redBagMoney = data.datas.useAmount;
            } else {
                redBagMoney = "0.00";
            }
            $('.redBagMoney').text(redBagMoney+"元");
        }
    });
}

/*改变选择的样式*/
function changeColor(ele) {
    $(`.${ele}`).on('click', function () {
        $(this).css('color','rgb(255, 104, 73)').children('.vertical').css('background','rgb(255, 104, 73)');
        $(this).siblings().css('color','#000');
        $(this).siblings().children('.vertical').css('background','#fff');
    })
}

function getCouponList(couponState,useType) {
    $$.request({
        url: UrlConfig.market_getCouponList,
        loading:true,
        pars: {
            couponState:couponState,
            useType:useType
        },
        sfn: function(data){
            if (data.datas.length==0){
                $(".title").hide();
            }
            if(data.success){
            $$.closeLoading();
            console.log(data);
            bindEvent(data.datas);
            }else{
                $$.layerToast("系统出错")
            }
        }
    });
}

function bindEvent(data) {
    if (data.length==0){
            $$.showNoResultView(".ulBag");
    }else{
            $$.hideNoResultView();
    }
    let html = "";
    let unit = "";
    for (let i=0;i<data.length;i++){
        if (data[i].couponType == 0){
            unit="元";
        }else if (data[i].couponType == 1){
            unit="折";
        }
        html += `${disabled ? '<li class="discounts"   style="background: url('+"../../images/my/cardBag/gray.png"+') no-repeat center center /100% 100%">' 
                : '<li class="discounts"   style="background: url('+data[i].couponIcon+') no-repeat center center /100% 100%">' }              
                <div class="left">
                    <div class="money">${data[i].amount}<div style="font-size: 12px;display: inline-block">${unit}</div></div>
                    ${ disabled ? '' :'<div class="use kimsColor" key="'+data[i].id+'" url="'+data[i].action+'" type="'+data[i].useType+'">立即使用</div>'}
                </div>
                <div class="right">
                    <div class="kimsTex">
                        <div class="name">${data[i].couponName}</div>
                        <div class="tips"></div>
                        <div class="time">${data[i].customExpirationDate}</div>
                    </div>
                </div>
                </li>`
    }
    if (disabled){
        $(".use").hide();
    }
    $(".ulBag").html(html);
    clickBag();
}

function clickLabel() {
    $(".now").on("click",function () {
        disabled=false;
        getCouponList(0,0);
        countAction('xb_2085', null);
    });
    $(".used").on("click",function () {
        disabled=true;
        getCouponList(1,0);
        $(".title").hide();
        countAction('xb_2086', null);
    });
    $(".before").on("click",function () {
        getCouponList(2,0);
        $(".title").hide();
        countAction('xb_2087', null);
    });
}


/*点击事件*/
function clickBag() {
    $(".use").on("click",function () {
        let url=$(this).attr("url");
        let couponId = $(this).attr("key");
        let type=$(this).attr("type");
        if (type=="0"){
            $$.loading();
                    $$.request({
                        url: UrlConfig.member_cashRecordsHandlerStats+'?couponId='+couponId,
                        sfn: function(data){
                            console.log(data);
                            if(data.success){
                                $$.layerToast("使用成功！");
                                location.reload();
                                $$.closeLoading();
                                window.location.href=url;
                            }else{
                                $$.layerToast("使用失败！");
                            }
                        }
                    });
        }
    })
}


/*判断是否进行了执业认证*/
function isProfessionalCertification() {
    if(isPC == true){
        $('.bigBag,.birthdayBag').show();
    }else{
        $('.bigBag,.birthdayBag').hide();
    }
}


//点击微信红包
function redBagClick() {
    $('.rebBag').click(function () {
        $$.push('my/wechatRedBag')
    });
}

//点击大礼包
let bigbag = ()=>{
    $('.bigBag').on('click',()=>{
        countAction('xb_2083', null);
        $$.push('insurance/appraisal');
    });
}

//点击生日礼包
let onBirthday = ()=>{
    $('.birthdayBag').click(()=>{
        $$.layerToast('敬请期待');
        return;
        countAction('xb_2084', null);
    });
}

