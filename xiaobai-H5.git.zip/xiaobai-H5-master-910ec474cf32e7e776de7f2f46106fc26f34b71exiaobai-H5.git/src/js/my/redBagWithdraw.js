//获取完成操作当前的时间
let date = setInterval(function () {
    date = new Date();
    date = date.getFullYear() + "-" + date.getMonth() + "-" + date.getDay() + " " + date.getHours() + ":" + date.getMinutes();
    return date;
}, 500);

//用户可提现的余额
let redBagMoney = "0.00";

window.onload = function () {
    $$.changeVersion();
    $$.request({
        url: UrlConfig.member_red_account,
        loading: true,
        sfn: function (data) {
            ShawHandler.closeLoading();
            if (data.success) {
                redBagMoney = data.datas.useAmount;
            } else {
                redBagMoney = "0.00";
            }
            //将可提现的余额显示到页面上的输入框
            $('.money').val(redBagMoney);

            $('.binding').off().click(() => {
                $$.layerToast("获取微信的用户授权");
                weChatAuthJump();
            });
            changeSubmit();
        }
    });
    countAction("xb_3030");
};

//判断所给参数是否符合提现需求
function changeSubmit() {
    let weChatID = $$.getUrlParam("weChatOpenId"),
        weChatName = '';
    if (weChatID) {
        $$.request({
            url: UrlConfig.management_getUserWeiXinName,
            pars: {
                weChatOpenId: weChatID,
            },
            loading: true,
            sfn: function (data) {
                ShawHandler.closeLoading();
                if (data.success) {
                    weChatName = data.datas.weChatName;
                    $('.inform').text(`提现到微信账户:  ${weChatName}`);
                    updateWeChatData();
                } else ShawHandler.alert(data.msg);
            }
        });
    }


    function updateWeChatData() {
        if ($$.isValidObj(weChatID) &&
            $$.isValidObj(weChatName) &&
            $('.money').val() != null &&
            $('.money').val() !== "" &&
            $('.money').val() <= redBagMoney &&
            $('.money').val() !== 0) {
            $('.binding>div').text("已授权");
            $(".submit").css('background-color', 'rgb(255, 112, 82)').off().click(() => {
                $$.confirm({
                    title: "您确认提现" + $('.money').val() + "元？",
                    onOk: () => withdraw($('.money').val()),
                });
            });
        } else {
            $(".submit").css('background-color', 'rgb(153, 153, 153)').unbind("click");
        }
        if (weChatID != null && weChatID != "" && weChatName != null && weChatName != "") {
            $('.binding').off().click(() => {
                $$.layerToast("已授权！");
            });
        }
    }
}

function withdraw(withdrawMoney) {
    $$.request({
        url: UrlConfig.management_redAccount_withdraw,
        pars: {
            withdrawMoney: withdrawMoney,
        },
        loading: true,
        sfn: function (data) {
            ShawHandler.closeLoading();
            if (data.success) {
                //点击提交后获取当前时间
                $$.layerToast(`${date}`);
                let html = `<div class="pop-up">
                            <img class="close" src="../../images/my/close.png" />
                            <img class="check" src="../../images/my/check.png" />
                            <div class="over">提现申请已提交</div>
                            <div class="date">预计48小时内到账</div>
                            <div class="know">我知道了</div>
                        </div>`;
                layer.open({
                    content: html,
                    type: 1
                });
                $('.close,.know').off().click(() => {
                    layer.closeAll();
                });
                $$.push("my/wechatRedBag");
            } else ShawHandler.alert(data.msg);
        }
    });
}

function weChatAuthJump() {
    if (!$$.weChat.isWx() || location.href.indexOf($$.constant.clientDomain) === -1) return;

    $$.request({
        url: UrlConfig.weChat_authorize,
        pars: {
            authType: $$.constant.weChatAuthorizeType.TYPE_10002,
            returnUrl: "my/redBagWithdraw.html",
            businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_2,
            otherParams: JSON.stringify({"_checkLogin": true})
        },
        loading: true,
        sfn: function (data) {
            ShawHandler.closeLoading();
            if (data.success) {
                location.href = data.datas;
            } else ShawHandler.alert(data.msg);
        }
    });

    ShawHandler.throw();
}

//输入栏的判断
function clearNoNum(obj) {
    obj.value = obj.value.replace(/[^\d.]/g, "");  //清除“数字”和“.”以外的字符
    obj.value = obj.value.replace(/\.{2,}/g, "."); //只保留第一个. 清除多余的
    obj.value = obj.value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
    obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');//只能输入两个小数
    if (obj.value.indexOf(".") < 0 && obj.value !== "") {//以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
        obj.value = parseFloat(obj.value);
    }
    if (parseFloat(obj.value) > redBagMoney) {
        obj.value = null;
        $('.warn').show();
    } else {
        $('.warn').hide();
    }
    changeSubmit();
}



