let memberId;
const memberStatus = {
    mType:null,
    userStatus:null,
    teamId:null,
    teamMemberType:null
};
window.onload = function () {
    $$.changeVersion();
    /**----- 工具项事件绑定 ----**/
    EvtMgr.bindToLi('tools-group');
    EvtMgr.bindToLi('member-group');
    EvtMgr.bindToLi('acquisition-group');
    load();
    /**----- 关于我们，意见反馈 事件绑定 ----**/
    EvtMgr.bindToLi('list');

    //-- 个人信息
    $(".header").click(function () {
        //数据统计
        try {
            countAction('xb_60', null);
        } catch (error) {
            console.log(error);
        }
        //window.location.href = "../../pages/my/personalInformation.html";
        $$.push('my/personalInformation');
    });

    //-- 理财工具
    $("#manageMoney").click(function () {
        $$.push("my/ManageMoney");
    });

    //-- 卡包
    $('.myCardBag').click(function () {
        //数据统计
        try {
            countAction('xb_77', null);
        } catch (error) {
            console.log(error);
        }
        $$.push("my/cardBag");
    });

    //-- 免费义诊
    $(".free_clinic").click(function () {
        window.location.href = "https://m.myweimai.com/topic/epidemic_info.html?from=groupmessage&isappinstalled=0";
    });

    //-- 积分商城
    $(".integral-buy").click(() => {
        $$.request({
            url: UrlConfig.checkIn_mailejifen_login,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    //数据统计
                    try {
                        countAction('xb_75', null);
                    } catch (error) {
                        console.log(error);
                    }
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });

    //-- 一对一咨询
    $(".specialistConsult").click(() => {
        $$.push("my/onlineConsulting/specialistConsult");
    });

    //-- 会员中心-报
    $(".member-nav .member-group .poster").click(() => {
        $$.push('my/poster');
    });

    $('.withdraw-btn').click(()=>{
        //数据统计
        try {
            countAction('xb_67', null);
        } catch (error) {
            console.log(error);
        }
        $$.push('my/wallet',{
            id:memberId
        });
    });

    //我的团队
    $('#myTeam').off().on('click',function () {
        $$.confirm({
            title: '请先实名认证成为经纪人',
            onOkLabel: '实名认证',
            onCancelLabel: '取消',
            onOk: function () {
                $$.push('my/professionalCertification');
            }
        });
    });

    /*点击显示或隐藏金额*/
    $(".img-display").on("click", function(){
        //数据统计
        try {
            countAction('xb_66', null);
        } catch (error) {
            console.log(error);
        }
        if($(this).hasClass('img-display')){
            $(this).removeClass().addClass('img-no-display');
            let html = `<span>*********</span>`;
            $('strong').after(html).hide();
        }else if($(this).hasClass('img-no-display')){
            $(this).removeClass().addClass('img-display');
            $('strong').show().next("span").remove();
        }
    });

    $('.proposal').click(()=>{
        layer.open({
            content:
                `<div class="popupContent">
                    <div class="question">
                        <b>扫描下方二维码，添加微信</b>
                        <img src="../../images/my/proposalQRCode.jpg" />
                        <span>长按识别二维码</span>
                    </div>
                </div>`
        });
    });

    //-- 跳转自动绑定
    $$.staticPushAutoBind();
};
/**
 * 描述信息：加载用户数据
 * @author 覃创斌
 * @date 2019-09-23
 */
function load() {
    if (!ShawHandler.checkLogin()){
        ShawHandler.gotoLogin();
    }
    $$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                memberId = data.datas.id;
                const mtype = data.datas.mtype;
                const userStatus = data.datas.userStatus;
                memberStatus.mType = mtype;
                memberStatus.userStatus = userStatus;
                localStorage.setItem("memberId", memberId);

                getVipData();               // VIP功能模块

                integralLevel();
                if (userStatus === 0 || userStatus === 3 ) {//userStatus:0：初始化；3：审核不通过；
                    /**----- 滚动条 执业认证 事件绑定 ----**/
                    scrollText(null,function(){
                        /* 跳转执业认证 */
                        $$.push("my/professionalCertification");
                    });
                } else if (mtype === 4 && userStatus === 2){//userStatus:2：审核通过；mtype:4：经纪人；
                    $('.withdraw-content').show();
                    //小白提醒您：你的执业认证申请已通过，签署经纪委托协议后即可展开保险业务！
                    getFadadaInfo(memberId,data.datas.isOldMember);
                    setMlevel();
                }

                let username = data.datas.phone;
                if (mtype === 4 && userStatus === 2 && $$.isValidObj(username)) {
                    username = data.datas.rname;
                }
                $(".username").html(username);
                let imgPath = data.datas.imgPath;
                if (!$$.isValidObj(imgPath)) {
                    imgPath = "../../images/my/defaultImg.png";
                }
                $(".logo").attr("src", imgPath);
                /*let hasNewUserByParent = data.datas.hasNewUserByParent;
                if (hasNewUserByParent) {
                    $('.swiper-slide[htmlUrl="my/newGiftBag"]').remove();
                }*/
                doSwiper();
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
    $$.request({
        url: UrlConfig.accountinfo_getMyWallet,
        pars: {},
        requestBody:true,
        loading: true,
        method: "POST",
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                $("#useAmount").html(data.datas.useAmount);
                $("#rewardAmount").html(data.datas.rewardAmount);
                $("#scoreCount").html(data.datas.scoreCount);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

}
function gotoMyTeam(){
    $$.request({
        url: UrlConfig.market_teammember_getTeamMemberByLogin,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let url = "teams/index";
                const params = {};
                let teamId = data.teamId;
                memberStatus.teamId = teamId;
                if (teamId != null) {
                    let teamStatus = data.teamStatus;
                    let teamLevel = data.teamLevel;
                    let mType = data.mType;
                    memberStatus.teamMemberType = mType;
                    params.teamId = teamId;
                    if (teamStatus === 0 || teamStatus === 1) {
                        url = "teams/addDetails";
                    } else if (teamStatus === 2) {
                        url = "teams/colonel";
                        if (mType === 2) {
                            url = "teams/clustering";
                        }
                    }
                    if (mType === 1 && teamLevel !== 'LV.0') {
                        $('.nomal-broker').hide();
                        let brokerUrl = '../../images/my/level/team/';
                        if (teamLevel === 'LV.2') {
                            brokerUrl += 'v2-pc.png';
                        } else if (teamLevel === 'LV.3') {
                            brokerUrl += 'v3-pc.png';
                        } else if (teamLevel === 'LV.4') {
                            brokerUrl += 'v4-pc.png';
                        } else if (teamLevel === 'LV.5') {
                            brokerUrl += 'v5-pc.png';
                        } else if (teamLevel === 'LV.6') {
                            brokerUrl += 'v6-pc.png';
                        } else {
                            brokerUrl += 'v1-pc.png';
                        }
                        $('.v1-team').attr('src',brokerUrl).show().click(function () {
                            $$.push('my/commanderLevel',{teamId:teamId});
                            return false;
                        });
                    }
                } else {
                    let teamMemberStatus = data.teamMemberStatus;
                    if (teamMemberStatus === 2) {
                        url = 'teams/notpass';
                    } else if (teamMemberStatus === 0) {
                        let teamMemberId = data.teamMemberId;
                        if (teamMemberId) {
                            url = 'teams/application';
                            params.teamMemberId = teamMemberId;
                        }
                    }
                }
                $('#myTeam').off().on('click',function () {
                    $$.push(url,params);
                });
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function setMlevel() {
    $$.request({
        url: UrlConfig.market_growthrule_wx_getBrokerLevelDataByLogin,
        pars: {},
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let code = data.growthRule.code;
                let brokerUrl = '../../images/my/level/broker/';
                if (code === 'b2') {
                    brokerUrl += 'gold-pc.png';
                } else if (code === 'b3') {
                    brokerUrl += 'diamond-pc.png';
                } else {
                    brokerUrl += 'nomal-pc.png';
                }
                $('.nomal-broker').attr('src',brokerUrl).show().click(function () {
                    //数据统计
                    try {
                        countAction('xb_63', null);
                    } catch (error) {
                        console.log(error);
                    }
                    $$.push('my/brokerLevel');
                    return false;
                });
                gotoMyTeam();
            } else {
                $$.layerToast(data.msg);
                $$.push("newIndex");
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function integralLevel() {
    $$.request({
        url: UrlConfig.member_getMemberIntegralLevel,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                bindMemberIntegralLevel(parseInt(data.datas));
            } else {

            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

}

//绑定元素
function  bindMemberIntegralLevel(integral) {
    function imgHtml(picName,otherClass){
        return `<img class="level-nomal-img${otherClass}" src="../../images/my/level/integral/${picName}.png" />`;
    }
    let html = imgHtml('integral-level',' level-integral');
    const integralEl = $('#integral');
    if (integral < 500) {
        html = '积分:' + integral;
        integralEl.css('color','#ffc900');
    } else {
        let starNum = Math.floor(integral/500);
        let moonNum = Math.floor(starNum/5);
        let sunNum = Math.floor(moonNum/5);
        let crownNum = Math.floor(sunNum/5);
        let jewelNum = Math.floor(crownNum/5);
        if(jewelNum > 0) {
            console.log('jewelNum:' + jewelNum);
            for(let i = 0;i < jewelNum;i++) {
                html += imgHtml('jewel','');
            }
        }
        if(crownNum > 0) {
            let num = crownNum - jewelNum * 5;
            console.log('crownNum:' + num);
            for(let i = 0;i < num;i++) {
                html += imgHtml('crown','');
            }
        }
        if(sunNum > 0) {
            let num =sunNum - crownNum * 5;
            console.log('sunNum:' + num);
            for(let i = 0;i < num;i++) {
                html += imgHtml('level-sun','');
            }
        }
        if(moonNum > 0) {
            let num = moonNum - sunNum * 5;
            console.log('moonNum:' + num);
            for(let i = 0;i < num;i++) {
                html += imgHtml('level-moon','');
            }
        }
        if(starNum > 0) {
            let num = starNum - moonNum * 5;
            console.log('starNum:' + num);
            for(let i = 0;i < num;i++) {
                html += imgHtml('level-star','');
            }
        }
    }
    integralEl.html(html).on('click',function () {
        //数据统计
        try {
            countAction('xb_62', null);
        } catch (error) {
            console.log(error);
        }
        $$.push('signin/integralList');
        return false;
    });
    $$.staticPushAutoBind();
}

//-- 获取法大大信息
function getFadadaInfo(memberId,isOldMember) {
    $$.request({
        url: UrlConfig.member_fadada_getFadadaInfo,
        pars: {
            memberId: memberId
        },
        requestBody:true,
        sfn: function(data) {
            $$.closeLoading();
            if(data.success) {
                let customer_id = data.customer_id;
                let auth_certStatus = data.auth_certStatus;
                let fadada_contractFilling = data.fadada_contractFilling;
                let fadada_extsign_tran_id_b = data.fadada_extsign_tran_id_b;
                if (customer_id != null) {
                    if (auth_certStatus === 1) {
                        if (fadada_contractFilling === 0 || fadada_extsign_tran_id_b == null){
                            /**----- 滚动条 法大大签署 事件绑定 ----**/
                            //针对法大大已完成实名认证，开始签署合同（新用户）
                            scrollText('针对法大大已完成实名认证，开始签署合同',function(){
                                /* 跳转法大大签署 */
                                $$.push("my/passed");
                            });
                        }
                    } else {
                        /**----- 滚动条 法大大签署 事件绑定 ----**/
                        scrollText('法大大实名认证未成功，请重新实名认证。',function(){
                            /* 跳转法大大签署 */
                            $$.push("my/passed");
                        });
                    }
                } else if (isOldMember) {
                    //针对法大大未实名认证（老用户）
                    scrollText('已注老册用户，需要到法大大进行实名认证',function(){
                        /* 跳转法大大签署 */
                        $$.push("my/passed");
                    });
                } else {
                    /**----- 滚动条 法大大签署 事件绑定 ----**/
                    scrollText('法大大实名认证未成功，请重新实名认证。',function(){
                        /* 跳转法大大签署 */
                        $$.push("my/passed");
                    });
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function(data) {
            $$.errorHandler();
        }
    });
}
//文字横向滚动
function scrollText(text = null, clickFunction){
    if ($$.isValidObj(text)) {
        $('#scroll_begin').html(text);
    }
    const announcement = $('.announcement');
    announcement.css('display','block');
    announcement.on("click",clickFunction);

    (function () {
        let speed=50;//初始化速度 也就是字体的整体滚动速度
        // let MyMar = null;//初始化一个变量为空 用来存放获取到的文本内容
        let scroll_begin = document.getElementById("scroll_begin");//获取滚动的开头id
        let scroll_end = document.getElementById("scroll_end");//获取滚动的结束id
        let scroll_div = document.getElementById("scroll_div");//获取整体的开头id
        scroll_end.innerHTML=scroll_begin.innerHTML;//滚动的是html内部的内容,原生知识!

        //定义一个方法
        function Marquee(){
            if(scroll_end.offsetWidth-scroll_div.scrollLeft<=0) {
                scroll_div.scrollLeft-=scroll_begin.offsetWidth;
            } else {
                scroll_div.scrollLeft++;
            }
        }
        setInterval(Marquee,speed);
    })();
}

function doSwiper() {
    /**
     * 我的页面小广告轮播图
     */
    let swiper = new Swiper('.swiper-container', {
        spaceBetween: 15,
        centeredSlides: true,
        loop: true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        on:{
            tap: function(){
                const htmlUrl = $(".swiper-container .swiper-slide[data-swiper-slide-index=" + this.realIndex + "]").attr('htmlUrl');
                if ($$.isValidObj(htmlUrl)) {
                    $$.push(htmlUrl);
                }
            },
        },
    });
}

//-- 获取当前用户的VIP信息
function getVipData() {
    $$.request({
        url: UrlConfig.member_memberVip_getVipData,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                switch (data.vipType) {
                    case 0:{
                        normalUser(data);       // 未开通用户
                        break;
                    }
                    case 1:{
                        vipUser(data);          // VIP用户
                        break;
                    }
                    case 2:{
                        TeamVipUser(data);      // 团长加速包用户
                        break;
                    }
                }
                //-- 开通VIP
                $('.openVIP>span').on('click',function (e) {
                    e.stopPropagation();
                    $$.push('my/purchaseVIP/purchaseVIP');
                });

                //-- 计算会员中心高度
                let member_group_height = $('.member-nav>.member-group').height();
                let acquisition_group_height = $('.member-nav>.acquisition-group').height();
                if (member_group_height > 164) {
                    $('.member-nav>.member-group').css('height', '179px');
                    $('.member-group').siblings('.member-arrow').show();
                }
                if (acquisition_group_height > 164) {
                    $('.member-nav>.acquisition-group').css('height', '179px');
                    $('.acquisition-group').siblings('.member-arrow').show();
                }

                //-- 显示会员中心全部
                $('.member-nav .member-arrow').on('click',function () {
                    //-- 计算会员中心高度
                    let height = $(this).prev().height();
                    if (height == 164){
                        $(this).prev().css('height', '100%');
                        $(this).find('span').text('收起');
                        $(this).find('img.arrow').css('transform','rotate(270deg)');
                    } else {
                        $(this).prev().css('height', '179px');
                        $(this).find('span').text('查看更多');
                        $(this).find('img.arrow').css('transform','rotate(90deg)');

                    }
                });

            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

    let nowDate = $$.dateUtils.dateFormat(new Date(), "yyyy-MM-dd HH:mm:ss");

    //-- 未开通用户
    function normalUser(data) {
        $('.acquisition-group>li').on("click", function () {
            let dataPermission = $(this).attr("data-permission");
            let dataId = $(this).attr("data-id");
            if (dataPermission == '1') {
                popup("使用此功能需开通VIP");
            } else {
                vipSubitemGoto(dataId);
            }
        });
    }

    //-- VIP用户
    function vipUser(data) {
        let time = $$.dateUtils.dateMinus(nowDate, data.expireTime);
        if (time > 0){
            let html = `<span>你的<span class="typeName">会员功能包剩余<span>${time}</span>天，</span><span class="renew">立即续费</span></span>`;
            $('.openVIP').html(html);
        }

        $('.acquisition-group>li').on("click", function () {
            let dataId = $(this).attr("data-id");
            vipSubitemGoto(dataId);
        });
        $('.withdraw-content').show();
        $('.member-nav .member-group .lookedMe').hide();
    }

    //-- 团长加速包用户
    function TeamVipUser(data) {
        let time = $$.dateUtils.dateMinus(nowDate, data.expireTime);
        if (time > 0){
            let html = `<span>你的<span class="typeName">团长功能包剩余<span>${time}</span>天，</span><span class="renew">立即续费</span></span>`;
            $('.openVIP').html(html);
        }

        $('.acquisition-group>li').on("click", function () {
            let dataId = $(this).attr("data-id");
            vipSubitemGoto(dataId);
        });
        $('.withdraw-content').show();
        $('.member-nav .member-group .lookedMe').hide();
    }

    function checkIsTeamLeader(url,params = {}) {
        function createConfirm(title,onOkLabel,onOk) {
            $$.confirm({
                title: title,
                onOkLabel: onOkLabel,
                onCancelLabel: '取消',
                onOk: onOk
            });
        }
        if ($$.isValidObj(memberStatus.teamMemberType) && memberStatus.teamMemberType === 1) {//你是团长
            $$.push(url,params);
        } else if ($$.isValidObj(memberStatus.teamId)) {//你有团
            createConfirm('你不是团长，但你可以创建本团的子团，成为团长','组建子团',function() {
                $$.push('teams/details',{parentTeamId:memberStatus.teamId});
            });
        } else if (memberStatus.mType === 4 && memberStatus.userStatus === 2) {//你是经纪人
            createConfirm('请先组建团队成为团长','组建团队',function() {
                $$.push('teams/details');
            });
        } else {//你不是经纪人
            createConfirm('请先实名认证成为经纪人','实名认证',function() {
                $$.push('my/professionalCertification');
            });
        }
    }

    //-- VIP功能页面跳转
    function vipSubitemGoto(value) {
        switch (value) {
            case "1":{      //-- 谁看过我
                $$.push('looked/lookedMe1');
                break;
            }
            case "2":{      //-- 素材库
                $$.push('my/posters');
                break;
            }
            case "3":{      //-- 案例库
                $$.push("my/caseLibrary/businessCase",{memberId : memberId});
                break;
            }
            case "4":{      //-- 我的名片
                $$.push("my/newMyVisitingCard/myVisitingCard",{memberId : memberId});
                //$$.push("my/myVisitingCard/myVisitingCard",{memberId : memberId});
                break;
            }
            case "5":{      //-- 一对一咨询
                break;
            }
            case "6":{      //-- 团长看板
                checkIsTeamLeader('teams/colonelSeeVersion/colonelSeeVersion',{teamId:memberStatus.teamId});
                break;
            }
            case "7":{      //-- 发布任务
                checkIsTeamLeader('teams/myPublishedTasks',{teamId:memberStatus.teamId});
                break;
            }
            case "8":{      //-- 云空间
                checkIsTeamLeader('my/cloudDisk/myCloud');
                break;
            }
        }
    }

    //-- 弹窗 - 跳转购买VIP页面
    function popup(title) {
        $$.confirm({
            title: title,
            onOkLabel: "去开通",
            onCancelLabel: "取消",
            onOk: function () {
                $$.push('my/purchaseVIP/purchaseVIP');
            }
        });
    }

    //-- 测试权限
    function permission() {
        // 用于临时操作  我的名片临时开放 针对用户id 851285
        if (memberId === 'jgIl4Ijb7dQ=' || memberId === 'SnpDEWwOGMQ='){
            $('.member-group>.poster').hide();
            $('.member-group>.specialistConsult').hide();
            // 打开会员中心素材库、一对一咨询
            $('acquisition-group>.poster').show();
            $('acquisition-group>.specialistConsult').show();
        }else {
            //$('.openVIP').hide();
            $('.poster').hide();
            $('.specialistConsult').hide();
        }
    }
}
