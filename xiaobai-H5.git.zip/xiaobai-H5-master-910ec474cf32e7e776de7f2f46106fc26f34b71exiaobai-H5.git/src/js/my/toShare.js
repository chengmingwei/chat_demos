const PAGE_STATE = {
    switchState: true,                      // 是否显示名片
    id:null
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        let id = $$.getUrlParam("id");
        let filePath = $$.getUrlParam("filePath");
        if (id != undefined){
            $$.request({
                url: UrlConfig.reprintarticle_getReprintArticleById,
                pars:{
                    id:id,
                    filePath:filePath
                },
                requestBody:true,
                loading: true,
                sfn: function (data) {
                    if (data.success) {
                        $("#modifyArticleSource").val(data.reprintArticle.articleSource);
                        PAGE_STATE.id = id;
                        $$.closeLoading();
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        }
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 是否 - 显示名片
        $(".switch").on("click", function(){
            if (PAGE_STATE.switchState){
                $(this).css("background-color","#999999");
                $(this).children("div.switchNo").removeClass("switchNo").addClass("switchYes");
                PAGE_STATE.switchState = false;
            } else {
                $(this).css("background-color","#EF5B09");
                $(this).children("div.switchYes").removeClass("switchYes").addClass("switchNo");
                PAGE_STATE.switchState = true;
            }
        });

        //-- 判断输入框的值，显示清除按钮
        $("#modifyArticleSource").on("input", function(){
            let length = $(this).val().length;
            length > 0 ? $(".clear").show():$(".clear").hide();
        });

        //-- 清除输入框的值
        $(".clear").on("click", function(){
            $("#modifyArticleSource").val("");
            $(this).hide();
        });

        //-- 选择封面 - 图片上传
        $('.cover').on("click",function () {
            $(this).find('input')[0].click();
        });
        $('.cover > input').on('change',function () {
            const _this = $(this);
            let file=_this[0].files[0];
            //文件类型
            let fileType=file.type;
            let type=getFileType(fileType);
            //文件大小
            let fileSize=(file.size/ 1024).toFixed(2);
            if(type!=="jpg"&&type!=="gif"&&type!=="jpeg"&&type!=="png"){
                $$.layerToast('请上传图片');
                return false;
            }
            if(fileSize>10240){//定义不能超过10MB
                $$.layerToast('请上传不超过10M的图片');
                return false;
            }
            lrz(file).then(function (resultObj) {
                $(".accordingCover").css("background", `url("${resultObj.base64}") no-repeat center / contain`);
            });
        });

        //-- 查看效果 - 文章详情
        $(".viewEffect").on("click", function(){
            let headPath;
            let filePath = $('#filePath')[0].files[0];//海报
            let title = $("#modifyArticleSource").val();

            const submit = function (uploadData) {
                $$.loading();
                let pars = {
                    title:title,
                    id:PAGE_STATE.id,
                    url:$Constant.shareLogo,
                    isShow:PAGE_STATE.switchState
                };
                if ($$.isValidObj(uploadData)) {
                    pars.url = uploadData.datas.filePath;
                }
                $$.request({
                    url: UrlConfig.reprintarticle_updateReprintArticleById,
                    pars:pars,
                    requestBody:true,
                    loading: true,
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success) {
                            $$.alert("上传成功！",function () {
                                 $$.push("my/articleDetails",{
                                     id:PAGE_STATE.id,
                                     switchState:PAGE_STATE.switchState
                                 });
                            })
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            };
            const  uploadHead = function () {
                if (filePath !== undefined){
                    let formData = new window.FormData();
                    formData.append('file', filePath);
                    formData.append('formType', '10007');
                    $$.request({
                        url: UrlConfig.upload_attachment_upload,
                        loading: true,
                        pars: formData,
                        requestBody: true,
                        sfn: function(data) {
                            if(data.success) {
                                headPath = data.datas.filePath;
                                $(".accordingCover").css("background", `url("${headPath}") no-repeat center / contain`);
                                if (headPath == null){
                                    $$.closeLoading();
                                    return;
                                }
                                submit(data);
                            } else {
                                $$.layerToast(data.msg);
                                return null;
                            }
                        },
                        ffn: function(data) {
                            $$.errorHandler();
                        }
                    });
                }else {
                    // $$.alert("请选择上传封面！");
                    submit(null);
                }
            };
            if ($$.isValidObj(title.trim(),"标题不能为空！")){
                uploadHead()
            }
        });
    }

    /**
     * 得到文件类型
     */
    function getFileType(filePath) {
        let startIndex=filePath.lastIndexOf("/");
        if(startIndex!==-1){
            return filePath.substring(startIndex+1,filePath.length).toLowerCase();
        }else {
            return "";
        }
    }

};
