window.onload = function () {
    $$.changeVersion();
    $("#ask").click(() => {
        $$.request({
            url: UrlConfig.xywy_wx_ask,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });

    $("#order").click(() => {
        $$.request({
            url: UrlConfig.xywy_wx_order,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

    });
}