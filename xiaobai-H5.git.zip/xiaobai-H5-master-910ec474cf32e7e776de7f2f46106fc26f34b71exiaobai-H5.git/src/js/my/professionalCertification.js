window.onload = function (){
	/**----- 取消按钮 事件绑定 ----**/
	$(".registration").on("click",function(){
		if(!$$.checkLogin()){
        	//-- 未登录状态先去登录
        	$$.confirmLogin();
        }else{
        	$$.request({
	            url: UrlConfig.member_Detailspage,
	            loading: true,
	            sfn: function (data) {
	                $$.closeLoading();
	                if (data.success) {
						let userStatus = data.datas.userStatus;
	                    let mtype = data.datas.mtype;

	                    if (userStatus === 2 && mtype === 4){
	                    	$$.layerToast("用户已通过认证");
	                    }else if(userStatus === 1){
	                    	$$.layerToast("等待审核中，请耐心等候");
	                    }else{
	                    	var index = layer.open({
								content:
									`<div class="popupContent">
										<img src="../../images/my/close.png" class="cancel"/>
										<div class="prepareData">执业认证登记前必备材料</div>
										<div>1. 身份证正反面照片</div>
										<div>2. 1张彩色白底免冠半身正面照片</div>
										<div class="answer">
											<span class="affirm">已准备，去登记</span>
										</div>
									</div>`
							});
							$(".answer").on("click", function(){
								$$.push("my/basicInformation");
							});
							$(".cancel").on("click", function(){
								layer.close(index);
							});
	                    }
	                } else {
	                    $$.layerToast(data.msg);
	                }
	            },
	            ffn: function (data) {
	                $$.errorHandler();
	            }
			});
        }
	})
};
