/**
 * 制作宣传册 JS
 * @Author 吴成林
 * @Date 2020-3-5 14:28:28
 */
const PAGE_STATE = {
    templateLength: 0,              // 模板长度
    viewWidth: 0,                   // 页面视图宽度
    viewHeight: 0,                  // 页面视图高度
    canvasList: {},                 // 合成图列表
    title:undefined,                //宣传册标题
};
window.onload = function () {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader() {
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit() {


        //PAGE_STATE.pageType = $$.getUrlParam("pageType");

        //-- 适配移动端 全屏宽高
        PAGE_STATE.viewWidth = window.innerWidth || document.documentElement.clientWidth;
        PAGE_STATE.viewHeight = window.innerHeight || document.documentElement.clientHeight;

        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading() {
        let textLength = $(`.unit1`).children("div:nth-child(1)").children("div").length;
        $(".textCount").text(textLength);
        let imageLength = $(`.unit1`).children("div:nth-child(2)").find("div.addPhoto").length;
        $(".imageCount").text(imageLength);

        PAGE_STATE.templateLength = $(".swiper-wrapper").children("div").length;

        let url = "https://pic.xiaobaibao.com/market/posterImages/2019/11/e7e02893664147298ce4f751be4dbf1c.png";
        //-- OSS图片转base64
        //convertImageToBase64(url);

    }

    /**
     * 事件绑定
     */
    function eventBinding() {
        //-- 页面滑动事件
        let touchStart, touchEnd, touchDiff = 10;
        $(window).on({
            'touchstart': function (e) {
                touchStart = e.originalEvent.changedTouches[0].clientY;
            },
            'touchend': function (e) {
                touchEnd = e.originalEvent.changedTouches[0].clientY;
                let diff = touchStart - touchEnd;
                let indexes = parseInt($('.browse').attr("data-indexes"));
                let templateLength = parseInt(PAGE_STATE.templateLength);
                if (!$('.browse').is(':hidden')) {
                    if (diff >= touchDiff) { // direction down
                        if ($(window).scrollTop() + $(window).height() >= $(document).height()) { // scroll bottom
                            indexes = indexes + 1;
                            if (indexes >= templateLength) {
                                //-- 当列表到底时，显示反向图标
                                $(".nextBottom").show();
                                $(".nextTop ").hide();
                                $('.detailsContent').attr("src", PAGE_STATE.canvasList[templateLength]);
                                $('.browse').attr("data-indexes", templateLength);
                            } else {
                                $('.detailsContent').attr("src", PAGE_STATE.canvasList[indexes]);
                                $('.browse').attr("data-indexes", indexes);
                            }
                        }
                    } else if (diff <= -touchDiff) { // direction up
                        if ($(window).scrollTop() == 0) {
                            indexes = indexes - 1;
                            if (indexes <= 1) {
                                $(".nextBottom").hide();
                                $(".nextTop ").show();
                                $('.detailsContent').attr("src", PAGE_STATE.canvasList[indexes]);
                                $('.browse').attr("data-indexes", 1);
                            } else {
                                $('.detailsContent').attr("src", PAGE_STATE.canvasList[indexes]);
                                $('.browse').attr("data-indexes", indexes);
                            }

                        }
                    }
                }
            }
        });

        //-- 图片滑动
        let mySwiper = new Swiper('.swiper-container', {
            on: {
                slideChangeTransitionStart: function () {
                    $('.indexes>span:nth-child(1)').text(this.realIndex + 1);
                    let href = ".unit" + (this.realIndex + 1).toString();
                    $(`${href}`).show();
                    $(`${href}`).siblings().hide();

                    let textLength = $(`${href}`).children("div:nth-child(1)").children("div").length;
                    $(".textCount").text(textLength);
                    let imageLength = $(`${href}`).children("div:nth-child(2)").find("div.addPhoto").length;
                    $(".imageCount").text(imageLength);
                }
            }
        });

        //-- 预览
        $('.preview').on('click', function () {
            syntheticImg();
        });

        //-- 切换标题 文字-图片
        $('.configurationTitle>div').on('click', function () {
            $(this).siblings().children("span").removeClass("titleSelected");
            $(this).children("span").addClass("titleSelected");

            let href = $(this).attr("href");
            $(`${href}`).show();
            $(`${href}`).siblings().hide();
        });

        //-- 显示 输入框 清除按钮
        $('.configuration').on("input", function () {
            let length = $(this).val().length;
            length > 0 ? $(this).siblings("img.clear").show() : $(this).siblings("img.clear").hide();
        });

        //-- 清除 - 输入框内容
        $('.clear').on("click", function () {
            $(this).siblings("input").val("");
            $(this).hide();
        });

        //-- 清除 - 上传图片
        $('.remove').on("click", function (e) {
            e.stopPropagation();
            $(this).siblings('div').children("img.addImg").attr("src", "");
            $(this).siblings("input").val("");
        });

        //-- 选择海报 - 图片上传
        $('.addPhoto').on("click", function () {
            $(this).find('input')[0].click();
        });
        $('.addPhoto > input').on('change', function () {
            const _this = $(this);
            let file = _this[0].files[0];
            //文件类型
            let fileType = file.type;
            let type = getFileType(fileType);
            //文件大小
            let fileSize = (file.size / 1024).toFixed(2);
            if (type !== "jpg" && type !== "gif" && type !== "jpeg" && type !== "png") {
                $$.layerToast('请上传图片');
                return false;
            }
            if (fileSize > 1024 * 2) {//定义不能超过2MB
                $$.layerToast('请上传不超过2M的图片');
                return false;
            }
            lrz(file).then(function (resultObj) {
                _this.siblings('div').children("img.addImg").attr("src", resultObj.base64);
                _this.siblings('div').children("img.addImg").css('display', 'block');

                $("#photo1").attr("src", resultObj.base64);
            });
        });

        //-- 完成
        $('.completion,.completionPreview').on("click", function () {
            let index = layer.open({
                content:
                    `<div class="popupContent">
           <div class="question">
              <input placeholder="请输入宣传册标题（键盘隐藏再确认）" type="text" class="timeFrame">
           </div>
           <div class="answer space-between">
              <div class="cancel">取消</div>
              <div class="affirm">确认</div>
           </div>
        </div>`
            });
            /**----- 取消按钮 事件绑定 ----**/
            $(".answer>.cancel").on("click",function(){
                console.log('1111');
                layer.close(index);
            });
            /**----- 确认按钮 事件绑定 ----**/
            $(".answer>.affirm").on("click",function(){
              let title = $(".timeFrame").val();
              if (title.trim() != ""){
                  PAGE_STATE.title = title;

                  //-- 调用PAGE_STATE.canvasList 上传模板  预览的完成
                  if (Object.keys(PAGE_STATE.canvasList).length == PAGE_STATE.templateLength) {
                      let fileIds = new Array();
                      //图片Map
                      let map = PAGE_STATE.canvasList;
                      let fileLength = Object.keys(PAGE_STATE.canvasList).length;
                      //保存数据
                      const save = function () {
                          console.log(fileIds.join(","));
                          $$.request({
                              url: UrlConfig.brochure_insertBrochure,
                              pars: {
                                  viewNum:0,
                                  shareNum:0,
                                  type:1,
                                  imageArr:fileIds.join(","),
                                  title:PAGE_STATE.title
                              },
                              requestBody: true,
                              sfn: function (data) {
                                  if (data.success) {
                                      $$.closeLoading();
                                      $$.push("my/posters");
                                  } else {
                                      $$.layerToast(data.msg);
                                      return null;
                                  }
                              },
                              ffn: function (data) {
                                  $$.errorHandler();
                              }
                          });
                      }
                      //循环遍历
                      const uploadFile = function (i) {
                          $$.loading("正在保存中...");
                          if (i < fileLength) {
                              //base64转文件流
                              let fileSource = dataURLtoFile(map[i + 1], "pic_" + (i + 1) + ".png");
                              lrz(fileSource).then(function (resultObj) {
                                  let file_Head = resultObj.origin;
                                  if (file_Head !== undefined) {
                                      let formData = new window.FormData();
                                      formData.append('file', file_Head);
                                      formData.append('formType', '10007');
                                      console.log('第' + i + "次")
                                      $$.request({
                                          url: UrlConfig.upload_attachment_upload,
                                          pars: formData,
                                          requestBody: true,
                                          sfn: function (data) {
                                              if (data.success) {
                                                  uploadFile(++i);
                                                  //attachmentId
                                                  console.log(data.datas.filePath)
                                                  fileIds.push(data.datas.attachmentId);
                                              } else {
                                                  $$.layerToast(data.msg);
                                                  return null;
                                              }
                                          },
                                          ffn: function (data) {
                                              $$.errorHandler();
                                          }
                                      });
                                  }
                              });
                          } else {
                              save();
                              console.log('结束递归');
                              console.log(fileIds)
                          }
                      }
                      uploadFile(0);
                  } else {
                      //合成图片
                      syntheticImg(1);
                  }
                  layer.close(index);
              }else {
                  $$.layerToast("标题不能为空！")
              }


            })

        });


        //-- 返回
        $('.stepBackward').on('click', function () {
            $('.browse').hide();
            $('.browse').attr("data-indexes", 1);
        });


    }

    /**
     * 得到文件类型
     */
    function getFileType(filePath) {
        let startIndex = filePath.lastIndexOf("/");
        if (startIndex !== -1) {
            return filePath.substring(startIndex + 1, filePath.length).toLowerCase();
        } else {
            return "";
        }
    }

    //-- 网络图片OSS 转 base64
    function convertImageToBase64(image) {
        const {viewWidth, viewHeight} = PAGE_STATE;
        let canvas = document.createElement('CANVAS');
        let ctx = canvas.getContext('2d');
        let imgObj = new Image();
        imgObj.setAttribute('crossOrigin', 'anonymous');
        imgObj.src = image;
        imgObj.onload = function () {
            canvas.height = viewHeight;
            canvas.width = viewWidth;
            ctx.drawImage(this, 0, 0);
            let img = canvas.toDataURL("image/png");
            $("#browseBackground").attr("src", img);
        }
    }

    /* 绘制弹窗 赋值 画布 */
    function setCanvas(state) {
        const {viewWidth, viewHeight} = PAGE_STATE;
        if (state == 1){
            $$.loading("正在保存中...");
        }else {
            $$.loading("正在生成中...");
        }
        $("input").blur();
        $('.browseCanvas').show();
        let templateLength = PAGE_STATE.templateLength + 1;
        for (let i = 1; i < templateLength; i++) {
            let id = `brochure${i}`;
            $(`#${id}`).show().siblings().hide();
            new html2canvas(document.getElementById(`${id}`), {
                allowTaint: true,
                useCORS: true,
                width: viewWidth,
                height: viewHeight
            }).then(canvas => {
                let imgUrl = canvas.toDataURL();
                PAGE_STATE.canvasList[i] = imgUrl;
            });

            if (i == templateLength - 1) {
                setTimeout(function () {
                    $(".browseCanvas").hide();
                    $('.detailsContent').attr("src", PAGE_STATE.canvasList[1]);

                    if ($$.isValidObj(state)) {
                        $('.browse').hide();
                        //外面完成 保存事件
                        if (Object.keys(PAGE_STATE.canvasList).length == PAGE_STATE.templateLength) {
                            let fileIds = new Array();
                            //图片Map
                            let map = PAGE_STATE.canvasList;
                            let fileLength = Object.keys(PAGE_STATE.canvasList).length;
                            //保存数据
                            const save = function () {
                                console.log(fileIds.join(","));
                                $$.request({
                                    url: UrlConfig.brochure_insertBrochure,
                                    pars: {
                                        viewNum:0,
                                        shareNum:0,
                                        type:1,
                                        imageArr:fileIds.join(","),
                                        title:PAGE_STATE.title
                                    },
                                    requestBody: true,
                                    sfn: function (data) {
                                        if (data.success) {
                                            $$.closeLoading();
                                            $$.push("my/posters");
                                        } else {
                                            $$.layerToast(data.msg);
                                            return null;
                                        }
                                    },
                                    ffn: function (data) {
                                        $$.errorHandler();
                                    }
                                });
                            }
                            //循环遍历
                            const uploadFile = function (i) {
                                $$.loading("正在保存中...");
                                if (i <= fileLength) {
                                    //base64转文件流
                                    let fileSource = dataURLtoFile(map[i], "pic_" + (i) + ".png");
                                    lrz(fileSource).then(function (resultObj) {
                                        let file_Head = resultObj.origin;
                                        if (file_Head !== undefined) {
                                            let formData = new window.FormData();
                                            formData.append('file', file_Head);
                                            formData.append('formType', '10007');
                                            console.log('第' + i + "次")
                                            $$.request({
                                                url: UrlConfig.upload_attachment_upload,
                                                pars: formData,
                                                requestBody: true,
                                                sfn: function (data) {
                                                    if (data.success) {
                                                        //attachmentId
                                                        console.log(data.datas.attachmentId)
                                                        fileIds.push(data.datas.attachmentId);
                                                        uploadFile(++i);

                                                    } else {
                                                        $$.layerToast(data.msg);
                                                        return null;
                                                    }
                                                },
                                                ffn: function (data) {
                                                    $$.errorHandler();
                                                }
                                            });
                                        }
                                    });
                                } else {
                                   save();
                                    console.log('结束递归');
                                    console.log(fileIds)
                                }
                            }
                            uploadFile(1);

                        }
                    } else {
                        $$.closeLoading()
                        // 预览
                        $('.browse').show();
                    }
                }, 1000)
            }
        }
    }

    //图片合成
    function syntheticImg(state) {
        let templateLength = PAGE_STATE.templateLength;
        for (let i = 1; i < templateLength + 1; i++) {
            let textLength = $(`.unit${i}`).children("div:nth-child(1)").children("div").length;
            let imageLength = $(`.unit${i}`).children("div:nth-child(2)").find("div.addPhoto").length;
            if (textLength > 0) {
                for (let j = 1; j < textLength + 1; j++) {
                    let text = $(`.unit${i}-text${j}`).val();
                    if ($$.isValidObj(text)) $(`.brochure${i}-text${j}`).text(text);
                }
            }
            if (imageLength > 0) {
                for (let k = 1; k < imageLength + 1; k++) {
                    let photo = $(`.unit${i}-photo${k}`).attr("src");
                    if ($$.isValidObj(photo)) $(`.brochure${i}-photo${k}`).attr("src", photo);
                }
            }
            if (i == templateLength) {
                /*if (Object.keys(PAGE_STATE.canvasList).length == PAGE_STATE.templateLength) {
                    $('.detailsContent').attr("src", PAGE_STATE.canvasList[1]);
                    $('.browse').show();
                } else {
                    //-- 合成图片
                    setCanvas();
                }*/
                //-- 合成图片
                setCanvas(state);
            }
        }
        ;
    }

    /**
     * 描述信息：将base64转换为文件，dataurl为base64字符串，filename为文件名（必须带后缀名，如.jpg,.png）
     * @author 覃创斌
     * @date 2020/3/19
     */
    function dataURLtoFile(dataurl, filename) {
        var arr = dataurl.split(','), mime = arr[0].match(/:(.*?);/)[1],
            bstr = atob(arr[1]), n = bstr.length, u8arr = new Uint8Array(n);
        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }
        return new File([u8arr], filename, {type: mime});
    }
}
