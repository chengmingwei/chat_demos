/**
 * 宣传册详情 JS
 * @Author 吴成林
 * @Date 2020-3-4 18:32:31
 */
const PAGE_STATE = {
    pageType: 0,                   // 页面类型 （0-邀请函详情，1-宣传册详情）
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: '宣传册分享'
    }
};
let brochureBackground = [          // 模板列表
    "../../../images/my/posters/brochureImage-1.png",
    "../../../images/my/posters/brochureImage-2.png",
    "../../../images/my/posters/brochureImage-3.png",
    "../../../images/my/posters/brochureImage-4.png",
    "../../../images/my/posters/brochureImage-5.png",
];
let title = null;
window.onload = function () {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader() {
        loadData();
    }

    function loadData() {
        let id = $$.getUrlParam("id");
        if (id != null) {
            $(".useTemplate").hide();
            $$.request({
                url: UrlConfig.brochure_getBrochure,
                pars: {
                    id: id
                },
                requestBody: true,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        $(".detailsContent").attr("src", data.imgList[0]);
                        brochureBackground = data.imgList;
                        title = data.title;
                        pageInit();
                        $('title').html(title);
                        share(id);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
            let shareNo = $$.getUrlParam("shareNo");
           if (shareNo === "true"){
               $$.request({
                   url: UrlConfig.brochure_getBrochureByIdAddViewNum,
                   pars:{
                       id:id
                   },
                   requestBody:true,
                   sfn: function (data) {},
                   ffn: function (data) {
                       $$.errorHandler();
                   }
               });
           }
        } else {
            $(".share").hide();
            pageInit();
        }

    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit() {
        PAGE_STATE.pageType = $$.getUrlParam("detailsType");
        if (PAGE_STATE.pageType === '0') {
            $("title").text("邀请函详情");
        } else if (PAGE_STATE.pageType === '1') {
            $("title").text("宣传册详情");
        }

        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading() {

    }

    /**
     * 事件绑定
     */
    function eventBinding() {
        //-- 页面滑动事件
        let touchStart, touchEnd, touchDiff = 10;
        $(window).on({
            'touchstart': function (e) {
                touchStart = e.originalEvent.changedTouches[0].clientY;
            },
            'touchend': function (e) {
                touchEnd = e.originalEvent.changedTouches[0].clientY;
                const diff = touchStart - touchEnd;
                let indexes = parseInt($('.detailsContent').attr("data-indexes"));
                let brochureBackgroundLength = brochureBackground.length;
                if (diff >= touchDiff) { // direction down
                    if ($(window).scrollTop() + $(window).height() >= $(document).height()) { // scroll bottom
                        if (indexes >= brochureBackgroundLength - 1) {
                            //-- 当列表到底时，显示反向图标
                            $(".nextBottom").show();
                            $(".nextTop ").hide();
                            $(".detailsContent").attr("src", brochureBackground[indexes]);
                            $(".detailsContent").attr("data-indexes", brochureBackgroundLength - 1);
                        } else {
                            $(".detailsContent").attr("src", brochureBackground[indexes]);
                            $(".detailsContent").attr("data-indexes", indexes + 1);
                        }

                    }
                } else if (diff <= -touchDiff) { // direction up
                    if ($(window).scrollTop() === 0) { // scroll top
                        if (indexes <= 1) {
                            //-- 当列表到顶时，显示反向图标
                            $(".nextBottom").hide();
                            $(".nextTop ").show();
                            $(".detailsContent").attr("src", brochureBackground[indexes - 1]);
                            $(".detailsContent").attr("data-indexes", 1);
                        } else {
                            $(".detailsContent").attr("src", brochureBackground[indexes - 1]);
                            $(".detailsContent").attr("data-indexes", indexes - 1);
                        }
                    }
                }
            }
        });
        //往下翻
        $(".nextTop").click(function () {
            let brochureBackgroundLength = brochureBackground.length;
            let indexes = parseInt($('.detailsContent').attr("data-indexes"));
            if ($(window).scrollTop() + $(window).height() >= $(document).height()) { // scroll bottom
                if (indexes >= brochureBackgroundLength - 1) {
                    //-- 当列表到底时，显示反向图标
                    $(".nextBottom").show();
                    $(".nextTop ").hide();
                    $(".detailsContent").attr("src", brochureBackground[indexes]);
                    $(".detailsContent").attr("data-indexes", brochureBackgroundLength - 1);
                } else {
                    $(".detailsContent").attr("src", brochureBackground[indexes]);
                    $(".detailsContent").attr("data-indexes", indexes + 1);
                }

            }
        });
        //往上
        $(".nextBottom").click(function () {
            let indexes = parseInt($('.detailsContent').attr("data-indexes"));
            if ($(window).scrollTop() === 0) { // scroll top
                if (indexes <= 1) {
                    //-- 当列表到顶时，显示反向图标
                    $(".nextBottom").hide();
                    $(".nextTop ").show();
                    $(".detailsContent").attr("src", brochureBackground[indexes - 1]);
                    $(".detailsContent").attr("data-indexes", 1);
                } else {
                    $(".detailsContent").attr("src", brochureBackground[indexes - 1]);
                    $(".detailsContent").attr("data-indexes", indexes - 1);
                }
            }
        });
        //-- 使用模板
        $('.useTemplate').on('click', function () {
            $$.push("my/brochure/makeBrochure");
        });
        $(".share").click(function () {
            shareHandler();
        });
    }

    /**
     * 分享名片 (加载数据成功后调用)
     */
    function share(id) {
        if (!$WeChat.isWx() && !PAGE_APP) {
            return;
        }
        let _lineLink = $$.getFullHost() + '/src/pages/my/brochure/brochureDetails.html';
        /* 是否带参 */
        _lineLink += $$.jsonToUrlParams({
            id: id,
            detailsType: 1,
            shareNo: true
        });
        PAGE_STATE.shareDatums = {      //-- 保存分享参数
            image: brochureBackground[0],
            url: _lineLink,
            title: title,
            content: '我给你发了一份宣传册，快来查看吧',
        };
        weChatJSTool.share({
            _imgUrl: brochureBackground[0],
            _lineLink: _lineLink,
            _shareTitle: title,
            _descContent: '我给你发了一份宣来查看吧',
            _sfn: function () {
                $$.layerToast("分享成功~");
            }
        });
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-5-15 11:24:47
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;
            console.log(shareDatums);
            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            //-- 分享
            $$.showShareView('点击右上角,分享宣传册给好友！');
        }
    }
};
