let id = null;
window.onload = function () {
    $$.changeVersion();
    wechatShare();
    if (!(decodeURIComponent($$.getUrlParam("id")) == "null")) {
        id = decodeURIComponent($$.getUrlParam("id"));
        loadData(id);
    }
    setPicImgSize();


    $('#personal').on('click', function () {
        $('#wrapper .detail .btnList .btn').removeClass('on');
        $(this).addClass('on');
        $('.person').css('display', 'block');
        $('.group').css('display', 'none');
        let personEssentialText = null;
        let personInformation = null;
        personEssentialText = $(".person div:nth-of-type(1) .mainText").text();
        personInformation = $(".person div:nth-of-type(2) .mainText").text();

        if( (personEssentialText == null || personEssentialText == "") && (personInformation == null || personInformation == "") ){
            $(".person").hide();
            $(".none").show();
        }else{
            $('.none').hide();
        }
        countAction("xb_3015");
    });


    $('#group').on('click', function () {
        $('#wrapper .detail .btnList .btn').removeClass('on');
        $(this).addClass('on');
        $('.group').css('display', 'block');
        $('.person').css('display', 'none');
        let groupEssentialText = null;
        let groupInformation = null;
        groupEssentialText = $(".group div:nth-of-type(1) .mainText").text();
        groupInformation = $(".group div:nth-of-type(2) .mainText").text();

        if( (groupEssentialText == null || groupEssentialText == "") && (groupInformation == null || groupInformation == "") ){
            $(".group").hide();
            $(".none").show();
        }else{
            $('.none').hide();
        }
        countAction("xb_3016");
    });

    countAction("xb_2051");
    countAction("xb_3015");

};

function setPicImgSize() {
    var img = $('#wrapper .pic .picImg img');
    var picImg = $('#wrapper .pic .picImg');
    $("<img/>").attr("src", img.attr('src')).load(function () {
        var width = this.width;
        var height = this.height;
        var picImgHeight = picImg.height();
        if (height > picImgHeight) {
            width = width * picImgHeight / height;
            height = picImgHeight;
        }
        var picImgWidth = picImg.width();
        if (width > picImgWidth) {
            width = picImgWidth;
        }
        img.css('width', width);
        img.css('height', height);
    });
}

function loadData(id) {
    $(".none").hide();
    let Information = null;
    $$.request({
        url: UrlConfig.management_claim_information,
        loading: true,
        pars: {
            id: id
        },
        sfn: function (data) {
            if (data.success) {
                console.log(data)
                $$.closeLoading();
                Information = data.datas;
                //先展示上部分数据
                bindInsuranceCompany(Information);
                //然后在追加标签
                $(".infoNeed").append(`<div class="none"><img src="../../images/my/Mailinboxempty.png" /><div class="text">暂无资料</div></div>`)
                //最后进行判断是否隐藏
                bindClaimInformation(Information);
            } else {
                $$.layerToast("查询失败");
            }
        }
    });
}
//头部
function bindInsuranceCompany(data) {
	$(".picImg img").attr("src", $$.imageUrlCompatible(data.logo));
	//$(".picImg img").css({"pointer-events":"none","-webkit-user-select":"none","-moz-user-select":"none"})
    $(".text span:nth-of-type(1)").text(data.shortName);
    $(".text span:nth-of-type(2)").text(data.customerPhone);
    $(".text span:nth-of-type(3)").text(data.companyUrl);
}
//资料
function bindClaimInformation(data) {
    let personEssential = null;
    let personInformation = null;
    let groupEssential = null;
    let groupInformation = null;
    console.log(data);
    if (data.personalInsuranceEssentialInfo != null) {
        personEssential = data.personalInsuranceEssentialInfo;
    }

    if (data.personalInsuranceInfo != null) {
        personInformation = data.personalInsuranceInfo;
    }

    if (data.groupInsuranceEssentialInfo != null) {
        groupEssential = data.groupInsuranceEssentialInfo;
    }

    if (data.groupInsuranceInfo != null) {
        groupInformation = data.groupInsuranceInfo;
    }

    if ((personEssential==null || personEssential=='') && (personInformation==null || personInformation=='')) {
        console.log("阿斯顿撒旦")
        $(".none").show();
        $(".person").hide();
        $(".group").hide();
    }else{
        $(".none").hide();
        $(".group").hide();
    }


    $(".person div:nth-of-type(1) .mainText").html(personEssential);
    $(".person div:nth-of-type(2) .mainText").html(personInformation);
    $(".group div:nth-of-type(1) .mainText").html(groupEssential);
    $(".group div:nth-of-type(2) .mainText").html(groupInformation);

}
function wechatShare() {
    let lineLink = window.location.href;
    weChatJSTool.share({
        _imgUrl: $Constant.shareLogo,
        _lineLink: lineLink,
        _shareTitle: '亲，您有一份理赔须知要查收',
        _descContent: '请提前准备好所需资料，我们将尽快协助您处理该保单',
        _sfn: function () {
            console.log("成功注册分享链接：" + lineLink);
        },
        _cfn: function () {
        },
        _ffn: function () {
            console.log("失败注册分享链接：" + lineLink);
        }
    });
}
