
/**判断是否完成执业认证**/
let isAT = false;

window.onload = function () {
    $$.changeVersion();
    if ($$.checkLogin()) {
        isAT = true;
        $$.request({
            url: UrlConfig.member_Detailspage,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success && data.datas) {
                    let userStatus = data.datas.userStatus;
                    let mtype = data.datas.mtype;
                    if (userStatus === 2 && mtype === 4) {
                        $$.layerToast('您已完成了执业认证');
                        $('.toAT').click(()=>{
                            $$.layerToast('您已完成了执业认证');
                        });
                    } else {
                        getIsAT();
                    }
                }
            }
        });
    } else {
        getIsAT();
    }

    //-- 清理HTML注释
    $$.clearHTMLNotes();
};

/**获取是否完成执业认证**/
function getIsAT() {
    $('.toAT').click(()=>{
        if(isAT === true){
            $$.push('my/professionalCertification');
        }else{
            ShawHandler.confirm({
                title: "您还未登录，是否登录？",
                onOk: function () {
                    ShawHandler.push("login/login", {
                        returnUrl:encodeURIComponent(window.location.href),
                        weChatOpenId:$$.getUrlParam("weChatOpenId"),
                        memberId:$$.getUrlParam("memberId")
                    })
                }
            });
        }
    });
}
