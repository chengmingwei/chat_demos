

/**
 * 团险订单 JS
 * @Author 肖家添
 * @Date 2019/10/15 20:09
 */


window.onload = function(){
	//数据统计
	try {
		countAction('xb_71', null);
	} catch (error) {
		console.log(error);
	}

	/**
	 * 数据存储中心
	 * @Author 肖家添
	 * @Date 2019/9/16 14:56
	 */
	const PAGE_STATE = {

	}

	pageLoader();

	/**
	 * 页面加载对必要的参数作处理
	 * @Author 肖家添
	 * @Date 2019/8/29 16:35
	 */
	function pageLoader(){

		//-- 页面初始化
		pageInit();

	}

	/**
	 * 绑定事件及页面初始化处理
	 * @Author 肖家添
	 * @Date 2019/8/29 16:37
	 */
	function pageInit() {

		//-- 绑定事件
		bindEvent();

		//-- 初始化页面
		initPageState();

	}

	/**
	 * 绑定事件
	 * @Author 肖家添
	 * @Date 2019/9/3 15:27
	 */
	function bindEvent() {

		//-- 静态跳转自动绑定
		$$.staticPushAutoBind();

	}

	/**
	 * 初始化页面参数
	 * @Author 肖家添
	 * @Date 2019/9/26 17:43
	 */
	function initPageState(){

	}
}