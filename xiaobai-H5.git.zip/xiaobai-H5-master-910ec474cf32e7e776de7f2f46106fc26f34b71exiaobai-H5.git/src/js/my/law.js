

const text = load("../../js/tool/xiaobai.txt");
const txt = {"t" : text};
const canvas = document.getElementById("canvas");
canvas.width = $('#canvas').width();
canvas.height = $('#canvas').height();
console.log(canvas.width+"<---->"+canvas.height);
const ctx = canvas.getContext("2d");




/*var getPixelRatio = function (context) {
    var backingStore = context.backingStorePixelRatio ||
        context.webkitBackingStorePixelRatio ||
        context.mozBackingStorePixelRatio ||
        context.msBackingStorePixelRatio ||
        context.oBackingStorePixelRatio ||
        context.backingStorePixelRatio || 1;
    return (window.devicePixelRatio || 1) / backingStore;
};
var ratio = getPixelRatio(ctx);
// ctx.font = "36px Georgia"; //一倍屏下18px字体
ctx.fillStyle = "#999";
ctx.fillText("我是清晰的文字", 50*ratio, 50*ratio);// 坐标位置乘以像素比*/




let index = 0;
/*字体尺寸*/
const font = {
    size: 14
}
/*面板尺寸*/
const panel = {
    col: Math.floor((canvas.width / font.size)/2),//列数
    row: Math.floor((canvas.height / font.size)/2)-0.5,//行数
    space: 2,
}
//14--27

console.log(panel.col+"<---->"+panel.row);

ctx.fillStyle = "#333333";
ctx.font = font.size + "px 微软雅黑";

const str_write = txt.t;
const str_write_list = str_write.split("\r\n");

/*本页开始*/
const page_begin = {
    line: 0,//当前行
    offset: 0//当前偏移量
};
/*本页结束*/
const page_end = {
    line: 0,//当前行
    offset: 0//当前偏移量
}

$(function(){

    //进入加载
    write();

    //上一页
    $('.left').click(()=>{
        write_before();
    });

    //下一页
    $('.right').click(()=>{
        write();
    });
})



/**
 * 获取文本数据
 * @param name
 * @returns {any}
 */
function load(name) {
    let xhr = new XMLHttpRequest(),
        okStatus = document.location.protocol === "file:" ? 0 : 200;
    xhr.open('GET', name, false);
    xhr.overrideMimeType("text/html;charset=utf-8");//默认为utf-8
    xhr.send(null);
    return xhr.status === okStatus ? xhr.responseText : null;
}



/*下一屏页*/
function write(){
    var cur = page_end.line;
    page_begin.line  = page_end.line;
    page_begin.offset = page_end.offset;

    check(cur);
}


/*开始真实绘制下一屏*/
function check(current){
    ctx.clearRect(0,0,canvas.width,canvas.height);

    var total = panel.col * panel.row * 2;//字符有占一位和两位的，一行最多可绘制2倍长度
    var count = 0;
    var tag = false;

    var tmp_all_write = [];
    var isBreak = false;//检查是否正常跳出
    while(current < str_write_list.length){

        var len = str_write_list[current].length;
        var tmp_write = [];
        var str = str_write_list[current];
        var start = 0;
        if(!tag){
            start = page_end.offset;
            tag = true;
        }

        var tmp = 0;
        var begin = start;
        for(var i = start; i < len ; i ++ ){
            //逐个检查
            if(tmp >= panel.col * 2 - 1){
                tmp_write.push(str.substring(begin,i));
                begin = i;
                tmp = 0;
            }

            var len_char = 1;
            if(str.charCodeAt(i) > 128){
                len_char = 2;
            }

            tmp += len_char;
        }

        if(tmp > 0){
            tmp_write.push(str.substring(begin,i))
        }

        if(str == "") {
            tmp_write.push("");
        };

        var offset = 0;
        if(tmp_all_write.length + tmp_write.length > panel.row) {
            for(var i = 0 ; i < tmp_all_write.length ; i ++){
                ctx.fillText(tmp_all_write[i],0, (i + 1) * font.size);
            }

            for(var j = 0 ; j < tmp_write.length && j + i < panel.row ; j ++){
                offset += tmp_write[j].length;
                ctx.fillText(tmp_write[j],0, (i + j + 1) * font.size);
            }
            page_end.line = current;
            page_end.offset = offset;
            isBreak = true;
            break	;
        }

        tmp_all_write = tmp_all_write.concat(tmp_write);

        current ++;


    }

    //当页数不等于0的时候显示上一页按钮
    if(index != 0){
        $('.left').show();
    }
    index++;


    /*未正常跳出，表示到达书尾，直接绘制*/
    if(!isBreak){
        for(var i = 0 ; i < tmp_all_write.length ; i ++){
            ctx.fillText(tmp_all_write[i],0, (i + 1) * font.size);
        }
        //隐藏下一页按钮,显示上一页按钮
        $('.right').hide();
    }

}


/*上一页*/
function write_before(){
    var tag = false;
    var total = panel.col * panel.row * 2;
    var count = 0;
    var line = page_begin.offset > 0 ? page_begin.line : page_begin.line - 1 ;
    var t = 0;
    var tmp_all_write = [];


    //当left为小于或1的时候则不显示上一页按钮
    index--;
    if(index <= 1){
        $('.left').hide();
        $('.right').show();
    }else{
        if(index<1) {
            index = 1;
        }
        $('.right').show();
    }


    while(line >= 0){

        var len = str_write_list[line].length;
        var tmp_write = [];
        var str = str_write_list[line];
        var start = len;
        if(!tag){
            if(page_begin.offset > 0 ){
                start = page_begin.offset
            }

            tag = true;
        }

        var tmp = 0;
        var begin = 0;
        for(var i = 0; i < start ; i ++ ){
            //逐个检查
            if(tmp >= panel.col * 2  - 1){
                tmp_write.push(str.substring(i,begin));
                begin = i;
                tmp = 0;
            }

            var len_char = 1;
            if(str.charCodeAt(i) > 128){
                len_char = 2;
            }

            tmp += len_char;
        }

        if(tmp > 0){
            tmp_write.push(str.substring(begin,i))
        }

        /*此行为空行，也单独占一行*/
        if(str == "") {
            tmp_write.push("");
        };

        var offset = 0;
        if(tmp_all_write.length + tmp_write.length >= panel.row) {
            ctx.clearRect(0,0,canvas.width,canvas.height);
            var y = panel.row;

            for(var i = tmp_all_write.length - 1 ; i >= 0  ; i --){
                ctx.fillText(tmp_all_write[i],0, (y--) * font.size);
            }
            i = tmp_all_write.length;
//						
            var k = 0;
            for(var j = tmp_write.length - 1 ; j >= 0 && (k + i) < panel.row ; j --){
                offset += tmp_write[j].length;
                k++;
                ctx.fillText(tmp_write[j],0, (y--) * font.size);
            }

            /*重置页尾数据*/
            page_end.line = page_begin.line;
            page_end.offset = page_begin.offset;
            /*重置页头数据*/
            page_begin.line = line;
            page_begin.offset = str.length - offset;
            break
        }
        tmp_all_write = tmp_write.concat(tmp_all_write);
        line --;
    }



}


/**
 * 滑动
 */
/*document.addEventListener("click",function(e){
    var x = e.pageX;
    if(x > canvas.width / 2){
        write();
    }else{
        write_before();
    }
});*/
			
			
			