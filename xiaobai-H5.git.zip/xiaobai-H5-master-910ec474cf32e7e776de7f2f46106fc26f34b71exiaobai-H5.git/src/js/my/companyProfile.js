

(function (window, document) {
    var currentPosition = 0;
    var currentPoint = -1;
    var pageNow = 1;
    var points = null;
    var app = {
        init: function () {
            if (/(windows)/i.test(navigator.userAgent)) {
            }
            document.addEventListener('DOMContentLoaded', function () {
                points = document.querySelectorAll('.pagenumber div');
                app.bindTouchEvent();
                app.bindBtnClick();
                app.setPageNow();
            }.bind(app), false);
        }(), bindBtnClick: function () {
            var button = document.querySelector('#testbtn');
            button.addEventListener('touchstart', function () {
                console.log('touch');
            })
        }, transform: function (translate) {
            this.style.webkitTransform = 'translate3d(' + translate + 'px, 0, 0)';
            currentPosition = translate;
        }, setPageNow: function () {
            if (currentPoint != -1) {
                points[currentPoint].className = '';
            }
            currentPoint = pageNow - 1;
            points[currentPoint].className = 'now';
        }, bindTouchEvent: function () {
            var viewport = document.querySelector('#viewport');
            var pageWidth = window.innerWidth;
            var maxWidth = -pageWidth * (points.length - 1);
            var startX, startY;
            var initialPos = 0;
            var moveLength = 0;
            var direction = 'left';
            var isMove = false;
            var startT = 0;
            var isTouchEnd = true;
            viewport.addEventListener('touchstart', function (e) {
                e.preventDefault();
                if (e.touches.length === 1 || isTouchEnd) {
                    var touch = e.touches[0];
                    startX = touch.pageX;
                    startY = touch.pageY;
                    initialPos = currentPosition;
                    viewport.style.webkitTransition = '';
                    startT = +new Date();
                    isMove = false;
                    isTouchEnd = false;
                }
            }.bind(this), false);
            viewport.addEventListener('touchmove', function (e) {
                e.preventDefault();
                if (isTouchEnd) return;
                var touch = e.touches[0];
                var deltaX = touch.pageX - startX;
                var deltaY = touch.pageY - startY;
                var translate = initialPos + deltaX;
                if (translate > 0) {
                    translate = 0;
                }
                if (translate < maxWidth) {
                    translate = maxWidth;
                }
                deltaX = translate - initialPos;
                this.transform.call(viewport, translate);
                isMove = true;
                moveLength = deltaX;
                direction = deltaX > 0 ? 'right' : 'left';
            }.bind(this), false);
            viewport.addEventListener('touchend', function (e) {
                e.preventDefault();
                var translate = 0;
                var deltaT = +new Date() - startT;
                if (isMove && !isTouchEnd) {
                    isTouchEnd = true;
                    viewport.style.webkitTransition = '0.3s ease -webkit-transform';
                    if (deltaT < 300) {
                        if (currentPosition === 0 && translate === 0) {
                            return;
                        }
                        translate = direction === 'left' ? currentPosition - (pageWidth + moveLength) : currentPosition + pageWidth - moveLength;
                        translate = translate > 0 ? 0 : translate;
                        translate = translate < maxWidth ? maxWidth : translate;
                    } else {
                        if (Math.abs(moveLength) / pageWidth < 0.5) {
                            translate = currentPosition - moveLength;
                        } else {
                            translate = direction === 'left' ? currentPosition - (pageWidth + moveLength) : currentPosition + pageWidth - moveLength;
                            translate = translate > 0 ? 0 : translate;
                            translate = translate < maxWidth ? maxWidth : translate;
                        }
                    }
                    this.transform.call(viewport, translate);
                    pageNow = Math.round(Math.abs(translate) / pageWidth) + 1;
                    setTimeout(function () {
                        this.setPageNow();
                    }.bind(this), 100);
                }
            }.bind(this), false);
        }
    }
})(window, document);




