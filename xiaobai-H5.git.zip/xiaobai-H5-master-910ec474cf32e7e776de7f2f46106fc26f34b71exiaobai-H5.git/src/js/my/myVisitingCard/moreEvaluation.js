
/**
 *  更多评价 JS
 * @Author 吴成林
 * @Date 2020-1-14 15:11:30
 */
window.onload = function(){
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
        loadDataSource();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        //-- 跳转自动绑定
        $$.staticPushAutoBind();

        dataLoading();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        /* 请求数据 */

        /* 客户页面 显示查看更多 */
        $('.more').show();

        /* 显示评价 绑定事件 */
        $(".switch").on("click", function(){
            if ($(this).hasClass("selected")){
                $(this).toggleClass("selected");
                $(this).text("显示评价");
            } else {
                $(this).toggleClass("selected");
                $(this).text("隐藏评价");
            }
        });


        /* 客户页面 查看更多 绑定事件 */
        $('.more').on("click", function () {
            // let html = `<li class="flex-start">
            //     <div class="estimatePhotos">
            //         <img src="../../../images/my/myVisitingCard/09.png" />
            //     </div>
            //     <div class="details">
            //         <div class="space-between">
            //             <div>
            //                 <span>陈小姐</span>
            //                 <span class="time">2020-01-12</span>
            //             </div>
            //             <div class="switch">显示评价</div>
            //         </div>
            //         <div class="estimateContent">很专业！很专业！很专业！很专业！很专业！</div>
            //         <div class="estimateType">
            //             <span>服务态度很好</span>
            //             <span>专业可靠</span>
            //             <span>负责任</span>
            //         </div>
            //         <div class="product space-between">
            //             <span>安联户外运动-运动无限运动无限运动无限</span>
            //             <img src="../../../images/my/myVisitingCard/16.png" />
            //         </div>
            //     </div>
            // </li>`;
            //
            // $('.estimateList ul').append(html);
            $(this).hide();
        })
    }
    function loadDataSource() {
        let id = $$.getUrlParam("memberId");
        $$.request({
            url: UrlConfig.orderevaluation_getMoreOrderEvaluationList,
            loading: true,
            pars: {
                memberId:id,
            },
            requestBody: true,
            sfn: function(data) {
                $$.closeLoading();
                let html = "";
                let totalScore  = 0;
                for (let i = 0; i < data.datas.length; i++) {
                    totalScore = parseInt(totalScore)+ parseInt(data.datas[i].score);
                     html += `<li class="flex-start">
                                    <div class="estimatePhotos">
                                        <img src="${data.datas[i].headimgurl}" />
                                    </div>
                                    <div class="details">
                                        <div class="space-between">
                                            <div>
                                                <span>${data.datas[i].nickname}</span>
                                                <span class="time">${data.datas[i].createtime}</span>
                                            </div>
<!--                                            <div class="switch">显示评价</div>  暂时屏蔽  以后做--> 
                                        </div>
                                        <div class="estimateContent">${data.datas[i].evaluation}</div>
                                        <div class="estimateType">
                                            <span>服务态度很好</span>
                                            <span>专业可靠</span>
                                            <span>负责任</span>
                                        </div>
                                        <div class="product space-between" data-productid="${data.datas[i].productid}" data-sellid='${data.datas[i].sellid}'>
                                            <span>${data.datas[i].name}</span>
                                            <img src="${$$.imageUrlCompatible(data.datas[i].logo)}" />
                                        </div>
                                    </div>
                                </li>`;
                }
                $(".number").html(data.datas.length);
                console.log(data.datas.length)
                console.log(totalScore)
                $(".score").html(totalScore/data.datas.length);
                $('.estimateList ul').append(html);
                //跳转
                $(".product").on("click", function(){
                    $$.push("product/productDetail",{
                        productId:$(this).attr("data-productid"),
                        sellId: $(this).attr("data-sellid"),
                        uuid:new Date().getTime()
                    })
                });
            },
            ffn: function(data) {
                $$.closeLoading();
                $$.errorHandler();
            }
        });

    }
}
