/**
 *  我的名片 JS
 * @Author 吴成林
 * @Date 2020-1-14 14:26:24
 */
let entityId;
let memberId;
const PAGE_STATE = {
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: '万水千山总是缘，很高兴认识您，点击可查看我更多介绍哦'
    }
};
window.onload = function(){
    countAction("xb_6001");
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        //-- 跳转自动绑定
        $$.staticPushAutoBind();
        memberId = $$.getUrlParam("memberId");
        if (memberId === undefined){
            $$.alert("加载失败！！！",function () {
                $$.gotoLogin();
            });
            return;
        }
        dataLoading();
        loadDate();
        visiting();
        evaluation();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        $(".photoWall").on("click", function(){
            $$.push("my/myVisitingCard/photoWall",{
                memberId:memberId
            })
        });

        $(".Modify").on("click", function(){
            $$.push("my/myVisitingCard/addVisitingCard",{
                memberId:memberId
            });
        });
        $(".addWx").off().on("click", function(){
            $$.push("my/myVisitingCard/addVisitingCard",{
                memberId:memberId
            });
        });
        $(".more").on("click", function(){
            $$.push("my/myVisitingCard/moreEvaluation",{
                memberId:memberId
            })
        });

        /* 发给客户 右上角分享 */
        $(".share>div").on("click", function(){
            shareHandler();
        });
    }
    /**
     * 描述信息：加载数据
     * @author 覃创斌
     * @date 2020/1/15
    */
    function loadDate() {
        $$.request({
            url: UrlConfig.market_growthrule_wx_getBrokerLevelData,
            pars:{
                memberId:memberId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if ($$.isValidObj(data.growthRule)){
                        let code = data.growthRule.code;
                        let text = "";
                        if (code === 'b2') {
                            text += '黄金经纪人';
                        } else if (code === 'b3') {
                            text += '钻石经纪人';
                        } else {
                            text += '专业经纪人';
                        }
                        $('.level').html(text);
                    }
                    console.log(data);
                    if((data.member.imgPath == null)||(data.member.imgPath === "")){
                        $(".photos img").attr("src","../../../images/my/defaultImg.png");
                    }else {
                        $(".photos img").attr("src", data.member.imgPath);
                    }
                    if((data.member.memberName == null)||(data.member.memberName === "")){
                        $(".name").html(data.member.phone);
                    }else {
                        $(".name").html(data.member.memberName);
                    }
                    $(".phone").html(data.member.phone);
                    if(PAGE_APP){
                        $("#phone").on("click", function () {
                            let params = {};
                            params["phone"] = data.member.phone;
                            $$.postAPP(10003, params);
                        });
                    } else{
                        $("#phone").attr("href", 'tel:'+data.member.phone);
                    }
                    gotoMyTeam()
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //团长等级
    function gotoMyTeam(){
        $$.request({
            url: UrlConfig.market_teammember_getTeamMember,
            pars:{
                memberId:memberId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let url = "../teams/index.html";
                    let teamId = data.teamId;
                    if (teamId != null) {
                        let teamStatus = data.teamStatus;
                        let teamLevel = data.teamLevel;
                        let mType = data.mType;

                        if (mType === 1 && teamLevel !== 'LV.0') {
                           $(".level").html(teamLevel)
                        }
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //名片信息
    function visiting() {
        $$.request({
            url: UrlConfig.mybusinesscard_getBusinessCardScreen,
            pars:{
                memberId:memberId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success){
                    if (data.entity!==undefined){
                        entityId = data.entity.id;
                        let years = data.entity.years;
                        if ($$.isValidObj(years) && years.includes("/")){
                            years = years.split("/");
                            years = dateDiff(years[0], years[1]);
                        }
                        $(".years").html(years);
                        let results =  data.entity.speciality.split(",");
                        let typeHtml="";
                        for (let i = 0; i <results.length ; i++) {
                            typeHtml +="<span>"+results[i]+"</span>";
                        }
                        $(".insuranceType").html(typeHtml);
                        $(".intro .info").html(data.entity.synopsis);
                        $(".qRcode img").attr("src",data.entity.shareQRCode);
                        if (data.entity.isOpen === "1"){
                            $(".photoWall").show();
                        }else {
                            $(".photoWall").hide();
                        }
                        if ($$.isValidObj(data.entity.rankTitle)){
                            $(".rankTitle").show();
                            $(".rankTitle .info").html(data.entity.rankTitle);
                        }
                        /* 添加二维码 绑定事件 */
                        if (data.entity.wxQRCode !== undefined){
                            $(".addWx").off().on("click", function(){
                                var index = layer.open({
                                    content:
                                        `<div class="popupContent">
                                        <div class="question">
                                            <b>扫描下方二维码，添加微信</b>
                                            <img src="${data.entity.wxQRCode}" />
                                            <span>长按识别二维码</span>
                                        </div>
                                    </div>`
                                });
                            });
                        }else {
                            $(".qRcodeText").html("待补充");
                        }

                        shareWeeklyLuckyDraw();
                    }else {
                        $(".insuranceType").html("待补充");
                        $(".info").html("待补充");
                        $(".years").html("待补充");
                        $(".qRcodeText").html("待补充");
                        $(".shareContent").hide();
                      //  $(".photoWall").hide();
                    }
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //评论
    function evaluation() {
        $$.request({
            url: UrlConfig.orderevaluation_getOrderEvaluationList,
            pars:{
                memberId:memberId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success){
                    if (data.datas.length == 0){
                        $(".number").html("0");
                        $(".more").hide()
                    }else {
                        $(".number").html(data.datas.length);
                    }
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

    }
    /**
     * 分享名片 (加载数据成功后调用)
     */
    function shareWeeklyLuckyDraw() {
        if (!$WeChat.isWx() && !PAGE_APP) {
            return;
        }
        $$.request({
            url: UrlConfig.member_getMemberName,
            pars:{memberId:memberId},
            sfn: function (data) {
                if (data.success) {
                    let _lineLink = $$.getFullHost() + '/src/pages/my/myVisitingCard/shareVisitingCard.html';
                    /* 是否带参 */
                    _lineLink += $$.jsonToUrlParams({
                        share:true,
                        memberId:memberId
                    });
                    PAGE_STATE.shareDatums = {      //-- 保存分享参数
                        image: $$.isValidHeadImg(data.imgPath),
                        url: _lineLink,
                        title: 'hello，我是' + data.userName,
                        content: '万水千山总是缘，很高兴认识您，点击可查看我更多介绍哦'
                    };
                    weChatJSTool.share({
                        _imgUrl:  $$.isValidHeadImg(data.imgPath),
                        _lineLink:  _lineLink,
                        _shareTitle: 'hello，我是' + data.userName,
                        _descContent: '万水千山总是缘，很高兴认识您，点击可查看我更多介绍哦',
                        _sfn: function () {
                            $$.share(entityId,2);
                            $$.layerToast("分享成功~");
                        }
                    });
                } else {
                    $$.alert('获取不到该名片的用户信息');
                }
            }
        });
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-5-14 20:56:12
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;
            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            //-- 分享
            $$.showShareView('点击右上角,分享名片给好友！');
        }
    }

    //计算时间差
    function dateDiff(d1,d2){
        d1 = new Date(d1.replace(/-/g,'/'));
        d2 = new Date(d2.replace(/-/g,'/'));
        let obj={},
            M1=d1.getMonth(),
            D1=d1.getDate(),
            M2=d2.getMonth(),
            D2=d2.getDate();
        obj.Y=d2.getFullYear() - d1.getFullYear() + (M1*100+D1 > M2*100+D2 ? -1 : 0);
        return obj.Y === 0 ? "低于1年" : obj.Y +"年";
    }
};
