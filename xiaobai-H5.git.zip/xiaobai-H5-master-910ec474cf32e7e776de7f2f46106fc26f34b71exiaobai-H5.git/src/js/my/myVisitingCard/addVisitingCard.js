/**
 *  新增名片 JS
 * @Author 吴成林
 * @Date 2020-1-14 15:11:08
 */
let startTime;
let endTime;
let insuranceTypeQuantity = 1;
window.onload = function(){

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        //-- 跳转自动绑定
        $$.staticPushAutoBind();

        dataLoading();
        loadDate();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        //获取当前年份
        const date = new Date();
        let year,month,day,defaultValue;
        /* 请求数据 */

        /* 开始时间 事件 */
        $(".startTime").on("click", function(){
            weui.datePicker({
                id: 1,
                start: 1900,
                end: $$.isValidObj(endTime)?new Date(endTime):date,
                defaultValue: $$.isValidObj(startTime)?startTime.split("-"):[date.getFullYear(), date.getMonth()+1, date.getDate()],
                onConfirm: function (result) {
                    year = result[0];
                    month = result[1];
                    day = result[2];
                    startTime = year + '-' + month + '-' + day;
                    $(".startTime > span").text(startTime).css("color", "rgb(120, 120, 120)").attr("data-id", startTime);
                }
            });
        });

        /* 结束时间 事件 */
        $(".endTime").on("click", function(){
            weui.datePicker({
                id: 2,
                start: $$.isValidObj(startTime)?new Date(startTime):1900,
                end: date,
                onConfirm: function (result) {
                    year = result[0];
                    month = result[1];
                    day = result[2];
                    endTime = year + '-' + month + '-' + day;
                    $(".endTime > span").text(endTime).css("color", "rgb(120, 120, 120)").attr("data-id", endTime);
                }
            });
        });

        /* 擅长领域 事件 */
        $(document).on("click", ".insuranceType>span",function(){
            if ($(this).hasClass("insuranceType-click")) {
                $(this).removeClass("insuranceType-click");
                insuranceTypeQuantity -= 1;
            } else {
                if (insuranceTypeQuantity >= 4){
                    $$.layerToast("最多选择4个");
                } else{
                    $(this).addClass("insuranceType-click");
                    insuranceTypeQuantity += 1;
                }
            }
        });

        /* 擅长领域 自定义 弹窗事件 */
        $(".more").on("click", function(){
            let index = layer.open({
                content:
                    `<div class="popupContent">
                        <div class="insuranceRepertoire">
                            <input type="text" maxlength="8" placeholder="请填写险种" onkeyup="this.value=this.value.replace(/[^\u4e00-\u9fa5]/g,'')" class="insurance-name" autofocus>      
                            <span class="count">0</span><span>/8</span>   
                        </div>
                        <div class="answer">
                            <span class="affirm">完成</span>
                        </div>
				    </div>`
            });

            /* 获取input输入内容长度 */
            $(".insurance-name").on("input propertychange",function() {
                let contentLength = $(this).val().trim().length;
                if (contentLength <= 8){
                    $('.count').text(contentLength);
                }
            });

            /* 完成 事件 */
            $(".answer").on("click", function(){
                let content = $(".insurance-name").val();
               if (content !== ""){
                   let html = `<span>${content}</span>`;
                   $('.insuranceType').append(html);
               }
                layer.close(index);
            });
        });

        /* 上传图片 - 头像*/
        $('.portrait').on("click", function() {
            $('#photo-one').click();
        });
        $('#photo-one').on("change", function() {
            let photo = $('.portrait');
            let deletes = $('.delete');
            let name = $('.photo-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /* 上传图片 - 微信二维码 */
        $('.qRCode-photo').on("click", function() {
            $('#photo-two').click();
        });
        $('#photo-two').on("change", function() {
            let photo = $('.qRCode-photo');
            let deletes = $('.qRCode-delete');
            let name = $('.qRCode-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /* 上传图片 - 图片墙1 */
        $('.photo1-portrait').on("click", function() {
            $('#photo1').click();
        });
        $('#photo1').on("change", function() {
            let photo = $('.photo1-portrait');
            let deletes = $('.photo1-delete');
            let name = $('.photo1-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /* 上传图片 - 图片墙2 */
        $('.photo2-portrait').on("click", function() {
            $('#photo2').click();
        });
        $('#photo2').on("change", function() {
            let photo = $('.photo2-portrait');
            let deletes = $('.photo2-delete');
            let name = $('.photo2-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /* 上传图片 - 图片墙3 */
        $('.photo3-portrait').on("click", function() {
            $('#photo3').click();
        });
        $('#photo3').on("change", function() {
            let photo = $('.photo3-portrait');
            let deletes = $('.photo3-delete');
            let name = $('.photo3-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /* 上传图片 - 图片墙4 */
        $('.photo4-portrait').on("click", function() {
            $('#photo4').click();
        });
        $('#photo4').on("change", function() {
            let photo = $('.photo4-portrait');
            let deletes = $('.photo4-delete');
            let name = $('.photo4-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /* 上传图片 - 图片墙5 */
        $('.photo5-portrait').on("click", function() {
            $('#photo5').click();
        });
        $('#photo5').on("change", function() {
            let photo = $('.photo5-portrait');
            let deletes = $('.photo5-delete');
            let name = $('.photo5-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /* 上传图片 - 图片墙6 */
        $('.photo6-portrait').on("click", function() {
            $('#photo6').click();
        });
        $('#photo6').on("change", function() {
            let photo = $('.photo6-portrait');
            let deletes = $('.photo6-delete');
            let name = $('.photo6-select');
            let the = $(this);

            files(photo, deletes, name, the);
        });

        /**----- 提交 事件绑定 ----**/
        $(".save").on("click", function() {
            $$.loading();
            /* 判断是否为空 */
            /*let startTime = $(".startTime span").attr("data-id");
            let endTime = $(".endTime  span").attr("data-id");*/
            let phone  = $(".phone").val();
            let insuranceType =  new Array();
            $(".insuranceType span.insuranceType-click").each(function(i,e){
                insuranceType[i] =  $(this).html();
            });
            let synopsis = $(".synopsis textarea").val();
            let rankTitle = $(".rankTitle textarea").val();
            let checkbox = $('#switch').prop('checked');

            if(!(/^1[3456789]\d{9}$/.test(phone))){
                $$.alert("手机号码有误，请重新填写！");
                $$.closeLoading();
                return false;
            }
            /* 图片上传 */
            let file_Head = $('#photo-one')[0].files[0];//头像
            let file_QRcode = $('#photo-two')[0].files[0];//二维码
            let photo1 = $('#photo1')[0].files[0];
            let photo2 = $('#photo2')[0].files[0];
            let photo3 = $('#photo3')[0].files[0];
            let photo4 = $('#photo4')[0].files[0];
            let photo5 = $('#photo5')[0].files[0];
            let photo6 = $('#photo6')[0].files[0];

            let fileArray = new Array();
            fileArray.push(photo1);
            fileArray.push(photo2);
            fileArray.push(photo3);
            fileArray.push(photo4);
            fileArray.push(photo5);
            fileArray.push(photo6);
            console.log(fileArray);
            let photo1Url;
            let photo2Url;
            let photo3Url;
            let photo4Url;
            let photo5Url;
            let photo6Url;
            let headPath;
            let qrCodePath;
            const uploadQRcode = function () {
                if (file_QRcode !== undefined){
                    let formData = new window.FormData();
                    formData.append('file', file_QRcode);
                    formData.append('formType', '10007');
                    $$.request({
                        url: UrlConfig.upload_attachment_upload,
                        loading: true,
                        pars: formData,
                        requestBody: true,
                        sfn: function(data) {
                            if(data.success) {
                                qrCodePath = data.datas.filePath;
                                $(".qRCode-select").attr("src",qrCodePath);
                                loopFileUpload(0);
                            } else {
                                $$.closeLoading();
                                $$.layerToast(data.msg);
                                return null;
                            }
                        },
                        ffn: function(data) {
                            $$.errorHandler();
                        }
                    });

                }else {
                    loopFileUpload(0);
                }
            };
            const loopFileUpload = function(i) {
                let formData = new window.FormData();
                formData.append('file', fileArray[i]);
                formData.append('formType', '10007');
                console.log("第"+i+"次");
                if (fileArray[i] !== undefined){
                    $$.request({
                        url: UrlConfig.upload_attachment_upload,
                        loading: true,
                        pars: formData,
                        requestBody: true,
                        sfn: function(data) {

                            if(data.success) {
                                if(i === 0) {
                                    photo1Url = data.datas.filePath;
                                } else if(i === 1) {
                                    photo2Url = data.datas.filePath;
                                } else if(i === 2) {
                                    photo3Url = data.datas.filePath;
                                } else if(i === 3) {
                                    photo4Url = data.datas.filePath;
                                }else if(i === 4) {
                                    photo5Url = data.datas.filePath;
                                }else if(i === 5) {
                                    photo6Url = data.datas.filePath;
                                    submit();
                                    return;
                                }
                                loopFileUpload(++i);

                            } else {
                                $$.closeLoading();
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function(data) {
                            $$.closeLoading();
                            $$.errorHandler();
                        }
                    });
                }else {
                    if ((i+1) > fileArray.length){
                        submit();
                        return;
                    }else {
                        loopFileUpload(++i);
                    }
                }

            };
            const submit = function () {
                $$.loading();
                let years;
                if ($$.isValidObj(startTime)){
                    let now = new Date();
                    now = now.getFullYear() + '-' + (now.getMonth() + 1) + '-' + now.getDate();
                    years = startTime + "/" + ($$.isValidObj(endTime)?endTime:now);
                }
                let isOpen ;
                if (checkbox){
                    isOpen = 1;//显示
                }else {
                    isOpen = 2;
                }
                let id = $$.getUrlParam("memberId");
                let shareUrl = $$.getFullHost()+"/src/pages/my/myVisitingCard/shareVisitingCard.html?memberId="+id;
                $$.request({
                    url: UrlConfig.mybusinesscard_insertOrUpdateBusinessCardOld,
                    pars:{
                        memberId:id,
                        years:years,
                        wxQRCode:qrCodePath,
                        synopsis:synopsis,
                        Speciality:insuranceType.join(","),
                        photo6:photo6Url,
                        photo5:photo5Url,
                        photo4:photo4Url,
                        photo3:photo3Url,
                        photo2:photo2Url,
                        photo1:photo1Url,
                        isOpen:isOpen,
                        shareUrl:shareUrl,
                        rankTitle:rankTitle
                    },
                    requestBody:true,
                    loading: true,
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success){
                            $$.alert("保存成功",function () {
                                $$.push("my/myVisitingCard/myVisitingCard",{
                                    memberId : id
                                });
                            })
                        }else {
                            $$.alert("保存失败");
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });

            };
            const  uploadHead = function () {
                if (file_Head !== undefined){
                    let formData = new window.FormData();
                    formData.append('file', file_Head);
                    formData.append('formType', '10007');
                    $$.request({
                        url: UrlConfig.upload_attachment_upload,
                        loading: true,
                        pars: formData,
                        requestBody: true,
                        sfn: function(data) {
                            if(data.success) {
                                headPath = data.datas.filePath;
                                $(".photo1-select").attr("src",headPath);
                                if (headPath == null){
                                    $$.closeLoading();
                                    return;
                                }
                                let id = $$.getUrlParam("memberId");
                                //保存头像
                                $$.request({
                                    url: UrlConfig.member_updateImgPath,
                                    loading: true,
                                    pars: {
                                        id:id,
                                        imgPath:headPath,
                                        phone:phone
                                    },
                                    requestBody: true,
                                    sfn: function(data) {
                                        uploadQRcode();
                                    },
                                    ffn: function(data) {
                                        $$.errorHandler();
                                    }
                                });


                            } else {
                                $$.layerToast(data.msg);
                                return null;
                            }
                        },
                        ffn: function(data) {
                            $$.errorHandler();
                        }
                    });
                }else {
                    uploadQRcode();
                }
            };
            uploadHead();

        });
    }
    /* 上传封装 */
    function files(photo, deletes, name, the) {
        let file = the[0].files[0];
        //文件类型
        let fileType = file.type;
        let type = getFileType(fileType);
        //文件大小
        let fileSize = (file.size / 1024).toFixed(2);
        if(type !== "jpg" && type !== "gif" && type !== "jpeg" && type !== "png") {
            $$.layerToast('请上传图片');
            return false;
        }
        if(fileSize > 10240) { //定义不能超过10MB
            $$.layerToast('请上传不超过10M的图片');
            return false;
        }
        lrz(file).then(function(resultObj) {
            name.attr("src", resultObj.base64);
            //name.css('display', 'block');
            name.show();
            photo.hide();
            deletes.show();
            name.off('click');
            name.on('click', function() {
                the.click();
            });
        });
    }

    /* 获取文件类型 */
    function getFileType(filePath) {
        let startIndex = filePath.lastIndexOf("/");
        if(startIndex !== -1) {
            return filePath.substring(startIndex + 1, filePath.length).toLowerCase();
        } else {
            return "";
        }
    }


    /**
     * 描述信息：加载数据
     * @author 覃创斌
     * @date 2020/1/15
     */
    function loadDate() {
        let id = $$.getUrlParam("memberId");
        $$.request({
            url: UrlConfig.market_growthrule_wx_getBrokerLevelData,
            pars:{
                memberId:id
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let code = data.growthRule.code;
                    let text = "";
                    if (code === 'b2') {
                        text += '黄金经纪人';
                    } else if (code === 'b3') {
                        text += '钻石经纪人';
                    } else {
                        text += '专业经纪人';
                    }
                    $('.level').html(text);
                    console.log(data);
                    if((data.member.imgPath==null)||(data.member.imgPath==="")){
                        $(".photo img").attr("src","../../../images/my/defaultImg.png");
                    }else {
                        $(".photo img").attr("src", data.member.imgPath);
                    }
                    if((data.member.memberName==null)||(data.member.memberName==="")){
                        $(".name").html(data.member.memberAccount);
                        $(".phone").val(data.member.phone)
                    }else {
                        $(".name").html(data.member.memberName);
                        $(".phone").val(data.member.phone)
                    }
                    gotoMyTeam();
                    visiting();
                } else {
                    $$.layerToast(data.msg);
                    $$.push("newIndex");
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //团长等级
    function gotoMyTeam(){
        let id = $$.getUrlParam("memberId");
        $$.request({
            url: UrlConfig.market_teammember_getTeamMember,
            pars:{
                memberId:id
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let teamId = data.teamId;
                    if (teamId != null) {
                        let teamLevel = data.teamLevel;
                        let mType = data.mType;

                        if (mType === 1 && teamLevel !== 'LV.0') {
                            $(".level").html(teamLevel)
                        }
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //加载名片信息
    function visiting() {
        let id = $$.getUrlParam("memberId");
        $$.request({
            url: UrlConfig.mybusinesscard_getBusinessCardScreen,
            pars:{
                memberId:id
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success){
                    if (data.entity !== undefined){
                        let years = data.entity.years;
                        if ($$.isValidObj(years) && years.includes("/")){
                            years = years.split("/");
                            startTime = years[0];
                            endTime = years[1];
                            $(".startTime > span").text(startTime).css("color", "rgb(120, 120, 120)").attr("data-id", startTime);
                            $(".endTime > span").text(endTime).css("color", "rgb(120, 120, 120)").attr("data-id", endTime);
                        }

                        if (data.entity.wxQRCode !== undefined) {
                            $(".qRCode-photo").html("<img src=\""+data.entity.wxQRCode+"\" />");
                        }
                        let array = data.entity.speciality.split(",");
                        insuranceTypeQuantity = array.length;
                        let insuranceType =  new Array();
                        $(".insuranceType span").each(function(i,e){
                            insuranceType[i] =  $(this).html();
                        });
                        let resultHtml = "";
                        if (array.length>insuranceType.length){
                            for (let i = 0; i < array.length; i++) {
                                if (array[i] === insuranceType[i]){
                                    resultHtml += " <span class=\"insuranceType-click\">"+array[i]+"</span>";
                                }
                            }
                            for (let i = 0; i < array.length; i++) {
                                if (array[i] !== insuranceType[i]){
                                    resultHtml += " <span class=\"insuranceType-click\">"+array[i]+"</span>";
                                }
                            }
                        }
                        console.log(array.length);
                        console.log(insuranceType.length);
                        if (array.length<insuranceType.length){
                            for (let i = 0; i < insuranceType.length; i++) {
                                if (array[i] === insuranceType[i]){
                                    resultHtml += " <span class=\"insuranceType-click\">"+array[i]+"</span>";
                                }
                                else {
                                    resultHtml += " <span >"+insuranceType[i]+"</span>";
                                }

                            }
                            for (let i = 0; i < array.length; i++) {
                                if (array[i] !== insuranceType[i]){
                                    resultHtml += " <span class=\"insuranceType-click\">"+array[i]+"</span>";
                                }
                            }
                        }
                        if (array.length === insuranceType.length){
                            for (let i = 0; i < insuranceType.length; i++) {
                                if (array[i] === insuranceType[i]){
                                    resultHtml += " <span class=\"insuranceType-click\">"+array[i]+"</span>";
                                }else {
                                    resultHtml += " <span >"+insuranceType[i]+"</span>";
                                }
                                if (array[i] !== insuranceType[i]){
                                    resultHtml += " <span class=\"insuranceType-click\">"+array[i]+"</span>";
                                }
                            }
                        }

                        // for (let i = 0; i < newArray.length; i++) {
                        //     console.log(newArray[i])
                        //     if (array[i] == newArray[i]){
                        //         resultHtml += " <span class=\"insuranceType-click\">"+array[i]+"</span>";
                        //     }else {
                        //         resultHtml += " <span >"+newArray[i]+"</span>";
                        //     }
                        // }
                        $(".insuranceType").html(resultHtml);
                        if (data.entity.photo1 !== undefined){
                            $(".photo1-portrait").attr("src",data.entity.photo1);
                        }
                        if (data.entity.photo2 !== undefined){
                            $(".photo2-portrait").attr("src",data.entity.photo2);
                        }
                        if (data.entity.photo3 !== undefined){
                            $(".photo3-portrait").attr("src",data.entity.photo3);
                        }
                        if (data.entity.photo4 !== undefined){
                            $(".photo4-portrait").attr("src",data.entity.photo4);
                        }
                        if (data.entity.photo5 !== undefined){
                            $(".photo5-portrait").attr("src",data.entity.photo5);
                        }
                        if (data.entity.photo6 !== undefined){
                            $(".photo6-portrait").attr("src",data.entity.photo6);
                        }
                        if (data.entity.synopsis !== undefined) {
                            $(".synopsis textarea").val(data.entity.synopsis);
                        }
                        if (data.entity.rankTitle !== undefined) {
                            $(".rankTitle textarea").val(data.entity.rankTitle);
                        }
                    }
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

};
