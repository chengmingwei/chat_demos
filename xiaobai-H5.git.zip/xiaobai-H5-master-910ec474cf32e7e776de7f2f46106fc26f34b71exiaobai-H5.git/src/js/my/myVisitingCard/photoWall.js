/**
 *  图片墙 JS
 * @Author 吴成林
 * @Date
 */
window.onload = function(){
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        //-- 请求数据

        let id = $$.getUrlParam("memberId");
        $$.request({
            url: UrlConfig.mybusinesscard_getPhotoWallList,
            pars:{
                memberId:id
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                console.log(data);
                if (data.success){
                    let html="";
                    for (let i = 0; i <data.list.length ; i++) {
                        html += `
                            <div class="image">
                                <img src="${data.list[i]}" />
                            </div>`;
                    }
                    $(".wrapper").html(html);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

    }
}
