window.onload = function () {
	$$.changeVersion();
	/**
	 * 数据存储中心
	 * @Author 吴成林
	 * @Date 2019/12/9 14:41
	 */
	const PAGE_STATE = {
		//-- 模板ID（执业评测）
		tempId: 2,
		//-- 状态
		xstatus: 0,
		//-- 测评结果ID
		resultId: null,
		//-- 保险测评题库ID
		itsubjectId: [],
		//-- 结果值
		vals: [],
	};

	/* 题目加载  */
	$$.request({
		url: UrlConfig.market_insuranceTest_questionShow,
		pars: {
			"tempId": 2,
		},
		loading: true,
		sfn: function(data) {
			$$.closeLoading();
			if(data.success) {

				testQuestionList(data);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});

	/* 下一步 事件绑定 */
	$(".nextStep").on("click",function(){
		/* 10道题答案 */
		var answer = ["A","B","C","A","B","D","A","A","A","A"];
		let titleAmount = $(".top .title span").text();

		//-- 获取答题结果值
		for(let i=0; i<answer.length; i++){
			switch (answer[i]) {
				case 'A':
					PAGE_STATE.vals[i] = $('.unit:eq('+i+') li:eq(1) span').text();
					PAGE_STATE.itsubjectId[i] = $('.unit:eq('+i+')').attr("data-id");
					break;
				case 'B':
					PAGE_STATE.vals[i] = $('.unit:eq('+i+') li:eq(2) span').text();
					PAGE_STATE.itsubjectId[i] = $('.unit:eq('+i+')').attr("data-id");
					break;
				case 'C':
					PAGE_STATE.vals[i] = $('.unit:eq('+i+') li:eq(3) span').text();
					PAGE_STATE.itsubjectId[i] = $('.unit:eq('+i+')').attr("data-id");
					break;
				case 'D':
					PAGE_STATE.vals[i] = $('.unit:eq('+i+') li:eq(4) span').text();
					PAGE_STATE.itsubjectId[i] = $('.unit:eq('+i+')').attr("data-id");
					break;
				default:
					break;
			}
		}

		/**----- 事件判断 ----**/
		for(let i=0; i<titleAmount; i++){
			let dataSelect = $('.unit:eq('+i+') .topic').attr("data-select");
			let href = $('.unit:eq('+i+')').attr("id");

			if(dataSelect == undefined || dataSelect == ""){
				$$.layerToast("第"+(i+1)+"题没有选择，请选择再下一步");
				$('#notAdded').attr("href","#"+href);
				$('#notAdded')[0].click();
				break;
			}else if(dataSelect != answer[i] || dataSelect == ""){
				$$.layerToast("第"+(i+1)+"题选择的答案不正确");
				$('#notAdded').attr("href","#"+href);
				$('#notAdded')[0].click();
				break;
			}else if(i == 9){
				//-- 添加评测结果
				addTestResult();
			}
		}
	});
	//-- 添加评测结果
	function addTestResult() {
		$$.request({
			url: UrlConfig.market_testresult_setTestResult,
			pars: {
				tempId:PAGE_STATE.tempId,
				xstatus:PAGE_STATE.xstatus,
			},
			loading: true,
			sfn: function(data) {
				$$.closeLoading();
				if(data.success) {
					PAGE_STATE.resultId = data.datas.id;

					//-- 添加评测结果
					addSubjectResult();
				}
			},
			ffn: function(data) {
				$$.errorHandler();
			}
		});
	}

	//-- 添加评测结果
	function addSubjectResult() {
		let itsubjectId = PAGE_STATE.itsubjectId.join();
		let vals = PAGE_STATE.vals.join();
		$$.request({
			url: UrlConfig.market_subjectresult_setSubjectResult,
			pars: {
				resultId:PAGE_STATE.resultId,
				itsubjectId:itsubjectId,
				vals:vals,
			},
			loading: true,
			sfn: function(data) {
				$$.closeLoading();

				if(data.success) {
					/* 跳转资料填写页面 */
					$$.push("my/fillDetails");
				}
			},
			ffn: function(data) {
				$$.errorHandler();
			}
		});
	}
};
/* 资质测试问题列表 */
function testQuestionList(data){
	let html = "";
	let html_title = "";
	let display_none = "display_none";
	let display_block = "display_block";
	let content = [];

	html_title += `<div class="title">资质测试 (共<span>${data.datas.list.length}</span>道题)</div>`;
	$(`.wrapper .top`).append(html_title);

	for (let i = 0; i < data.datas.list.length; i++) {
		content = data.datas.list[i].vals.split(",");
		html += `
			<ul class="unit" id="topic_${i}" data-id="${data.datas.list[i].id}">
				<li class="topic" data-select="">
					${data.datas.list[i].question}
				</li>
				<li>
					<label>
						<input type="radio" name="questionSelect_${i+1}" value="A" />
						<span>${content[0]}</span>
					</label>
				</li>
				<li>
					<label>
						<input type="radio" name="questionSelect_${i+1}" value="B" />
						<span>${content[1]}</span>
					</label>
				</li>
				<li class="${content.length>=3?display_block:display_none}">
					<label>
						<input type="radio" name="questionSelect_${i+1}" value="C" />
						<span>${content[2]}</span>
					</label>
				</li>
				<li class="${content.length>=4?display_block:display_none}">
					<label>
						<input type="radio" name="questionSelect_${i+1}" value="D" />
						<span>${content[3]}</span>
					</label>
				</li>
			</ul>`;

	}
	$(`.wrapper .content`).append(html);

	/* 单选按钮绑定checked 事件绑定 */
	$(":radio").on("click",function(){
		$(this).attr("checked","checked");
		$(this).parents("li").siblings().find('input').removeAttr("checked");
		const value = $(this).attr("value");
		$(this).parents("li").siblings(".topic").attr("data-select",value);
	});
}
