window.onload = function () {
	loadData();
	$$.changeVersion();
	//数据统计
	try {
		countAction('xb_15', null);
	} catch (error) {
		console.log(error);
	}

	/**
	 * 绑定事件
	 * @Author 肖家添
	 * @Date 2019/9/3 15:27
	 */
	function bindEvent() {
		$('.list li').on('click',function() {
			let id= $(this).attr("key");
			$$.push('my/settlementOfClaimsDetail',{"id":encodeURI(encodeURI(id))});
		});
	}



	//加载数据
	function loadData() {
		$$.request({
			url: UrlConfig.management_insurance_company,
			loading: true,
			method: 'GET',
			sfn: function (data) {
				$$.closeLoading();
				if (data.success) {
					console.log(data);
					bindInsuranceData(data.datas)
				} else {

				}

			}
		});
	}
	function  bindInsuranceData(data) {

		let html=``;
		for (let i=0;i<data.length;i++){
			if (data[i].shortName===""||data[i].shortName==null){
				data[i].shortName="暂无公司简称";
			}
			html+=`	<li key="${data[i].id}">
						<span>${data[i].shortName}</span>
						<img src="../../images/my/arrow.png" alt="">
					</li>`;
		}
		$(".list").html(html);
		bindEvent()
	}
};
