/**
 * 分享记录 JS
 * @Author 吴成林
 * @Date 2020-3-3 10:11:23
 */
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        loadReprintRecordList();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 文章详情
        $('.articleDetails').on('click', function () {
            $$.push("my/articleDetails");
        });

        //-- 去转载
        $('.toReprint').on('click', function () {
            $$.push("my/reprintedArticles");
        });

    }
    function loadReprintRecordList() {
        $$.request({
            url: UrlConfig.reprintrecord_getReprintRecordList,
            pars:{ },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading()
                if (data.success) {
                    let resultHtml = "";
                    if (data.datas.length > 0){
                        for (let i = 0; i < data.datas.length; i++) {
                            resultHtml += "<li class=\"articleDetails space-between reprintedArticle\" data-id="+data.datas[i].id+">";
                            resultHtml += "	<div class=\"articleContent\">";
                            resultHtml += "		<div>";
                            resultHtml += "			<div class=\"overflow articleTitle\">"+data.datas[i].articleTitle+"</div>";
                            resultHtml += "			<div class=\"articleContentCount flex-start\">";
                            resultHtml += "				<div>";
                            resultHtml += "					<img src=\"../../images/my/posters/shareRecord-3.png\">";
                            resultHtml += "					<span>"+data.datas[i].browse+"</span>人";
                            resultHtml += "				</div>";
                            resultHtml += "				<div>";
                            resultHtml += "					<img src=\"../../images/my/posters/shareRecord-2.png\">";
                            resultHtml += "					<span>"+data.datas[i].share+"</span>人";
                            resultHtml += "				</div>";
                            resultHtml += "			</div>";
                            resultHtml += "			<div>";
                            resultHtml += "				<span>来源：</span>";
                            resultHtml += "				<span>"+data.datas[i].articleSource+"</span>";
                            resultHtml += "			</div>";
                            resultHtml += "		</div>";
                            resultHtml += "		<div>"+data.datas[i].createTime+"</div>";
                            resultHtml += "	</div>";
                            resultHtml += "	<div class=\"articleContentRight\">";
                            resultHtml += "		<img src=\""+data.datas[i].coverUrl+"\">";
                            resultHtml += "		<div class=\"articleType\">转载</div>";
                            resultHtml += "	</div>";
                            resultHtml += "</li>";
                        }
                        $(".articleList").html(resultHtml);
                        //-- 文章详情
                        $('.reprintedArticle').on('click', function () {
                            $$.push("my/articleDetails",{
                                id:$(this).attr("data-id"),
                                switchState:true
                            });
                        });
                    }else {
                        $(".noContent").show()
                    }

                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};