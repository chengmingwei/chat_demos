/**
 * 更多好文 JS
 * @Author 吴成林
 * @Date 2020-3-3 11:56:48
 */
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        loadClassify();                    // 加载分类
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 文章详情
        $('.articleDetails').on('click', function () {
            $$.push("my/articleDetails");
        });

    }

    /**
     * 描述信息：加载分类
     * @author 吴成林
     * @date 2020-3-3 12:08:46
     */
    function loadClassify() {
        $$.request({
            url: UrlConfig.classify_list,
            pars:{
                state:1
            },
            method: "POST",
            loading: true,
            sfn: function (data) {
                if (data.success) {
                    $$.closeLoading();
                    let resultHtml = ``;
                    for (let i = 0; i < data.datas.length; i++) {
                        if (i == 0) {
                            resultHtml += `<div class="postersTypeSelected" href=".postersType" data-val=${data.datas[i].id}>${data.datas[i].classifyName}</div>`;
                            informationList(data.datas[i].id);
                        } else {
                            resultHtml += `<div href=".postersType" data-val=${data.datas[i].id}>${data.datas[i].classifyName}</div>`;
                        }
                    }
                    $(".postersType").html(resultHtml);
                } else {
                    $$.layerToast(`获取分类失败！[${data.msg}]`);
                }

                //-- 海报 - 右边属性栏
                $('.postersType>div').on('click', function () {
                    $(this).addClass("postersTypeSelected");
                    $(this).siblings().removeClass("postersTypeSelected");

                    let id = $(this).attr('data-val');
                    informationList(id);
                });
            }
        });
    }

    /**
     * 描述信息：加载资讯列表 --- (label)
     * @author 吴成林
     * @date 2020-3-3 12:29:23
     */
    function informationList(id) {
        $$.request({
            url: UrlConfig.getWebInformaList,
            pars: {
                classifyId: id
            },
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    //console.log("实现getWebInformaList函数");
                    let z = data.articleList.length + data.videoList.length;
                    let articleIndex = 0, articleLen = 0, videoIndex = 0, videoLen = 0;
                    let resultHtml = ``;
                    let s = 0;
                    if (data.articleList.length > 0) {
                        articleLen = data.articleList.length;
                    }
                    if (data.videoList.length > 0) {
                        videoLen = data.videoList.length;
                    }
                    //文章长度比视频长度
                    if (data.articleList.length > data.videoList.length) {
                        for (let i = 0; i < data.articleList.length; i++) {
                            resultHtml += ` <div class="part3" onclick='jumpArticleDetails(${data.articleList[i].id})'>
                                            <div class="item">
                                            <div class="left">
                                            <p>${data.articleList[i].title}</p>
                                            <div class="label">
                                            <span class="icon">${data.articleList[i].classifyname}</span>
                                            <div class="commentWrap">
                                            <span class="comment"></span><span class="commentNum">${data.articleList[i].ecount < 999 ? data.articleList[i].ecount : "999+"}</span>
                                            </div>
                                            <div class="eyesWrap">
                                            <span class="eyes"></span><span class="eyesNum">${data.articleList[i].vscount < 999 ? data.articleList[i].vscount : "999+"}</span>
                                            </div>
                                            </div>
                                            </div>
                                            <div class="right">
                                            <a href="javascript:;" style=background-image:url(${data.articleList[i].coverimgurl})></a>
                                            </div>
                                            </div>
                                            </div>`;
                            if (i > 0 && (i + 1) % 2 == 0) {
                                if (videoIndex < videoLen) {
                                    resultHtml += ` <div class="part2" onclick='jumpVideoDetails(${data.videoList[videoIndex].id})'>
                                                    <h3>${data.videoList[videoIndex].title}</h3>
                                                    <div class="img img1" style='position: relative;'>
                                                    <img id='coverImgUrl' style='height: 200px' src=${data.videoList[videoIndex].coverImgUrl} />
                                                    <img style='height: 40px; width: 40px; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);' src='../../images/know/information/ico_play.png' />
                                                    </div>
                                                    <div class="label">
                                                    <span class="icon">${data.videoList[videoIndex].classifyname}</span>
                                                    <div class="commentWrap">
                                                    <span class="comment"></span><span class="commentNum">${data.articleList[videoIndex].ecount < 999 ? data.articleList[videoIndex].ecount : "999+"}</span>
                                                    </div>
                                                    <div class="eyesWrap">
                                                    <span class="eyes"></span><span class="eyesNum">${data.articleList[videoIndex].vscount < 999 ? data.articleList[videoIndex].vscount : "999+"}</span>
                                                    </div>
                                                    </div>
                                                    </div>`;
                                }
                                videoIndex++;
                            }
                        }
                    } else if (data.videoList.length > data.articleList.length) {
                        for (let i = 0; i < data.videoList.length; i++) {
                            resultHtml += ` <div class="part2" onclick='jumpVideoDetails(${data.videoList[i].id})'>
                                            <h3>${data.videoList[i].title}</h3>
                                            <div class="img img1" style='position: relative;'>
                                            <img id='coverImgUrl' style='height: 200px' src=${data.videoList[i].coverImgUrl}' />
                                            <img style='height: 40px; width: 40px; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);' src='../../images/know/information/ico_play.png' />
                                            </div>
                                            <div class="label">
                                            <span class="icon">${data.videoList[i].classifyname}</span>
                                            <div class="commentWrap">
                                            <span class="comment"></span><span class="commentNum">${data.articleList[i].ecount < 999 ? data.articleList[i].ecount : "999+"}</span>
                                            </div>
                                            <div class="eyesWrap">
                                            <span class="eyes"></span><span class="eyesNum">${data.articleList[i].vscount < 999 ? data.articleList[i].vscount : "999+"}</span>
                                            </div>
                                            </div>
                                            </div>`;
                            if (i > 0 && (i + 1) % 2 == 0) {
                                if (articleIndex < articleLen) {
                                    resultHtml += ` <div class="part3" onclick='jumpArticleDetails(${data.articleList[articleIndex].id})'>
                                                    <div class="item">
                                                    <div class="left">
                                                    <p>${data.articleList[articleIndex].title}</p>
                                                    <div class="label">
                                                    <span class="icon">${data.articleList[articleIndex].classifyname}</span>
                                                    <div class="commentWrap">
                                                    <span class="comment"></span><span class="commentNum">${data.articleList[articleIndex].ecount < 999 ? data.articleList[articleIndex].ecount : "999+"}</span>
                                                    </div>
                                                    <div class="eyesWrap">
                                                    <span class="eyes"></span><span class="eyesNum">${data.articleList[articleIndex].vscount < 999 ? data.articleList[articleIndex].vscount : "999+"}</span>
                                                    </div>
                                                    </div>
                                                    </div>
                                                    <div class="right">
                                                    <a href="javascript:;" style=background-image:url(${data.articleList[articleIndex].coverimgurl})></a>
                                                    </div>
                                                    </div>
                                                    </div>`;
                                }
                                articleIndex++;
                            }
                        }
                    }
                    $(".informationList").html(resultHtml);
                    // loadRes();
                    // return resultHtml;
                } else {
                    $$.layerToast(`获取资讯列表失败！[${data.msg}]`);
                }
            }
        });
    }


};

//跳转文章详情
function jumpArticleDetails(id) {
    $$.push("newKnow/articleDetails",{
        id:id
    });
}