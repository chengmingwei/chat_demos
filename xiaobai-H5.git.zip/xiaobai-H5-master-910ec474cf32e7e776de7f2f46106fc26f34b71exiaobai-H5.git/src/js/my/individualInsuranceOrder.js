

/**
 * 个险订单 JS
 * @Author 肖家添
 * @Date 2019/10/15 10:24
 */


ShawHandler.loaderRes({
    scripts: [
        //-- Order helper
        `js/product/orderHelper.js`,
    ]
});

window.onload = function(){
    //数据统计
    try {
        countAction('xb_70', null);
    } catch (error) {
        console.log(error);
    }

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 展示的列表类型, [10001: 已完成订单, 10002: 处理中订单]
        exhibition: 10001,
        //-- 分页参数
        pagingData : {
            10001: $Constant.paginationDefault,
            10002: $Constant.paginationDefault
        },
        //-- 列表数据源, 根据列表类型区分存储
        listDataSource: {
            10001: [],
            10002: []
        },
        //-- 过滤日期数据源
        filterDataTimesDataSource: [],
        //-- 过滤日期
        filterDataTimes: {
            10001: "筛选",
            10002: "筛选"
        },
        //-- 订单类型 [0: 个险, 1: 企业险, 2: 雇主责任险, 3: 公众责任险]
        insuranceIsGroup: 0,
        memberId: null
    };

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){

        const insuranceIsGroup = $$.getUrlParam("insuranceIsGroup");

        if($$.isValidObj(insuranceIsGroup) && ["0", "1", "2", "3"].indexOf(insuranceIsGroup) != -1){
            PAGE_STATE.insuranceIsGroup = insuranceIsGroup;
        }

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

        //-- 获取订单列表
        findOrderList({});

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 选择数据显示类型 [10001: 已完成, 10002: 处理中]
        $(".nav li[data-exhibition]").click(function(){
            $(".nav li[data-exhibition]").removeClass("active");
            $(this).addClass("active");

            let exhibition = $(this).attr("data-exhibition");

            PAGE_STATE.exhibition = parseInt(exhibition);
            $(".nav li .select").html(PAGE_STATE.filterDataTimes[exhibition]);

            const listDataSource = PAGE_STATE.listDataSource[exhibition];
            if(!$$.isValidObj(listDataSource) || listDataSource.length <= 0){
                findOrderList({});
            }else{
                generateHTML();
            }
            if(PAGE_STATE.insuranceIsGroup === 0){
                if(exhibition === 10001){
                    countAction("xb_2066");
                }else{
                    countAction("xb_2067");
                }
            }
        });

        //-- 页面滚动到底部监听事件
        $Listener.pageScrollToBottomListener(function(){
            let { _current, _pageSize, _total } = getPaginationData();

            //-- 总页数
            const sumPageNum = Math.ceil(_total / _pageSize);
            if(_current >= sumPageNum){
                return;
            }

            if($(".pageLoading").size() > 0){
                return;
            }

            setPaginationData("_current", ++_current);

            $(".content>.list").append(`<p class="pageLoading" style="text-align: center;font-size: 14px;margin: 15px 0px;">加载中...</p>`);
            findOrderList({
                loading: false,
                handlerOverCallback: function(){
                    $(".pageLoading").remove();
                }
            });
        });

        //-- 数据筛选
        $(".filterData").off().click(function(){
            let { exhibition, filterDataTimesDataSource } = PAGE_STATE;

            if(!$$.isValidObj(filterDataTimesDataSource) && filterDataTimesDataSource.length <= 0){
                return;
            }

            filterDataTimesDataSource = filterDataTimesDataSource.map((item) => {
                return {
                    value: item,
                    label: item
                };
            });

            weui.picker(filterDataTimesDataSource, {
                defaultValue: [filterDataTimesDataSource[0].value],
                onConfirm: function (result) {
                    const { value, label } = result[0];

                    $(".nav li .select").html(label);

                    PAGE_STATE.filterDataTimes[exhibition] = value;
                    PAGE_STATE.listDataSource[exhibition] = [];
                    PAGE_STATE.pagingData[exhibition] = $Constant.paginationDefault;

                    findOrderList({});
                },
                id: `filterData_picker_${exhibition}`
            });
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){
        const { insuranceIsGroup } = PAGE_STATE;
        $("title").html(insuranceIsGroup == 0 ? "个险订单" : "团险订单");

        $$.clearHTMLNotes();
        switch(PAGE_STATE.insuranceIsGroup){
            case 0:{
                countAction("xb_2066");
                break;
            }
            case 1:{
                countAction("xb_2068");
                break;
            }
            case 2:{
                countAction("xb_2069");
                break;
            }
        }
    }

    /**
     * 获取订单列表
     * @Author 肖家添
     * @Date 2019/10/15 10:25
     */
    function findOrderList({loading = true, handlerOverCallback}){
        const { exhibition, filterDataTimes, insuranceIsGroup } = PAGE_STATE;
        let params = JSON.parse(JSON.stringify(getPaginationData()));

        //-- params handler
        (function(){
            if("10001" == exhibition){
                //-- 已完成
                params.orderStatus = OrderHelper.orderStatus.ORDER_STATUS_2;
            }else if("10002" == exhibition){
                //-- 处理中
                params.orderStatus = OrderHelper.orderStatus.ORDER_STATUS_0;
            }

            //-- 投保时间
            const insuranceTime = filterDataTimes[exhibition];
            if("筛选" != insuranceTime){
                params.insuranceTime = insuranceTime;
            }

            //-- 个险/团险
            params.insuranceIsGroup = insuranceIsGroup;
        })();

        $$.request({
            url: UrlConfig.mobileOrderInfoLog_getOrderByUser,
            pars: params,
            loading: loading,
            checkLogin: true,
            sfn: function (data) {
                $$.closeLoading();

                if(data.success){
                    responseHandler(data.datas);
                }else{
                    $$.alert(data.msg);
                }
            }
        });

        //-- 订单列表 -> 响应处理
        function responseHandler(data){
            const { filterDataTimes,memberId } = data;
            data = data.list;
            try{

                PAGE_STATE.filterDataTimesDataSource = filterDataTimes;

                const { exhibition, listDataSource } = PAGE_STATE;
                const { list, pagination } = data;

                PAGE_STATE.memberId = memberId;
                //-- paging handler
                (function(){
                    setPaginationData("_current", pagination.current);
                    setPaginationData("_pageSize", pagination.pageSize);
                    setPaginationData("_total", pagination.total);
                })();

                //-- html handler
                (function(){

                    //-- 数据合并
                    PAGE_STATE.listDataSource[exhibition] = listDataSource[exhibition].concat(list);

                    generateHTML();
                })();
            }catch (e) {
                console.error(e);
            }finally {
                $$.closeLoading();

                if(handlerOverCallback) handlerOverCallback();
            }
        }
    }

    function generateHTML(){
        const { exhibition, listDataSource,memberId } = PAGE_STATE;
        let html = "", datums = listDataSource[exhibition];
        console.log(memberId);
        if(!$$.isValidObj(datums) || datums.length <= 0){
            $$.showNoResultView({
                msg: "无订单信息",
                btnText: "获取保障服务",
                btnHref: "product/productList"
            });
        }else{
            $$.hideNoResultView();
        }

        for(const item of datums){
            const { orderId, insuranceName, beginTime, endTime, orderStatus, sellProductName, orderToken,isInsuredStatus } = item;

            html += `
                <li data-token="${orderToken}">
                    <p class="top">
                        <span>${sellProductName}</span>
                        <span class="status">${orderStatus}</span>
                    </p>
                    <div class="bottom">
                        <p><span class="label">订单号：</span><span>${orderId}</span></p>
                        <p><span class="label">投保人：</span><span>${insuranceName}</span></p>
                        <p><span class="label">保障时间：</span><span>${beginTime} 至 ${endTime}</span></p>
                   
                        ${isInsuredStatus === '7' ? `<p class="invite" data-id="${orderId}" data-memberId="${memberId}"><span>邀请客户评价</span></p>` : ``}
                        ${exhibition === 10001 && 1 !== 1 ? `
                            <button class="commentBtn">评价有礼</button>
                        ` : ``}
                    </div>
                </li>
            `;
        }

        //-- 订单详情
        $(".content>.list").html(html).find("li").off().click(function(){
            const orderToken = $(this).attr("data-token");
            $$.push("product/orderDetail", {orderToken});
        });
        //-- 评论页面
        $(".content>.list").find(".commentBtn").off().click(function(e){
            //-- 阻止事件穿透
            e.stopPropagation();
        });
        //-- 邀请客户评价
        $(".content>.list").find(".invite").off().click(function(e){
            //-- 阻止事件穿透
            e.stopPropagation();

            //先判断是否评论过
            $$.request({
                url: UrlConfig.orderevaluation_getOrderEvaluationList,
                pars: {
                    memberId: $(this).attr("data-memberId"),
                    orderId:$(this).attr("data-id")
                },
                method: "POST",
                requestBody:true,
                sfn: function (data) {
                    if (data.datas.length === 0){
                        //-- 分享
                        $$.showShareView('点击右上角分享,邀请客户评价！');
                        shareWeeklyLuckyDraw($(this).attr("data-id"));
                    }else {
                        $$.alert("客户已评论，请勿重复点击！")
                    }
                }
            });


        });
    }

    /**
     * 获取分页参数
     * @Author 肖家添
     * @Date 2019/10/15 12:16
     */
    function getPaginationData(){
        const { exhibition, pagingData } = PAGE_STATE;

        return pagingData[exhibition];
    }

    /**
     * 设置分页参数
     * @Author 肖家添
     * @Date 2019/10/15 12:17
     */
    function setPaginationData(key, val){
        const { exhibition, pagingData } = PAGE_STATE;
        pagingData[exhibition][key] = val;

        PAGE_STATE.pagingData = pagingData;
    }

    /**
     * 邀请评价
     */
    function shareWeeklyLuckyDraw(orderId) {
        if (!$WeChat.isWx()) {
            return;
        }
        $$.request({
            url: UrlConfig.member_getMemberName,
            sfn: function (data) {
                let _lineLink = $$.getFullHost() + '/src/pages/product/myEstimate/myEstimateBroker.html';
                /* 是否带参 */
                _lineLink += $$.jsonToUrlParams({
                    share:true,
                    memberId:data.id,
                    id : orderId
                });
                weChatJSTool.share({
                    _imgUrl:  $$.isValidHeadImg(data.imgPath),
                    _lineLink:  _lineLink,
                    _shareTitle: '我的个险订单',
                    _descContent: '这是我所有的订单详情，点击即可查看记录',
                    _sfn: function () {
                        $$.layerToast("分享成功~");
                    }
                });
            }
        });

    }

};
