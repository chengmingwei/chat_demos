window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_84', null);
    } catch (error) {
        console.log(error);
    }

    //公司简介
    $('.intro').click(function () {
        $$.push('my/companyProfile');
    });

    //小白用户协议
    $('.protocol').click(function () {
        $$.push('my/userAgreement');
    });

    //小白保险商标声明
    $('.statement').click(function () {
        $$.push('my/trademarkStatement');
    });

}