window.onload = function () {
    $$.changeVersion();
    setNowLv();

    //点击成长值说明
    $('.explain').click(()=>{
        $$.push('teams/rule',{page : "3"});
    });
}

/*根据成长值改变进度条和等级*/
function setNowLv() {
    let teamId = $$.getUrlParam("teamId");
    $$.request({
        url: UrlConfig.market_teamlevel_wx_getTeamLevelData,
        pars:{
            teamId:teamId
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let member = data.member;
                $('.name').html(member.memberName);
                let imgPath = member.imgPath;
                if (imgPath) {
                    $('.photo img').attr('src',imgPath);
                }
                changeHtml(data);
                let teamStatus = data.teamStatus;
                $('.examine').click(()=>{
                    if(PAGE_APP){
                        $$.pushAPP("/team/detail", {
                            teamState: 5,
                            teamId: teamId
                        });
                    }else{
                        let gotoUrl = 'teams/addDetails';
                        if (teamStatus == 2) {
                            gotoUrl = 'teams/colonel';
                        }
                        $$.push(gotoUrl,{teamId:teamId});
                    }
                });
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

}

function changeHtml(data) {
    let teamLevel = data.teamLevel;
    let nextTeamLevel = data.nextTeamLevel;
    //当前等级
    let nowLv = data.orderPayMoney;
    let code = teamLevel.code;
    let mgrSubsidy = teamLevel.mgrSubsidy;
    let rearSubsidy = teamLevel.rearSubsidy;
    $('.nowLevel').text(code);
    $('.mgrSubsidy').html(mgrSubsidy + '%');
    $('.rearSubsidy').html(rearSubsidy + '%');
    //将当前的成长值显示到页面
    $('.now').text(nowLv);
    let isFull = data.isFull;
    if (isFull) {
        $('.grow,#notFull').hide();
        $('#isFull').css('display','flex');
        $('#isFull').css('height','auto');
        $('#isFull > img').attr('src','../../images/my/level/team/v6.png');
        $('.photo').css('margin-top',25);
    } else {
        let maxAmount = teamLevel.maxAmount;
        let nextCode = nextTeamLevel.code;
        //将当前的成长值显示到页面
        $('.now').text(nowLv);
        $('.all').text(maxAmount);
        $('.growTitle > div:eq(0)').text(code);
        $('.growTitle > div:eq(2)').text(nextCode);
        let percent = data.percent;
        $('.number').css('width', `${percent}%`);
    }
    if (code == 'LV.0') {
        $('.left').html(`<div id="lv0"></div>`);
        $('.right').html(`<img src="../../images/my/level/team/v1-icon.png" />`);
    } else if (code == 'LV.1') {//LV1
        $('.upper').css('background','url("../../images/my/1.png") no-repeat center center /100% 100%');
        $('.left').html(`<img src="../../images/my/level/team/v1-icon.png" />`);
        $('.right').html(`<img src="../../images/my/level/team/v2-icon.png" />`);
        $('.teamMsg,.icon,.number').css('background','rgb(97, 55, 186)');
    } else if (code == 'LV.2') {//LV2
        $('.upper').css('background','url("../../images/my/2.png") no-repeat center center /100% 100%');
        $('.left').html(`<img src="../../images/my/level/team/v2-icon.png" />`);
        $('.right').html(`<img src="../../images/my/level/team/v3-icon.png" />`);
        $('.teamMsg,.icon,.number').css('background','rgb(171, 0, 184)');
    } else if (code == 'LV.3') {//LV3
        $('.upper').css('background','url("../../images/my/3.png") no-repeat center center /100% 100%');
        $('.left').html(`<img src="../../images/my/level/team/v3-icon.png" />`);
        $('.right').html(`<img src="../../images/my/level/team/v4-icon.png" />`);
        $('.teamMsg,.icon,.number').css('background','rgb(164, 0, 0)');
    } else if (code == 'LV.4') {//LV4
        $('.upper').css('background','url("../../images/my/4.png") no-repeat center center /100% 100%');
        $('.left').html(`<img src="../../images/my/level/team/v4-icon.png" />`);
        $('.right').html(`<img src="../../images/my/level/team/v5-icon.png" />`);
        $('.teamMsg,.icon,.number').css('background','rgb(255, 112, 82)');
    } else if (code == 'LV.5') {//LV5
        $('.upper').css('background','url("../../images/my/5.png") no-repeat center center /100% 100%');
        $('.left').html(`<img src="../../images/my/level/team/v5-icon.png" />`);
        $('.right').html(`<img src="../../images/my/level/team/v6-icon.png" />`);
        $('.teamMsg,.icon,.number').css('background','rgb(255, 187, 0)');
    } else {//LV6
        $('.upper').css('background','url("../../images/my/6.png") no-repeat center center /100% 100%');
        $('.teamMsg,.icon').css('background','rgb(50, 177, 108)');
    }
}
