let id;
window.onload = function () {
	/**----- 公告栏文字滚动 ----**/
	ScrollImgLeft();

    $$.changeVersion();
	/**
     *获取积分
     *
     * */
    IntegralLevel();

    //TO DO ...
    /**----- 工具项事件绑定 ----**/
    EvtMgr.bindToLi('tools-group');
    EvtMgr.bindToLi('member-group');
    load();
    /**----- 关于我们，意见反馈 事件绑定 ----**/
    EvtMgr.bindToLi('list');
    $(".withdraw-btn").on("click",function () {
        $$.push("my/withdraw",{
            id:id
        });
    });



    $(".logo,.username,.arrow").click(function () {
        //window.location.href = "../../pages/my/personalInformation.html";
        $$.push('my/personalInformation');
    });


    $(".bank").click(function () {
        window.location.href = "../../pages/my/personalInformation4.html";
    });
    $(".free_clinic").click(function () {
        window.location.href = "https://m.myweimai.com/topic/epidemic_info.html?from=groupmessage&isappinstalled=0";
    });
    $('.myCardBag').click(function () {
        $$.push("my/cardBag");
    });
    /**----- 滚动条 执业认证 事件绑定 ----**/
	$(".announcement").on("click",function(){
		/* 跳转执业认证 */
		$$.push("my/professionalCertification");
	});

    $(".integral-buy").click(() => {
        $$.request({
            url: UrlConfig.checkIn_mailejifen_login,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });

    /*$('.activity-content').click(()=>{
        $$.push('my/newGiftBag');
    });*/
	//-- 跳转自动绑定
    $$.staticPushAutoBind();
};
/**
 * 描述信息：加载用户数据
 * @author 覃创斌
 * @date 2019-09-23
*/
function load() {
    $$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                console.log(data);
                id = data.datas.id;
                localStorage.setItem("memberId", id);

                if (data.datas.userStatus === 2 && data.datas.mtype === 4){
                    $(".username").html(data.datas.rname);
                }else{
                    $(".username").html(data.datas.phone);
                }
                if((data.datas.imgPath==null)||(data.datas.imgPath==="")){
                    console.log("头像为空!");
                    $(".logo").attr("src","../../images/my/defaultImg.png");
                }else {
                    $(".logo").attr("src", data.datas.imgPath);
                }
                let userStatus = data.datas.userStatus;
                if (userStatus === 0 || userStatus === 3 ) {
                    $('.announcement').css('display','block');
                }
                /*let hasNewUserByParent = data.datas.hasNewUserByParent;
                if (hasNewUserByParent) {
                    $('.swiper-slide[htmlUrl="my/newGiftBag"]').remove();
                }*/
                doSwiper();
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

//获取积分等级
function IntegralLevel() {
    $$.request({
        url: UrlConfig.member_getMemberIntegralLevel,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                console.log(data.datas);
                bindMemberIntegralLevel(parseInt(data.datas));
            } else {

            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

}

//绑定元素
function  bindMemberIntegralLevel(integral) {
    let integral_level_img=`<img class="level-nomal-img level-integral" src="../../images/my/level/integral/integral-level.png" />`;
    let star_img=`<img class="level-nomal-img" src="../../images/my/level/integral/level-star.png" />`;
    let moon_img=`<img class="level-nomal-img" src="../../images/my/level/integral/level-moon.png" />`;
    let sun_img=`<img class="level-nomal-img" src="../../images/my/level/integral/level-sun.png" />`;
    let crown_img=`<img class="level-nomal-img" src="../../images/my/level/integral/crown.png" />`;
    let jewel_img=`<img class="level-nomal-img" src="../../images/my/level/integral/jewel.png" />`;
    let html = integral_level_img;
    if (integral < 500) {
        html = '积分:' + integral;
        $('#integral').css('color','#ffc900');
    } else {
        let starNum = Math.floor(integral/500);
        let moonNum = Math.floor(starNum/5);
        let sunNum = Math.floor(moonNum/5);
        let crownNum = Math.floor(sunNum/5);
        let jewelNum = Math.floor(crownNum/5);
        if(jewelNum > 0) {
            console.log('jewelNum:' + jewelNum);
            for(let i = 0;i < jewelNum;i++) {
                html += jewel_img;
            }
        }
        if(crownNum > 0) {
            let num = crownNum - jewelNum * 5;
            console.log('crownNum:' + num);
            for(let i = 0;i < num;i++) {
                html += crown_img;
            }
        }
        if(sunNum > 0) {
            let num =sunNum - crownNum * 5;
            console.log('sunNum:' + num);
            for(let i = 0;i < num;i++) {
                html += sun_img;
            }
        }
        if(moonNum > 0) {
            let num = moonNum - sunNum * 5;
            console.log('moonNum:' + num);
            for(let i = 0;i < num;i++) {
                html += moon_img;
            }
        }
        if(starNum > 0) {
            let num = starNum - moonNum * 5;
            console.log('starNum:' + num);
            for(let i = 0;i < num;i++) {
                html += star_img;
            }
        }
    }
    $('#integral').html(html).on('click',function () {
        $$.push('signin/integralList',{
            yintegral:integral
        });
        return false;
    });
    $$.staticPushAutoBind();
}



//文字横向滚动
function ScrollImgLeft(){
    let speed=50;//初始化速度 也就是字体的整体滚动速度
    // let MyMar = null;//初始化一个变量为空 用来存放获取到的文本内容
    let scroll_begin = document.getElementById("scroll_begin");//获取滚动的开头id
    let scroll_end = document.getElementById("scroll_end");//获取滚动的结束id
    let scroll_div = document.getElementById("scroll_div");//获取整体的开头id
    scroll_end.innerHTML=scroll_begin.innerHTML;//滚动的是html内部的内容,原生知识!

    //定义一个方法
    function Marquee(){
        if(scroll_end.offsetWidth-scroll_div.scrollLeft<=0)
            scroll_div.scrollLeft-=scroll_begin.offsetWidth;
        else
            scroll_div.scrollLeft++;
	}
	setInterval(Marquee,speed);
}

function doSwiper() {
    /**
     * 我的页面小广告轮播图
     */
    var swiper = new Swiper('.swiper-container', {
        spaceBetween: 15,
        centeredSlides: true,
        loop: true,
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
        },
        on:{
            tap: function(){
                const htmlUrl = $(".swiper-container .swiper-slide[data-swiper-slide-index=" + this.realIndex + "]").attr('htmlUrl');
                if ($$.isValidObj(htmlUrl)) {
                    $$.push(htmlUrl);
                }
            },
        },
    });
}
