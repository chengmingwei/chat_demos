/**
 * 转载文章 JS
 * @Author 吴成林
 * @Date 2020-3-1 17:15:12
 */
const PAGE_STATE = {
    whetherVIP: false,                  // 是否是VIP
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        getVipData();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 去分享
        $('.toShare').on('click', function () {
            if (!PAGE_STATE.whetherVIP) {
                $$.confirm({
                    title: "哦噢，使用此功能需先开通展业功能包哦，点击确认即前往开通！",
                    onOkLabel: "确认",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
                return;
            }
            let articlesUrl = $("#articlesUrl").val();
            if ($$.isValidObj(articlesUrl.trim(),"文章链接不能为空！！！")){
                if (articlesUrl.indexOf("https://mp.weixin.qq.com") ==  -1){
                    $$.layerToast("文章链接不正确,如有不明白请看教程！！！");
                   return;
                }
                $$.request({
                    url: UrlConfig.reprintarticle_uploadArticle,
                    pars:{
                        url:articlesUrl
                    },
                    requestBody:true,
                    loading: true,
                    sfn: function (data) {
                        if (data.success) {
                            $$.push("my/toShare",{
                                id:data.reprintArticleId,
                                filePath:data.filePath
                            });
                            console.log(data);
                            $$.closeLoading();
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });

            }

        });

        //-- 新手教程
        $('.newbieGuide').on('click', function () {
            $$.push("my/newbieGuide");
        });
    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType !== 0;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
