/**
 * 收货地址 js
 */
window.onload = function () {
    $$.changeVersion();
    /**
     * 数据存储中心
     * @Author 吴成林
     * @Date 2019/12/9 14:41
     */
    const PAGE_STATE = {
        //-- 收货人姓名
        consignee: "",
        //-- 手机号
        phone: "",
        //-- 收货地址
        address: "",
        //-- 抽奖记录表ID
        lotteryRecodeId: 0,
    };

    //-- 获取URL参数lotteryRecodeId（抽奖记录表ID）
    if($$.isValidObj($$.getUrlParam("lotteryRecodeId"))){
        PAGE_STATE.lotteryRecodeId = $$.getUrlParam("lotteryRecodeId");
    }

    //-- 加载 收货地址数据
    $$.request({
        url: UrlConfig.market_receivingaddress_getByPars,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                console.log(data);
                PAGE_STATE.consignee = data.datas.consignee;
                PAGE_STATE.phone = data.datas.phone;
                PAGE_STATE.address = data.datas.address;
                PAGE_STATE.lotteryRecodeId = data.datas.id;

                $('#consignee').val(data.datas.consignee);	//收货人姓名
                $('#phone').val(data.datas.phone);	//手机号
                $('#detailedAddress').val(data.datas.address);	//收货地址
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

    //-- 保存
    $('.save').on('click', function() {
        let consignee = $('#consignee').val().trim();	//收货人姓名
        let phone = $('#phone').val().trim();	//手机号
        let address = $('#detailedAddress').val().trim();	//收货地址

        let datum = {
            consignee,
            phone
        };
        let checkMsgArr = [];
        for (const key in datum) {
            let type, msg;
            switch (key) {
                case 'consignee':
                    type = "中文姓名";
                    msg = "姓名格式不正确~";
                    break;
                case 'phone':
                    type = "手机号码";
                    msg = "手机号码格式不正确~";
                    break;
                default:
                    break;
            }
            const checkMsg = new $Valid.validComment({
                "type": type,
                "isEmpty": false,
                "value": datum[key],
                "errorMsg": msg
            }).check();
            checkMsgArr.push(checkMsg);
        }

        if (checkMsgArr[0] != true) {
            $$.throwTips(checkMsgArr[0]);
        } else if (checkMsgArr[1] != true) {
            $$.throwTips(checkMsgArr[1]);
        } else if (!$$.isValidObj(address)) {
            $$.layerToast("收货地址不能为空")
        } else if ($$.isValidObj(PAGE_STATE.consignee) && $$.isValidObj(PAGE_STATE.phone) && $$.isValidObj(PAGE_STATE.address)) {
            if(PAGE_STATE.consignee == consignee && PAGE_STATE.phone == phone && PAGE_STATE.address == address){
                $$.layerToast("收货地址未修改~");
            } else if (PAGE_STATE.lotteryRecodeId != 0) {
                $$.request({
                    url: UrlConfig.market_receivingaddress_save,
                    pars: {
                        consignee:consignee,
                        phone:phone,
                        address:address,
                        id:PAGE_STATE.lotteryRecodeId,
                    },
                    loading: true,
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success) {
                            console.log(data);
                            $$.alert("更新成功！",function () {
                                $$.push("my/personalInformation");
                            })
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            }
        } else {
            $$.request({
                url: UrlConfig.market_receivingaddress_save,
                pars: {
                    consignee:consignee,
                    phone:phone,
                    address:address,
                },
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        console.log(data);
                        $$.alert("绑定成功！",function () {
                            $$.push("my/personalInformation");
                        })
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        }
    });
    countAction("xb_2061");
}
