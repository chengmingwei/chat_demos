let mtype=null
$(function(){
    try {
        countAction('xb_8', null);
    } catch (error) {
        console.log(error);
    }
	/* 加载用户消息  */
	$$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                mtype=data.datas.mtype;
                if (mtype === 4){
                    $(".broker").show();
                }
            	if ((data.datas.rname==null)||data.datas.rname===""){
                    $(".header:first span").html(data.datas.account);
                }else{
                    $(".header:first span").html(data.datas.rname);
                }

            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

	/**----- 意见反馈 常见问题 事件绑定 ----**/
	$(".list").off().on("click", "li", function(){
	    const that = $(this),
	        url = that.attr("url"),
            mtaEventId = that.attr("mtaEventId");
	    if (that.hasClass('service')){
            /* 找客服 二维码 绑定事件 */
            var index = layer.open({
                content:
                    `<div class="popupContent">
					<div class="question">
						<b>扫描下方二维码，添加小白专属客服</b>
						<img src="../../images/my/serviceQrCode.png" />
						<span>长按识别二维码</span>
					</div>
				</div>`
            });
            countAction("xb_2045");
        } else {
            if($$.isValidObj(mtaEventId)){
                countAction(mtaEventId);
            }
            location.href = url;
        }
    });

});
/*
function clickMiddleman() {
    if (mtype!=4){
        $$.layerToast("你没有权限查看此问题");
        return;
    }else{
        $$.push("my/faq.html?id=8");
    }
}*/
