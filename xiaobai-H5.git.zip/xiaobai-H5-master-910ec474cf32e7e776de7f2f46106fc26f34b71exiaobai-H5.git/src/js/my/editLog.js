var id = null;
//-- 本地缓存
const cacheKey = "WX_workLog_DATA";
$(function(){
	/* 加载数据 */
	if($$.getUrlParam("id") != null){
		id = $$.getUrlParam("id");
	}
	if($$.getUrlParam("workLogId") != null){
		let workLogId = $$.getUrlParam("workLogId");
		$(".wrapper").attr("data-id",workLogId);
	}
	if($$.getUrlParam("date") != null){
		let dates = $$.getUrlParam("date");
		$(".date").text(dates);
	}
	if($$.getUrlParam("week") != null){
		var week = decodeURI(decodeURI($$.getUrlParam("week")));
		$(".week").text(week);
	}

	if($$.getUrlParam("contentStatus") != null){
		let content = decodeURI(decodeURI($$.getUrlParam("contentStatus")));
		if (content == "true") {
			let cacheData = localStorage.getItem(cacheKey);
			const hasCache = $$.isValidObj(cacheData);
			if (hasCache) {
				let content = cacheData;
				$(".content").children("textarea").val(content);
			}
		}
	}

	/**----- 删除日志 事件绑定 ----**/
	$(".delete").on("click",function(){
		var index = layer.open({
			content: 
				`<div class="popupContent">
					<div class="question">
						<b>删除该日志?</b>
					</div>
					<div class="answer space-between">
						<div class="cancel">取消</div>
						<div class="affirm">确认</div>
					</div>
				</div>`
		});
		/**----- 取消按钮 事件绑定 ----**/
		$(".answer .cancel").on("click",function(){
			layer.close(index);
		});	
		/**----- 确认按钮 事件绑定 ----**/
		$(".answer .affirm").on("click",function(){
			layer.close(index);
			
			if(id != null){
				/* 删除日志内容 再跳转到工作日志 */
				let isenabled = -1;
				let contents = $(".content").children("textarea").val().trim();
				$$.request({
			        url: UrlConfig.member_logcontet_save,
			        pars : {
			        	id:id,
			        	isenabled:isenabled,
			        	content:contents
			        },
			        method: "POST",
			        sfn: function (data) {
			            if(data.success){
			            	//$$.push("my/workLog");
							localStorage.removeItem(cacheKey);
							window.history.back();
			            }else{
			            	$$.layerToast(`${data.msg}`);
			            }
			        }
			    });
			}else{
				$$.push("my/workLog");
			}
		});
	});
	/**----- 保存日志 事件绑定 ----**/
	$(".save").on("click",function(){
		let contents = $(".content").children("textarea").val().trim();
		let workLogId = $(".wrapper").attr("data-id")
		let logDate = $(".date").text().replace(/\./g,'-');
		logDate = logDate + localTime();

		if(id != null){
			/* 更新日志内容 */
			$$.request({
		        url: UrlConfig.member_logcontet_save,
		        pars : {
		        	id:id,
		        	content:contents
		        },
		        method: "POST",
		        sfn: function (data) {
		            if(data.success){
		            	//$$.push("my/workLog");
						$$.layerToast("更新日志成功~");
						setTimeout(function(){
							window.history.back();
						}, 1000);
		            }
		        }
		    });
		}else{
			/* 添加日志内容 */
			$$.request({
		        url: UrlConfig.member_logcontet_save,
		        pars : {
		        	logDate:logDate,
		        	workLogId:workLogId,
		        	content:contents
		        },
		        method: "POST",
		        sfn: function (data) {
		            if(data.success){
		            	//$$.push("my/workLog");
						$$.layerToast("添加日志成功~");
						setTimeout(function(){
							window.history.back();
						}, 1000);
					}else{
		            	$$.layerToast(`${data.msg}`);
		            }
		        },
		    });
		}
	});
});

function localTime(){
	let myDate = new Date();
	let year = myDate.getFullYear(); 														//获取当前年
	let mon = myDate.getMonth()+1<10 ? "0"+(myDate.getMonth()+1) : (myDate.getMonth()+1); 	//获取当前月
	let date = myDate.getDate()<10 ? "0"+myDate.getDate() : myDate.getDate();               //获取当前日
	let h = myDate.getHours()<10 ? "0"+myDate.getHours() : myDate.getHours();       		//获取当前小时数(0-23)
	let m = myDate.getMinutes()<10 ? "0"+myDate.getMinutes() : myDate.getMinutes(); 		//获取当前分钟数(0-59)
	let s = myDate.getSeconds()<10 ? "0"+myDate.getSeconds() : myDate.getSeconds(); 		//获取当前秒

	let now = " "+ h +":"+ m +":"+ s;	//当前时间 (2019.10.08)

	return now;
}
