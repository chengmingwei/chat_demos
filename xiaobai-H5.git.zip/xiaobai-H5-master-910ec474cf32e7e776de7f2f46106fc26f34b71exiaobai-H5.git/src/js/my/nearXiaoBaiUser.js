window.onload = function () {
	$$.changeVersion();
	try {
		countAction('xb_86', null);
	} catch (error) {
		console.log(error);
	}
	const terminal = $$.getUrlParam("terminal");
	let longitude, latitude;
	if(terminal == "APP"){
		latitude = $$.getUrlParam("lat");
		longitude = $$.getUrlParam("lng");
		after();
	}else{
		// 获取微信地理位置
		weChatJSTool.getLocation(function (res) {
			console.log("获取微信地理位置");
			longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
			latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
			after();
		});
	}

	function after(){
		//创建点坐标
		let point = new BMap.Point(longitude, latitude);
		locations(point);
		getRamdonIcon();
	}
    
    /* 获取GPS定位wgs84（经度,纬度）转换百度 坐标BD09 加载地图*/
    function locations(point){
    	console.log("加载地图");
    	// 创建地图实例 
		let map = new BMap.Map("map");
		//地图初始化
		map.centerAndZoom(point, 15);
		//地图组件
		/*map.addControl(new BMap.NavigationControl());    
	    map.addControl(new BMap.ScaleControl());    
	    map.addControl(new BMap.OverviewMapControl());    
	    map.addControl(new BMap.MapTypeControl());*/
		
        //坐标转换完之后的回调函数
        translateCallback = function (data){
	        if(data.status === 0) {
	        	var myIcon = new BMap.Icon("../../images/my/location.png", new BMap.Size(23, 25), {
                        imageOffset: new BMap.Size(0, 0) // 设置图片偏移
                    });
                myIcon.setImageSize(new BMap.Size(23, 25));
	        	//添加三角坐标
		        let marker = new BMap.Marker(data.points[0], {icon: myIcon});
		        map.addOverlay(marker);
		       	map.setCenter(data.points[0]);
		        
	        }
	    };
	    
	    //GPS坐标wgs84 转 百度 坐标BD09
	    setTimeout(function(){
	        let convertor = new BMap.Convertor();
	        let pointArr = [];
	        pointArr.push(point);
	        convertor.translate(pointArr, 1, 5, translateCallback)
	    }, 1000);
    }
    
    /* 添加小白兔 图标 */
   	function getRamdonIcon(){
   		//X轴 宽度百分百数值
	    let left = randomNumber(4,5,95);
		
		//获取地图百分比高度的像素值
		let height = parseFloat($('#map').css("height"))-23;
		
		//Y轴 高度数值
		let top = randomNumber(5,4,height);
		
		//添加小白兔
		let html = "";
		for(let i=0;i<20;i++){
			html += `<img src="../../images/my/rabbit.png" style="top: ${top[i]}px;left: ${left[i]}%;" />`;
		}
		$(".coverLayer").html(html);
		
   	}
   	/* 矩阵5x4 随机小白兔 */
   	function randomNumber(x,y,length){
   		let arr = [];
   		for(let i=0;i<x;i++){
   			let a = 0;
	   		let b = Math.round(length/y);
	   		let c = b;
   			for(let j=0;j<y;j++){
	    		let random = parseInt(a + (c - a) * (Math.random()));
		    	arr.push(random);
		    	a = a+b
		    	c = c+b;
		    }
	    }
		return arr;
   	}
}
