/**
 * 消息中心 JS
 * @Author 吴成林
 * @Date
 */
window.onload = function () {
	//$(".weui-tab__panel").css("overflow","auto");
	$$.changeVersion();

	let messageType = "#tab1";	//默认0(0:系统消息、1:活动消息、2:其他消息)
	let tabUnreadSum1 = 0;
	let tabUnreadSum2 = 0;
	let tabUnreadSum3 = 0;
	let timeOutEvent = 0;
	let preventDefault = false;
	const PAGE_STATE = {
		params:{
			_current: 0,                    // 页数（0开始）
			_pageSize: 20,                  // 每页显示多少条
		},
		loadedState: false,                 // 分页加载状态
	};

	//加载系统消息和活动消息
	modelLoadOne();

	$('.weui-navbar__item').on('click', function () {
		$(this).children(".underframe").addClass('weui-bar__item_on');
		$(this).siblings('.weui-bar__item_on').children(".underframe").removeClass('weui-bar__item_on');

		$(this).addClass('weui-bar__item_on').siblings('.weui-bar__item_on').removeClass('weui-bar__item_on');
		$($(this).attr("href")).show().siblings('.weui-tab__content').hide();

		/* 判断消息内容是否存在  */
		if($(this).attr("data-id") === 1){
			let contentHtml1 = $(`#tab1`).html();
			contentHtml1.length !== 0 ? $(".allMarkRead").show():$(".allMarkRead").hide();
			if(tabUnreadSum1 === 0){
				$(".allMarkRead").hide();
			}
			messageType = "#tab1";
			countAction("xb_2048");
		}
		if($(this).attr("data-id") === 2){
			let contentHtml2 = $(`#tab2`).html();
			contentHtml2.length !== 0 ? $(".allMarkRead").show():$(".allMarkRead").hide();
			if(tabUnreadSum2 === 0){
				$(".allMarkRead").hide();
			}
			messageType = "#tab2";
			countAction("xb_2049");
		}
		if($(this).attr("data-id") === 3){
			let contentHtml3 = $(`#tab3`).html();
			contentHtml3.length !== 0 ? $(".allMarkRead").show():$(".allMarkRead").hide();
			if(tabUnreadSum3 === 0){
				$(".allMarkRead").hide();
			}
			messageType = "#tab3";
			countAction("xb_2050");
		}
	});

	//加载 其他消息
	getOpinionReplyList();

	//全部已读——点击事件
	$(".allMarkRead").on("click",function(){
		if(messageType === "#tab1" || messageType === "#tab2"){
			popup(2);
		}else if(messageType === "#tab3"){
			popup(3);
		}
	});

	//-- 页面滚动事件监听
	$(window).scroll(function () {
		if (PAGE_STATE.loadedState){
			if ($(window).scrollTop() == $(document).height() - $(window).height()) {
				if($(".pageLoading").size() > 0){
					return;
				}

				$(".weui-tab__panel").append(`<p class="pageLoading" style="text-align: center;font-size: 14px;margin: 15px 0px;">加载中...</p>`);
				PAGE_STATE.params._current += 1;
				modelLoadOne(function () {
					$(".pageLoading").remove();
					preventDefault = false;
				});
			}
		}
	});

	/* 获取意见回复信息列表 */
	function getOpinionReplyList(){
		$$.request({
			url: UrlConfig.feedback_getOpinionReplyList,
			method: "POST",
			loading: true,
			sfn: function(data){
				$$.closeLoading();
				if(data.success){
					//清空页面内容
					$(`#tab3`).html("");

					//加载内容
					let datas = data.datas;
					for(var i=0; i<datas.length; i++){
						let repTime = getDate(datas[i].repTime);
						let html = `
		            		<div class="elseUnit" data-id="${datas[i].id}">
								<div class="content_details">
									<div class="content_left" style="${datas[i].xstatus === 2?'display:none':'display:block'}"></div>
									<div class="content_right">
										<div class="titles overflow">提问：${datas[i].title}</div>
										<div class="repContent overflow">回复：${datas[i].repContent}</div>
									</div>
								</div>
								<div class="time">${repTime}</div>
							</div>`;
						if(datas[i].xstatus !== 2){
							tabUnreadSum3 = tabUnreadSum3 + 1;
						}
						$(`#tab3`).append(html);
					}

					//消息点击事件
					$(".elseUnit").on("click", function(){
						let title = $(this).find(".titles").text();
						let repContent = $(this).find(".repContent").text();
						let index = layer.open({
							content:
								`<div class="popupContent">
									<div class="questions">
										<span>${title}</span>
									</div>
									<div class="answers">
										<span>${repContent}</span>
									</div>
								</div>`
						});
					});
				} else {
					$$.layerToast(data.msg);
				}
			}
		});
	}

    function gotoMyTeam() {
        $$.request({
            url: UrlConfig.market_teammember_getTeamMemberByLogin,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let teamId = data.teamId;
                    if (teamId != null) {
                        let teamStatus = data.teamStatus;
                        let mType = data.mType;
                        let url = "teams/addDetails";
                        if (teamStatus === 2) {
                            url = "teams/colonel";
                            if (mType === 2) {
                                url = "teams/clustering";
                            }
                        }
                        $$.push(url,{teamId : teamId});
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /* 获取系统和活动信息列表*/
	function modelLoadOne(overCallback){
		/* 获取消息列表 */
		$$.request({
			url: UrlConfig.sysbase_msg_wxlist,
			pars: PAGE_STATE.params,
			method: "POST",
			sfn: function (data) {
				if(data.success){
					const {list, pagination} = data.datas;
					loadMessage(list, overCallback);

					let {total, current, pageSize} = pagination;
					let pageCount = total % pageSize == 0 ? total / pageSize : Math.ceil(total / pageSize) ;
					PAGE_STATE.loadedState = pageCount > current ? true : false;
				}
			}
		});

        function jumpPage(href, params = undefined) {
            const arr = [];
            if (href) {
                arr.push(`location-href="${href}"`);
            }
            if (params) {
                arr.push(`location-params="${params}"`);
            }
            return arr.join(' ');
        }

        //-- 加载列表
		function loadMessage(datas, overCallback) {
			try {
				let html1 = ``;
				let html2 = ``;
				for(let i=0; i<datas.length; i++){
				    let jumpPageHtml = '';
                    switch(datas[i].formType){
                        case 401:	//执业认证通过
                            jumpPageHtml = jumpPage('my/passed');
                            break;
                        case 402:	//执业认证不通过
                            jumpPageHtml = jumpPage('my/notPassed');
                            break;
                        case 41:	//订单消息
                            break;
                        case 42:	//评价邀请
                            break;
                        case 43:	//积分商城
                            jumpPageHtml = jumpPage('signin/signin');
                            break;
                        case 44:	//新人红包
                            jumpPageHtml = jumpPage('my/newGiftBag');
                            break;
                        case 45:	//话题PK
                            break;
                        case 46:	//早起 打卡
                            jumpPageHtml = jumpPage('signin/signin');
                            break;
                        case 47:	//产品评价回复
                            break;
                        case 48:	//意见反馈
                            break;
                        case 50:	//入团成功
                            jumpPageHtml = jumpPage('teamDetail', datas[i].formId);
                            break;
                        case 51:	//入团不通过
                            jumpPageHtml = jumpPage('teams/join');
                            break;
                        case 52:	//组团成功
                            break;
                        case 53:	//每周抽奖获奖
                            jumpPageHtml = jumpPage('my/deliveryAddress', datas[i].formId);
                            break;
                    }
					let html = `
								<div class="unit" data-id="${datas[i].id}">
									<div class="content_details" ${jumpPageHtml}>
										<div class="content_left" style="${datas[i].rstatus === 1?`display:none`:`display:block`}" data-rstatus="${datas[i].rstatus}"></div>
										<div class="content_right">
											<div class="titles overflow">${datas[i].title}</div>
											<div class="repContent overflow">${datas[i].content}</div>
										</div>
									</div>
									<div class="time">${datas[i].createTime}</div>
								</div>`;
					switch(datas[i].btype){
						case 1:
							if(datas[i].rstatus === 0){
								tabUnreadSum1 = tabUnreadSum1 + 1;
							}
							html1 += html;
							break;
						case 2:
							if(datas[i].rstatus === 0){
								tabUnreadSum2 = tabUnreadSum2 + 1;
							}
							html2 += html;
							break;
					}
				}

				if (overCallback) {
					$('#tab1').append(html1);
					$('#tab2').append(html2);
				} else {
					$('#tab1').html(html1);
					$('#tab2').html(html2);
				}
			}catch (e) {
				console.error(e);
			} finally {
				if (overCallback) overCallback();
			}

			let contentHtml = $(`#tab1`).html();
			if(contentHtml.length !== 0){
				if(tabUnreadSum1 !== 0){
					$(".allMarkRead").show();
				}
			}

			/* 内容点击和长按事件 */
			$(".unit").on({
                touchstart: function(e) {
					e.stopImmediatePropagation();
                    // 长按事件触发
                    timeOutEvent = setTimeout(function() {
                        timeOutEvent = 0;
						preventDefault = false;
                        let id = $(e.currentTarget).attr("data-id");
                        popup(1,id);
                    }, 500);
                },
                touchmove: function(e) {
					e.stopImmediatePropagation();
                    clearTimeout(timeOutEvent);
                    timeOutEvent = 0;
					preventDefault = true;
                },
                touchend: function(e) {
					e.stopImmediatePropagation();
                    clearTimeout(timeOutEvent);
					if (preventDefault) {
						preventDefault = false;
						return true;
					} else {
						if (timeOutEvent !== 0) {
							// 点击事件
							let id = $(this).attr("data-id");
							if ($(".content_left").attr("data-rstatus") === "0") {
								popup(4, id);
								$(".content_left").attr("data-rstatus", "0");
							}
							let href = $(this).children().attr("location-href");
							let params = $(this).children().attr("location-params");
							if ($$.isValidObj(href)){
								if (href === 'teamDetail') {
									gotoMyTeam();
								} else {
									if ($$.isValidObj(params)){
										$$.push(href,{teamId : params});
									} else {
										$$.push(href);
									}
								}
							} else {
								$(this).find(".content_left").hide();
								let title = $(this).find(".titles").text();
								let repContent = $(this).find(".repContent").text();
								let index = layer.open({
									content:
										`<div class="popupContent">
                                        <div class="questions">
                                            <span>${title}</span>
                                        </div>
                                        <div class="answers">
                                            <span>${repContent}</span>
                                        </div>
                                        <div class="affirm">确定</div>
                                    </div>`
								});
								/**----- 确认按钮 事件绑定 ----**/
								$(".popupContent>.affirm").on("click",function() {
									layer.close(index);
								});
							}
						}
						return false;
					}
                }
            });
		}
	}

	/* 弹窗 status：1、系统和活动消息作废，2、根据id更新系统和活动消息全部已读，3、其他消息全部已读 */
	function popup(status, id){
		if (status === 1 || status === 2 || status === 3){
			let index = layer.open({
				content:
					`<div class="popupContent">
						<div class="question">
							<b>${status === 1?"确定要删除？":"确定要全部已读？"}</b>
						</div>
						<div class="answer space-between">
							<div class="cancel">取消</div>
							<div class="affirm">确认</div>
						</div>
					</div>`
			});
			/**----- 取消按钮 事件绑定 ----**/
			$(".answer>.cancel").on("click",function(){
				layer.close(index);
			});
			/**----- 确认按钮 事件绑定 ----**/
			$(".answer>.affirm").on("click",function(){
				layer.close(index);

				if(status === 1){
					/* 消息作废  */
					let isenabled = -1;
					$$.request({
						url: UrlConfig.sysbase_msg_save,
						pars : {
							id:id,
							isenabled:isenabled,
						},
						method: "POST",
						sfn: function (data) {
							if(data.success){
								modelLoadOne();
							}else{
								$$.layerToast(`${data.msg}`);
							}
						}
					});
				}else if(status === 2){
					/* 系统或活动消息全部已读 */
					if (!$$.isValidObj(id)){
						$$.request({
							url: UrlConfig.sysbase_msg_readed,
							method: "POST",
							sfn: function (data) {
								if(data.success){
									$(".allMarkRead").hide();
									modelLoadOne();
								}else{
									$$.layerToast(`${data.msg}`);
								}
							}
						});
					}
				}else if(status === 3){
					/* 其他消息全部已读 */
					if (!$$.isValidObj(id)){
						$$.request({
							url: UrlConfig.feedback_updateMarkRead,
							method: "POST",
							sfn: function (data) {
								if(data.success){
									$(".allMarkRead").hide();
									getOpinionReplyList();
								}else{
									$$.layerToast(`${data.msg}`);
								}
							}
						});
					} else {
						$$.request({
							url: UrlConfig.feedback_updateMarkRead,
							pars : {
								id:id,
							},
							method: "POST",
							sfn: function (data) {
								if(data.success){
									$(".allMarkRead").hide();
									getOpinionReplyList();
								}else{
									$$.layerToast(`${data.msg}`);
								}
							}
						});
					}
				}
			});
		} else if (status === 4){
			if ($$.isValidObj(id)){
				$$.request({
					url: UrlConfig.sysbase_msg_readed,
					pars : {
						id:id,
					},
					method: "POST",
					sfn: function (data) {
						if(data.success){
							//modelLoadOne();
						}else{
							$$.layerToast(`${data.msg}`);
						}
					}
				});
			}
		}
	}

	function getDate(old) {
        let returnText = "";
        const nowDate = new Date().getTime();   //当前时间
        const setDate = new Date(old).getTime();
        const times = Math.floor((nowDate - setDate) / 1000);
        if(times > 60*60*24){
			returnText= old.substring(0,10);
		}else if(times > 60*60){
			returnText=Math.floor(times / (60*60))+"小时前";
		}else if(times > 60){
			returnText=Math.floor(times / (60))+"分钟前";
		}else if(times > 0){
			returnText=Math.floor(times / 1)+"秒前";
		}else{
			returnText="刚刚";
		}
		return returnText;
	}

	countAction("xb_2048");
};
