/**
 * 在线咨询 JS
 * @Author 吴成林
 * @Date 2020-2-27 16:44:39
 */
const PAGE_STATE = {
    pageType: 0,                    // 0-经纪人, 1-客户
    dataState: 1,                   // 0-服务结束， 1-服务进行中
    consultationId: null,           //一对一咨询ID
    userName: "小白保险",            // 用户名称
    viewHeight: 0,                  // 浏览器高度
    viewVaryingHeight: '60%',       // 底部撑起的浏览器高度
    bottomVaryingHeight: '40%',     // 底部撑起的高度
    bottomHeight: 0,                // 输入框撑起的高度
    inputHeight: 0,                 // 输入框边距的高度
    scrollHeight: 0,                // 输入框最大高度
    inputInitHeight: 0,             // 输入框初始高度
    bottomInitHeight: 0,            // 底部初始高度
    changeHeight: 0,                // 输入框改变的高度
    endServiceMsgTag:'ONE_TO_ONE_SERVICE_END_MSG' //服务结束消息标记
};

let selfMember = null;  //当前用户的信息
let reviceMember = null; //服务于当前用户的经纪人的信息

window.onload = function() {

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    // 重新调整聊天窗口
    function resizeScreen() {
        var areaMsgList = document.getElementById("onlineConsultingContent");
        // 设置聊天记录进入页面的时候自动滚动到最后一条
        areaMsgList.scrollTop = areaMsgList.scrollHeight + areaMsgList.offsetHeight;
    }

    function spBack() {
        if ($$.isValidObj($$.getUrlParam("paymentCbk"))) {
            $$.pushHistory();
            window.addEventListener("popstate", function() {
                window.location.href = decodeURIComponent($$.getUrlParam('backUrl'));
                localStorage.removeItem('backUrl');
            }, false);
        }
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        chatInit();
        PAGE_STATE.pageType = $$.getUrlParam("pageType");
        PAGE_STATE.dataState = $$.getUrlParam("dataState");
        PAGE_STATE.consultationId = $$.getUrlParam("consultationId");
        if (PAGE_STATE.pageType == 0){
            $(".broker").show();
        } else {
            $(".client").show();
            $(".consultationProblem").attr("placeholder", "用一句话描述您的问题");
        }
        const consultationXstatus = localStorage.getItem("consultationXstatus");
        if(consultationXstatus && consultationXstatus == '2'){ //结束状态标识
            PAGE_STATE.dataState = 0;
        }
        if (PAGE_STATE.dataState == 0){
            endService();
            //$('.service').hide();
        }
        PAGE_STATE.bottomHeight = $('.onlineConsultingChat').outerHeight();
        PAGE_STATE.bottomInitHeight = PAGE_STATE.bottomHeight;
        PAGE_STATE.inputHeight = PAGE_STATE.bottomHeight - $('.consultationProblem').outerHeight();
        PAGE_STATE.inputInitHeight = $('.consultationProblem').height();
        PAGE_STATE.viewHeight = window.innerHeight || document.documentElement.clientHeight;    //-- 浏览器高度
        $('div').scrollTop(10000);  //-- 滚动条 - 滚动到最新消息

        //-- 表情符号
        $.Lemoji({
            emojiInput: '.consultationProblem',
            emojiBtn: '.emoji',
            length: 8,
            emojis: {
                emoji: {path: '../../../images/my/onlineConsulting/emoji', code: ',', name: ''},
            }
        });

        dataLoading();

        eventBinding();
        spBack();
    }



    /**
     * 实时消息初始化
     */
    function chatInit(){
        const _selfMember = localStorage.getItem("selfMember");
        const _reviceMember = localStorage.getItem("reviceMember");

        if(!_selfMember || !_reviceMember){
         //   alert("referrer= "+document.referrer);
            $$.push("my/onlineConsulting/specialistConsult",{});
            return;
        }
        if(_selfMember){
            selfMember = JSON.parse(_selfMember);
        }
        if(_reviceMember){
            reviceMember = JSON.parse(_reviceMember);
            const reviceMemberName = reviceMember.rname;
            $("#userName").text(reviceMemberName);
            $("#myCustomer").text(reviceMemberName);
        }

        IM_Msg.events.openCallback = ()=>{
            const senderId = selfMember.memberId;
            const receiverId = reviceMember.memberId;
            const msg = new IM_Model.Msg(senderId,receiverId,null,null,null);
            return new IM_Model.MsgPacket(IM_Model.CONNECT,msg,null,null);
        };
        IM_Msg.events.fetchUnReadMsg = () => {//获取未读消息
            fetchUnReadMsg(false);
        };
        IM_Msg.events.reviceMsg = (msgPacket) => { //接收消息时触发
            console.log("reviceMsg:");
            console.log(msgPacket);
            const action = msgPacket.action;
            if(action == IM_Model.CHAT){ //发送消息
                const msgObj = msgPacket.msg;
                const uuid = msgObj.uuid;
                const msgId = msgObj.msgId || uuid;
                let msgContent = msgObj.msgContent;
                if(msgContent == PAGE_STATE.endServiceMsgTag){
                    localStorage.setItem("consultationXstatus","2");
                    endService();
                    msgContent = "您好，本次服务已结束！";
                    msgObj.msgContent = msgContent;
                }
                _reviceMsg(msgId,msgContent);
                IM_Presenter.signMsg(uuid, 1);
            }else if(action == IM_Model.CHANGE_REVICER){ //重新分配客户
                reallocationVipServicer(msgPacket);
            }
            return true;
        };
        IM_Msg.init();
    }


    /**
     * 获取未读消息列表
     */
    function fetchUnReadMsg(isLoading) {
        const selfMemberId = selfMember.memberId;
        const url = UrlConfig.msg_message_unread_list;
        ShawHandler.request({
            url: url,
            loading: isLoading,
            checkLogin: true,
            method:'GET',
            pars: {
                memberId:selfMemberId
            },
            sfn: function(data){
                ShawHandler.closeLoading();
                if(data.success){
                    const list = data.datas;
                    renderHtmls(list);
                }else{
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }

    function reallocationVipServicer(msgPacket){
        const msgObj = msgPacket.msg;
        const uuid = msgObj.uuid;
        const msgId = msgObj.msgId || uuid;
        let receiverData = msgObj.msgContent;
        receiverData = JSON.parse(receiverData);
        const memberId = receiverData.memberId;
        const rname = receiverData.rname;
        const imgPath = receiverData.imgPath;
        let oldReviceMemberName = null;
        const _reviceMember = localStorage.getItem("reviceMember");
        if(_reviceMember){
           let reviceMember = JSON.parse(_reviceMember);
           const _memberId = reviceMember.memberId;
            oldReviceMemberName = reviceMember.rname;
           if(memberId == _memberId) return;
            reviceMember = {memberId:memberId,rname:rname,imgPath:imgPath};
            localStorage.setItem("reviceMember", JSON.stringify(reviceMember));
            $("#userName").text(rname);
            $("#myCustomer").text(rname);
        }

        const msgContent = "您好！我是小白客服："+rname+",由于"+oldReviceMemberName+"比较忙。现在由我来为您提供服务，请问有什么可以帮到您的？";
        _reviceMsg(msgId,msgContent);
    }

    function renderHtmls(list){
        if(!list || list.length == 0) return;
        let msgIdArr = [];
        list.forEach(data => {
            const {id,sender,receiver,content,createTime} = data;
            msgIdArr.push(id);
            IM_Presenter.saveUserMsgHistory(receiver,sender, id, content, createTime, 2);
            _reviceMsg(id,content);
        });
        IM_Presenter.signMsgList(msgIdArr, 1);
    }


    /**
     * 数据加载
     */
    function dataLoading(){
        loadSpeechcraftList();
        loadHistoryMsgList();
    }

    /***
     * 加载话术（1:客户, 2:保险顾问）
     */
    function loadSpeechcraftList(){
        const _pageType = PAGE_STATE.pageType;
        let roleType = 2;   //经纪人
        if(parseInt(_pageType) === 1){ //客户
            roleType = 1;
        }
        const url = UrlConfig.management_speechcraftconfiginfo_list+"/"+roleType;
        ShawHandler.request({
            url: url,
            loading: true,
            checkLogin: true,
            method:'GET',
            pars: {},
            sfn: function(data){
                ShawHandler.closeLoading();
                if(data.success){
                    const list = data.datas;
                    const ele = $(".typicalSentencesList");
                    ele.empty();
                    if(!list || list.length == 0){
                        ele.append(' <div>您好~</div>');
                    }else{
                        const htmlArr = list.map(item => {
                            const speechcraft = item.speechcraft;
                            return ' <div>'+speechcraft+'~</div>';
                        });
                        ele.append(htmlArr.join(" "));
                    }
                }else{
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }


    function loadHistoryMsgList(){
        const consultationXstatus = localStorage.getItem("consultationXstatus");
        if(consultationXstatus && consultationXstatus == '2'){ //结束会话
            endService();
        }
        if(!selfMember){
            console.log("selfMember is null!");
            return;
        }
        const senderId = selfMember.memberId;
        const receiverId = reviceMember.memberId;
        const jsonArr = IM_Presenter.getUserMsgHistory(senderId, receiverId);
        if(jsonArr && jsonArr.length > 0){  //加载本地消息
            jsonArr.forEach((data, index) => {
                const flag = data.flag;
                const msgId = data.msgId || index+"";
                const msg = data.msg;
                if(flag && flag == 1){ //我发送的消息
                    _sendMsg(msg);
                }else{//我接收的消息
                    _reviceMsg(msgId,msg);
                }
            });
            resizeScreen();
        }
    }



    function _reviceMsg(msgId,msg){
        const msgPrefix = "MSG_CHAT_";
        const msgEleId = msgPrefix + msgId;
        console.log(msgEleId+" = "+ msg);
        if(document.getElementById(msgEleId)) return;
        if(msg == PAGE_STATE.endServiceMsgTag){
            msg = "您好，本次服务已结束！";
        }
        msg = $.emojiParse({
            content: msg,
            emojis: [{path: '../../../images/my/onlineConsulting/emoji/', code: ',', type: 'emoji'}]
        });
        const reviceMember = localStorage.getItem("reviceMember");
        const _reviceMember = JSON.parse(reviceMember);
        let nickName = _reviceMember.rname;
        let imgLogo = _reviceMember.imgPath || "../../../images/my/mituLogo.png";
        let html = [
            '<div class="leftRecord flex-start">',
            '<img src="'+imgLogo+'" class="contentIcon">',
            '<div class="leftContent">',
            '<div>'+nickName+'</div>',
            '<div class="flex-start">',
            '<img src="../../../images/my/onlineConsulting/onlineConsulting-12.png">',
            '<div id="'+msgEleId+'" class="dialogueContent"><span>'+msg+'</span></div>',
            '<div class="readingState">已读</div>',
            '</div>',
            '</div>',
            '</div>'
        ];
        $(".onlineConsultingContent").append(html.join("  "));
        setTimeout(function () {
            resizeScreen();
        }, 300);
        //resizeScreen();
    }

    function _sendMsg(msg){
        msg = $.emojiParse({
            content: msg,
            emojis: [{path: '../../../images/my/onlineConsulting/emoji/', code: ',', type: 'emoji'}]
        });
        let nickName = selfMember.rname;
        let imgLogo = selfMember.imgPath || "../../../images/my/mituLogo.png";
        let html = `<div class="rightRecord flex-end">
                    <div class="rightContent">
                        <div>${nickName}</div>
                        <div class="flex-start">
                            <div class="dialogueContent"><span>${msg}</span></div>
                            <img src= "../../../images/my/onlineConsulting/onlineConsulting-13.png" />
                        </div>
                    </div>
                    <img src="`+imgLogo+`" class="contentIcon">
                </div>`;
        $(".onlineConsultingContent").append(html);
        $(".consultationProblem").val("");
        setTimeout(function () {
            $('div').scrollTop(10000);
            $(".sending").hide();
            $(".phoneFile").show();
            resizeScreen();
        }, 300);
    }

    function _getMsgData(msgContent) {
        const senderId = selfMember.memberId;
        const receiverId = reviceMember.memberId;
        const consultationId = PAGE_STATE.consultationId;
        const time = new Date().getTime();
        const msgId = consultationId+"_"+ time;
        const msg = new IM_Model.Msg(senderId,receiverId,msgContent,msgId,time);
        return new IM_Model.MsgPacket(IM_Model.CHAT,msg,consultationId,1); //1 : 会员1对我咨询
    }

    /**
     * 事件绑定
     */
    function eventBinding(){

        //-- 经纪人 - 结束本次服务 - 咨询改为历史咨询
        $('.endService').on('click', function () {
            $$.confirm({
                title: "确定结束本次服务吗？",
                onOkLabel: "确定",
                onCancelLabel: "取消",
                onOk: () => {
                    //-- 咨询状态改为历史咨询
                    $(this).css("pointer-events", "none").children("span").css("background-color", "#ebeced").text("服务已结束");
                    doEndService();
                }
            });
        });

        //-- 输入框 - 点击
        $('.consultationProblem').on('click', function () {
            $(this).blur();
            $('.onlineConsultingContent').css("height", "auto");
            closeList();
            timer();
            $(this).focus();
        });

        //-- 输入框 - 内容改变
        $(".consultationProblem").on('input',function(){
            if ($(".consultationProblem").val().length >= 200){
                $$.layerToast("最多可输入200字喔~");
                return;
            }
            let inputValueLength = $(this).val().length;
            inputValueLength > 0 ? $(".phoneFile").hide():$(".phoneFile").show();
            inputValueLength > 0 ? $(".sending").show():$(".sending").hide();

            $(this).newAutoHeight();
            let changeHeight = $('.consultationProblem').height()-PAGE_STATE.inputInitHeight;
            if ($(this).outerHeight() < 100){
                $('.onlineConsultingChat').outerHeight(this.scrollHeight+PAGE_STATE.inputHeight);
                PAGE_STATE.bottomHeight = $('.onlineConsultingChat').outerHeight();
            } else {
                if (PAGE_STATE.scrollHeight == 0){
                    PAGE_STATE.bottomHeight = this.scrollHeight;
                    $('.onlineConsultingChat').outerHeight(this.scrollHeight+PAGE_STATE.inputHeight);
                    PAGE_STATE.scrollHeight = this.scrollHeight+PAGE_STATE.inputHeight/2;
                } else {
                    PAGE_STATE.bottomHeight = PAGE_STATE.scrollHeight;
                }
                $(this).css('overflow-y', 'scroll');
            }

            $('.onlineConsultingContent').css("padding", `70px 15px calc(13vw + ${changeHeight}px)`);
            if (changeHeight != PAGE_STATE.changeHeight){
                PAGE_STATE.changeHeight = changeHeight;
                $('div').scrollTop(10000);
            }
        });

        //-- 发送
        $('.sending').on('click', function () {
            closeList();
            $('.onlineConsultingContent').css("height", 'auto');
            let sendingContent = $(".consultationProblem").val();

            const msgPacket = _getMsgData(sendingContent);
            IM_Msg.send(msgPacket); //1.发送消息到服务端
            _sendMsg(sendingContent); //2.在页面展示聊天内容
            const msgId = msgPacket.msg.msgId;
            const senderId = selfMember.memberId;
            const receiverId = reviceMember.memberId;
            const sendTime = DateUtil.formatDateTime(new Date(),date_formate.normDatetimeMinutePattern);
            IM_Presenter.saveUserMsgHistory(senderId, receiverId,msgId, sendingContent,sendTime, 1); //3.保存消息到本地和快照中
            $(".consultationProblem").height(PAGE_STATE.inputInitHeight);
            $('.onlineConsultingChat').outerHeight(PAGE_STATE.bottomInitHeight);
            PAGE_STATE.bottomHeight = PAGE_STATE.bottomInitHeight;
            //IM_Presenter.saveUserMsgSnapshot(senderId, receiverId, sendingContent, true);
        });




        /* 常用语 - 打开 */
        $(document).on("click", ".typicalSentences", function() {
            openList();
            timer(1);
            $(this).addClass("keypad").removeClass("typicalSentences");
            $(".typicalSentencesList").show();
        });

        /* 常用语 - 关闭 */;
        $(document).on("click", ".keypad", function(){
            $(this).addClass("typicalSentences").removeClass("keypad");
            closeList();
            $('.onlineConsultingContent').css("height", 'auto');
        });

        /* 选择常用语 */
        $(document).on("click", '.typicalSentencesList>div',function(){
            let text = $(this).text();
            $('.consultationProblem').val(text);
            $(".phoneFile").hide();
            $(".sending").show();
            $(".consultationProblem").newAutoHeight();

            $('.bottomModule').height($(".consultationProblem").height()+PAGE_STATE.inputHeight);
            PAGE_STATE.bottomHeight = $(".consultationProblem").outerHeight()+PAGE_STATE.inputHeight;
        });

        /* 表情包 */
        $('.emoji').on("click", function(){
            if ($('.emojiList').is(":hidden")){
                closeList();
                return;
            }
            timer(2);
        });

        /* 文件 */
        $('.phoneFile').on("click", function(){
            if ($('.featurePackList').is(":visible")){
                closeList();
                return;
            }
            $('.featurePackList').show();
            $(".keypad").addClass("typicalSentences").removeClass("keypad");
            $(".typicalSentencesList").hide();
            openList();
            timer(3);
        });

        /* 选择照片 */
        $('.photoAlbum').on("click", function(){

        });

        /* 选择文件 */
        $('.file').on("click", function(){

        });

        $('.onlineConsultingContent').on('click', function () {
            closeList();
            $('.onlineConsultingContent').css("height", 'auto');
            $('div').scrollTop(10000);
        });
    }

    /**
     * 结束服务
     */
    function doEndService(){
        const consultationId = PAGE_STATE.consultationId;
        if(!consultationId){
            ShawHandler.layerToast("参数：consultationId 不能为空！");
            return;
        }

        const url = UrlConfig.msg_consultation_list+"/"+consultationId;
        ShawHandler.request({
            url: url,
            loading: true,
            checkLogin: true,
            method:'PUT',
            pars: {},
            sfn: function(data){
                ShawHandler.closeLoading();
                if(data.success){
                    doServiceCount();
                    localStorage.setItem("consultationXstatus","2");
                   endService();
                    const msgPacket = _getMsgData("ONE_TO_ONE_SERVICE_END_MSG");
                    IM_Msg.send(msgPacket); //1.发送消息结束通知
                }else{
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }

    /**
     * 更新服务次数
     */
    function doServiceCount() {
        const senderId = selfMember.memberId;
        const url = UrlConfig.member_vip_servicer;
        ShawHandler.request({
            url: url,
            loading: true,
            checkLogin: true,
            method:'PUT',
            pars: {
                memberId: senderId
            },
            sfn: function(data){
                ShawHandler.closeLoading();
                if(!data.success){
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }

    //-- 结束服务 禁用属性和样式 （客户界面需根据咨询状态同步调用）
    function endService() {
        $('#service-status').html('已完成了对您的服务......');
        $('.endService').show().css("pointer-events", "none").children("span").css("background-color", "#ebeced").text("服务已结束");
        $('.onlineConsultingChat').hide();
        $(".typicalSentences, .emoji, .phoneFile, .sending").css("pointer-events", "none");
        $(".consultationProblem").attr("readonly", "readonly").val("");
        $(".sending").hide();
        $(".phoneFile").show();
        let html = `<div class="consultationTime">本次服务已结束~</div>`;
        $(".onlineConsultingContent").append(html);
        PAGE_STATE.scrollHeight = $('.onlineConsultingContent')[0].scrollHeight;
        $('div').scrollTop(PAGE_STATE.scrollHeight);
    }

    //-- 开启底部功能
    function openList() {
        $(".emojiList").hide();
        $(".emoji").attr("data-switch", "true");
        $(".onlineConsultingChat").css("height", "calc("+PAGE_STATE.bottomVaryingHeight+" + "+PAGE_STATE.bottomHeight+"px)");
        $(".bottomModule").css({"height": PAGE_STATE.bottomHeight-PAGE_STATE.inputHeight+"px", "margin":"1vw 0px"});
        $(".bottomModuleContent").css("height", "calc(100% - "+((PAGE_STATE.bottomHeight-PAGE_STATE.inputHeight)/2+PAGE_STATE.inputHeight+"px")+")");
    }

    //-- 关闭底部功能
    function closeList() {
        $(".typicalSentencesList").hide();
        $(".emojiList").hide();
        $(".emoji").attr("data-switch", "true");
        $(".featurePackList").hide();
        $(".onlineConsultingChat").css("height", PAGE_STATE.bottomHeight+"px");
        $(".bottomModule").css({"height": "100%", "margin": "0px auto"});
        $(".bottomModuleContent").css("height", "0px");
        $(".keypad").addClass("typicalSentences").removeClass("keypad");
        let changeHeight = $('.consultationProblem').height()-PAGE_STATE.inputInitHeight;
        $('.onlineConsultingContent').css({"height":'auto', "padding":`70px 15px calc(13vw + ${changeHeight}px)`});
        $('div').scrollTop(10000);
    }

    $.fn.extend({
        newAutoHeight: function () {
            return this.each(function () {
                let $this = $(this);
                if (!$this.attr('initAttrH')) {
                    $this.attr('initAttrH', $this.height());
                }
                setAutoHeight(this);
            });
            function setAutoHeight(elem) {
                let $obj = $(elem);
                return $obj.css({ height: $obj.attr('initAttrH'), 'overflow-y': 'hidden' }).outerHeight(elem.scrollHeight>100?100:elem.scrollHeight);
            }
        }
    });

    function timer(state = 0) {
        const timer = setInterval(function(){
            PAGE_STATE.viewVaryingHeight = window.innerHeight || document.documentElement.clientHeight;
            let bottomVaryingHeight = PAGE_STATE.viewHeight-PAGE_STATE.viewVaryingHeight+"px";
            if (bottomVaryingHeight != "0px") {
                if (PAGE_STATE.bottomVaryingHeight == '40%'){
                    PAGE_STATE.bottomVaryingHeight = bottomVaryingHeight;
                }
            } else {
                if (state != 0){
                    let bottomHeight = 0;
                    if (state == 1){
                        bottomHeight = $('.typicalSentencesList').outerHeight();
                    } else if (state == 2){
                        bottomHeight = $('.emojiList').outerHeight();
                    } else if (state == 3){
                        bottomHeight = $('.featurePackList').outerHeight();
                    }
                    let contentHeight = PAGE_STATE.viewVaryingHeight - bottomHeight + ($('.consultationProblem').height()-PAGE_STATE.inputInitHeight)/2;
                    $('.onlineConsultingContent').css("height", contentHeight);
                }
            }
            $('div').scrollTop(10000);
            $('.emoji_item').scrollTop(0);
            clearInterval(timer);
        }, 500);
    }



}
//  绑定textarea的失焦事件
function checkWxScroll(){
    var ua = navigator.userAgent.toLowerCase();
    var u = navigator.userAgent.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
    if (ua.match(/MicroMessenger/i) == 'micromessenger' && !!u) {
        var currentPosition, timer;
        var speed = 0;//页面滚动距离
        timer = setInterval(function () {
            currentPosition = document.documentElement.scrollTop || document.body.scrollTop;
            currentPosition -= speed;
            window.scrollTo(0, currentPosition);//页面向上滚动
            currentPosition += speed; //speed变量
            window.scrollTo(0, currentPosition);//页面向下滚动
            clearInterval(timer);
        }, 1);
    }
}

//-- 插入字符到输入框末尾
function moveCaretToEnd(el) {
    if (typeof el.selectionStart == "number") {
        el.selectionStart = el.selectionEnd = el.value.length;
    } else if (typeof el.createTextRange != "undefined") {
        el.focus();
        var range = el.createTextRange();
        range.collapse(false);
        range.select();

    }
}
var textarea = document.getElementById("consultationProblem");
textarea.onfocus = function() {
    moveCaretToEnd(textarea);    // Work around Chrome's little problem
    window.setTimeout(function() {
        moveCaretToEnd(textarea);
    }, 1);
};