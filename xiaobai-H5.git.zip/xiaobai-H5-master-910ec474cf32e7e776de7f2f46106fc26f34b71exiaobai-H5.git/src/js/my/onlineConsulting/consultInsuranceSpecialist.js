/**
 * 订单详情 JS
 * @Author 肖家添
 * @Date 2019/10/6 16:13
 */

ShawHandler.loaderRes({
    scripts: [
        //-- Order helper
        `js/product/orderHelper.js`,
    ]
});
/**
 * 咨询保险专家 JS
 * @Author 吴成林
 * @Date 2020-2-27 11:28:10
 */
let viewHeight = 0;          //浏览器高度
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    function loop(orderToken, loopIndex = 0) {
        loopIndex++;
        $$.request({
            url: UrlConfig.msg_consultation_wx_getPstatus,
            pars: { consultationId:orderToken },
            sfn: function(data){
                if(data.success){
                    const pstatus = data.pstatus;
                    if(pstatus === 1){
                        $$.closeLoading();
                        $$.alert("支付成功！");
                        createConsultation(orderToken);
                    }else if(pstatus === 0){
                        //-- 待支付状态
                        if(loopIndex >= 10){
                            $$.closeLoading();
                            $$.alert("似乎没支付成功！");
                        }else{
                            setTimeout(function(){
                                loop(orderToken, loopIndex);
                            }, 1000);
                        }
                    }else {
                        $$.closeLoading();
                        $$.alert("支付失败！");
                    }
                }else{
                    $$.closeLoading();
                }
            }
        });
    }

    function verifyPaymentSuccess() {
        const paymentCbk = $$.getUrlParam("paymentCbk");
        const orderToken = $$.getUrlParam("orderToken");
        if(paymentCbk){
            $$.loading("支付处理中");
            //-- 支付完成
            $$.pushHistory();
            window.addEventListener("popstate", function() {
                window.location.href = localStorage.getItem('backUrl');
                localStorage.removeItem('backUrl');
            }, false);
            loop(orderToken);
        } else {
            localStorage.setItem('backUrl',document.referrer);
        }
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();

        verifyPaymentSuccess();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        viewHeight = window.innerHeight || document.documentElement.clientHeight;    //-- 浏览器高度
        let length = $('.background').height();
        console.log(length/viewHeight);
        $('.bottomButton').css({"top":length*0.78+"px", "height":length*0.025+"px"});
        $('.topButton').css({"top":length*0.14+"px", "height":length*0.04+"px"});
    }

    function paymentHandler(consultationId) {
        const returnUrl = encodeURIComponent('my/onlineConsulting/consultInsuranceSpecialist');
        $$.push("product/payment", {
            paymentType: 'weChatPay',
            doComplexFormType: OrderHelper.payDoComplexFormType.FORM_TYPE_10005,
            otherParams: JSON.stringify({
                orderToken:consultationId,
                returnUrl:returnUrl,
                successPayUrl:returnUrl
            })
        });
    }

    function createConsultation(consultationId,reviceMember,selfMember) {
        ShawHandler.request({
            url: UrlConfig.msg_consultation_wx_create,
            loading: true,
            checkLogin: true,
            method:'GET',
            pars: {
                bussType:1,
                consultationId:consultationId,
                reviceMember:reviceMember,
                selfMember:selfMember
            },
            sfn: function(data){
                ShawHandler.closeLoading();
                if(data.success){
                    if ($$.isValidObj(consultationId)) {
                        $$.push('my/onlineConsulting/onlineConsulting', {
                            "pageType": 1,
                            consultationId:consultationId,
                            paymentCbk:$$.getUrlParam("paymentCbk"),
                            backUrl:encodeURIComponent(localStorage.getItem('backUrl'))
                        });   // 0-经纪人, 1-客户
                    } else {
                        paymentHandler(data.consultationId);
                    }
                }else{
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 点击咨询专家
        $('.clickConsultation').on('click', function () {
            fetchVipServicer();
        });
    }

    function fetchVipServicer() {
        localStorage.removeItem("reviceMember");
        localStorage.removeItem("selfMember");
        ShawHandler.request({
            url: UrlConfig.member_vip_servicer,
            loading: true,
            checkLogin: true,
            method:'GET',
            pars: {},
            sfn: function(data){
                ShawHandler.closeLoading();
                if(data.success){
                    const reviceMember = data.datas.reviceMember;
                    const selfMember = data.datas.selfMember;
                    localStorage.setItem("reviceMember", JSON.stringify(reviceMember));
                    localStorage.setItem("selfMember", JSON.stringify(selfMember));
                    createConsultation(null,reviceMember.memberId,selfMember.memberId);
                }else{
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }
};
