/**
 * 专家咨询 JS
 * @Author 吴成林
 * @Date 2020-2-27 15:09:33
 */
const PAGE_STATE = {
    pageType: 0,                    // 0-经纪人, 1-客户
    roleType:-1, //[1:经纪人,2:普通会员]
    bussTag:1, // [1:进行中,2:完成]
    memberId: localStorage.getItem("memberId"),
    list : null, //缓存咨询列表
    encrypt_memberId: null
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        chatInit();
        dataLoading();
        eventBinding();
    }

    /**
     * 实时消息初始化
     */
    function chatInit(){

        IM_Msg.events.openCallback = ()=>{
            const senderId = localStorage.getItem("memberId");
            const msg = new IM_Model.Msg(senderId,null,null,null,null);
            return new IM_Model.MsgPacket(IM_Model.CONNECT,msg,null,null);
        };
        IM_Msg.events.fetchUnReadMsg = () => {
            console.log("fetchUnReadMsg...");
            if(PAGE_STATE.roleType == -1){
                loadRoleType();
            }else{
                loadConsultations();
            }
        }
        IM_Msg.events.reviceMsg = (msgPacket) => { //接收消息时触发
            console.log("reviceMsg...");
            console.log(msgPacket);
            if(PAGE_STATE.roleType == -1){
                loadRoleType();
            }else{
                loadConsultations();
            }
            return false; //true:保存接收消息到本地缓存历史记录中; false:不缓存记录到本地
        }
        IM_Msg.init();
    }


    /**
     * 数据加载
     */
    function dataLoading(){
        loadRoleType();
    }

    function loadRoleType() {
        ShawHandler.request({
            url: UrlConfig.member_role_type,
            loading: true,
            checkLogin: true,
            method:'GET',
            pars: {},
            sfn: function(data){
                ShawHandler.closeLoading();
                if(data.success){
                    const _roleType = data.roleType;
                    PAGE_STATE.roleType = _roleType;
                    renderEmptyTip();
                    loadConsultations();
                }else{
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }

    function renderEmptyTip(){
        let tip = null;
        if(PAGE_STATE.roleType == 1){ //经纪人
            tip = "目前还没有用户咨询过您!";
            $('.doAsk').hide();
        }else{ //普通用户
            tip = "你还没有咨询过问题！!";
            $('.doAsk').show();
        }
        $(".emptyList-tip").html(tip);
    }

    /**
     * 加载咨询列表
     */
    function loadConsultations() {
        ShawHandler.request({
            url: UrlConfig.msg_consultation_list,
            loading: true,
            checkLogin: true,
            method:'GET',
            pars: {
                bussTag: PAGE_STATE.bussTag,
                roleType: PAGE_STATE.roleType,
                memberId: PAGE_STATE.memberId
            },
            sfn: function(data){
                ShawHandler.closeLoading();
                if(data.success){
                    const list = data.datas;
                    const encrypt_memberId = data.encrypt_memberId;
                    PAGE_STATE.list = list;
                    PAGE_STATE.encrypt_memberId = encrypt_memberId;
                    renderHtmls();
                }else{
                    ShawHandler.layerToast(data.msg);
                }
            }
        });
    }

    /**
     * 渲染咨询列表HTML
     */
    function renderHtmls(){
        const bussTag = PAGE_STATE.bussTag;
        const list = PAGE_STATE.list;
        let listEleCls = null;
        let emptyEleId = null;
        if(bussTag == 1){ //进行中
            listEleCls = '.ongoingList';
            emptyEleId = '#emptyList-ongoing';
        }else{
            listEleCls = '.historyList';
            emptyEleId = '#emptyList-history';
        }
        const listEle = $(listEleCls);
        const emptyEle = $(emptyEleId);
        listEle.empty();
        if(!list || list.length == 0){
            listEle.hide();
            emptyEle.show();
        }else{
            emptyEle.hide();
            listEle.show();
            const html = getListHtml();
            listEle.append(html);

        }
    }

    function getListHtml() {
        const list = PAGE_STATE.list;
        const htmlArr = list.map(data => {
            return getRowHtml(data);
        });
        return htmlArr.join(" ");
    }

    function getRowHtml(data) {
        const consultationId = data.consultationId;
        const sender = data.sender;
        const receiver = data.receiver;
        const createTime = data.createTime;
        const imgLogo = data.imgPath || '../../../images/my/mituLogo.png';
        let content = data.content || '&nbsp;';
        const samount = data.samount;
        content = $.emojiParse({
            content: content,
            emojis: [{path: '../../../images/my/onlineConsulting/emoji/', code: ',', type: 'emoji'}]
        });
        return [
            '<li>',
            '    <div class="unitTime flex-end">',
            '        <img src="../../../images/my/onlineConsulting/specialistConsult-4.png">',
            '        <span>'+createTime+'</span>',
            '    </div>',
            '    <div class="unitContent" data-state="'+PAGE_STATE.bussTag+'" data-consultationId="'+consultationId+'" data-sender="'+sender+'" data-receiver="'+receiver+'">',
                '   <div class="space-between">',
                    '   <img src="'+imgLogo+'" class="userIcon">',
                    '   <span class="unitTitle overflow">'+content+'</span>',
                    '   <img src="../../../images/my/onlineConsulting/specialistConsult-'+PAGE_STATE.bussTag+'.png" class="consultState">',
                '   </div>',
                '   <div class="space-between">',
                    '   <div class="counterparts">',
                        '   <img src="../../../images/my/onlineConsulting/specialistConsult-5.png">',
                        '   <span>一对一咨询</span>',
                    '   </div>',
                    '   <div class="price">',
                        '   <img src="../../../images/my/onlineConsulting/specialistConsult-6.png">',
                        '   <span>'+samount +'元</span>',
                        '</div>',
                    '</div>',
                '</div>',
            '</li>'
        ].join("  ");
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 主题切换
        $('.weui-navbar__item').on('click', function () {
            $(this).children(".underframe").addClass('weui-bar__item_on')
            $(this).siblings('.weui-bar__item_on').children(".underframe").removeClass('weui-bar__item_on');

            $(this).addClass('weui-bar__item_on').siblings('.weui-bar__item_on').removeClass('weui-bar__item_on');
            const activeTabId = $(this).attr("href");
            $(activeTabId).show().siblings('.weui-tab__content').hide();


            console.log("activeTabId="+activeTabId);
            PAGE_STATE.bussTag = (activeTabId == '#tab2') ? 2 : 1;
            loadConsultations();
        });

        //-- 在线 一对一咨询
        $('.doAsk').click(()=>{
            $$.push('my/onlineConsulting/consultInsuranceSpecialist');
            // fetchVipServicer();
        });

        //-- 点击 - 进入咨询页面
        $(document).on('click', ".unitContent",  function () {
            const meEle = $(this);
            let dataState = meEle.attr("data-state");     // 0-服务结束， 1-服务进行中
            let dataConsultationId = meEle.attr("data-consultationId");     //一对一咨询ID
            let dataSender = meEle.attr("data-sender");     //消息发送人
            let dataReceiver = meEle.attr("data-receiver");     //消息接收人
            let receiverId = null;
            const _encrypt_memberId = PAGE_STATE.encrypt_memberId;
            if(!_encrypt_memberId){
                alert("当前登录会员的ID不存在，请退出重新登录或联系我司客服！");
                return;
            }
            const _memberId = _encrypt_memberId.split("_")[0];
            if(_memberId == dataSender){ //普通用户 （发起咨询一方）
                PAGE_STATE.roleType = 2;
                PAGE_STATE.pageType = 1;
                receiverId = dataReceiver;
            }else{  //经纪人 （VIP经纪人，提供服务一方）
                PAGE_STATE.roleType = 1;
                PAGE_STATE.pageType = 0;
                receiverId = dataSender;
            }

            fetchMemberBaseInfos(dataConsultationId,receiverId);
        });


        function fetchVipServicer() {
            localStorage.removeItem("reviceMember");
            localStorage.removeItem("selfMember");


            ShawHandler.request({
                url: UrlConfig.member_vip_servicer,
                loading: true,
                checkLogin: true,
                method:'GET',
                pars: {},
                sfn: function(data){
                    ShawHandler.closeLoading();
                    if(data.success){
                        const reviceMember = data.datas.reviceMember;
                        const selfMember = data.datas.selfMember;
                        localStorage.setItem("reviceMember", JSON.stringify(reviceMember));
                        localStorage.setItem("selfMember", JSON.stringify(selfMember));
                        $$.push('my/onlineConsulting/onlineConsulting', {"pageType": 1});   // 0-经纪人, 1-客户
                    }else{
                        ShawHandler.layerToast(data.msg);
                    }
                }
            });
        }

        function fetchMemberBaseInfos(consultationId, receiverId) {
            localStorage.removeItem("reviceMember");
            localStorage.removeItem("selfMember");
            localStorage.removeItem("consultationXstatus"); //删除聊天页面结束服务的本地状态
            ShawHandler.request({
                url: UrlConfig.member_vip_servicer+'/'+receiverId,
                loading: true,
                checkLogin: true,
                method:'GET',
                pars: {},
                sfn: function(data){
                    ShawHandler.closeLoading();
                    if(data.success){
                        const reviceMember = data.datas.reviceMember;
                        const selfMember = data.datas.selfMember;
                        localStorage.setItem("reviceMember", JSON.stringify(reviceMember));
                        localStorage.setItem("selfMember", JSON.stringify(selfMember));
                        gotoChat(consultationId);
                    }else{
                        ShawHandler.layerToast(data.msg);
                    }
                }
            });


        }

        function  gotoChat(consultationId) {
            const dataState = (PAGE_STATE.bussTag == 1) ? 1 : 0;
            $$.push("my/onlineConsulting/onlineConsulting",{
                pageType: PAGE_STATE.pageType,
                dataState: dataState,
                consultationId: consultationId
            });
        }
    }
}
