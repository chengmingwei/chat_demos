window.onload = function () {
    $$.changeVersion();
    pageInit();

    function pageInit() {
        let content = "";
        $("#submit").css({'background-color': 'gray'});
        $("#submit").attr("disabled", true);

        $("#content").bind('input propertychange', 'textarea', () => {
            content = $("#content").val().replace(/<[^>]+>/g, "").replace(/(^\s+)|(\s+$)/g, "");
            if (content.length > 10) {
                $("#submit").css({'background-color': '#ff7052'});
                $('#submit').removeAttr("disabled");
            } else {
                $("#submit").css({'background-color': 'gray'});
                $("#submit").attr("disabled", true);
            }
        });
        /**
         * 提交
         */
        $("#submit").click(function (e) {
            $$.loading();
            $(this).attr("disabled","true");
            console.log("不可用")
            e.preventDefault();
            const errorMsg = validationForm();

            if ($$.isValidObj(errorMsg)) {
                $$.layerToast(errorMsg);
                return;
            }
            $$.request({
                url: UrlConfig.feedback_data,
                loading: true,
                pars: {
                    content: content,
                },
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        $$.layerToast("反馈成功");
                        setTimeout(function () {
                            $$.push("my/callCenter");
                        }, 1000);
                    } else {
                        $$.layerToast(data.msg);
                    }
                }
            });
        });
    }
    function validationForm() {
        let content = $("#content").val();

        //-- check form
        if (!$$.isValidObj(content)) {
            return "请输入意见反馈~";
        }

        return null;
    }
}
