window.onload = function(){
	let dataId = "";
	let photoDataId = "";
	/**----- 选择 是 事件绑定 ----**/
	$(".yes").on("click", function() {
		if(!($(this).children("input").is(':checked'))) {
			$(this).children("input").attr("checked", "checked");
			$(".no").children("input").removeAttr("checked");

			//--提示
			prompt();
		}
		$(".submit").addClass("submit-no").removeClass("submit");

		/**----- 灰色提交 事件绑定 ----**/
		$(".submit-no").on("click", function () {
			if ($('#yes').attr("checked")) {
				//--提示
				prompt();
			}
		})
	});
	/**----- 选择 否 事件绑定 ----**/
	$(".no").on("click", function() {
		if(!($(this).children("input").is(':checked'))) {
			$(this).children("input").attr("checked", "checked");
			$(".yes").children("input").removeAttr("checked");
		}
		$(".submit-no").addClass("submit").removeClass("submit-no");
	});


	/**----- 提交 事件绑定 ----**/
	$(".submit").on("click", function() {
		if($(this).hasClass("submit")) {
			/* 图片 */
			let selects = $('input:radio[name="select"]:checked').val();
			let front = $('.front').attr('src');
			let reverse = $('.reverse').attr('src');
			let bust = $('.bust').attr('src');
			//-- 2020.9.11新增毕业证
			let diploma = $('.diploma').attr('src');

			/**----- 事件判断 ----**/
			if(!$$.isValidObj(front)) {
				$$.layerToast("身份证头像面不能为空");
				$('#notAdded')[0].click();
			} else if(!$$.isValidObj(reverse)) {
				$$.layerToast("身份证国徽面不能为空");
				$('#notAdded')[0].click();
			} else if(!$$.isValidObj(bust)) {
				$$.layerToast("半身正面照片不能为空");
				$('#notAdded')[0].click();
			} else if(!$$.isValidObj(diploma)) {
				$$.layerToast("毕业证不能为空");
				$('#notAdded')[0].click();
			} else if(!$$.isValidObj(selects)) {
				$$.layerToast("未选择是否办理执业登记");
			} else {
				/* 图片上传 */
				let file_one = $('#flagFile-one')[0].files[0];
				let file_two = $('#flagFile-two')[0].files[0];
				let file_three = $('#flagFile-three')[0].files[0];
				let file_four = $('#flagFile-four')[0].files[0];
				//-- 毕业证
				let file_diploma = $('#flagFile-diploma')[0].files[0];
				let fileArray = new Array();
				fileArray[0] = file_one;
				fileArray[1] = file_two;
				fileArray[2] = file_three;
				fileArray[3] = file_diploma;
				if(file_four != null) {
					fileArray[4] = file_four;
				}

				const loopFileUpload = function(i) {
					let formData = new window.FormData();
					formData.append('file', fileArray[i]);
					formData.append('formType', '10011');
					$$.request({
						url: UrlConfig.upload_attachment_upload,
						loading: true,
						pars: formData,
						requestBody: true,
						sfn: function(data) {
							$$.closeLoading();
							if(data.success) {
								if(i === 0) {
									$('.front').attr('src', data.datas.filePath);
									$$.layerToast("第一张图片上传成功");
								} else if(i === 1) {
									$('.reverse').attr('src', data.datas.filePath);
									$$.layerToast("第二张图片上传成功");
								} else if(i === 2) {
									$('.bust').attr('src', data.datas.filePath);
									$$.layerToast("第三张图片上传成功");
								}  else if(i === 3) {
									$('.diploma').attr('src', data.datas.filePath);
									$$.layerToast("第四张图片上传成功");
									if(i === fileArray.length - 1) {
										creatSubmit();
										return;
									}
								}else if(i === 4) {
									$('.chestnut').attr('src', data.datas.filePath);
									$$.layerToast("第五张图片上传成功");
									creatSubmit();
									return;
								}
								loopFileUpload(++i);
							} else {
								$$.layerToast(data.msg);
							}
						},
						ffn: function(data) {
							$$.errorHandler();
						}
					});
				};
				loopFileUpload(0);
			}
		}

	});
	/*上传图片-身份证头像面*/
	$('.photo-one').on("click", function() {
		dataId = $(this).next().attr("data-id");
		$('#flagFile-one').click();
	});
	$('#flagFile-one').on("change", function() {
		let front = $(".front");

		let file = $('#flagFile-one')[0].files[0];
		//文件类型
		let fileType = file.type;
		let type = getFileType(fileType);
		//文件大小
		let fileSize = (file.size / 1024).toFixed(2);
		if(type != "jpg" && type != "gif" && type != "jpeg" && type != "png") {
			$$.layerToast('请上传图片');
			return false;
		}
		if(fileSize > 10240) { //定义不能超过10MB
			$$.layerToast('请上传不超过10M的图片');
			return false;
		}
		lrz(file).then(function(resultObj) {
			$(front).attr("src", resultObj.base64);
			$(front).css('display', 'block');
			$('#left .photo').css('display', 'none');
			$('#left .displayNone').addClass("photo-off-one").removeClass("displayNone");
			$(front).off('click');
			$(front).on('click', function() {
				photoDataId = $(this).prev().attr("data-id");
				$('#flagFile-one').click();
			});
		});
	});
	/*上传图片-身份证国徽面*/
	$('.photo-two').on("click", function() {
		dataId = $(this).next().attr("data-id");
		$('#flagFile-two').click();
	});
	$('#flagFile-two').on("change", function() {
		let reverse = $(".reverse");

		let file = $('#flagFile-two')[0].files[0];
		//文件类型
		let fileType = file.type;
		let type = getFileType(fileType);
		//文件大小
		let fileSize = (file.size / 1024).toFixed(2);
		if(type != "jpg" && type != "gif" && type != "jpeg" && type != "png") {
			$$.layerToast('请上传图片');
			return false;
		}
		if(fileSize > 10240) { //定义不能超过10MB
			$$.layerToast('请上传不超过10M的图片');
			return false;
		}
		lrz(file).then(function(resultObj) {
			$(reverse).attr("src", resultObj.base64);
			$(reverse).css('display', 'block');
			$('#right .photo').css('display', 'none');
			$('#right .displayNone').addClass("photo-off-one").removeClass("displayNone");
			$(reverse).off('click');
			$(reverse).on('click', function() {
				photoDataId = $(this).prev().attr("data-id");
				$('#flagFile-two').click();
			});
		});
	});
	/*上传图片-半身像*/
	$('.photo-three').on("click", function() {
		dataId = $(this).next().attr("data-id");
		$('#flagFile-three').click();
	});
	$('#flagFile-three').on("change", function() {
		let bust = $(".bust");

		let file = $('#flagFile-three')[0].files[0];
		//文件类型
		let fileType = file.type;
		let type = getFileType(fileType);
		//文件大小
		let fileSize = (file.size / 1024).toFixed(2);
		if(type != "jpg" && type != "gif" && type != "jpeg" && type != "png") {
			$$.layerToast('请上传图片');
			return false;
		}
		if(fileSize > 10240) { //定义不能超过10MB
			$$.layerToast('请上传不超过10M的图片');
			return false;
		}
		lrz(file).then(function(resultObj) {
			$(bust).attr("src", resultObj.base64);
			$(bust).css('display', 'block');
			$('#bustPhotos-left .photo').css('display', 'none');
			$('#bustPhotos-left .displayNone').addClass("photo-off-two").removeClass("displayNone");
			$(bust).off('click');
			$(bust).on('click', function() {
				photoDataId = $(this).prev().attr("data-id");
				$('#flagFile-three').click();
			});
		});
	});
	/*上传图片-栗子学院账户截图*/
	$('.photo-four').on("click", function() {
		dataId = $(this).next().attr("data-id");
		$('#flagFile-four').click();
	});
	$('#flagFile-four').on("change", function() {
		let chestnut = $(".chestnut");

		let file = $('#flagFile-four')[0].files[0];
		//文件类型
		let fileType = file.type;
		let type = getFileType(fileType);
		//文件大小
		let fileSize = (file.size / 1024).toFixed(2);
		if(type != "jpg" && type != "gif" && type != "jpeg" && type != "png") {
			$$.layerToast('请上传图片');
			return false;
		}
		if(fileSize > 10240) { //定义不能超过10MB
			$$.layerToast('请上传不超过10M的图片');
			return false;
		}
		lrz(file).then(function(resultObj) {
			$(chestnut).attr("src", resultObj.base64);
			$(chestnut).css('display', 'block');
			$('.account-left .photo').css('display', 'none');
			$('.account-left .displayNone').addClass("photo-off-two").removeClass("displayNone");
			$(chestnut).off('click');
			$(chestnut).on('click', function() {
				photoDataId = $(this).prev().attr("data-id");
				$('#flagFile-four').click();
			});
		});
	});

	/*上传图片-毕业证*/
	$('.photo-diploma').on("click", function() {
		dataId = $(this).next().attr("data-id");
		$('#flagFile-diploma').click();
	});
	$('#flagFile-diploma').on("change", function() {
		let diploma = $(".diploma");

		let file = $('#flagFile-diploma')[0].files[0];
		//文件类型
		let fileType = file.type;
		let type = getFileType(fileType);
		//文件大小
		let fileSize = (file.size / 1024).toFixed(2);
		if(type != "jpg" && type != "gif" && type != "jpeg" && type != "png") {
			$$.layerToast('请上传图片');
			return false;
		}
		if(fileSize > 10240) { //定义不能超过10MB
			$$.layerToast('请上传不超过10M的图片');
			return false;
		}
		lrz(file).then(function(resultObj) {
			$(diploma).attr("src", resultObj.base64);
			$(diploma).css('display', 'block');
			$('.diploma-left .photo').css('display', 'none');
			$('.diploma-left .displayNone').addClass("photo-off-two").removeClass("displayNone");
			$(diploma).off('click');
			$(diploma).on('click', function() {
				photoDataId = $(this).prev().attr("data-id");
				$('#flagFile-diploma').click();
			});
		});
	});
	/**----- X 按钮  事件绑定 ----**/
	$(".displayNone").on("click", function() {
		if($(this).hasClass("photo-off-one")) {
			$(this).addClass("displayNone").removeClass("photo-off-one");
			$(this).siblings(".photo-add").css("display", "block");
			$(this).siblings("img,input").hide();
			$(this).siblings("img").removeAttr("src");
			let files = $(this).siblings("input");
			files.after(files.clone().val(""));
			$(this).siblings("input").val("");

		} else if($(this).hasClass("photo-off-two")) {
			$(this).addClass("displayNone").removeClass("photo-off-two");
			$(this).siblings(".photo-add").show();
			$(this).siblings("img,input").hide();
			$(this).siblings("img").removeAttr("src");
			let files = $(this).siblings("input");
			files.after(files.clone().val(""));
			$(this).siblings("input").val("");
		}
	});

	/*  */
	function prompt(){
		//-- 提示
		let index = layer.open({
			content:
				`<div class="popupContent">
						<div>您已办理执业登记，暂不能在小白进行执业认证！</div>
						<div class="answer space-between">
							<div class="affirm">好的</div>
						</div>
					</div>`
		});
		$(".answer .affirm").on("click", function () {
			layer.close(index);
		});
	}

	/* 获取文件类型 */
	function getFileType(filePath) {
		let startIndex = filePath.lastIndexOf("/");
		if(startIndex != -1) {
			return filePath.substring(startIndex + 1, filePath.length).toLowerCase();
		} else {
			return "";
		}
	}

	/* 图片路径上传  */
	function creatSubmit() {
		let front = $('.front').attr('src');
		let reverse = $('.reverse').attr('src');
		let bust = $('.bust').attr('src');
		let chestnut = "";
		if(typeof($(".chestnut").attr("src")) != "undefined") {
			chestnut = $('.chestnut').attr('src');
		}
		let diploma = $('.diploma').attr('src');
		alert(reverse)
		alert(diploma)
		$$.request({
			url: UrlConfig.member_memberdetail_modifierDetailedAddress,
			loading:true,
			pars: {
				"idcardPic": front,
				"idcardBackPic": reverse,
				"halfBodyPic": bust,
				"accountPic": chestnut,
				"diplomaPic":diploma
			},
			sfn: function(data) {
				if(data.success) {
					$$.closeLoading();
					$$.request({
						url: UrlConfig.member_Detailspage,
						loading: true,
						sfn: function (data) {
							$$.closeLoading();
							if (data.success) {
								let isOldMember = data.datas.isOldMember;
								let explainHtml = '<div>申请已提交</div><div class="explain">请留意小白保险客服热线来电</div>';
								let pars = {
									userStatus: 1 ,
									isNewUserAuthenticationCompleted : '1'
								};
								if (isOldMember) {
									explainHtml = '<div>您已成功补充认证资料</div>';
									pars = {
										userStatus: 2,
										mtype: 4
									}
								}
								let contentHtml = [
									'<div class="popupContent">',
										'<img src="../../images/my/professionalCertification/commited.png" />',
										'<div class="question">' + explainHtml + '</div>',
										'<div class="answer space-between">',
											'<div class="affirm">确定</div>',
										'</div>',
									'</div>'];
								/**----- 确认按钮 事件绑定 ----**/
								let index = layer.open({
									shadeClose: false,
									content: contentHtml.join('')
								});
								$(".answer .affirm").on("click", function() {
									layer.close(index);

									//更新会员基本信息
									$$.request({
										url: UrlConfig.member_member_modifierRealName,
										pars: pars,
										sfn: function(data) {
											if(data.success) {
												/* 跳转首页 */
												$$.push("newIndex");
											}
										}
									});
								});
								countAction("xb_4004");
							} else {
								$$.layerToast(data.msg);
							}
						},
						ffn: function (data) {
							$$.errorHandler();
						}
					});
				}
			},
			ffn: function(data) {
				$$.errorHandler();
			}
		});
	}

};
