
//判断收藏是否为空
let collectIsNone = false;
//判断足迹是否为空
let footprintIsNone = false;

/**
 * 分页参数
 * @Author 肖家添
 * @Date 2019/8/22 15:09
 */
let pagingData = {
    _pageSize: 1000,
    _current: 1,
    _total: 0
};

window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_76', null);
        countAction('xb_2080', null);
    } catch (error) {
        console.log(error);
    }
    const PAGE_STATE = {
        //-- 险种类型, [1: 个人险, 2: 企业险]
        insuranceType: 1
    }


    pageLoader();
    $$.changeVersion();
    function pageLoader(){
        //先加载收藏模块
        loadingPage(collectIsNone,"collect")
        changeColor("collect");
        changeColor("footprint");
    }



    /**
     * 获取产品库
     * @Author 肖家添
     * @Date 2019/9/3 15:25
     */
    function findInsuranceInfo(judge,loading = true, clearList = false, overCallback){
        let params = JSON.parse(JSON.stringify(pagingData));
        const { insuranceType } = PAGE_STATE;

        //-- params handler
        (function(){
            //-- 险种分类
            const insuranceTypeId = $(".search-tit.choose-search").attr("data-id");

            if($$.isValidObj(insuranceTypeId)){
                params["insuranceTypeId"] = insuranceTypeId;
            }
            //-- 产品库名称
            const insuranceInfoName = $(".search").val();
            if($$.isValidObj(insuranceInfoName)){
                params["insuranceInfoName"] = insuranceInfoName;
            }
            //-- 险种类型, [1: 个人险, 2: 企业险]
            params.insuranceType = insuranceType;

            if(clearList){
                pagingData._current = 0;
                params._current = 0;
            }
            if (judge){
                params.judge=judge;
            }
            console.log(params);
        })();

        $$.request({
            url: UrlConfig.collect_insuranceInfo_data,
            loading: loading,
            pars: params,
            sfn: function(data){
                if (data.msg=="暂无浏览足迹"){
                    $$.showNoResultView(".content");
                }else{
                    $$.hideNoResultView(".content");
                }

                if(data.success){
                    console.log(data);
                    if (data.datas[0].list.length>0){
                        $$.hideNoResultView(".content");
                    }else{
                        $$.showNoResultView(".content");
                    }
                    const { tips_promotionFeeDisplay } = data;
                        for (let i=0;i<data.datas.length;i++){
                           const { list, pagination } = data.datas[i];
                            bindInsuranceInfoElement(list, pagination, tips_promotionFeeDisplay);
                        }

                }else{
                        $$.showNoResultView(".content");
                        $$.closeLoading();

                }
            }
        });



        /**
         * 绑定保险产品元素
         * @Author 肖家添
         * @Date 2019/9/3 15:37
         */
        function bindInsuranceInfoElement(list, pagination, tips_promotionFeeDisplay){
            console.log("==========="+list.length);
            try{
                const showOrHideMakeProfits = $(".showOrHideMakeProfits").hasClass("closeEyes");

                //-- paging handler
                (function(){
                    pagingData._current = pagination.current;
                    pagingData._pageSize = pagination.pageSize;
                    pagingData._total = pagination.total;

                    if($$.isValidObj(tips_promotionFeeDisplay)){
                        $(".showOrHideMakeProfits").show();
                    }
                })();

                //-- html handler
                (function(){
                    let html = "";
                    if($$.isValidObj(list)){

                        $$.hideNoResultView();

                        list.forEach((item) => {

                            const { listShowCover, labelList } = item;

                            //-- product labels handler start
                            let labelsHtml = "";
                            if($$.isValidObj(labelList)){

                                labelList.forEach((item) => {
                                    labelsHtml += `<span>${item.labelName}</span>`;
                                });
                            }
                            //-- product labels handler end

                            //-- insureEnsure handler start
                            let insureEnsureHtml = "";
                            const insureEnsureData = item.insureEnsureData;

                            if($$.isValidObj(insureEnsureData)){
                                insureEnsureData.forEach((item) => {
                                    insureEnsureHtml += `
                                        <li>
                                            <span style="padding-right: 10px;text-align: justify;">${item.name}</span>
                                            <span style="white-space:nowrap;">${item.money}</span>
                                        </li>
                                    `;
                                });
                            }
                            //-- insureEnsure handler end

                            html += `
                                <li data-id="${item.insuranceInfoId}" data-sellId="${item.id}">
                                    <span class="left productImage" style="background-image: url(${$$.isValidObj(listShowCover) ? listShowCover : $$.imageUrlCompatible(item.plogo)});"></span>
                                    <div class="right">
                                        <div class="top">
                                            <h3>${item.name}</h3>
                                            <p class="icon" style="${$$.isValidObj(labelsHtml) ? `` : `padding-top: 0px;`}">
                                                ${labelsHtml}
                                            </p>
                                            <p class="desc">${item.productIntroduce}</p>
                                        </div>
                                        <div class="bottom">
                                            <!--<ul class="list">
                                                ${insureEnsureHtml}
                                            </ul>-->
                                            <p class="price">${parseFloat($$.changeIsNilVal(item.sellMoney, 0)).toFixed(2)}元起</p>
                                            <p class="makeProfits" style="opacity: ${showOrHideMakeProfits || !$$.isValidObj(tips_promotionFeeDisplay) ? 0 : 1}">立赚${$$.changeIsNilVal(item.tiMoney, 0)}%</p>
                                        </div>
                                    </div>
                                </li>
                            `;
                        });
                    }

                    if(!$$.isValidObj($(".search").val()) && list.length > 0){
                        $(".searchIcon").stop().fadeOut();
                    }

                    /*if(clearList){
                        $(".content>.list").html(html);
                    }else{
                        $(".content>.list").append(html);
                    }*/
                    $(".content>.list").append(html);
                    //-- 跳转 产品详情
                    $(".content .list li").off().click(function () {
                        const hasShawSearchWrap = $("#searchWrap").hasClass("show");
                        if(!hasShawSearchWrap){
                            const productId = $(this).attr("data-id");
                            const sellId = $(this).attr("data-sellId");
                            $$.push("product/productDetail", {productId, sellId});
                        }
                    });
                })();
            }catch (e) {
                console.error(e);
            }finally {
                $$.closeLoading();
                $$.clearHTMLNotes();

                if(overCallback) overCallback();
            }
        }
    }


    //先加载
    function loadingPage  (isNone,isModule){
        //判断传入进来的模块是否为空;
        if(isNone != true){
            //如果是收藏模块的话就进行展示
            if(isModule == "collect"){
                findInsuranceInfo(isModule);
                //如果是足迹模块的话就展示
            }else if(isModule == "footprint"){
                findInsuranceInfo(isModule);
            }
        }else{
            //如果为空则展示为空效果
            $('.middle').html(noContent());
        }
    }

    /*改变选择的样式*/
    function changeColor(ele) {
        $(`.${ele}`).click( function () {
            $(this).css('color','rgb(255, 104, 73)').children('.vertical').css('background','rgb(255, 104, 73)');
            $(this).siblings().css('color','#000');
            $(this).siblings().children('.vertical').css('background','#fff');
            //点击后选择遍历的数据
            if(ele === "collect"){
                countAction("xb_2080");
                //判断内容是否为空
                $(".list").empty();
                loadingPage(collectIsNone,"collect");
            }else if(ele === "footprint"){
                countAction("xb_2081");
                $(".list").empty();
                //判断内容是否为空
                loadingPage(footprintIsNone,"footprint");
            }
        });
    }
};

