window.onload = function () {
    $$.changeVersion();
    $("#FinancialCalculator").click(function () {
        $$.push('calculator/calculator');
    });

    $("#FundHoldings").click(function () {
        $$.push('calculator/valuation');
    });

};
