let id;
let bankId;//选中的银行卡ID
/*用户的余额*/
let allmoney;
let bankCardListLength = 0;
window.onload = function () {
	$$.changeVersion();
	//如果没有接收到上一个页面传的用户ID则页面金额提示为undefined;
	id = $$.getUrlParam("id");

	//模拟测试
	//allmoney = $$.getUrlParam('allmoney');
	//id = 5;
	//$("#money").val("可提现"+allmoney+"元").css("color","rgba(0,0,0,0.2)");

	$("#money").val("可提现"+allmoney+"元").css("color","rgba(0,0,0,0.2)");
	/*可提现*/
	$$.request({
		url: UrlConfig.accountinfo_data,
		loading: true,
		pars: {id: id},
		method: "POST",
		requestBody:true,
		sfn: function (data) {
			console.log(data);
			$$.closeLoading();
			if (data.success) {
				if (data.accountInfo.useAmount != null || data.accountInfo.useAmount !== ""){
					allmoney = data.accountInfo.useAmount;
					if(allmoney !== 0){
						$("#money").val("可提现"+formatCurrencyTenThou(allmoney)+"元").css("color","rgba(0,0,0,0.2)");
					}else{
						console.log(allmoney);
						$("#money").val("当前可提现金额为0元").css("color","rgba(0,0,0,0.2)");
						$("#money").attr("disabled","disabled");
					}
				}
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});


	/*可用免费次数*/
	$$.request({
		url: UrlConfig.withdraw_count,
		loading: true,
		pars:{
			memberId:id
		},
		requestBody:true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				if (data.count === 0){
					$(".fee").text("1.00")
				}else {
					$("#available").html("(本月免费提现次数"+data.count+")");
				}
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});


	/*银行卡列表*/
	$$.request({
		url: UrlConfig.bankcard_data,
		loading: true,
		pars:{},
		requestBody:true,
		sfn: function (data) {
			$$.closeLoading();
			console.log(data);
			let resultHtml="";
			if (data.success) {
				if (data.bankCard.length > 0){
					for (let i = 0; i <data.bankCard.length ; i++) {
						resultHtml += "<li onclick='selectBank("+data.bankCard[i].id+")' >";
						resultHtml += `<img src=${$$.imageUrlCompatible(data.bankCard[i].bankPic)} />`;
						resultHtml += ""+data.bankCard[i].bankname+"&nbsp;&nbsp;&nbsp;***&nbsp;***&nbsp;****&nbsp;****&nbsp;&nbsp;"+data.bankCard[i].banknum+"";
						resultHtml += "</li>";
					}
					$(".list3").html(resultHtml);
					bankCardListLength = data.bankCard.length;
				}
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});



	/*提现金额的输入*/
	$("#money").focus(function () {
		if($(this).val().indexOf("可提现") !== -1){
			$(this).val("");
			$(this).css("color","#DA5325;");
		}
	}).blur(function () {
		//当输入栏的值为空时
		if($(this).val() == null || $(this).val() === "") {
			$(this).val("可提现"+allmoney+"元").css("color","rgba(0,0,0,0.2)");
			$("#submit").css({"background-color":"silver","pointer-events":"none"});
		}else{
			//判断是否为数字和小数点
			var reg = /^([1-9][\d]{0,7}|0)(\.[\d]{1,2})?$/;
			//输入栏的值不符合判断时
			if(!reg.test($(this).val()) || $(this).val() <= 0){
				$(this).val("可提现"+allmoney+"元").css("color","rgba(0,0,0,0.2)");
				$("#submit").css({"background-color":"silver","pointer-events":"none"});
			} else{
				//当输入正确的金额时,按钮变色
				$("#submit").css({"background-color":"#DA5325","pointer-events":"auto"});
			}
		}
	});



	/**
	 * 描述信息：金额离开事件
	 * @author 覃创斌
	 * @date 2019-09-24
	 */
	$("#money").change(function () {
		let  inputMoney =  $("#money").val();
		if (inputMoney > allmoney){
			$$.layerToast("提现金额不能大于可提现金额！");
			$("#money").val("");
			return;
		}else if(inputMoney <= 0){
			$$.layerToast("提现金额不能小于0元！");
			$("#money").val("");
			return;
		}

		$$.request({
			url: UrlConfig.accountinfo_Calculate,
			loading: true,
			pars:{
				memberId:id,
				money:inputMoney
			},
			requestBody:true,
			sfn: function (data) {
				$$.closeLoading();
				let resultHtml="";
				if (data.success) {
					$("#tax").html(data.tax);
					let fee = $(".fee").text();
					$(".money").html(inputMoney - data.tax - fee);
					$("#money").css("color","#DA5325");
				} else {
					$$.layerToast(data.msg);
				}
			},
			ffn: function (data) {
				$$.errorHandler();
			}
		});
	});

	/*选择银行下拉选项*/
	$(".time").bind('click',function () {
		if (bankCardListLength > 0){
			/*判断是否点击过下拉按钮*/
			if($("#bankselect").hasClass("bankselect")){
				open();
			}else{
				close();
			}
			countAction("xb_3028");
		} else{
			$$.confirm({
				title: "您还未绑定银行卡，是否前往绑定",
				onOk: function () {
					$$.push('my/withdrawParticulars');
				}
			});
		}
	});





	/*选择银行选项*/
	$(".pitch").click(function () {
		$(this).css("display","none");
		open();
	});


	/*下拉选择银行*/
	$(".bankselect>ul>li").click(function () {
		close();
		var msg = $(this).html();
		$(".bank>div:eq(1)").html(msg);
		console.log(msg)
	});


	/*点击提现按钮*/
	$("#submit").click(function () {
		if (bankId == undefined){
			$$.layerToast("请选择提现的银行卡~~");
			return;
		}
		var htmlArr = [
			'<div class="center">',
			'<ul>',
			'<li class="li_1">本次到账金额:</li>',
			'<li class="li_2">'+$(".money").text()+'元</li>',
			'<li class="li_3">代扣税额<span>'+$("#tax").html()+'元</span></li>',
			'<li class="li_4">提现手续费<span>'+$(".fee").text()+'元</span></li>',
			'</ul>',
			'</div>'
		];


		var html = htmlArr.join(" ");

		//询问框
		layer.open({
			content: html
			,btn: ['确定', '先不提']
			/*确定的判断*/
			,yes: function(data){
				var data = true;
				/**
				 * 用户ID
				 * 提现金额
				 * 税
				 * 手续费
				 * 选择的卡ID
				 */

				$$.request({
					url: UrlConfig.withdraw_Apply,
					loading: true,
					pars:{
						memberId:id,
						bankId:bankId,
						money:$("#money").val()
					},
					requestBody:true,
					sfn: function (data) {
						$$.closeLoading();
						if (data.success) {
							if(data.success == true){
								countAction("xb_3029");
								layer.open({
									content: '<div class = "good" ><img src="../../images/my/good.png" /><span>提现申请成功！2秒后跳转。。。</span></div>'
								})
								setTimeout(function () {
									$$.push("my/withdraw",{
										id:id,
										time:10000*Math.random()
									});
								},2000);
							}else{
								layer.open({
									content: '<div class = "bad"><img src="../../images/my/bad.png" /><span>系统有点问题，请联系客服帮助客服电话：020-8888888</span></div>'
								})
								setTimeout(function () {
									$$.push("my/withdraw",{
										id:id,
										time:10000*Math.random()
									});
								},2000);
							}
						} else {
							$$.layerToast(data.msg);
						}
					},
					ffn: function (data) {
						$$.errorHandler();
					}
				});

			},
			/*先不提的判断*/
			no: function(){
				$("#money").val("可提现"+allmoney+"元").css("color","rgba(0,0,0,0.2)");
				$("#submit").css({"background-color":"silver","pointer-events":"none"});
			}
		});

	});


	/*点击获取全部金额*/
	$(".all").click(function(){
		if (allmoney==0){
			$$.layerToast("当前余额为0,无法进行操作");
			return false;
		}
		if(this.allmoney > 0 || this.allmoney != null || this.allmoney != ""){
			var moneyObject = $("#money");
			/*获取可提现的额度*/
			if(moneyObject.val() == null || moneyObject.val() == ""){
				$("#submit").css({"background-color":"silver","pointer-events":"none"});
			}else{
				moneyObject.val(allmoney).css("color","#DA5325")
				$("#submit").css({"background-color":"#DA5325","pointer-events":"auto"});
			}
			let  inputMoney =  $("#money").val();
			$$.request({
				url: UrlConfig.accountinfo_Calculate,
				loading: true,
				pars:{
					memberId:id,
					money:inputMoney
				},
				requestBody:true,
				sfn: function (data) {
					$$.closeLoading();
					let resultHtml="";
					if (data.success) {
						$("#tax").html(data.tax);
						let fee = $(".fee").text();
						$(".money").html(inputMoney - data.tax - fee);
						countAction("xb_3026");
					} else {
						$$.layerToast(data.msg);
					}
				},
				ffn: function (data) {
					$$.errorHandler();
				}
			});
		}else{
			$$.layerToast("当前余额无法提现");
		}
	});



	/*点击扣税攻略*/
	$(".reduction>span").click(function(){
		let html = `<div class="pop-up">
                            <div class="title">扣减攻略</div>
                            <div class="text">
                                <div>1.扣税说明：</div>
                                根据国家相关税法规定，当月累计提现超过800部分。
                                将依法代扣20%劳务税费后，向您支付剩余款项，
                                税费=（当月累计提现金额+本次提现金额-800）*20%
                            </div>
                            <div class="text">
                                 <div>2.手续费说明：</div>
                                 每个账号每月可免费提现2次，
                                 第三次开始收取手续费每次1元手续费从提现金额中扣取。
                                 若提现失败则不会扣除手续费和税费，提现金额将全部返回账号
                            </div>
                            以上解释权归小白保险所有。
                            <div class="know">我知道了</div>
                        </div>`;
		layer.open({
			content : html,
			type : 1
		});
		$('.know').click(() => {
			layer.closeAll();
		});
		countAction("xb_3027");
	});

	countAction("xb_2064");
};

function open(){
	/*更换样式用于判断*/
	$("#bankselect").removeClass("bankselect");
	$("#bankselect").addClass("bankselectclose");

	$(".bankselectbotton").css("transform","rotate(90deg)");
	$(".pitch").css("display","none");
}


function close(){
	/*更换样式用于判断*/
	$("#bankselect").removeClass("bankselectclose");
	$("#bankselect").addClass("bankselect");

	$(".bankselectbotton").css("transform","rotate(0deg)");
	$(".bankselectclose").css("display","inline-block");
	$(".pitch").css("display","block");
}
/**
 * 描述信息：选中银行卡
 * @author 覃创斌
 * @date 2019-09-24
 */
function selectBank(id) {
	close();
	let result = "";

	$$.request({
		url: UrlConfig.bankcard_data,
		loading: true,
		pars:{
			id:id
		},
		requestBody:true,
		sfn: function (data) {
			$$.closeLoading();
			let resultHtml="";
			if (data.success) {
				for (let i = 0; i <data.bankCard.length ; i++) {
					resultHtml += `<img src=${$$.imageUrlCompatible(data.bankCard[i].bankPic)} />`;
					resultHtml += "<span>"+data.bankCard[i].bankname+"&nbsp;&nbsp;&nbsp;***&nbsp;***&nbsp;****&nbsp;****&nbsp;"+data.bankCard[i].banknum+"</span>";
				}
				bankId= id;
				$(".pitch").html(resultHtml);

			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}


//输入栏的判断
function clearNoNum(obj) {
	obj.value = obj.value.replace(/[^\d.]/g, "");  //清除“数字”和“.”以外的字符
	obj.value = obj.value.replace(/\.{2,}/g, "."); //只保留第一个. 清除多余的
	obj.value = obj.value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
	obj.value = obj.value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3');//只能输入两个小数
	if (obj.value.indexOf(".") < 0 && obj.value != "") {//以上已经过滤，此处控制的是如果没有小数点，首位不能为类似于 01、02的金额
		obj.value = parseFloat(obj.value);
		$('#money').css('color','#DA5325');
	}
}




/**
 * 描述信息：金额格式化
 * @author 覃创斌
 * @date 2019-09-23
 */
function formatCurrencyTenThou(num) {
	num = num.toString().replace(/\$|\,/g,'');
	if(isNaN(num))
		num = "0";
	sign = (num == (num = Math.abs(num)));
	// num = Math.floor(num*10+0.50000000001);
	//cents = num%10;
	// num = Math.floor(num/10).toString();
	for (let i = 0; i < Math.floor((num.length-(1+i))/3); i++)
		num = num.substring(0,num.length-(4*i+3))+','+
			num.substring(num.length-(4*i+3));
	return (((sign)?'':'-') + num );
}

/**
 * 拨打客服电话
 * @Author 肖家添
 * @Date 2020/4/10 14:43
 */
function goCustomerService(){
	countAction("xb_3025");
	location.href = "tel:02083274011";
}