window.onload = function () {
    $$.changeVersion();
    let id;

    //-- 跳转自动绑定
    $$.staticPushAutoBind();

    /**----- 个人信息 事件绑定 ----**/
    $(".header").click(function () {
        //window.location.href = "../../pages/my/personalInformation.html";
        $$.push('my/personalInformation3');
    })

    var a=$(".bank p").children("span:last-child");
    var b=$(".bank input");

	/**----- 执业认证 事件绑定 ----**/
	$(".professionalCertification>.arrow").on("click",function(){
		let userStatus = $(this).attr("data-userStatus");
        //数据统计
        try {
            countAction('xb_65', null);
        } catch (error) {
            console.log(error);
        }
		if(userStatus == 0){
			$$.push("my/professionalCertification");
		}else if(userStatus == 1){
		    $$.alert('等待审核中，请耐心等候');
		}else if(userStatus == 2){
			$$.push("my/passed");
		}else if(userStatus == 3){
			$$.push("my/notPassed");
		}
	});


    $$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();

            if (data.success) {
                console.log(data);
                let userStatus = $(".list li").eq(0).children("span:last-child");
                userStatus.attr("data-userStatus",data.datas.userStatus);
                if(data.datas.userStatus === 0){
                    userStatus.html("去认证");
                }else if(data.datas.userStatus === 1){
                    userStatus.html("待审核");
                }else if(data.datas.userStatus === 2){
                    userStatus.html("审核通过");
                    $(".bank").show();
                }else if(data.datas.userStatus === 3){
                    userStatus.html("审核不通过");
                }
                if (data.datas.userStatus === 2 && data.datas.mtype === 4){
                    $(".username").html(data.datas.rname);
                }else{
                    $(".username").html(data.datas.phone);
                }

                if((data.datas.imgPath==null)||(data.datas.imgPath==="")){
                    $(".logo").attr("src","../../images/my/defaultImg.png");
                }else {
                    $(".logo").attr("src", data.datas.imgPath);
                }
                //$(".list li").eq(2).children("span:last-child").html(data.datas.phone);
                $(".arrow_phone").html(data.datas.phone);
                checkBank();
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

    /**----- 绑定银行卡 事件绑定 ----**/
    $(a).click(function () {
        $$.push('my/withdrawParticulars');
    })

      /* 退出登录 */
    $(".loginOut").click(function () {
        const terminal = 4;
        $$.request({
            url: UrlConfig.member_loginOut,
            pars:{terminal:terminal},
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let timestamp = new Date().getTime();
                    //-- 清除登录记录
                    sessionStorage.clear();
                    localStorage.removeItem($Constant.tokenKey);
                    localStorage.setItem($Constant.weChatUserManualExitKey, timestamp);
                    localStorage.removeItem('memberId');
                    countAction("xb_2062");
                    $$.push('newIndex');
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    })
    /* 注销用户 */
    $(".loginOff").click(function () {
        const rsource = $WeChat.isWx() ? 4 : 1;
        $$.confirm({
            title: "确定永久注销账户？<br/>注销账户不支持恢复!!!",
            onOkLabel: "确定",
            onCancelLabel: "取消",
            onOk: function () {
                $$.request({
                    url: UrlConfig.member_cancelUser,
                    pars:{rsource:rsource},
                    loading: true,
                    requestBody:true,
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success) {
                            //-- 清除登录记录
                            sessionStorage.clear();
                            localStorage.removeItem($Constant.tokenKey);
                            localStorage.setItem($Constant.weChatUserManualExitKey, true);
                            localStorage.removeItem('memberId');

                            $$.push('newIndex');
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            }
        });

    })

    //-- 加载 收货地址数据
    $$.request({
        url: UrlConfig.market_receivingaddress_getByPars,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                $(".deliveryAddressArrow").text("已添加");
            } else {
                $(".deliveryAddressArrow").text("未添加");
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function checkBank() {
    $$.request({
        url: UrlConfig.bankcard_data,
        loading: true,
        pars:{},
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                console.log(data);
                if (data.bankCard.length > 0){
                    $("#bankInfo").html(""+data.bankCard[0].rname+" &nbsp;&nbsp;****&nbsp;****&nbsp;****&nbsp;"+data.bankCard[0].banknum);
                    $(".bank .arrow").html("已绑定")
                }
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
