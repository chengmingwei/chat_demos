

/**
 * 保单管理 JS
 * @Author 肖家添
 * @Date 2019/10/16 10:31
 */


window.onload = function(){
    if (!$$.checkLogin()) {
        ShawHandler.gotoLogin();
    }
    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 保单数据源
        policyDatums: {
            "1-0": null,
            "1-1": null,
            "9-0": null,
            "9-1": null,
        }
    }

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        //数据统计
        try {
            countAction('xb_16', null);
        } catch (error) {
            console.log(error);
        }
        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

        //-- 加载[当前保障]保单数据
        findPolicy(1, 0, function(){
            findPolicy(1, 1);
        });

        $$.changeVersion();
        countAction("xb_2053");
        countAction("xb_2054");
    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 产品介绍产品详情切换
        $(".main-info .tit").on("click", function () {
            const _that = $(this),
                tips = _that.attr("data-tips");

            $(".main-info .tit").removeClass("active");
            _that.addClass("active");

            if(tips == "1"){
                findPolicy(9, 0, function(){
                    findPolicy(9, 1);
                });
            }
            if(tips === "0"){
                countAction("xb_2053");
            }else{
                countAction("xb_2052");
            }

            tabsHeightChange();
        });

        //-- 下载保单
        $(".btn-download").click(function(e){
            downloadPolicy(e);
        });

        //-- 打开电子保单
        $(".info-wrap ul").on("click", "li", function(){
            const pdfPath = $(this).attr("data-pdf");
            if(!$$.isValidObj(pdfPath)) return;
            let prefix = pdfPath.substring(0, $$.findStringPosition(pdfPath,'/', 3));
            location.href = `${prefix}/pdfnew/pdf.html?path=` + $$.pdfUrlCompatible(pdfPath);
        });

        //-- 获取保障服务
        $(".no-order-content button").on("click", function(){
            $$.push("product/productList");
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){

        $$.clearHTMLNotes();

    }

    /**
     * 标签页高度改变
     * @Author 肖家添
     * @Date 2019/9/4 16:04
     */
    function tabsHeightChange() {
        const tips = $(".main-info .tit.active").attr("data-tips");

        const transform = ["0", "-50%"];
        const showViewCls = ["detail-content1", "detail-content2"];
        const height = $(`.${showViewCls[tips]}`).height();

        $("#slideWrap").css({
            '-webkit-transform': `translate(${transform[tips]}, 0)`,
            'transform': `translate(${transform[tips]}, 0)`
        });
        $("#infoCon").css({height: height});
    };

    /**
     * 下载保单
     * @Author 程明卫
     * @Date 2019/10/16 10:38
     */
    function downloadPolicy(){
        // const orderId = $(this).attr("orderId");

        const htmlArr = [
            '<span>确定将电子保单发送至以下邮箱?</span>',
            '<div><input type="email" id="user_email" name="user_email" placeholder="输入你的邮箱地址"/></div>'
        ];
        const content = htmlArr.join(" ");
        layer.open({
            anim: 'up',
            content: content,
            btn: ['<span class="btn-confirm">确认</span>', '取消'],
            yes: sendEmailFinish
        });
    }

    /**
     * 邮件发送成功提示
     * @Author 程明卫
     * @Date 2019/10/16 10:37
     */
    function sendEmailFinish() {
        const htmlArr = [
            '<span>发送成功!</span>',
            '<div>请留意您的邮箱，注意查收</div>'
        ];
        const content = htmlArr.join(" ");
        layer.open({
            content: content
            , btn: '<span class="btn-confirm">好的</span>'
        });
    }

    /**
     * 获取保单
     *
     * isInsuredStatus: 保单状态, [1: 当前保障, 9: 历史保障]
     * insuranceIsGroup: 个险/团险, [0: 个险, 1: 团险]
     *
     * @Author 肖家添
     * @Date 2019/10/16 10:40
     */
    function findPolicy(isInsuredStatus = 1, insuranceIsGroup = 0, callback){
        //-- 值处理
        (function(){
            isInsuredStatus = $$.changeIsNilVal(isInsuredStatus, 1);
            insuranceIsGroup = $$.changeIsNilVal(insuranceIsGroup, 0);
        })();

        const cacheKey = `${isInsuredStatus}-${insuranceIsGroup}`;
        const cacheDatums = PAGE_STATE.policyDatums[cacheKey];
        if($$.isValidObj(cacheDatums) || cacheDatums instanceof Array){
            responseHandler(cacheDatums);
            return;
        }

        $$.request({
            url: UrlConfig.mobileOrderInfoLog_getInsurancePolicy,
            pars: {
                isInsuredStatus,
                insuranceIsGroup
            },
            loading: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){
                    responseHandler(data.datas);
                }else $$.alert(data.msg);
            }
        });

        //-- 获取保单 -> 响应处理
        function responseHandler(data){
            data = $$.changeIsNilVal(data, []);
            PAGE_STATE.policyDatums[cacheKey] = data;

            let sectionId = isInsuredStatus == 1 ? (
                insuranceIsGroup == 0 ? "#currentGuarantee-personal" : "#currentGuarantee-team"
            ) : (
                insuranceIsGroup == 0 ? "#historyGuarantee-personal" : "#historyGuarantee-team"
            );

            let html = "";
            for(const item of data){
                const { sellProductName, productCover, beInsureName, insureTime, beInsurePolicyUrl } = item;

                html += `
                    <li data-pdf="${$$.changeIsNilVal(beInsurePolicyUrl, '')}">
                        <div class="one-cmn">
                            <img src="${$$.imageUrlCompatible(productCover)}"/>
                        </div>
                        <div class="two-cmn">
                            <h3>${sellProductName}</h3>
                            <p class="order-applicant">被保人：${beInsureName}</p>
                            <p class="order-date">${insureTime}</p>
                            ${1 == 1 ? `` : `
                                <p class="order-line">
                                    <a class="btn-download" href="#">下载保单</a>
                                </p>
                            `}
                        </div>
                    </li>
                `;
            }
            const sectionElement = $(sectionId),
                sectionParent = "." + sectionElement.parent().attr("class")
            sectionElement.find("ul").html(html);
            if(data.length > 0) {
                $$.hideNoResultView(sectionParent);
                sectionElement.show();
            }

            if(callback){
                callback();
            }else{
                if(sectionElement.children("ul").children("li").size() <= 0 && sectionElement.prev().children("ul").children("li").size() <= 0){
                    $$.showNoResultView({
                        parentJqSelector: sectionParent,
                        msg: "无保单信息",
                        btnText: "获取保障项目",
                        btnHref: "product/productList"
                    });
                }
            }

            tabsHeightChange();
        }
    }
}
