$(function(){
	/**-----  获取参数值  ----**/
		let url = location.search; //获取url中"?"符后的字串
		let theRequest = new Object();
		if (url.indexOf("?") != -1) {
			let str = url.substr(1);
			strs = str.split("&");
			for(let i = 0; i < strs.length; i ++) {
				theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
			}
		}
		findPageData(theRequest.id);
	/**----- 点击问题显示对应的弹框 ----**/
	function clickDiv(className) {
		console.log('.'+className)
		let $question=document.getElementsByClassName("subject");
		for (let i=0;i<$question.length;i++){
			$question[i].index=i;
		}
		$($question).click(function () {
			let $answer=$(".popupContent")[this.index];
			console.log($($answer).html());
			layer.open({
				content: $($answer).html()
			});
		})
	}
	function findPageData(id){
	 	let html="";
	 	let answer="";
		 $$.request({
			 url: UrlConfig.market_callCenter_questionList,
			 pars:{qtypeId:id},
			 sfn: function(data){
				 if(data.success){
					 console.log(data);
					 for (let i=0;i<data.datas.length;i++){
						 html+=`<div class="subject" data-id="">` +
							 `<span>Q`+(i+1)+`:</span>` +
							 `<span>${data.datas[i].question}</span>`+
							 `</div>`;
						 answer+=`<div class="popupContent">`
							 +`<div class="question">`+
							 `<span>Q:</span>`+
							 `<span>${data.datas[i].question}</span>`+
							 `</div>`+
							 `<div class="answer">`+
							 `<span>A:</span>`+
							 `<span>${data.datas[i].repContent}</span>`+
							 `</div>`+
						 	`</div>`;
					 		}
				 }else{
					 $$.layerToast(`无法获取信息[${data.msg}]`);
				 }
				 $(".content").append(html);
				 $(".popup").append(answer);
				 clickDiv("subject");
			 }
		 });
	}

});