//可提现金额
let Money = 0;

//昨天结算金额
let yesterdayMoney = 0;

//代结算金额
let waitMoney = 0;

//本月累计收入金额
let monthMoney = 0;

//当月保费金额
let protectMoney = 0;

//本月扣税金额
let deductMoney = 0;

let id;

window.onload = function () {
    $$.changeVersion();
    id = $$.getUrlParam("id");
    loadMyWallet();
    changeEyes();
    showWalletStrategy();


    /*点击提现跳转到提现页面*/
    $('.withdraw').click(()=>{
        $$.push('my/withdraw',{
            id:id,
            allmoney: Money
        });
    });

    /*点击收入明细跳转到收入明细页面*/
    $('#incomeDetail').click(()=>{
        $$.push('my/incomeDetail');
    });

};


/*点击显示或隐藏金额*/
let changeEyes = ()=>{
    $('.tex > div:nth-of-type(2)').off().click(function () {
        if($(this).hasClass('changeImg_1')){
            $(this).removeClass().addClass('changeImg_2');
            $('[class $= Money]').text('*********');

        }else{
            $(this).removeClass().addClass('changeImg_1');
            showMoney();
        }
    });
}


let loadMyWallet = ()=> {
    $$.request({
        url: UrlConfig.accountinfo_getMyWallet,
        pars: {},
        method: "POST",
        requestBody:true,
        sfn: function (data) {
            if (data.success) {
                if (data.datas.useAmount==null||data.datas.useAmount===""){
                    Money=0;
                }else{
                    Money = data.datas.useAmount;
                }
                console.log(data);
                yesterdayMoney = data.datas.scoreDay;
                waitMoney = data.datas.rewardAmount;
                monthMoney = data.datas.scoreCount;
                protectMoney = data.datas.payMoney;
                deductMoney = data.datas.tax;
                showMoney();
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}


/*点击钱包攻略*/
let showWalletStrategy = ()=>{
    /*点击扣税攻略*/
    $(".strategy").click(function(){
        let html = `<div class="pop-up">
                            <div class="title">扣减攻略</div>
                            <div class="text">
                                <div>1.扣税说明：</div>
                                根据国家相关税法规定，当月累计提现超过800部分。
                                将依法代扣20%劳务税费后，向您支付剩余款项，
                                税费=（当月累计提现金额+本次提现金额-800）*20%
                            </div>
                            <div class="text">
                                 <div>2.手续费说明：</div>
                                 每个账号每月可免费提现2次，
                                 第三次开始收取手续费每次1元手续费从提现金额中扣取。
                                 若提现失败则不会扣除手续费和税费，提现金额将全部返回账号
                            </div>
                            以上解释权归小白保险所有。
                            <div class="know">我知道了</div>
                        </div>`;
        layer.open({
            content : html,
            type : 1
        });
        $('.know').click(() => {
            layer.closeAll();
        });
        countAction("xb_2063");
    });

}

 /**
  * 参数说明：
  * number：要格式化的数字
  * decimals：保留几位小数
  * dec_point：小数点符号
  * thousands_sep：千分位符号
  */
function number_format(number, decimals, dec_point, thousands_sep) {

    number = (number + '').replace(/[^0-9+-Ee.]/g, '');
    var n = !isFinite(+number) ? 0 : +number,
        prec = !isFinite(+decimals) ? 2 : Math.abs(decimals),
        sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
        dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
        s = '',
        toFixedFix = function(n, prec) {
            var k = Math.pow(10, prec);
            return '' + Math.ceil(n * k) / k;
        };

    s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
    var re = /(-?\d+)(\d{3})/;
    while(re.test(s[0])) {
        s[0] = s[0].replace(re, "$1" + sep + "$2");
    }

    if((s[1] || '').length < prec) {
        s[1] = s[1] || '';
        s[1] += new Array(prec - s[1].length + 1).join('0');
    }
    return s.join(dec);
}

/*显示金额*/
let showMoney = () => {
    $('.Money').text(`${number_format(Money,2)}`);
    $('.yesterdayMoney').text(`${number_format(yesterdayMoney,2)}`);
    $('.waitMoney').text(`${number_format(waitMoney,2)}`);
    $('.monthMoney').text(`${number_format(monthMoney,2)}`);
    $('.protectMoney').text(`${number_format(protectMoney,2)}元`);
    $('.deductMoney').text(`${number_format(deductMoney,2)}`);
}
