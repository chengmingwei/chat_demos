//获取当前年份
const date = new Date();
const nowYear = date.getFullYear();
let year,month,day;
let id = null;
let name = null;
let memberId = null;
let browseId = null;
let fillInState = 0;
window.onload = function () {
    $$.changeVersion();
    id = $$.getUrlParam('id');
    name = $$.getUrlParam('name');
    memberId = $$.getUrlParam('memberId');
    browseId = $$.getUrlParam('browseId');
    fillInState = $$.getUrlParam('fillInState');

    if (fillInState == 0){
        $("title").text("新增联系人");
    } else{
        $("title").text("编辑联系人");
    }

    getData();

    function showUserLinkData(data) {
        $("#id").attr("data-id", data.id);
        $("#name").val(data.name);
        $("#mobile").val(data.mobile);
        $("#email").val(data.email);
        $("#idCardNum").val(data.idCardNum);
        $(".selectCertificates > p").text(certificates[data.idCardTypeId - 1].label).css("color", "rgb(120, 120, 120)").attr("data-id", data.idCardTypeId);
        let curr_time = new Date(data.birthday.replace(/\-/g, "/").replace("00:00:00.0", ""));
        $(".selectDay > p").text(curr_time.getFullYear() + '年' + (curr_time.getMonth() + 1) + '月' + curr_time.getDate() + '日').css("color", "rgb(120, 120, 120)").attr("data-id", curr_time.getFullYear() + "-" + (curr_time.getMonth() + 1) + "-" + curr_time.getDate());
        if (data.sex === 0) {
            $("#man").click();
        } else if (data.sex === 1) {
            $("#woman").click();
        }
    }


    //证件选择
    $('.certificates').on('click', function () {
        weui.picker(certificates, {
            //证件类型默认为身份证
            defaultValue: [1],
            onConfirm: function (result) {
                $(".selectCertificates > p").text(result[0].label).css("color", "rgb(120, 120, 120)").attr("data-id", result[0].value);
            }
        });
    });

    //出生日期选择
    $('.birthday').on('click', function () {
        weui.datePicker({
            start: 1900,
            end: nowYear,
            defaultValue: [1998, 12, 6],
            onConfirm: function (result) {
                year = result[0];
                month = result[1];
                day = result[2];
                console.log(year + '年' + month + '月' + day + '日');
                $(".selectDay > p").text(year + '年' + month + '月' + day + '日').css("color", "rgb(120, 120, 120)").attr("data-id", year + "-" + month + "-" + day);
            }
        });
    });

    //性别选择-----------------------
    $('.sex > .right > div').on('click', function () {
        if ($(this).hasClass('changeColor_1')) {
            $(this).siblings().removeClass('changeColor_1').addClass('changeColor_2');
        } else {
            $(this).removeClass('changeColor_2').addClass('changeColor_1');
            $(this).siblings().removeClass('changeColor_1').addClass('changeColor_2');
        }
        getSex();
    });

    //点击分享给客户填写
    $('.send').on('click', () => {
        $('#popup').show();
        return false;
    });

    $('#popup .bg,.showFrame').click(function () {
        $('#popup').hide();
        return false;
    });


    //点击保存
    $('.submit,.bottom_share').on('click', () => {
        const from = {};
        //id
        from.id = $('#id').attr("data-id");
        //姓名
        from.name = $('.name > .right > input').val().trim();
        //手机号码
        from.mobile = $('.tel > .right > input').val().trim();
        //邮箱
        from.email = $('.email > .right > input').val().trim();
        //证件号码
        from.idCardNum = $('.cardNumber > .right > input').val().trim();
        //出生日期
        from.birthday = $('.selectDay > p').attr("data-id");
        //性别
        from.sex = getSex();
        //证件号
        from.idCardTypeId = $(".selectCertificates > p").attr("data-id");
        /*提交验证输入框内的内容信息*/
        /*if (from.name.length == 0 ||
            from.mobile.length == 0 ||
            from.email.length == 0 ||
            from.idCardNum == 0) {
            $$.layerToast("输入内容不能为空");
        } else if (from.name.length > 10) {
            $$.layerToast("姓名输入有误,请重新输入");
            //$('.name > .right > input').val("");
        } else if (isTel(from.mobile)) {
            $$.layerToast("手机号码输入有误,请重新输入");
            //$('.tel > .right > input').val("");
        } else if (isEmail(from.email)) {
            $$.layerToast("邮箱输入有误,请重新输入");
            //$('.email > .right > input').val("");
        } else if ($('.selectDay > p').text().trim() == "请选择") {
            $$.layerToast("请选择出生日期");
        } else {
            console.log(from);
            submitFromData(from);
        }*/

        const regexCh = /^[a-zA-Z\u4e00-\u9fa5]+$/;      // 判断姓名 中文+英文
        if (from.name.length === 0) {
            $$.layerToast("输入姓名不能为空");
        } else if (!regexCh.test(from.name)){
            $$.layerToast("姓名输入有误,请重新输入");
        } else if (from.mobile.length === 0){
            $$.layerToast("输入手机号码不能为空");
        } else if (from.mobile.length !== 0 && isTel(from.mobile)){
            $$.layerToast("手机号码输入有误,请重新输入");
        } else if (from.email.length !== 0 && isEmail(from.email)){
            $$.layerToast("邮箱输入有误,请重新输入");
        } else {
            console.log(from);
            submitFromData(from);
        }

    });

    function getData() {
        $$.request({
            url: UrlConfig.userLinkMan_getData,
            method: "GET",
            pars:{
                id:id,
                memberId:memberId
            },
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if ($$.isValidObj(name)){
                        $("#name").val(decodeURI(name));
                    }
                    wechatShare(data);
                    if (data.datas) {
                        console.log(data.datas);
                        showUserLinkData(data.datas);
                    }

                    countAction("xb_2072");
                } else if (data.msg === 'noLogin') {
                    let returnUrl = window.location.href;
                    if (returnUrl.indexOf("memberId") > -1) {
                        returnUrl = $$.getFullHost() + '/src/pages/looked/client.html';
                        returnUrl += $$.jsonToUrlParams({
                            id:id,
                            name:name
                        });
                    }
                    $$.alert('你未登录',function () {
                        $$.push("login/login", {
                            returnUrl:encodeURIComponent(returnUrl)
                        });
                    });
                } else {
                    $$.alert(data.msg + '，跳转到首页',function () {
                        $$.push("newIndex");
                    });
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};

let submitFromData = (from) => {
    let url = UrlConfig.userLinkMan_insert;
    if (from.id) {
        url = UrlConfig.userLinkMan_update + "/" + from.id
    } else {
        from.memberId = memberId;
        from.browseId = browseId;
    }
    $$.request({
        url: url,
        pars: from,
        requestBody: true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                $$.alert('保存成功',function () {
                    if (memberId) {
                        window.location.href="about:blank";
                        window.close();
                    } else {
                        window.location.href = document.referrer;
                    }
                });
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
};

//js验证邮箱
let isEmail = (temp) => {
    const myreg = /^([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[_|\_|\.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$/;
    return myreg.test(temp) ? false : true;
};

//手机号码验证
let isTel = (tel) => {
    const PhoneReg = /^1[0-9]{10}$/;
    return PhoneReg.test(tel) ? false : true;
};

//判断性别并返回结果
let getSex = () => {
    //性别默认为男
    return $('.changeColor_1').hasClass("man") ? 0 : 1;//男(0) --- 女(1)
};


/**
 * -- 输入身份证时自动显示出生日期
 */
function setBirthday() {
    const $idCard = $('#idCardNum').val();
    const index = document.getElementsByClassName('selectCertificates')[0].children[0].getAttribute("data-id");
    if($idCard.length === 18 && index === "1"){
        const birthday = $idCard.substring(6,14);
        year = birthday.substring(0,4);
        month = birthday.substring(4,6);
        day = birthday.substring(6,8);
        $(".selectDay > p").text(year + '年' + month + '月' + day + '日').css("color", "rgb(120, 120, 120)").attr("data-id", year + "-" + month + "-" + day);
    }else{
        $(".selectDay > p").text('请选择').css("color", "rgb(120, 120, 120)").removeAttr("data-id");
    }
}


//证件类型JSON
const certificates =
    [
        {
            label: "身份证",
            value: 1
        },
        {
            label: "军官证",
            value: 2
        },
        {
            label: "护照",
            value: 3
        },
        {
            label: "驾驶证",
            value: 4
        },
        {
            label: "港澳通行证/回乡证",
            value: 5
        },
        {
            label: "其他",
            value: 6
        }
    ];

function wechatShare(member) {
    if (memberId) {
        $('.send').hide();
        $('.bottom').css({
            'display':'flex',
            'justify-content':'center'
        });
        WE_CHAT_MENU_FLAG = false;
        weChatMenuHandler();
    } else {
        let lineLink = $$.getFullHost() + '/src/pages/my/addClient.html';
        lineLink += $$.jsonToUrlParams({
            memberId:member.memberId,
            id:id,
            name:name,
            browseId:browseId
        });
        weChatJSTool.share({
            _imgUrl: member.imgPath,
            _lineLink: lineLink,
            _shareTitle: '认识你，是我最荣幸的事',
            _descContent: '写下专属于你的更多信息，让我更加了解你吧',
            _sfn: function () {
                console.log("成功注册分享链接：" + lineLink);
            },
            _cfn: function () {
            },
            _ffn: function () {
                console.log("失败注册分享链接：" + lineLink);
            }
        });
    }
}
