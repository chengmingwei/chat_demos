/**
 * 制作海报 JS
 * @Author 吴成林
 * @Date 2020-2-26 11:02:17
 */
const PAGE_STATE = {
    switchState: true,                      // 是否显示名片
    whetherVIP: false,                  // 是否是VIP
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        getVipData();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 是否 - 显示名片
        $(".switch").on("click", function(){
            if (PAGE_STATE.switchState){
                $(this).css("background-color","#999999");
                $(this).children("div.switchNo").removeClass("switchNo").addClass("switchYes");
                PAGE_STATE.switchState = false;
            } else {
                $(this).css("background-color","#EF5B09");
                $(this).children("div.switchYes").removeClass("switchYes").addClass("switchNo");
                PAGE_STATE.switchState = true;
            }
        });

        //-- 选择海报 - 图片上传
        $('.addPosters').on("click",function () {
            $(this).find('input')[0].click();
        });
        $('.addPosters > input').on('change',function () {
            const _this = $(this);
            let file=_this[0].files[0];
            //文件类型
            let fileType=file.type;
            let type=getFileType(fileType);
            //文件大小
            let fileSize=(file.size/ 1024).toFixed(2);
            if(type!=="jpg"&&type!=="gif"&&type!=="jpeg"&&type!=="png"){
                $$.layerToast('请上传图片');
                return false;
            }
            if(fileSize>10240){//定义不能超过10MB
                $$.layerToast('请上传不超过10M的图片');
                return false;
            }
            lrz(file).then(function (resultObj) {
                /*_this.siblings('img').attr("src",resultObj.base64);
                _this.siblings('img').css('display','block');
                _this.siblings('.btn').css('display','none');*/
                $("#postersImg").css("background", `url("${resultObj.base64}") no-repeat center / contain`);
            });
        });

        //-- 提交 - 制作海报
        $(".makePosters").on("click", function(){
            if (!PAGE_STATE.whetherVIP) {
                $$.confirm({
                    title: "哦噢，使用此功能需先开通展业功能包哦，点击确认即前往开通！",
                    onOkLabel: "确认",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
                return;
            }
            let headPath;
            let file_Head = $('#photo')[0].files[0];//海报
            let postersTitle = $("#postersTitle").val().trim();
            console.log(postersTitle);
            if (postersTitle == ""){
                $$.alert("海报标题不能为空！！！");
                return false;
            }
            const submit = function (uploadData) {
                $$.loading();
                $$.request({
                    url: UrlConfig.market_insertMyPoster,
                    pars:{
                        title:postersTitle,
                        picId:uploadData.datas.attachmentId,
                        picPath:uploadData.datas.filePath,
                        pvcount:0,
                        collectCount:0,
                        relayCount:0,
                        qxy:"0,0",
                        creatorType:2,
                        type:1
                    },
                    requestBody:true,
                    loading: true,
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success) {
                               $$.alert("海报上传成功！",function () {
                                   $$.push("my/posters");
                               })
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            };
            const  uploadHead = function () {
                if (file_Head !== undefined){
                    let formData = new window.FormData();
                    formData.append('file', file_Head);
                    formData.append('formType', '10007');
                    $$.request({
                        url: UrlConfig.upload_attachment_upload,
                        loading: true,
                        pars: formData,
                        requestBody: true,
                        sfn: function(data) {
                            if(data.success) {
                                headPath = data.datas.filePath;
                                $("#postersImg").attr("src",headPath);
                                if (headPath == null){
                                    $$.closeLoading();
                                    return;
                                }
                                submit(data)
                            } else {
                                $$.layerToast(data.msg);
                                return null;
                            }
                        },
                        ffn: function(data) {
                            $$.errorHandler();
                        }
                    });
                }else {
                    $$.alert("请选择文件上传！")
                }
            };
            uploadHead();
        });
    }

    /**
     * 得到文件类型
     */
    function getFileType(filePath) {
        let startIndex=filePath.lastIndexOf("/");
        if(startIndex!==-1){
            return filePath.substring(startIndex+1,filePath.length).toLowerCase();
        }else {
            return "";
        }
    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType !== 0;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
