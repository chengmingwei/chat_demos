/**
 * 每周抽奖 JS
 * @Author 吴成林
 * @Date 2019/12/4 19:07
 */
let hasCycle = false;
window.onload = function(){
	//数据统计
	try {
		countAction('xb_74', null);
	} catch (error) {
		console.log(error);
	}
	new _PAGE().pageLoader();
};

/**
 * 使用对象封装好方法方便APP调用
 * @Author 肖家添
 * @Date 2020/2/24 14:49
 */
function _PAGE(){

	const thisPage = this;

	/**
	 * 数据存储中心
	 * @Author 吴成林
	 * @Date 2019/12/12 14:56
	 */
	const PAGE_STATE = {
		formType : "",
		parentMemberId : "",
		formId : '',
		shareDatums: {
			url: "",
			image: $$.getFullHost() + "/src/images/activity/luckyDraw/shareImages.png",
			title: "这个奖品蛮不错哦",
			content: "点击分享即可免费参与抽奖!"
		}
	};

	/**
	 * 页面加载对必要的参数作处理
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	this.pageLoader = function() {

		//-- 页面初始化
		pageInit();

	}

	/**
	 * 绑定事件及页面初始化处理
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function pageInit() {

		//-- 初始化页面
		initPageState();

		//-- 判断用户是否登录
		if ($$.checkLogin()){
			//-- 绑定事件
			bindEvent();

			//-- 获取页面数据
			findPageData();
		} else {
			//-- 打开登录页面，登录完成会跳转回当前页面
			$$.gotoLogin();
		}

	}

	/**
	 * 绑定事件
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function bindEvent() {
		//-- 右上角 分享
		$('#share').on('click', function(){
			if (!hasCycle) {
				return;
			}
			shareHandler();
		});

		//-- 抽奖规则  弹窗
		$(".sweepstakesRules").on("click", function(){
			let index = layer.open({
				content: `
					<div class="popupContent">
						<div class="popupTitle">活动规则</div>
						<ul>
							<li>
								<span>1）</span>
								<span>活动为小白保险app用户专享用，每周五下午三点整公布中奖结果，15:00-次周15:00可报名参加活动；</span>
							</li>
							<li>
								<span>2）</span>
								<span>在活动时间内点击参加抽奖按钮即可获得1个抽奖码，每邀请一个好友参与活动可额外一个助力抽奖码，每个用户一个抽奖周期内最多可获得35个助力抽奖码；</span>
							</li>
							<li>
								<span>3）</span>
								<span>每周随机抽取十个抽奖码中奖赠送奖品；</span>
							</li>
							<li>
								<span>4）</span>
								<span>中奖者需在开奖后20日内在活动页内填写收件信息，若超过期限，则视为放弃当期中奖奖品，抽奖结果无效作废；</span>
							</li>
						</ul>
						<div>
							<p>温馨提示：</p>
							<p class="textIndent">活动解释权归属小白保险APP所有，若发现存在任何异常行为的用户，将取消其参与资格，若奖品已发出将有权收回奖品。</p>
							<p class="textIndent">软件使用规定用户年龄18+</p>
							<p class="textIndent">Apple没有以任何方式参与比赛或抽奖活动；Apple不是赞助商。</p>
						</div>
						<div class="answer">
							<span class="affirm">我知道了</span>
						</div>
					</div>
				`
			});
			$(".answer").on("click", function(){
				layer.close(index);
			});
		});

		//-- 领取抽奖码 弹窗
		$(".lotteryYards").on("click", function(){
			if (!hasCycle) {
				return;
			}
			getLotteryYards();
		});

	}

	/**
	 * 初始化页面参数
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function initPageState() {
		//-- 微信打开
		/*if(!$WeChat.isWx()){
			$$.alert("请从微信中打开！", function(){
				$$.push("newIndex");
			});
			return;
		}*/

		let width = $(window).width();
		if(width <= 340){
			$(".scrollBar").css("width","70vw");
		} else if(width <= 360){
			$(".scrollBar").css("width","66vw");
		} else if(width <= 380){
			$(".scrollBar").css("width","62vw");
		} else {
			$(".scrollBar").css("width","60vw");
		}
	}

	/**
	 * 获取页面数据
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function findPageData() {
		//-- 获取抽奖码信息
		$$.request({
			url: UrlConfig.market_mobileAC19001_getLotteryCodeData,
			loading: true,
			sfn: function(data){
				$$.closeLoading();
				if (data.success){
					console.log(data);
					hasCycle = data.datas.hasCycle;
					if (!hasCycle) {
						$$.alert('活动结束');
					}
					//-- 能获得多少抽奖码
					$(".unclaimed span").text(data.datas.availableCodeSize);

					//-- 已有抽奖码
					let codeList = data.datas.codeList;
					$(".myLotteryYards span").text($$.isValidObj(codeList) ? codeList.length : 0);
					//-- 我的抽奖码 弹窗
					$(".myLotteryYards").on("click", function(){
						//-- 查看抽奖码
						if (!hasCycle) {
							return;
						}
						myLotteryYards(codeList);
					});

					//-- 获取上期中奖用户公布
					priorPeriodWinning(data.datas.winnerList);
					PAGE_STATE.parentMemberId = data.datas.parentMemberId;
					PAGE_STATE.formType = data.datas.formType;
					PAGE_STATE.formId = data.datas.formId;
					let shareUrl = $$.getFullHost() + '/src/pages/login/register.html';
					shareUrl += $$.jsonToUrlParams({
						posterId: PAGE_STATE.formType,
						parentMemberId: PAGE_STATE.parentMemberId
					});
					PAGE_STATE.shareDatums.url = shareUrl;
					//-- 分享
					shareWeeklyLuckyDraw();
				} else {
					$$.alert(data.msg);
					hasCycle = false;
				}
			}
		});

		//-- 获取上期中奖用户公布
		function priorPeriodWinning(winnerList){
			if (winnerList.length === 0) {
				$(".temporary").show();
			} else {
				let html = "<ul>";
				for (let i in winnerList) {
					let account = winnerList[i].account;	//用户名（手机号）
					let rname = winnerList[i].rname;	//姓名
					let phone = account.replace(/^(\d{3})\d{4}(\d+)/,"$1****$2"); //手机号159****1111
					let prizeName = winnerList[i].prizeName;
					html +=
						`<li>
							<div><span>${$$.isValidObj(rname)?rname:phone}</span></div>
							<div><span>获得</span></div>
							<div><span class="prize">${prizeName}</span></div>
						</li>`;
				}
				html += "</ul>";
				$(".winningUserLsit").html(html);
			}
		}

		//-- 单行文字滚动条
		roll("roll", 2000);
	}

	/**
	 * 我的抽奖码
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function myLotteryYards(codeList) {
		if (!$$.isValidObj(codeList) || codeList.length === 0){
			//-- 没有抽奖码
			let index = layer.open({
				content:
					`<div class="popupContent">
                        <div class="popupLotteryYards">哎呀，暂无抽奖码</div>
                        <div class="choose">
                            <div class="more moreOf">获取抽奖码</div>
                        </div>
                    </div>`
			});
			$(".moreOf").on("click", function(){
				layer.close(index);
				shareHandler();
			});
		} else {
			//-- 有抽奖码
			let index = layer.open({
				content:
					`<div class="popupContent">
					<div class="popupLotteryYards">
						<span>我的抽奖码：</span><span class="lotteryYardsSum">${codeList.length}</span><span>个</span>
					</div>
					<div class="lotteryYardsList">
						<ul>
						</ul>
					</div>
					<div class="choose">
						<div class="more moreOf">关闭</div>
					</div>
				</div>`
			});
			$(".moreOf").on("click", function(){
				layer.close(index);
			});
			//-- 领取抽奖码
			for(let i in codeList){
				let lotteryYards = codeList[i];
				$('.lotteryYardsList ul').append(`<li>${lotteryYards}</li>`);
			}
		}
	}

	/**
	 * 获取页面数据
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function getLotteryYards() {
		let unclaimedSum = $(".unclaimed span").text();
		if (unclaimedSum == 0){
			//--没有抽奖码
			let index = layer.open({
				content:
					`<div class="popupContent">
                        <div class="popupLotteryYards">很抱歉,你没有待领取抽奖码！</div>
                        <div class="choose">
                            <div class="more moreOf">获取更多抽奖码</div>
                        </div>
                    </div>`
			});
			$(".moreOf").on("click", function(){
				layer.close(index);
				shareHandler();
			});
		} else {
			//-- 参加抽奖,领取抽奖码
			$$.request({
				url: UrlConfig.market_mobileAC19001_joinLottery,
				loading: true,
				sfn: function(data){
					$$.closeLoading();
					if (data.success){
						//-- 刷新加载
						findPageData();
						countAction("xb_2079");
						//-- APP端 埋点事件触发
                        $$.postAPP(10005, {
                            eventId: "xb_2011",
                            arguments: {
                                position: "每周抽奖-领取抽奖码"
                            }
                        });
					} else {
						$$.layerToast(data.msg);
					}
				}
			});
			//--有抽奖码
			let index = layer.open({
				content:
					`<div class="popupContent">
					<div class="popupLotteryYards">恭喜你成功领取<span>${unclaimedSum}</span>个抽奖码</div>
					<div class="popupLotteryYards">小白祝你好运！</div>
					<div class="choose">
						<div class="share">分享喜悦</div>
						<div class="more">获取更多抽奖码</div>
					</div>
				</div>`
			});

			$(".share,.more").on("click", function(){
				layer.close(index);
				shareHandler();
			});
		}
	}

	/**
	 * 单行文字滚动条
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function roll(elem, time){
		let ul = $("#"+elem);
		let li = ul.find("li");
		setInterval(function () {
			ul.animate({
				"margin-top": -li.innerHeight() + 'px'
			}, 500, function() {
				ul.css({
					marginTop: "0px"
				}).find("li:first").appendTo(ul);
			})
		}, time || 3000);
	}

	/**
	 * 分享每周抽奖
	 * @Author 吴成林
	 * @Date 2019/12/4 19:07
	 */
	function shareWeeklyLuckyDraw() {
		if (!hasCycle || !$WeChat.isWx()) {
			return;
		}
		const { url, image, title, content } = PAGE_STATE.shareDatums;
		weChatJSTool.share({
			_imgUrl: image,
			_lineLink:  url,
			_shareTitle: title,
			_descContent: content,
			_sfn: function () {
				thisPage.shareAfter();
			}
		});
	}

	/**
	 * 分享处理
	 * @Author 肖家添
	 * @Date 2020/2/24 12:35
	 */
	function shareHandler(){
		if(PAGE_APP){
			//-- APP
			const { shareDatums } = PAGE_STATE;
			const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
		}else{
			//-- 分享showShareView
			$$.showShareView('点击右上角,分享每周抽奖活动给好友！');
		}
	}

	/**
	 * 分享后续
	 * @Author 肖家添
	 * @Date 2020/2/24 14:37
	 */
	this.shareAfter = function() {
		$$.request({
			url: UrlConfig.member_insertForwarding,
			pars: {
				formType: PAGE_STATE.formType,
				formId: PAGE_STATE.formId,
			},
			sfn: function (data) {
				if (data.success) {
					$$.layerToast("分享成功~");
				}
			}
		});
	}
}
