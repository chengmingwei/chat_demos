/**
 * 小白训练营 - 报名成功 JS
 * @Author 吴成林
 * @Date 2020-4-13 15:45:30
 */
let userJoinId;
let browseId;
window.onload = function() {
    $$.changeVersion();
    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();
        $(".number").html($$.getUrlParam("MTXB_Num"));
        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        userJoinId = $$.getUrlParam("userJoinId");
        browseId = $$.getUrlParam("browseId");
        let prosperityKey = $$.getUrlParam("prosperityKey");    // 报名成功Key
        if ($$.isValidObj(prosperityKey)){
            getById();
        }
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        $('.more').on('click', function () {
            $$.push("login/register");
        });
    }

    //-- 获取领航计划用户信息
    function getById() {
        $$.request({
            url: UrlConfig.management_userjoininfo_getById,
            loading: true,
            pars:{
                browseId:browseId
            },
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    console.log(data);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 设置用户性别
    function setUserGender() {

    }

}
