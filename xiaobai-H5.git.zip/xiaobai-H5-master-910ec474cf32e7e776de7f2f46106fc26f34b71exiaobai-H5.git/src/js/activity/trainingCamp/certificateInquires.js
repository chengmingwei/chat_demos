/**
 * 证书查询 JS
 * @Author 吴成林
 * @Date 2020-4-15 19:54:01
 */
let activeId = 10002;           //活动ID
window.onload = function() {
    $$.changeVersion();
    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        activeId = $$.getUrlParam("activeId");
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 找客服
        $('.service').on('click', function () {
            var index = layer.open({
                content:
                    `<div class="popupContent">
					<div class="question">
						<b>扫描下方二维码，添加小白专属客服</b>
						<img src="../../../images/my/serviceQrCode.png" />
						<span>长按识别二维码</span>
					</div>
				</div>`
            });
        });

        //-- 更多精彩
        $('.login').on('click', function () {
            if ($$.checkLogin()){
                $$.push("newIndex");           // 已登录 => 去首页
            } else{
                $$.push("login/login");     // 未登录 => 去登录
            }
        });

        //-- 查询
        $('.query').on('click', function () {
            let value = $('.certificate').val();
            if (value){
                if (value.length < 3 && $Reg.numAndLetterReg.test(value)){
                    $$.alert('请输入正确的参训号');
                } else {
                    $$.request({
                        url: UrlConfig.management_getByParticipateNum,
                        pars: {
                            num:value,
                        },
                        requestBody: true,
                        loading: true,
                        sfn: function (data) {
                            $$.closeLoading();
                            if (data.success) {
                                //-- 根据参训号查询
                                $$.push('activity/trainingCamp/certificateDetails',{
                                    userJoinId: data.userJoinId,
                                    activeId: activeId
                                });
                            }else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });

                }
            } else{
                $$.layerToast('请输入参训号');
            }
        });
    }
};
