/**
 * 小白训练营 - 打榜 JS
 * @Author 吴成林
 * @Date 2020-4-14 15:38:40
 */
let shareStatus = 'false' ;      // 分享状态
let activeId = 10002;           //活动ID
let weChatOpenId;               //已加密的
let name;
let userJoinId;
window.onload = function() {
    $$.changeVersion();
    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();

    }

    function loadNperList(activeId) {
        $$.request({
            url: UrlConfig.market_active_loadNperList,
            sfn: function (data) {
                if (data.success) {
                    const list = data.list;
                    let nperList = [];
                    const nper = $('.nper');
                    for (let i = 0;i < list.length;i++){
                        nperList.push({
                            label: list[i].activeName,
                            value: list[i].id
                        });
                        if (parseInt(activeId) === list[i].id) {
                            nper.text(list[i].activeName+"▼");
                        }
                    }
                    //-- 选择期数
                    nper.on('click', function () {
                        weui.picker(nperList, {
                            id: 1,
                            defaultValue: [activeId],
                            onConfirm: function(result) {
                                console.log(result[0].value);
                                $('.nper').text(result[0].label+"▼");
                                activeId = result[0].value;
                                //-- 更新列表和排名
                                loadRanKingList(activeId);
                            }
                        });
                    });
                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        //-- 分享状态 - 显示打榜列表
        shareStatus = $$.getUrlParam("shareStatus");
        weChatOpenId = $$.getUrlParam("weChatOpenId");
        activeId = $$.getUrlParam("activeId");
        if (shareStatus === 'true'){
            $('.userData').hide();
        }
        if (activeId == null) {
            $$.alert("参数出现异常，请稍等操作！", function () {
                $$.push("index")
            })
        }

        /**
            1.先查询该用户是否参加了当前期的打榜
            2.查询前三名
            3.查询后面的名次

         点赞功能
            1 每天只能给自己点赞自己一次，可以给别人点赞三次

        */
        if ($$.isValidObj(weChatOpenId)) {
            loadUserInfo();
            loadRanKingList(activeId);
            loadNperList(activeId);
        } else {
            checkShare();
        }
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 打榜规则
        $('.rule').on('click', function () {
            let index = layer.open({
                content: `
					<div class="popupContent">
						<div class="popupTitle">打榜规则</div>
						<ul>
							<li>
							    <p>1、参训学员每人每天享有1次打榜机会；</p>
							</li>
							<li>
							    <p>2、如何在榜单排名靠前：</p>
							    <p>参训学员可转发打榜链接，亲友关注【小白保险】公众号，回复“打榜”，点击链接在榜单找到好友，即可帮好友打榜，好友每天可帮打榜3次哦。</p>
							</li>
							<li>
								<p>3、本次活动由小白保险享有最终解释权</p>
							</li>
						</ul>
						<div class="answer">
							<span class="affirm">好的</span>
						</div>
					</div>
				`
            });
            $(".answer").on("click", function(){
                layer.close(index);
            });
        });

        //-- 打榜
        $('.enroll').on('click', function () {
            let dataState = $(this).attr('data-state');
            if (dataState == '1'){
                $(this).attr('data-state', "2");
                $(this).text("邀请好友打榜");
                let ranking = 0;        // 当前排名
                let html = `当前排名：<span>${ranking}</span>`;
                $('.currentRanking').html(html);
                $$.request({
                    url: UrlConfig.management_insertActiHitDetail,
                    pars: {
                        weChatOpenId: weChatOpenId,
                        activeId: activeId,
                        userJoinId:userJoinId
                    },
                    requestBody: true,
                    method: "POST",
                    sfn: function (data) {
                        if (data.success) {
                            $$.layerToast(`${data.msg}`);
                        } else {
                            $$.layerToast(`${data.msg}`);
                        }
                    }
                });



            } else {
              // if (!$$.weChat.isWx()) return;
                //-- 右上角分享
                $$.showShareView();
            }
        });

    }

    //微信授权登录
    function checkShare() {
        let authorization = $$.getUrlParam("weChatAuthorization");
        if (!$WeChat.isWx()) {
            return;
        }
        if (authorization === "1") {
            let url = window.location.search;
            url = url.replace("1", '0');
            url = "activity/trainingCamp/rankingList.html" + url;
            console.log('----url', url);
            ShawHandler.request({
                url: UrlConfig.weChat_authorize,
                pars: {
                    authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                    returnUrl: url,
                    businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_7,
                    otherParams: JSON.stringify({"activeId": activeId, "type": 1})
                },
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    location.href = data.datas;
                }
            });
        }
    }
};
/**
 * 描述信息：加载信息
 * @author 覃创斌
 * @date 2020/4/21
*/
function loadUserInfo() {
    $$.request({
        url: UrlConfig.management_getCheckIsJoin,
        pars: {
            weChatOpenId: weChatOpenId,
            activeId:activeId
        },
        requestBody: true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                data.msg === "此用户还没参加训练营！"?$(".userData").hide():$(".userData").show();
                if (data.datas !== undefined){
                    $(".privateUserpic img").attr("src",data.datas.headimgurl);
                    $(".userName").html(data.datas.NAME);
                    name = data.datas.NAME;
                    $(".enroll").text("邀请好友打榜");
                    let ranking = data.datas.rownum;        // 当前排名
                    let html = `当前排名：<span>${ranking}</span>`;
                    $('.currentRanking').html(html);
                    $(".enroll").attr('data-state', "2");
                }else {
                    $(".privateUserpic img").attr("src",data.wx.headimgurl);
                    $(".userName").html(data.userJoinInfo.name);
                    name = data.userJoinInfo.name;
                    userJoinId = data.userJoinInfo.id;
                }

                //分享
                share();
            }else {
                if (data.msg === "查无此人"){
                    $(".userData").hide();
                }
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
/**
 * 描述信息：排行榜
 * @author 覃创斌
 * @date 2020/4/21
*/
function loadRanKingList(activeId) {
    $$.request({
        url: UrlConfig.management_getRanKingList,
        pars: {
            userActiId:activeId
        },
        requestBody: true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let kingHtml = '';
                $('.topThree_1').hide();
                $('.topThree_2').hide();
                $('.topThree_3').hide();
                for (let i = 0; i < data.datas.length; i++) {
                    if (data.datas.length === 2){
                        $('.topThree').css('padding-right', '33.3%');
                    }
                    if (i < 3){
                        //前三名
                        let className = '.topThree_'+(i+1).toString();
                        $(className).show();
                        $(className).attr("data-userActiId",data.datas[i].userActiId);
                        $(className).attr("data-userJoinId",data.datas[i].userJoinId);
                        $(className).children("img:nth-child(1)").attr("src",data.datas[i].headimgurl);
                        $(className).children("div.userInfo").children(".name").text(data.datas[i].NAME);
                        if (data.datas[i].sex === 2){
                            $(className).children("div.userInfo").children(".sex").addClass('userSex_woman');
                        }else if(data.datas[i].sex === 1) {
                            $(className).children("div.userInfo").children(".sex").addClass('userSex_man');

                        }
                        $(className).children("div.likeNumber").text(data.datas[i].count);
                        $(className).children("img:nth-child(1)").show();
                        $(className).children("img.like").show();

                    }else {
                        kingHtml += "<li data-userActiId='"+data.datas[i].userActiId+"'  data-userJoinId='"+data.datas[i].userJoinId+"'>";
                        kingHtml += "	<img src=\""+data.datas[i].headimgurl+"\">";
                        kingHtml += "	<div class=\"userInfo\">";
                        kingHtml += "		<span class=\"name\">"+data.datas[i].NAME+"</span>";
                        if (data.datas[i].sex === 2){
                            kingHtml += "		<span class=\"userSex_woman\"></span>";
                        }else if(data.datas[i].sex === 1) {
                            kingHtml += "		<span class=\"userSex_man\"></span>";
                        }

                        kingHtml += "	</div>";
                        kingHtml += "	<img class=\"like\" src=\"../../../images/activity/trainingCamp/rankingList-4.png\">";
                        kingHtml += "	<div class=\"likeNumber\">"+data.datas[i].count+"</div>";
                        kingHtml += "</li>";
                    }
                }
                $(".rankingList ul").html(kingHtml);
                $('.like').show();
                $(".count").html(data.datas.length);
                $(".topThree li").click(function () {
                    console.log(this);
                    giveLike(this);
                });

                $(".flex-wrap li").click(function () {
                    giveLike(this);
                });
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
//点赞
function giveLike(className) {
    let userActiId = $(className).attr("data-userActiId");
    let userJoinId = $(className).attr("data-userJoinId");
    $$.request({
        url: UrlConfig.management_insertActiHitDetail,
        pars: {
            weChatOpenId: weChatOpenId,
            activeId: userActiId,
            userJoinId:userJoinId
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                let likeNumber = parseInt($(className).children("div.likeNumber").text());
                $(className).children("div.likeNumber").text(likeNumber+1);
                $$.layerToast(`${data.msg}`);
            } else {
                $$.layerToast(`${data.msg}`);
            }
        }
    });
}

//-- 分享
function share() {
    let _lineLink = $$.getFullHost() + '/src/pages/activity/trainingCamp/rankingList.html';
    /* 是否带参 */
    _lineLink += $$.jsonToUrlParams({
        share:true,
        activeId:activeId
    });
    weChatJSTool.share({
        _imgUrl: $Constant.shareLogo,
        _lineLink: _lineLink,
        _shareTitle: '【小白保险】你的好友:'+name,
        _descContent: "你的好友正在参加训练营打榜活动，邀请你来助力打榜！",
        checkLogin: false,
        _sfn: function () {
            $$.layerToast("分享成功");
        }
    });
}
