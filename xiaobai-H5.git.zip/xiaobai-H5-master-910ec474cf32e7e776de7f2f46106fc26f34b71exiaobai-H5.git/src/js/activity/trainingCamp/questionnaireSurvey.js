/**
 * 小白训练营问卷调查 JS
 * @Author 吴成林
 * @Date 2020-4-13 15:45:02
 */
//-- 模拟数据
let list = [
    {
        id: 1,
        question: "1.您的性别",
        vals: "男,女"
    },
    {
        id: 2,
        question: "2.您的年龄",
        vals: "18-30,31-35,36-40,40以上"
    },
    {
        id: 3,
        question: "3.目前您职业的行业性质",
        vals: "保险业,旅游业,餐饮业,其他"
    },
    {
        id: 4,
        question: "4.保险代理人员可以分类为两类：（ ）和保险代理机构从业人员",
        vals: "保险营销员,保险代理人,保险公估人,保险经纪人"
    },
    {
        id: 5,
        question: "5.您对保险行业的了解",
        vals: "不了解,大概了解,知道一点,非常熟悉"
    },
]
let browseId;
let userJoinId;
let MTXB_Num;
window.onload = function () {
    $$.changeVersion();
    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader() {
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit() {
        browseId = $$.getUrlParam("browseId");
        userJoinId = $$.getUrlParam("userJoinId");
        MTXB_Num = $$.getUrlParam("MTXB_Num");
        dataLoading();
        loadSubject();
        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading() {
    }

    /**
     * 事件绑定
     */
    function eventBinding() {
        let count = 0;
        //-- 提交
        $('.submit').on("click", function () {
            let resultArr = new Array();
            for (let i = 0; i < 5; i++) {
                 let id = $("#topic_" + i).attr("data-id")
                let select = $("#topic_" + i + ">li").attr("data-select");
                resultArr.push({
                    id: id,
                    val: select
                });
                if (select == ""){
                    count++;
                }
            }
            console.log(resultArr)
            console.log(count)
            if (count > 0){
                $$.alert("你还有题目没有做完哦！");
                count = 0;
                return;
            }
            $$.request({
                url: UrlConfig.management_insertTestSubject,
                pars: {
                    resultArr:resultArr,
                    browseId:browseId
                },
                requestBody: true,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        $$.push('activity/trainingCamp/registrationSuccess',{
                            userJoinId:userJoinId,
                            browseId:browseId,
                            MTXB_Num:MTXB_Num,
                            prosperityKey: "true"    // 报名成功Key
                        });
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        });

    }

    /*加载所有题目*/
    function loadSubject() {
        $$.request({
            url: UrlConfig.management_getTestSubjectList,
            pars: {},
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    testQuestionList(data.datas)
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /* 调查问卷列表 */
    function testQuestionList(list) {
        let html = "";
        let display_none = "display_none";
        let display_block = "display_block";
        let content = [];
        for (let i = 0; i < list.length; i++) {
            content = list[i].vals.split(",");
            html += `
			<ul class="unit" id="topic_${i}" data-id="${list[i].id}">
				<li class="topic" data-select="">
					${list[i].question}
				</li>
				<li>
					<label class="checked_wrap">
						<input type="radio" name="questionSelect_${i + 1}" value="${content[0]}" />
						<span>${content[0]}</span>
					</label>
				</li>
				<li>
					<label>
						<input type="radio"  name="questionSelect_${i + 1}" value="${content[1]}" />
						<span>${content[1]}</span>
					</label>
				</li>
				<li class="${content.length >= 3 ? display_block : display_none}">
					<label>
						<input type="radio"   name="questionSelect_${i + 1}" value="${content[2]}" />
						<span>${content[2]}</span>
					</label>
				</li>
				<li class="${content.length >= 4 ? display_block : display_none}">
					<label>
						<input type="radio"  name="questionSelect_${i + 1}" value="${content[3]}" />
						<span>${content[3]}</span>
					</label>
					
					
				</li>
			</ul>`;
        }
        $(`.wrapper .content`).append(html);

        /* 单选按钮绑定checked 事件绑定 */
        $(":radio").on("click", function () {
            $(this).attr("checked", "checked");
            $(this).parents("li").siblings().find('input').removeAttr("checked");
            const value = $(this).attr("value");
            $(this).parents("li").siblings(".topic").attr("data-select", value);
        });
    }
}