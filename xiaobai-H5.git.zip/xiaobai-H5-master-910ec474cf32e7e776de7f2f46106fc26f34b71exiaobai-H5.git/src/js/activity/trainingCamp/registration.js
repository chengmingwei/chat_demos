/**
 * 小白训练营 - 立即报名 JS
 * @Author 吴成林
 * @Date
 */

//http://localhost:8666/xiaobai/src/pages/activity/trainingCamp/registration.html?activeId=10002&share=true
let activeId; //活动ID
let weChatOpenId;//已加密的
window.onload = function () {
    $$.changeVersion();
    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader() {
        checkShare();
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit() {
        activeId = $$.getUrlParam("activeId");
        weChatOpenId = $$.getUrlParam("weChatOpenId");
        if (activeId == null) {
            $$.alert("参数出现异常，请稍等操作！", function () {
                $$.push("index")
            })
        }
        dataLoading();
        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading() {

    }

    /**
     * 事件绑定
     */
    function eventBinding() {
        //-- 去登录查询
        $(".clickLogin").click(function () {
            $('.submitLogin').show();
            $('.submitRegistration').hide();
            $('.mobile').css('margin-top', '71px').show().siblings().hide();
        });

        //-- 去报名注册
        $(".clickRegistration").click(function () {
            $('.submitLogin').hide();
            $('.submitRegistration').show();
            $('.register ul .flex-start').show();
            $('.mobile').css('margin-top', '20px');
        });

        //获取验证码
        $(".codeBtn").click(function () {
            let name = $(".name").val().trim();
            let phone = $(".phone").val().trim();
            // let regName = /^[\u4e00-\u9fa5]{2,4}$/;
            let phoneReg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
            if (name.length > 6) {
                $$.alert("请正确输入您的姓名");
                return false;
            }
            if (!phoneReg.test(phone)) {
                $$.alert("请正确输入手机号码");
                return false;
            }
            $$.request({
                url: UrlConfig.msg_sendPhone,
                pars: {
                    phone: phone,
                    sendType: 4,
                    activeId:activeId
                },
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if(data.success){
                        resetTime($(".codeBtn"));
                        $$.layerToast("短信验证码已发送！");
                    }else{
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        });

        //-- 报名
        $(".submit").click(function () {
            let name = $(".name").val().trim();
            let phone = $(".phone").val().trim();
            let code = $(".code").val().trim();
            // let regName = /^[\u4e00-\u9fa5]{2,4}$/;
            let phoneReg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
            if (name.length > 6) {
                $$.alert("请正确输入您的姓名");
                return false;
            }
            if (!phoneReg.test(phone)) {
                $$.alert("请正确输入手机号码");
                return false;
            }
            if (code.length <= 5) {
                $$.alert("请正确输入验证码");
                return false;
            }
            $$.request({
                url: UrlConfig.management_insertSignUp,
                pars: {
                    userName: name,
                    phone: phone,
                    code: code,
                    activeId: activeId,
                    weChatOpenId: weChatOpenId
                },
                requestBody: true,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        const params = {
                            userJoinId:data.userJoinId,
                            browseId:data.browseId,
                            MTXB_Num:data.MTXB_Num
                        };
                        let path = 'registrationSuccess';
                        if (data.testMap === undefined){
                            path = 'questionnaireSurvey';
                        }
                        $$.push('activity/trainingCamp/' + path,params);

                    }else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        });

        //-- 登录查询
        $(".login").click(function () {
            let name = $(".name").val().trim();
            let phone = $(".phone").val().trim();
            let phoneReg = /(^1[3|4|5|7|8|9]\d{9}$)|(^09\d{8}$)/;
            if (name.length > 6) {
                $$.alert("请正确输入您的姓名");
                return false;
            }
            if (!phoneReg.test(phone)) {
                $$.alert("请正确输入手机号码");
                return false;
            }
            $$.request({
                url: UrlConfig.management_userjoininfo_login,
                pars: {
                    phone: phone,
                    activeId: activeId,
                    weChatOpenId: weChatOpenId
                },
                requestBody: true,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        const params = {
                            userJoinId: data.datas[0].id,
                            browseId: data.browseId,
                            MTXB_Num: data.datas[0].participateNum
                        };
                        let path;
                        data.testMap === undefined ? path='questionnaireSurvey' : path='registrationSuccess';
                        $$.push('activity/trainingCamp/' + path, params);
                    }else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        });

    }

    /**
     * 描述信息： 验证码倒计时
     * @author 覃创斌
     * @date 2020/4/16
     */
    function resetTime(e) {
        let second = 120;
        let timer = null;

        const timeFun = function () {
            second -= 1;
            if (second > 0) {
                $(e).attr("disabled", true).text(second + "s");
            } else {
                clearInterval(timer);

                $(e).attr("disabled", false).text("获取验证码");
            }
        };

        timeFun();
        timer = setInterval(function () {
            timeFun();
        }, 1000);
    }

};

//微信授权登录
function checkShare() {
    let share = $$.getUrlParam("share");
    activeId = $$.getUrlParam("activeId");
    if (!$WeChat.isWx()) {
        return;
    }
    if (share === 'true') {
        let url = window.location.search;
        url = url.replace("true", 'false');
        url = "activity/trainingCamp/registration.html" + url;
        console.log('----url', url);
        ShawHandler.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: url,
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_7,
                otherParams: JSON.stringify({"activeId": activeId, "type": 1})
            },
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                location.href = data.datas;
            }
        });
    }
}
