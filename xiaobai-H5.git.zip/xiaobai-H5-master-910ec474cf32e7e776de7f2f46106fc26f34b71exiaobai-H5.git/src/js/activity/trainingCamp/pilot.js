/**
 *  JS
 * @Author 吴成林
 * @Date
 */
let activeId;   //活动ID
let share;      //分享状态
window.onload = function() {
    $$.changeVersion();
    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        share = $$.getUrlParam("share");
        activeId = $$.getUrlParam("activeId");
        if (activeId == null) {
            $$.alert("参数出现异常，请稍等操作！", function () {
                $$.push("index")
            })
        }

        // 立即报名
        let length = $('.background').height();
        $('.button').css({"top":length*0.365+"px", "height":length*0.064+"px"});

        // 客服二维码
        let unopenedActivityBgLength = $('.unopenedActivity img').height();
        $('.customerService').css("height", unopenedActivityBgLength*0.095+"px");

        sharePage();     // 分享
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 立即报名
        $('.button').on('click', function () {
            $$.push('activity/trainingCamp/registration',{
                activeId: activeId,
                share: share,
            });
        });

        //-- 点击 客服二维码弹窗
        $('.customerService').on('click', function () {
            var index = layer.open({
                content:
                    `<div class="popupContent">
					<div class="question">
						<b>扫描下方二维码，添加小白专属客服</b>
						<img src="../../../images/my/serviceQrCode.png" />
						<span>长按识别二维码</span>
					</div>
				</div>`
            });
        });
    }

    /**
     * 分享
     */
    function sharePage() {
        if (!$WeChat.isWx()) {
            return;
        }
        let shareUrl = window.location.href;
        console.log(shareUrl);
        weChatJSTool.share({
            _imgUrl: $Constant.shareLogo,
            _lineLink: shareUrl,
            _shareTitle: '3分钟了解领航计划',
            _descContent: "帮助1000万人作出行业抉择",
            checkLogin: false,
            _sfn: function () {
                $$.layerToast("分享成功~");
            }
        });
    }
};
