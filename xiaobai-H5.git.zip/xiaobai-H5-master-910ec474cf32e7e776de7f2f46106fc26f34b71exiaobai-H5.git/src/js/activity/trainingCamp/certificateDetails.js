/**
 * 证书详情 JS
 * @Author 吴成林
 * @Date 2020-4-15 19:54:01
 */
let viewHeight = 0;             //浏览器高度
let activeId = 10002;           //活动ID
window.onload = function () {
    $$.changeVersion();
    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader() {
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit() {
        dataLoading();
        loadInfo();
        eventBinding();
        share()         //-- 分享
    }

    /**
     * 数据加载
     */
    function dataLoading() {
        activeId = $$.getUrlParam("activeId");
        viewHeight = window.innerHeight || document.documentElement.clientHeight;    //-- 浏览器高度
    }

    /**
     * 事件绑定
     */
    function eventBinding() {


        //-- 证书标题切换
        $('.certificateTitle>div').on('click', function () {
            $(this).addClass("selection").siblings().removeClass("selection");
            let href = $(this).attr("href");
            $(href).show().siblings().hide();
        });



        //-- 更多精彩 ~ 打榜
        $('.login').on('click', function () {
            $$.push("activity/trainingCamp/rankingList", {
                shareStatus: "false",
                weChatAuthorization: "1",
                activeId: activeId,
            });
        });

        $('.share').on('click', function () {
            $$.showShareView();
            console.log(window.location.href)

        });
    }
};

function loadInfo() {
    let userJoinId = $$.getUrlParam("userJoinId");
    if ($$.isValidObj(userJoinId)) {
        $$.request({
            url: UrlConfig.management_getByUserJoinIdInfo,
            pars: {
                userJoinId: userJoinId,
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $(".userName").html(data.userJoinInfo.name);
                    if (data.browseWXInfo.sex === 2) {
                        $("#sex").addClass("userSex_woman")
                    } else if (data.browseWXInfo.sex === 1) {
                        $("#sex").addClass("userSex_man")
                    }
                    let kechengHtml = "";
                    let kechengHtmlList = "";
                    for (let i = 0; i < data.userActiInfoList.length; i++) {
                        if (i < 2) {
                            if (data.userActiInfoList[i].isExcellent === 1){
                                kechengHtml += ` <li>
                                            <span>` + data.userActiInfoList[i].activeName + `</span>
                                            <img class="outstandingStudents" src="../../../images/activity/trainingCamp/certificateDetails-1.png">
                                        </li>`;
                            } else {
                                kechengHtml += `<li>
                                                    <span>` + data.userActiInfoList[i].activeName +`</span>
                                                </li>`;
                            }
                        }
                        if (data.userActiInfoList[i].isExcellent === 1){
                            kechengHtmlList += `<li>
                                                    <span>` + data.userActiInfoList[i].activeName +`</span>
                                                    <img class="outstandingStudents" src="../../../images/activity/trainingCamp/certificateDetails-1.png">
                                                </li>`;
                        }else {
                            kechengHtmlList += `<li>
                                                    <span>` + data.userActiInfoList[i].activeName +`</span>
                                                </li>`;
                        }


                    }

                    $(".coursesCompletedList").html(kechengHtml);
                    //-- 如果小白训练营期数列表大于2，显示2行，添加弹窗查看全部
                    let dataListLength = data.userActiInfoList.length;
                    if (dataListLength > 2) {
                        let html = `
                                    <div class="flex-start view">
                                        <span >查看全部</span>
                                        <img class="unfold" src="../../../images/topicPK/unfold.png">
                                    </div>`;
                        $('.coursesCompletedList').append(html);
                    }
                    $("#openList").html(kechengHtmlList);
                    //-- 查看全部
                    $('.view').on('click', function () {
                        let index = layer.open({
                            content: $("#openContent").html()
                        });
                        $('.popupContent').css('max-height', viewHeight * 0.9);
                        $('.popupList').css('max-height', viewHeight * 0.72);
                        $('.layui-m-layercont').css("padding", "20px");

                        $(".answer").on("click", function () {
                            layer.close(index);
                        });
                    });

                    let jieyeHtml = "";
                    let rongyuHtml = "";
                    for (let i = 0; i < data.userCertInfoList.length; i++) {
                        if (data.userCertInfoList[i].certType === 2){
                            jieyeHtml +=`<li>
                                            <img src="`+data.userCertInfoList[i].certUrl+`">
                                        </li>`;
                        }else if (data.userCertInfoList[i].certType === 3){
                            rongyuHtml +=`<li>
                                            <img src="`+data.userCertInfoList[i].certUrl+`">
                                        </li>`;
                        }
                    }
                    jieyeHtml.length > 0 ? $(".graduateList ul").html(jieyeHtml) : $('.graduateVacancy').show();
                    rongyuHtml.length > 0 ? $(".honorList ul").html(rongyuHtml) : $('.honorVacancy').show();

                    //-- 浏览图片
                    $('.certificateList img').on('click', function () {
                        let src = $(this).attr("src");
                        let index = layer.open({
                            content: `
					<div class="popupContent">
						<img src="${src}">
					</div>
				`
                        });
                        $('.layui-m-layercont').css("padding", "0px");
                        $('.popupContent').css('max-height', viewHeight * 0.9);
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    } else {
        $$.alert("页面出现数据错误,请稍后试试", function () {
            $$.push("newIndex");
        })
    }

}

function share() {
    if (!$WeChat.isWx()) {
        return;
    }
    weChatJSTool.share({
        _imgUrl:   $Constant.shareLogo,
        _lineLink:  window.location.href,
        _shareTitle: '【小白保险】我的训练营信息',
        _descContent: '我参加了全国独立保险经纪人领航计划，赶快来一起参加吧！',
        checkLogin: true,
        _sfn: function () {
            $$.layerToast("分享成功~");
        }
    });
}
