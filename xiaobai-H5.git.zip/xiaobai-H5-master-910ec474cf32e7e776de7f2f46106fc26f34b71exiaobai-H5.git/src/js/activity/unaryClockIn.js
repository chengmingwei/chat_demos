

/**
 * 一元早起打卡 JS
 * @Author 肖家添
 * @Date 2019/12/2 18:01
 */


window.onload = function () {
    $$.changeVersion();
    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 分享参数
        shareParams: {
            //-- 会员Id
            memberId: null,
            //-- 业务类型
            formType: null,
            //-- 业务Id
            formId: null,
            //-- 是否加载分享
            isLoadShare: false
        },
        //-- 参与活动所需的金额
        partakeMoney: 0.00,
        //-- 当前用户拥有的优惠券数量
        couponSize: 0,
        //-- 微信 openId
        weChatOpenId: null,
        //-- 客户端Ip
        clientIP: "127.0.0.1",
        //-- 倒计时组件
        countdownAssembly: null
    }

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader() {

        let weChatOpenId = $$.getUrlParam("weChatOpenId");
        PAGE_STATE.weChatOpenId = weChatOpenId;

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 初始化页面
        initPageState();

        //-- 绑定事件
        bindEvent();

        //-- 获取页面数据
        findPageData();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 抽奖规则
        $(".activityDescription").on("click", function () {
            openActivityRules();
        });

        //-- 立即参与
        $(".immediately").on("click", function () {
            const { partakeMoney, couponSize } = PAGE_STATE;
            layer.open({
                content: `
                    <div class="popupContent">
                        <div class="popupTitle">参与活动需支付费用</div>
                        <div class="unary">` + partakeMoney + `.00元</div>
                        <div>当前 <span class="deductionCount">` + couponSize + `</span> 张活动费用抵扣券可用，确认支付时会自动抵消费用</div>
                        <div class="answer">
                            <span class="affirm">立即支付</span>
                        </div>
                    </div>
                `
            });

            //-- 立即支付
            $(".affirm").off().click(function () {
                confirmPayment();
            });
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState() {
        const { weChatOpenId } = PAGE_STATE;

        //-- Clear HTML notes
        $$.clearHTMLNotes();

        //--  IP address of client, option one:
        try{
            PAGE_STATE.clientIP = returnCitySN["cip"]
        }catch (e) { }

        //-- 获取微信Id
        if(!$$.isValidObj(weChatOpenId)){
            getOpenId();
            $$.throw();
        }
    }

    //-- 加载页面数据
    function findPageData() {
        $$.request({
            url: UrlConfig.member_unaryClockInLoadPage,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    responseHandler(data.datas);
                } else {
                    $$.layerToast(data.msg);
                }
            }
        });

        //-- 查询页面数据 -> 响应处理
        function responseHandler(data) {
            let {
                //-- 奖金池Id
                bonusPoolId,
                //-- 奖金池金额
                bonusMoney,
                //-- 参与打卡所需金额
                partakeMoney,
                //-- 报名参与人数
                partakeNumber,
                //-- 活动开始时间
                startDate,
                //-- 活动截止时间
                endDate,
                statisticsUserDatums: {
                    //-- 累计奖励
                    cumulativeReward,
                    //-- 参与次数
                    participationTimes,
                    //-- 签到次数
                    checkInTimes,
                    //-- 邀请人数
                    inviteFriends
                },
                //-- 荣誉榜
                honorRoll,
                //-- 分享参数
                shareParams,
                //-- 是否中奖, [0: 未开奖, 1: 已中奖, 2: 未中奖, 3: 未报名, 4: 已报名未打卡]
                activityState,
                //-- 禁止参与活动标识, [true: 活动截止时间已过, false: 活动可参与]
                prohibitionParticipation,
                //-- 优惠券可用张数
                couponSize,
                //-- 系统时间
                systemDate,
                //-- 中奖的金额
                partitionAmount
            } = data;

            (function(){
                PAGE_STATE.shareParams = shareParams;
                PAGE_STATE.partakeMoney = partakeMoney;
                PAGE_STATE.couponSize = couponSize;
            })();

            //-- 页面设置
            (function(){
                $(".moneySum").text(parseFloat($$.changeIsNilVal(bonusMoney, 0).toString()).toFixed(2));
                $(".headcount span:first-child").text(partakeNumber);
                $(".accumulative span").text(parseFloat($$.changeIsNilVal(cumulativeReward, 0).toString()).toFixed(2));
                $(".participateCount span").text(participationTimes);
                $(".signInCount span").text(checkInTimes);
                $(".inviteFriends span").text(inviteFriends);
            })();

            //-- 荣誉榜
            (function(){
                if(!$$.isValidObj(honorRoll) || !honorRoll){
                    return;
                }
                $(".history").show();
                let honor = "";
                const html = honorRoll.map(item => {
                    const { userImg, userName, honorType } = item;
                    switch (honorType) {
                        case 1:{
                            honor = "手气最好";
                            break;
                        }
                        case 2:{
                            honor = "起床最早";
                            break;
                        }
                        case 3:{
                            honor = "毅力最强";
                            break;
                        }
                    }
                    return `<li><div><img src="${$$.changeIsNilVal(userImg, $Constant.memberDefaultImagePath)}"><div>${userName}</div></div><div>${honor}</div></li>`;
                });
                $(".history ul").html(html.join(""));
            })();

            //-- 活动状态设置
            (function(){
                const signInCountDownEle = $(".signInCountDown"),
                    immediatelyEle = $(".immediately");

                prohibitionParticipation = false;
                activityState = 4;

                if(prohibitionParticipation){
                    //-- 活动时间失效
                    immediatelyEle.unbind("click");
                    signInCountDownEle.hide();
                    switch (activityState) {
                        case 0:{
                            immediatelyEle.html("打卡成功, 等待开奖");
                            break;
                        }
                        case 1:{
                            immediatelyEle.html("已中奖");


                            break;
                        }
                        case 2:{
                            immediatelyEle.html("未中奖").addClass("gray");
                            break;
                        }
                        case 3:{
                            immediatelyEle.html("未报名").addClass("gray");
                            break;
                        }
                        case 4:{
                            immediatelyEle.html("报名成功, 等待打卡").addClass("gray");
                            break;
                        }
                    }
                }else{
                    switch (activityState) {
                        case 3:{
                            immediatelyEle.html("立即参与");
                            activityCountdown(systemDate, endDate);
                            signInCountDownEle.show();
                            break;
                        }
                        case 4:{
                            immediatelyEle.html("报名成功, 等待打卡").unbind("click").addClass("gray");
                            break;
                        }
                    }
                }
            })();

            wxShare();
        }
    }

    //-- 微信分享
    function wxShare() {
        const { shareParams: { memberId, formType, formId, isLoadShare } } = PAGE_STATE;
        if(isLoadShare || !$WeChat.isWx()) return;
        let _lineLink = window.location.href.split("/activity/unaryClockIn.html?")[0] + "/login/register.html";
        _lineLink += $$.jsonToUrlParams({
            parentMemberId: memberId,
            formType: formType,
            formId: formId,
        });
        const imgUrl = "https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com/app/appHomePic/2019/11/36b77c81805f46739cdeffff7859cf34.png";
        weChatJSTool.share({
            _imgUrl: imgUrl,
            _lineLink: _lineLink,
            _shareTitle: `你敢接受我的跳转码？`,
            _descContent: `一元早起大乱斗,我在这儿等你一起瓜分奖金池`,
            _sfn: function () {
                $$.request({
                    url: UrlConfig.member_insertForwarding,
                    pars: {
                        formType: formType,
                        formId: formId,
                    },
                    sfn: function (data) {
                        if (data.success) {
                            $$.layerToast("分享成功~");
                        }
                    }
                });
            }
        });
        PAGE_STATE.shareParams.isLoadShare = true;
    }

    //-- 活动参与倒计时
    function activityCountdown(startDate, endDate) {
        try{
            const { countdownAssembly } = PAGE_STATE;
            if($$.isValidObj(countdownAssembly)){
                clearInterval(countdownAssembly);
            }
        }catch (e) { }

        let differ = date_minus(startDate, endDate);
        PAGE_STATE.countdownAssembly = window.setInterval(function () {
            loop();
        }, 1000);
        loop();
        function loop(){
            let day = 0,
                hour = 0,
                minute = 0,
                second = 0;//时间默认值
            if (differ > 0) {
                day = Math.floor(differ / (60 * 60 * 24));
                hour = Math.floor(differ / (60 * 60)) - (day * 24);
                minute = Math.floor(differ / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(differ) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }
            if (hour <= 9) hour = '0' + hour;
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            $('.countDown:eq(0)').html(day);
            $('.countDown:eq(1)').html(hour);
            $('.countDown:eq(2)').html(minute);
            $('.countDown:eq(3)').html(second);
            differ--;
        }

        //-- 日期相减
        function date_minus(date_str1, date_str2) {
            const date1 = new Date(date_str1),
                date2 = new Date(date_str2);
            return parseInt((date2 - date1) / 1000);
        }
    }

    //-- 打开活动规则
    function openActivityRules(){
        let index = layer.open({
            content: `
                <div class="popupContent">
                    <div class="font-weight popupTitle">活动规则</div>
                    <ul>
                        <li>
                            <span>1）</span>
                            <span>活动为小白保险app用户专享用，支付1元参与挑战；</span>
                        </li>
                        <li>
                            <span>2）</span>
                            <span>打卡时间为早五点至早八点；</span>
                        </li>
                        <li>
                            <span>3）</span>
                            <span>按时打卡后可随机瓜分当日全部金额；</span>
                        </li>
                        <li>
                            <span>4）</span>
                            <span>点击邀请，分享给好友或分享朋友圈，如用户通过分享链接成功报名（先注册）参与早起打卡大挑战，奖励1元活动现金抵扣券；</span>
                        </li>
                        <li>
                            <span>5）</span>
                            <span>邀请好友需为有效用户且人数不做上限，用户可获得邀请前20名的奖励；</span>
                        </li>
                        <li>
                            <span>6）</span>
                            <span>邀请排行榜实时更新；</span>
                        </li>
                        <li>
                            <span>7）</span>
                            <span>平台拒绝采取任何手段恶意获取奖励，一经发现，有权收回奖励。必要时追溯法律责任；</span>
                        </li>
                    </ul>
                    <div class="answer">
                        <span class="affirm">我知道了</span>
                    </div>
                </div>
            `,
            // style: "overflow:auto;"
        });

        $(".answer").off().on("click", function () {
            layer.close(index);
        });
    }

    //-- 确认支付
    function confirmPayment(){
        const { clientIP, weChatOpenId } = PAGE_STATE,
                params = { clientIP, openId: weChatOpenId };
        $$.request({
            url: UrlConfig.member_participateClock,
            loading: true,
            pars: params,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                const { success, msg } = data;
                if (success) {
                    responseHandler(data.datas);
                }else{
                    $$.alert(msg);
                }
            }
        });

        //-- 确认支付 -> 响应处理
        function responseHandler(data){
            const { isUserCoupon, wxPaymentDatums } = data;

            if(isUserCoupon){
                //-- 使用优惠券
                $$.alert("参与成功！", function(){
                    findPageData();
                });
                return;
            }

            if($WeChat.isWx()){
                $WeChat.pay.publicAddressPayment(wxPaymentDatums);
            }else{
                $$.alert("请在微信中打开！");
            }
        }
    }

    //-- 获取OpenId
    function getOpenId(){
        if(!$WeChat.isWx()){
            $$.alert("请从微信中打开！", function(){
                $$.push("newIndex");
            });
            return;
        }
        ShawHandler.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10001,
                returnUrl: "activity/unaryClockIn.html",
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_1
            },
            loading: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){
                    location.href = data.datas;
                }else $$.alert(data.msg);
            }
        });
    }
}
