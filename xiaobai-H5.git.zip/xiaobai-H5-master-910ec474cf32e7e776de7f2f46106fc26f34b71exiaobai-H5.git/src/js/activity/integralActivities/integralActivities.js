/**
 * 积分大比拼 - 活动 JS
 * @Author 吴成林
 * @Date 2020-3-10 16:29:03
 */
let Login= false;
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        loadAttendSum();
        loadCurrentByMemberId();
        loadRankingList();
        $(".date").html(getFormatDate());

        let viewWidth = window.innerWidth||document.documentElement.clientWidth;
        let viewHeight = window.innerHeight||document.documentElement.clientHeight;
        if (viewHeight < 569){
            $(".unitTop").css("height", "130%");
        } else if (viewWidth < 321){
            $(".unitTop").css("height", "135%");
        }
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //积分商城
        $(".integral-buy").click(() => {
            if (Login){
                $$.request({
                    url: UrlConfig.checkIn_mailejifen_login,
                    loading: true,
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success) {
                            window.location.href = data.url;
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            }else {
                $$.alert("您还没有登录，请登录后操作",function () {
                    $$.gotoLogin();
                })
            }

        });
        //立即参加
        $(".immediatelyAttend>div").click(()=>{
            $$.alert("您还没有登录，请登录后操作",function () {
                $$.gotoLogin();
            })
        })
        //-- 签到
        $(".registration").click(() => {
            if (Login){
                if(PAGE_APP){
                    $$.pushAPP("/sign/signIn");
                    return;
                }
                $$.push("signin/signin");
            }else {
                $$.alert("您还没有登录，请登录后操作",function () {
                    $$.gotoLogin();
                })
            }
        });

        //-- 新人红包
        $(".activities").click(() => {
            if (Login){
                if(PAGE_APP){
                    $$.pushAPP("/activity/newGiftBag");
                    return;
                }
                $$.push("my/newGiftBag");
            }else {
                $$.alert("您还没有登录，请登录后操作",function () {
                    $$.gotoLogin();
                })
            }
        });
        //分享
        $(".share").click(()=>{
            shareData();
        })

    }
    //加载参加人数总和
    function loadAttendSum() {
        $$.request({
            url: UrlConfig.integralRecords_getAttendSum,
            pars:{

            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (data.datas.count != undefined){
                       $(".attendSum").html(1800+data.datas.count);
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //当前登录用户积分和排名
    function loadCurrentByMemberId() {
        $$.request({
            url: UrlConfig.integralRecords_getCurrentByMemberId,
            pars:{
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (data.msg =="ok"){
                        if (data.datas != undefined){
                            $(".score").html(data.datas.score);
                            $(".rownum").html(data.datas.rownum);
                        }
                        Login = true;
                        $(".immediatelyAttend").hide()
                        $(".myStandingsContent").show()
                        $(".score").click(()=>{
                            $$.push("signin/integralList");
                        })
                    }else {
                        $(".score").html(0);
                        $(".rownum").html("无");
                        Login = false;
                        $(".immediatelyAttend").show()
                        $(".myStandingsContent").hide()
                    }

                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    //排名
    function loadRankingList() {
        $$.request({
            url: UrlConfig.integralRecords_getRankingList,
            pars:{

            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let resultHtml = "";
                    if (data.datas !=undefined){
                        for (let i = 0; i <data.datas.length ; i++) {
                            resultHtml += "<li>";
                            resultHtml += "	<span>No."+(i+1)+"</span>";
                            resultHtml += "	<span><img src=\""+returnUrl(i,data)+"\"></span>";
                            resultHtml += "	<span class='overflow'>"+returnName(i,data) +"</span>";
                            resultHtml += "	<span>"+data.datas[i].score+"分</span>";
                            resultHtml += "</li>";
                        }
                        $(".unitRankingList").html(resultHtml);
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
    function returnUrl(i,data) {
        return data.datas[i].imgpath == undefined ? "../../../images/my/mituLogo.png": data.datas[i].imgpath;
    }
    function returnName(i,data) {
        return data.datas[i].rname == undefined ? data.datas[i].account : data.datas[i].rname;
    }
    function getFormatDate() {
        let date = new Date();
        let month = date.getMonth() + 1;
        let strDate = date.getDate();
        let Minutes = date.getMinutes();
        if (month >= 1 && month <= 9) {
            month = "0" + month;
        }
        if (strDate >= 0 && strDate <= 9) {
            strDate = "0" + strDate;
        }
        if (Minutes >= 0 && Minutes <= 9) {
            Minutes = "0" + Minutes;
        }
        let currentDate = date.getFullYear() + "年" + month + "月" + strDate
            + "日 " + date.getHours() + ":" + Minutes;
        return currentDate;
    }
    /**
     * 分享
     */
    function shareData() {
        let _lineLink = $$.getFullHost() + '/src/pages/activity/integralActivities/integralActivities.html';
        /* 是否带参 */
        _lineLink += $$.jsonToUrlParams({
        });
        const shareParams = {
            _imgUrl:  $Constant.shareLogo,
            _lineLink:  _lineLink,
            _shareTitle: '打卡狂欢，福利大放送',
            _descContent: '小白保险4.0火热上线，新版积分大比拼，坚持有豪礼，速来！',
            checkLogin: true,
            _sfn: function () {
                $$.layerToast("分享成功~");
            }
        };
        if(PAGE_APP){
            InsuranceAPP.postMessage(JSON.stringify({
                formType: 10002,
                datas: {
                    bussType: 10002,
                    url: shareParams._lineLink,
                    title: shareParams._shareTitle,
                    content: shareParams._descContent
                }
            }));
            return;
        }
        if (!$WeChat.isWx()) {
            return;
        }
        $$.showShareView('点击右上角,分享给好友！');
        weChatJSTool.share(shareParams);
    }
}