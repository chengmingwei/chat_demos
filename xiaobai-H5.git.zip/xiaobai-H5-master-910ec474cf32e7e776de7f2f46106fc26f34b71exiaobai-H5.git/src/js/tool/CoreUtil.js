var EvtMgr = {
	/**
	 * 绑定单击跳转页面事件到UL -> LI 上
	 * @param {Object} clsName	UL 对象的 class名
	 */
	bindToLi : function (clsName, fn){
 		$("ul."+clsName).on("click","li",function(){      //只需要找到你点击的是哪个ul里面的就行
   		var ele = $(this);
   		var url = ele.attr("url");
   		if(url){
   			window.location.href = url+"?t="+(new Date().getTime());
   		}else{
   			if(fn) fn(ele);	
   		}
 	});
 	},
 	/**
	 * 绑定单击跳转页面事件到元素对象上
	 * EvtMgr.bindClick('cls-order',function(){});
	 * @param {Object} clsName	 对象的 class名或ID
	 */
	bindClick : function (clsName,fn){
		var eleObj = (clsName.indexOf(".") != -1) ? $(clsName) : $("#"+clsName);
//		if(!eleObj) eleObj = $("."+clsName);
 		eleObj.on("click",function(){      //只需要找到你点击的是哪个ul里面的就行
   		var ele = $(this);
   		var url = ele.attr("url");
   		if(url){
   			window.location.href = url;
   		}else{
   			if(fn) fn(ele);	
   		}
 	});
 	}
};
