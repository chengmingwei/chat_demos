
/**
 * 请求地址配置
 * @Author 肖家添
 * @Date 2019/8/28 18:44
 */
const UrlConfig = {
    /**
     * 会员登录
     */
    member_login: UrlConfigFormat("/auth/member/accredit"),

    /**
     * 会员退出登录
     */
    member_loginOut: UrlConfigFormat("/member/member/memberLoginOut"),
    /**
     * 发送短信验证码
     */
    msg_sendPhoneCode: UrlConfigFormat("/msg/msg/memberPhoneCode"),
    /**
     * 校验短信验证码是否有效
     */
    msg_validSmdCodeCanUse: UrlConfigFormat("/member/member/validPhoneCode"),
    /**
     * 找回密码
     */
    member_forgetPassword: UrlConfigFormat("/member/member/forgetPassword"),
    /**
     * 会员注册
     */
    member_register: UrlConfigFormat("/member/member/registerMember"),
    /**
     * 会员详情页面
     */
    member_Detailspage: UrlConfigFormat("/member/member/detailsPageMember"),

    /**
     * 检查是否通过验证
     * */
    member_checkVerification:UrlConfigFormat("/member/member/checkUserStatus"),

    /**
     * 修改用户名
     * */
    member_modifierUserName:UrlConfigFormat("/member/member/modifierUserName"),

    /**
     *地区（省市级联动）修改
     * */
    member_modifierDistrict:UrlConfigFormat("/member/member/modifierDistrict"),
    /**
     * 首页数据
     */
    mobile_homeData: UrlConfigFormat("/management/mobileHome/getHomeData"),

    /**
     * 首页热门
     */
    mobile_hotTopic: UrlConfigFormat("/management/featureactivity/getHotSubject"),

    /**
     * 险种分类
     */
    insuranceType_data: UrlConfigFormat("/management/insuranceType/list"),
    /**
     * 保险产品库
     */
    insuranceInfo_data: UrlConfigFormat("/management/mobileInsuranceInfo/getInsuranceList"),
    /**
     * 收藏列表->产品库
     *
     */
    collect_insuranceInfo_data: UrlConfigFormat("/management/mobileInsuranceInfo/getCollectList"),

    /**
     * 保险产品库详情
     */
    insuranceInfo_detail: UrlConfigFormat("/management/mobileInsuranceInfo/getInsuranceDetail"),
    /**
     * 产品保障项目
     */
    insuranceEnsure_data: UrlConfigFormat("/management/mobileInsureEnsure/getInsuranceEnsureByPlanId"),
    /**
     * 产品保险条款
     */
    insuranceClause_data: UrlConfigFormat("/management/mobileInsuranceClause/getInsuranceClause"),
    /**
     * 会员意见反馈
     */
    feedback_data: UrlConfigFormat("/management/feedback/insert"),
    /**
     * 寻医问药-问诊公众号页面
     */
    xywy_wx_ask: UrlConfigFormat("/management/xywy/wx/ask"),
    /**
     * 寻医问药-订单公众号页面
     */
    xywy_wx_order: UrlConfigFormat("/management/xywy/wx/orderInfo"),
    /**
     * 描述信息：分类列表
     * @author 覃创斌
     * @date 2019-09-10
     */
    classify_list:UrlConfigFormat("/member/classify/getWebListByName"),
    /**
     * 描述信息：专题
     * @author 覃创斌
     * @date 2019-09-10
     */
    getByClassifyIdList:UrlConfigFormat("/member/subject/getByClassifyIdList"),
    /**
     * 产品详情 -> 立即投保所需的数据
     */
    insuranceInfo_detail_immediatelyData: UrlConfigFormat("/management/mobileInsuranceInfo/getInsuranceNeedData"),

    /**
     * 描述信息：根据分类ID去查找文章和视频
     * @author 覃创斌
     * @date 2019-09-10
     */
    getWebInformaList:UrlConfigFormat("/member/article/getWebInformaList"),
    /**
     * 描述信息：根据ID获取专题
     * @author 覃创斌
     * @date 2019-09-10
     */
    getSubject:UrlConfigFormat("/member/subject/getSubject"),
    /**
     * 描述信息：前台--- 根据专题ID去查找
     * @author 覃创斌
     * @date 2019-09-10
     */
    getBySubjectIdArticle:UrlConfigFormat("/member/article/getBySubjectIdArticle"),
    /**
     * 描述信息：获取所有专题
     * @author 覃创斌
     * @date 2019-09-10
     */
    getSubjectAll:UrlConfigFormat("/member/subject/getSubjectAll"),

    /**
     * 描述信息：获取所有专题
     * @author 覃创斌
     * @date 2019-09-10
     */
    getLabelList:UrlConfigFormat("/member/label/getLabelList"),
    /**
     * 产品详情 -> 职业数据源
     */
    vocationInfo_data: UrlConfigFormat("/management/mobileVocationInfo/findOccupation"),
    /**
     * 收藏记录 -> 保存/删除
     */
    userFavInfo_handler: UrlConfigFormat("/member/userFavInfo/handlerFav"),
    /**
     * 收藏记录 -> 检查是否存在记录
     */
    userFavInfo_checkHasRecord: UrlConfigFormat("/member/userFavInfo/checkHasRecord"),
    /**
     * 签到 -> 页面数据源
     */
    checkIn_dailyTask_data: UrlConfigFormat("/management/checkIn/list"),
    /*
    * 签到 -> 签到
    */
    checkIn_submit: UrlConfigFormat("/management/checkIn/submit"),
    /**
     * 签到 -> 补签
     */
    checkIn_resign: UrlConfigFormat("/management/checkIn/resign"),
    /**
     * 签到 -> 早起打卡数据
     */
    checkIn_morning: UrlConfigFormat("/management/checkIn/morning"),
    /**
     * 签到 -> 积分明细
     */
    checkIn_integralRecords_listPage: UrlConfigFormat("/management/checkIn/integralRecords/listPage"),
    /**
     * 签到 -> 积分商城 -> 登录
     */
    checkIn_mailejifen_login: UrlConfigFormat("/management/maile/login"),
    /**
     * 签到 -> 积分商城兑换记录
     */
    checkIn_order_listPage: UrlConfigFormat("/management/order/listPage"),
    /**
     * 投保详情 -> 立即投保
     */
    insuranceInfo_detail_immediateInsurance: UrlConfigFormat("/management/mobileInsuranceInfo/immediateInsurance"),
    /**
     * 投保产品健康告知 -> 数据源
     */
    insuranceInfoHealthTold_data: UrlConfigFormat("/management/insuranceInfoHealthTold/list"),
    /**
     * 产品 -> 订单处理
     */
    insuranceInfo_orderHandler: UrlConfigFormat("/management/mobileInsuranceInfo/orderHandler"),
    /**
     * 产品 -> 加载投保资料
     */
    insuranceInfo_loadInsuranceInformation: UrlConfigFormat("/management/mobileInsuranceInfo/loadInsuranceInformation"),
    /**
     * 特殊处理 -> 平安燃气险按beShareToken查询有记录才继续
     */
    insuranceInfo_loadThirdPartyParam: UrlConfigFormat("/management/mobileInsuranceInfo/loadThirdPartyParam"),
    /**
     * 描述信息：根据标签ID获取内容
     * @author 覃创斌
     * @date 2019-09-10
     */
    getWebWenDaList:UrlConfigFormat("/member/label/getWebWenDaList"),
    /**
     * 描述信息：根据文章ID去查找
     * @author 覃创斌
     * @date 2019-09-10
     */
    getByArticleId:UrlConfigFormat("/member/article/getByArticleId"),
    /**
     * 描述信息：根据文章ID去查找评论
     * @author 覃创斌
     * @date 2019-09-10
     */
    getListByEvaluation:UrlConfigFormat("/member/evaluation/getListByEvaluation"),


    getListByHeatOrTime:UrlConfigFormat("/member/evaluation/getListByHeatOrTime"),
    /**
     * 描述信息：根据文章ID去查找评论
     * @author 覃创斌
     * @date 2019-09-10
     */
    insertEvaluation:UrlConfigFormat("/member/evaluation/insert"),

    /**
     * 描述信息：收藏
     * @author 覃创斌
     * @date 2019-09-10
     */
    insertCollectstatistic:UrlConfigFormat("/member/collectstatistic/insert"),
    /**
     * 描述信息：收藏记录
     * @author 覃创斌
     * @date 2019-09-10
     */
    getCountCollectstatistic:UrlConfigFormat("/member/collectstatistic/getCount"),
    /**
     * 描述信息：根据ID获取视频信息
     * @author 覃创斌
     * @date 2019-09-10
     */
    Video_data:UrlConfigFormat("/member/video/getByVideoId"),
    query_province:UrlConfigFormat("/sysbase/province/getChinaArea"),
    query_city:UrlConfigFormat("/sysbase/city/list"),
    /**
     * 描述信息：查询资金账户表
     * @author 覃创斌
     * @date 2019-09-23
    */
    accountinfo_data:UrlConfigFormat("/member/accountinfo/getByMemberId"),
    /**
     * 描述信息：统计可用提现次数
     * @author 覃创斌
     * @date 2019-09-23
     */
    withdraw_count :UrlConfigFormat("/member/withdraw/getCountWithdraw"),
    /**
     * 描述信息：根据用户ID查询银行卡
     * @author 覃创斌
     * @date 2019-09-23
     */
    bankcard_data :UrlConfigFormat("/member/bankcard/getBankCardByCondiList"),
    /**
     * 描述信息：计算税费
     * @author 覃创斌
     * @date 2019-09-23
     */
    accountinfo_Calculate :UrlConfigFormat("/member/accountinfo/getCalculateTax"),
    /**
     * 描述信息：提现申请
     * @author 覃创斌
     * @date 2019-09-24
    */
    withdraw_Apply:UrlConfigFormat("/member/withdraw/submitWithdrawApply"),
    /**
     * 投保资料 -> 订单提交
     */
    insuranceInfo_submitOrderHandler: UrlConfigFormat("/management/mobileInsuranceInfo/submitOrderHandler"),
    /**
     * 订单详情
     */
    insuranceInfo_loadOrderDetail: UrlConfigFormat("/management/mobileInsuranceInfo/loadOrderDetail"),
    /**
     * 订单支付前数据校验
     */
    insuranceInfo_orderPaymentBefore: UrlConfigFormat("/management/mobileInsuranceInfo/orderPaymentBefore"),
    /**
     * 描述信息：根据会员id查询团员信息
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_teammember_getTeamMember:UrlConfigFormat('/market/teammember/getTeamMember'),
    /**
     * 描述信息：根据会员id查询团员信息（登录用）
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_teammember_getTeamMemberByLogin:UrlConfigFormat('/market/teammember/getTeamMemberByLogin'),
    /**
     * 描述信息：根据会员id查询订单
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_teammember_checkOrder:UrlConfigFormat('/market/teammember/checkOrder'),
    /**
     * 描述信息：上传图片
     * @author 孔伟杰
     * @date 2019-09-29
     */
    upload_attachment_upload:UrlConfigFormat('/upload/attachment/upload'),
    /**
     * 描述信息：创建/编辑团队
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_team_wx_save:UrlConfigFormat('/market/team/wx/save'),
    /**
     * 描述信息：团队列表
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_team_wx_teamListOfNotFullMember:UrlConfigFormat('/market/team/wx/teamListOfNotFullMember'),
    /**
     * 描述信息：加入团队
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_teammember_joinTeam:UrlConfigFormat('/market/teammember/wx/joinTeam'),
    /**
     * 描述信息：获取申请剩余时间
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_teammember_wx_applyLittleTime:UrlConfigFormat('/market/teammember/wx/applyLittleTime'),
    /**
     * 描述信息：取消申请
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_teammember_wx_cancelApply:UrlConfigFormat('/market/teammember/wx/cancelApply'),
    /**
     * 描述信息：保险测评问题展示
     * @author wujiahong
     * @date
     */
    market_insuranceTest_questionShow:UrlConfigFormat('/market/testsubject/wx/questionList'),
    /**
     * 描述信息：验证是否已经测评状态
     * @author wujiahong
     * @date
     */
    market_insuranceTest_checkStatus:UrlConfigFormat('/market/testresult/wx/checkStatus'),
    /**
     * 描述信息：保险问题保存
     * @author wujiahong
     * @date
     */
    market_insuranceTest_saveResult:UrlConfigFormat('/market/subjectresult/wx/saveResult'),

    /**
     * 描述信息：显示团队
     * @author 孔伟杰
     * @date 2019-10-10
     */
    market_team_wx_show:UrlConfigFormat('/market/team/wx/show'),
    /**
     * 绑定银行卡
     */
    bankCard_insert: UrlConfigFormat("/member/bankcard/insertBankCard"),
    /**
     * 绑定银行卡
     */
    bankCard_getBankName: UrlConfigFormat("/member/bankcard/getBankCardName"),
    /**
     * 获取课堂banner
     */
    AppHomePic_getPicList: UrlConfigFormat("/management/appHomePic/getAppHomePicList"),
    /**
     * 获取课堂分类标签
     * */
    course_getClassClassification:UrlConfigFormat("/member/label/getLabelList"),

    /**
     * 获取课堂TOP3
     */
    course_getCourseList: UrlConfigFormat("/member/course/getCourseManageList"),

    /**
     * 防止影视频无数据
     */
    course_getKnowClassList: UrlConfigFormat("/member/course/getKnowClassList"),

    /**
     *Banner
     */
    course_getCourseBannerList: UrlConfigFormat("/member/course/getCourseBannerList"),
    /**
     *根据ID获取
     */
    courseItem_getByCourseId: UrlConfigFormat("/member/courseitem/getByCourseId"),
    /**
     *根据courseItemID获取
     */
    courseItem_getByCourseItemId: UrlConfigFormat("/member/courseitem/getByCourseItemId"),
    /**
     *
     */
    courseItem_prevCourseItem: UrlConfigFormat("/member/courseitem/prevCourseItem"),
    /**
     *点赞功能
     */
    praisestatistic_save: UrlConfigFormat("/member/praisestatistic/insert"),
    /**
     * 描述信息：免费学习
     * @author 覃创斌
     * @date 2019/10/11
     */
    order_insertOrder : UrlConfigFormat("/member/order/insertOrder"),

    /**
     * 根据用户查下问题信息
     * @author 覃创斌
     * @date 2019/10/11
     */
    question_getQuestionByMemberId : UrlConfigFormat("/member/question/getQuestionByMemberId"),
    /**
     * 根据用户查询问题信息
     * @author 覃创斌
     * @date 2019/10/11
     */
    answer_getAnswerByMemberId : UrlConfigFormat("/member/answer/getAnswerByMemberId"),
    /**
     * 查下已经购买的课程
     * @author 覃创斌
     * @date 2019/10/11
     */
    course_getOrderByCourseList : UrlConfigFormat("/member/course/getOrderByCourseList"),
    /**
     * 查下收藏
     * @author 覃创斌
     * @date 2019/10/11
     */
    course_getMyCollectByCourseList : UrlConfigFormat("/member/course/getMyCollectByCourseList"),
    /**
     * 描述信息：
     * @author 覃创斌
     * @date 2019/10/12
    */
    order_insertOrder: UrlConfigFormat("/member/order/insertOrder"),
    /**
     * 描述信息：获取消息列表
     * @author 孔伟杰
     * @date 2019-10-10
     */
    market_teammember_wx_getMsgList:UrlConfigFormat('/market/teammember/wx/getMsgList'),
    /**
     * 添加浏览量
     * @author 覃创斌
     * @date 2019/10/11
     */
    viewStatistic_insertViewStatistic : UrlConfigFormat("/member/viewstatistic/insertViewStatistic"),
    /**
     * 查询浏览量
     * @author 覃创斌
     * @date 2019/10/11
     */
    course_getViewStatisticByCourseList : UrlConfigFormat("/member/course/getViewStatisticByCourseList"),
    /**
     * 查询浏览量
     * @author 覃创斌
     * @date 2019/10/11
     */
    course_getMyCollectByArticleList : UrlConfigFormat("/member/course/getMyCollectByArticleList"),
    /**
     * 消息中心
     * @author 覃创斌
     * @date 2019/10/11
     */
    course_getMessageCenterList : UrlConfigFormat("/member/course/getMessageCenterList"),
    /**
     * 描述信息：获取学历列表
     * @author 吴成林
     * @date 2019-10-13
     */
    sysbase_gvlist_restype:UrlConfigFormat('/sysbase/gvlist/restype/100006'),
    /**
     * 描述信息：更新会员基本信息(真实姓名、性别、身份证、手机号)
     * @author 吴成林
     * @date 2019-10-14
     */
    member_member_modifierRealName:UrlConfigFormat('/member/member/modifierRealName'),
    /**
     * 描述信息：更新会员详细信息
     * @author 吴成林
     * @date 2019-10-14
     */
    member_memberdetail_modifierDetailedAddress:UrlConfigFormat('/member/memberdetail/modifierDetailedAddress'),
    /**
     * 投保订单 -> 订单支付  ``POST [orderToken, paymentWay]
     */
    mobileOrderInfoLog_orderPayment: UrlConfigFormat("/management/mobileOrderInfoLog/orderPayment"),
    /**
     * 投保订单 -> 用户订单列表  ``POST [orderStatus]
     */
    mobileOrderInfoLog_getOrderByUser: UrlConfigFormat("/management/mobileOrderInfoLog/getOrderByUser"),
    /**
     * 描述信息：入团申请处理
     * @author 孔伟杰
     * @date 2019-10-10
     */
    market_teammember_wx_applySentence:UrlConfigFormat('/market/teammember/wx/applySentence'),
    /**
     * 投保订单 -> 用户保单列表  ``POST [isInsuredStatus, insuranceIsGroup]
     */
    mobileOrderInfoLog_getInsurancePolicy: UrlConfigFormat("/management/mobileOrderInfoLog/getInsurancePolicy"),
    /**
     * 描述信息：获取经纪人等级
     * @author 孔伟杰
     * @date 2019-10-17
     */
    market_growthrule_wx_getBrokerLevelData: UrlConfigFormat("/market/growthrule/wx/getBrokerLevelData"),
    /**
     * 描述信息：获取经纪人等级（登录用）
     * @author 孔伟杰
     * @date 2019-10-17
     */
    market_growthrule_wx_getBrokerLevelDataByLogin: UrlConfigFormat("/market/growthrule/wx/getBrokerLevelDataByLogin"),
    /**
     * 客服中心-问题分类列表
     */
    market_callCenter_questionList: UrlConfigFormat("/market/servicereply/questionList"),

    /**
     * 描述信息：获取日志内容列表
     * @author 吴成林
     * @date 2019-10-17
     */
    member_logcontet_logListAll:UrlConfigFormat('/member/logcontet/logListAll'),

    /**
     * 描述信息：保存/更新日志内容
     * @author 吴成林
     * @date 2019-10-17
     */
    member_logcontet_save:UrlConfigFormat('/member/logcontet/save'),

    /**
     * 描述信息：获取团队等级
     * @author 孔伟杰
     * @date 2019-10-17
     */
    market_teamlevel_wx_getTeamLevelData:UrlConfigFormat('/market/teamlevel/wx/getTeamLevelData'),
    /**
     * 微信分享
     */
    weChat_shareUrl: UrlConfigFormat('/management/wx/share/wx694ff8e576238b95'),
    /**
     * 客户信息列表
     */
    userLinkMan_listAll: UrlConfigFormat('/management/userLinkManInfo/listAll'),
      /**
     * 已经投保的客户信息
     */
    userLinkMan_getUserLinkManInfoByOrder: UrlConfigFormat('/management/userLinkManInfo/getUserLinkManInfoByOrder'),
    /**
     * 访客
     */
    userLinkMan_getVisitorsList: UrlConfigFormat('/management/userLinkManInfo/getVisitorsList'),
    /**
     * 重置
     */
    emptyLookedMeList:UrlConfigFormat('/management/wholookme/emptyLookedMeList'),
    /**
     * 个人客户信息
     */
    userLinkMan_getData: UrlConfigFormat('/management/userLinkManInfo/getData'),
    /**
     * 新增客户信息
     */
    userLinkMan_insert: UrlConfigFormat('/management/userLinkManInfo/insert'),
    /**
     * 更新信息列表
     */
    userLinkMan_update: UrlConfigFormat('/management/userLinkManInfo/update'),
    /**
     * 删除客户信息
     */
    userLinkMan_delete: UrlConfigFormat('/management/userLinkManInfo/delete'),
    /**
     * 微信授权 -> 获取OpenId  ``POST [returnUrl]
     */
    weChat_authorize: UrlConfigFormat("/management/wx/authorize"),
    /**
     * 全局搜索  ``POST [keyword]
     */
    mobileHome_globalSearch: UrlConfigFormat("/management/mobileHome/globalSearch"),
    /**
     * 海报类型列表
     */
    poster_type_list: UrlConfigFormat("/sysbase/gvlist/restype/500000"),
    /**
     * 海报全部列表
     */
    poster_listAll: UrlConfigFormat("/market/poster/listAll"),
    /**
     * 海报列表
     */
    poster_list: UrlConfigFormat("/market/poster/list"),
    /**
     * 获取消息中心列表
     */
    sysbase_msg_wxlist: UrlConfigFormat('/sysbase/msg/wxlist'),
    /**
     * 更新消息为已读
     */
    sysbase_msg_readed: UrlConfigFormat('/sysbase/msg/readed'),
    /**
     * 更新消息中心列表
     */
    sysbase_msg_save: UrlConfigFormat('/sysbase/msg/save'),
	/**
     * 学历列表
     */
    sysbase_gvlist_restype:UrlConfigFormat('/sysbase/gvlist/restype/100006'),
    /**
     * 描述信息：查询我关注的问题
     * @author 覃创斌
     * @date 2019/10/15
    */
    focusquestion_getFocusQuestionList : UrlConfigFormat("/member/focusquestion/getFocusQuestionList"),
    /**
     * 描述信息：取消关注
     * @author 覃创斌
     * @date 2019/10/15
    */
    focusquestion_cancelFocus : UrlConfigFormat("/member/focusquestion/cancelFocus"),
    /**
     * 描述信息：谁看过我
     * @author 覃创斌
     * @date 2019/10/15
     */
    view_getViewStatisticByWeiXin : UrlConfigFormat("/member/viewstatistic/getViewStatisticByWeiXin"),
    /**
     * 描述信息：话题PK查询列表
     * @author 覃创斌
     * @date 2019/10/15
     */
    debate_getWapDebateList : UrlConfigFormat("/member/debate/getWapDebateList"),

    /**
     * 描述信息：投票数据
     * @author 覃创斌
     * @date 2019/10/15
     */
    debatevote_insert : UrlConfigFormat("/member/debatevote/insert"),
    /**
     * 描述信息：获取详情
     * @author 覃创斌
     * @date 2019/10/15
     */
    debate_getDebateId : UrlConfigFormat("/member/debate/getDebateId"),

    /**
     * 描述信息：获取详情
     * @author 覃创斌
     * @date 2019/10/15
     */
    debatevote_getVoteList : UrlConfigFormat("/member/debatevote/getVoteList"),

    /**
     * 描述信息：根据话题id查询评论
     * @author 覃创斌
     * @date 2019/10/15
     */
    debate_getDebateByEvaluationList : UrlConfigFormat("/member/debate/getDebateByEvaluationList"),
    /**
     * 修改文章评论点赞数
     */
    evaluation_updateGiveLike:UrlConfigFormat("/member/evaluation/updateGiveLike" ),


    /**
     *获取标签内容
     *
     * */
    getAllLabel:UrlConfigFormat("/management/featuretab/getLabelList" ),

    /**
     *获取专题内容
     *
     * */
    getAllSubject:UrlConfigFormat("/management/featureactivity/getAllSubject" ),


    /**
     * 获取详情页面信息
     * */

    getSubjectDetails:UrlConfigFormat("/management/featureactivity/getSubjectDetails" ),

    /**
     * 获取其他详情页面信息
     * */
    getSubjectOrder:UrlConfigFormat("/management/featureactivity/getSubjectOther" ),



    /**
     * 获取根据用户ID和id提问详情
     */
    question_getDetailsByMemberId:UrlConfigFormat("/member/question/getDetailsByMemberId"),

    /**
     * 获取根据用户ID和id提问详情
     */
    question_getMyAnswerDetails:UrlConfigFormat("/member/question/getMyAnswerDetails"),
    /**
     * 获取精选回答详情
     */
    answer_getTopDetailsByMemberId:UrlConfigFormat("/member/answer/getTopDetailsByMemberId"),
    /**
     * 获取回答所有 根据提问ID
     */
    answer_getAllAnswer:UrlConfigFormat("/member/answer/getAllAnswer"),
    /**
     * 添加回答
     */
    answer_insertAnswer:UrlConfigFormat("/member/answer/insertAnswer"),
    /**
     * 我的钱包
     */
    accountinfo_getMyWallet:UrlConfigFormat("/member/accountinfo/getMyWallet"),
    /**
     * 银行名称
     */
    bankType_getBankTypeList:UrlConfigFormat("/member/banktype/getBankTypeList"),
    /**
     * 保险热门产品列表
     */
    getHotProductsList_data: UrlConfigFormat("/management/mobileInsuranceInfo/getHotProductsList"),
    /**
     * 获取团队出单数、总人数、总保费（元）
     */
    market_teammember_wx_getTeamCount:UrlConfigFormat('/market/teammember/wx/getTeamCount'),
    /**
     * 企业险 -> 创建订单  ``POST [sellProductId, occupationId, requestToken, terminal, ...]
     */
    businessInsurance_createOrder: UrlConfigFormat("/management/mobileBusinessInsurance/createOrder"),
    /**
     * 企业险 -> 加载填写投保资料页面  ``POST [orderToken]
     */
    businessInsurance_loadFillInInsuranceInformation: UrlConfigFormat("/management/mobileBusinessInsurance/load_fillInInsuranceInformation"),
    /**
     * 获取某月份新增团员总数
     */
    market_teammember_wx_getTeamInformation:UrlConfigFormat('/market/teammember/wx/getTeamInformation'),
    /**
     * 文件上传-用于复杂业务操作  ``POST [file, formType, formId, ...]
     */
    upload_attachment_uploadFileByComplex: UrlConfigFormat("/upload/attachment/uploadFileByComplex"),
    /**
     * 关注问题
     */
    focusquestion_insertData:UrlConfigFormat("/member/focusquestion/insertData"),
    /**
     * 获取某月份新增团员列表
     */
    market_teammember_wx_getNewMembersList:UrlConfigFormat('/market/teammember/wx/getNewMembersList'),
    /**
     * 描述信息：加载团队二维码
     * @author 孔伟杰
     * @date 2019-09-29
     */
    market_team_wx_getQRCode:UrlConfigFormat('/market/team/wx/getQRCode'),
    /**
     * 获取团队总津贴金额、某月团队津贴金额、某月育成团津贴金额
     */
    market_teamsubsidy_getTeamSubsidy:UrlConfigFormat('/market/teamsubsidy/getTeamSubsidy'),
    /**
     * 根据团长ID获取已加团的团ID查询某月份新增团员列表（作废）
     */
    market_teammember_wx_getTeamId:UrlConfigFormat('/market/teammember/wx/getTeamId'),
    /**
     * 根据时间获取团队订单排行榜列表
     */
    market_teammember_wx_getTeamMemberRankList:UrlConfigFormat('/market/teammember/wx/getTeamMemberRankList'),

    /**
     * 早起提醒
     */
    member_check_early_reminder:UrlConfigFormat('/member/member/checkEarlyReminder'),

    /**
     * 早起提醒开关
     */
    member_update_early_reminder:UrlConfigFormat('/member/member/updateEarlyReminder'),

    /**
     * 红包账户
     */
    member_red_account:UrlConfigFormat('/member/redaccount/person'),

    /**
     * 红包记录明细
     */
    member_redRecords_personList:UrlConfigFormat('/member/redrecords/personList'),
    /**
     * 获取育成团数
     */
    market_team_wx_getYuChengTeamNumber:UrlConfigFormat('/market/team/wx/getYuChengTeamNumber'),
    /**
     * 获取育成团截止时间的团队列表
     */
    market_teamsubsidy_getAffiliateTeamList:UrlConfigFormat('/market/teamsubsidy/getAffiliateTeamList'),
    /**
     * 更新播放
     */
    course_updateCourse:UrlConfigFormat("/member/course/updateCourse"),
    /**
     * 更新回答
     */
    answer_updateAnswer:UrlConfigFormat("/member/answer/updateAnswer"),

    /**
     * 更改代金券使用状态
     */
    member_cashRecordsHandlerStats:UrlConfigFormat('/market/mobileCoupon/useCoupon'),
    /**
     * 条件标签
     */
    label_searchLabelList:UrlConfigFormat('/member/label/searchLabelList'),
    /**
     * 条件标签
     */
    label_webSearchLabelList:UrlConfigFormat('/member/label/webSearchLabelList'),
    /**
     * 获取代金券数据[l临时]
     */
    member_getCashRecords:UrlConfigFormat('/member/cashrecords/getCardBag'),
    /**
     * 获取代金券数据
     */
    market_getCouponList:UrlConfigFormat('/market/coupon/getCouponList'),

    /**
     * 获得用户总积分
     */
    member_getMemberIntegralLevel:UrlConfigFormat('/management/integral/IntegralLevel'),
    /**
     * 保存问题
     */
    question_insertQuestion:UrlConfigFormat('/member/question/insertQuestion'),
    /**
     * 企业险 -> 提交投保资料页面  ``POST [RequestBody]
     */
    businessInsurance_submitFillInsuranceInfo: UrlConfigFormat("/management/mobileBusinessInsurance/submit_fillInsuranceInfo"),
    /**
     * 获取意见回复信息列表
     */
    feedback_getOpinionReplyList: UrlConfigFormat("/management/feedback/getOpinionReplyList"),
	/**
     * 获取意见回复信息列表
     */
    feedback_updateMarkRead: UrlConfigFormat("/management/feedback/updateMarkRead"),
    /**
     * 描述信息：创建海报二维码
     * @author 孔伟杰
     * @date 2019-11-16
     */
    market_poster_buildPosterQRCode: UrlConfigFormat("/market/poster/buildPosterQRCode"),
    /**
     *获取保险公司列表
     */
    management_insurance_company:UrlConfigFormat("/management/insuranceCompany/list"),
    /**
     *保险公司理赔资料
     */
    management_claim_information:UrlConfigFormat("/management/insuranceCompany/getInsuranceCompanyById"),
    /**
     * 根据openId判断用户是否存在
     */
    member_weixinbase_matchingOpenId:UrlConfigFormat('/member/weixinbase/matchingOpenId'),
    /**
     *查询openId
     */
    browsewxinfo_getByOpenid: UrlConfigFormat("/management/browsewxinfo/getByOpenid"),
    /**
     *谁看过我记录
     */
    whoLookMe_getWhoLookMeList: UrlConfigFormat("/management/wholookme/getWhoLookMeList"),
    /**
     *检查今日是否分享文章/话题
     */
    integral_checkToDayShareArticle: UrlConfigFormat("/management/integral/checkToDayShareArticle"),
    /**
     *检查当日是否参与平台话题PK讨论
     */
    integral_checkToDayTopic: UrlConfigFormat("/management/integral/checkToDayTopic"),
    /**
     *检查当日是否阅读文章并点赞
     */
    integral_checkToDayRead: UrlConfigFormat("/management/integral/checkToDayRead"),
    /**
     *检查当日是否参与观看并学习,课后评价
     */
    integral_checkToDayWatchAndLearn: UrlConfigFormat("/management/integral/checkToDayWatchAndLearn"),
    /**
     *根据code和memberId送积分
     */
    integral_handSendIntegral: UrlConfigFormat("/management/integral/handSendIntegral"),

    /**
     * 获取微信昵称(红包提现)
     */
    management_getUserWeiXinName: UrlConfigFormat("/management/userweixininfo/getUserWeiXinName"),
    /**
     * 红包提现
     */
    management_redAccount_withdraw: UrlConfigFormat("/member/redaccount/withdraw"),
    /**
     * 根据openId保存memberId
     */
    member_weixinbase_updateMemberId: UrlConfigFormat('/member/weixinbase/updateMemberId'),
    /**
     * 法大大注册账号
     * @author 孔伟杰
     * @date 2019-11-25
     */
    member_fadada_regAccount: UrlConfigFormat("/member/fadada/regAccount"),
    /**
     * 法大大获取实名认证地址
     * @author 孔伟杰
     * @date 2019-11-25
     */
    member_fadada_getAuthUrl: UrlConfigFormat("/member/fadada/getAuthUrl"),
    /**
     * 获取模板信息
     */
    management_reporttemp_getTemp: UrlConfigFormat('/management/reporttemp/getTemp'),
    /**
     *  提现信息展示
     */
    member_bankcard_getMemberWithdraw: UrlConfigFormat("/member/bankcard/withdrawMember"),
    /**
     * 法大大实名认证异步回调
     * @author 孔伟杰
     * @date 2019-11-25
     */
    member_fadada_authNotify: UrlConfigFormat("/member/fadada/authNotify"),
    /**
     * 获取法大大信息
     * @author 孔伟杰
     * @date 2019-11-25
     */
    member_fadada_getFadadaInfo: UrlConfigFormat("/member/fadada/getFadadaInfo"),
    /**
     * 法大大申请实名证书
     * @author 孔伟杰
     * @date 2019-11-25
     */
    member_fadada_applyCert: UrlConfigFormat("/member/fadada/applyCert"),

    /**
     *添加分享次数
     * */
    member_insertForwarding:UrlConfigFormat("/market/forwardingrecord/insert"),
    /**
     *一元打卡页面加载
     * */
    member_unaryClockInLoadPage:UrlConfigFormat("/market/mobileAC19002/loadPage"),
    /**
     *参数打卡
     * */
    member_participateClock:UrlConfigFormat("/market/mobileAC19002/signUp"),
    /**
     * 根据账号获取会员详情并展示
     * */
    memberdetail_detailsPageMemberDetail:UrlConfigFormat("/member/memberdetail/detailsPageMemberDetail"),
    /**
     * 参加抽奖
     */
    market_mobileAC19001_joinLottery: UrlConfigFormat("/market/mobileAC19001/joinLottery"),
    /**
     * 获取抽奖码信息
     */
    market_mobileAC19001_getLotteryCodeData: UrlConfigFormat("/market/mobileAC19001/getLotteryCodeData"),
    /**
     * 保存收货地址
     */
    market_receivingaddress_save: UrlConfigFormat("/market/receivingaddress/save"),
    /**
     * 描述信息：用户批量数据[手机号，身份证号]加密
     * @author 覃创斌
     * @date 2019/12/5
    */
    member_memberUpdateOld: UrlConfigFormat("/member/UpdateOld/memberUpdateOld"),
    /**
     * 描述信息：银行卡批量数据[银行卡，身份证号]加密
     * @author 覃创斌
     * @date 2019/12/5
     */
    member_bankCardUpdateOld: UrlConfigFormat("/member/UpdateOld/bankCardUpdateOld"),
    /**
     * 描述信息：批量迁移数据把手机迁移到account
     * @author 覃创斌
     * @date 2019/12/5
    */
    member_memberAccountUpdateOld: UrlConfigFormat("/member/UpdateOld/memberAccountUpdateOld"),
    /**
     * 获取投保订单状态
     */
    mobileOrderInfoLog_getOrderStatus: UrlConfigFormat("/management/mobileOrderInfoLog/getOrderStatus"),

    /**
     *获取分享用户的信息
     * */
    member_getShareMemberInfo:UrlConfigFormat("/member/member/getShareMemberInfo"),
    /**
     * 描述信息：定投计算
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_compound:UrlConfigFormat("/market/calculator/compound"),
    /**
     * 描述信息：贷款计算
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_loan:UrlConfigFormat("/market/calculator/loan"),
    /**
     * 描述信息：理财收益计算
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_investment:UrlConfigFormat("/market/calculator/investment"),
    /**
     * 描述信息：货币列表
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_exchangeList:UrlConfigFormat("/market/calculator/exchangeList"),
    /**
     * 描述信息：汇率换算
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_exchange:UrlConfigFormat("/market/calculator/exchange"),
    /**
     * 描述信息：基金查询
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_fundSearch:UrlConfigFormat("/market/calculator/fundSearch"),
    /**
     * 描述信息：行情信息
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_fundSummaryList:UrlConfigFormat("/market/calculator/fundSummaryList"),
    /**
     * 描述信息：基金定投计算
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_fundFixed:UrlConfigFormat("/market/calculator/fundFixed"),
    /**
     * 描述信息：分期付款
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_installment:UrlConfigFormat("/market/calculator/installment"),
    /**
     * 描述信息：分期付款对比
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_installmentList:UrlConfigFormat("/market/calculator/installmentList"),
    /**
     * 描述信息：投资日历
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_getCalendarData:UrlConfigFormat("/market/calculator/getCalendarData"),
    /**
     * 描述信息：合同生成
     * @author 孔伟杰
     * @date 2019/12/6
     */
    member_fadada_generateContract:UrlConfigFormat("/member/fadada/generateContract"),
    /**
     * 描述信息：自动签署
     * @author 孔伟杰
     * @date 2019/12/6
     */
    member_fadada_extsignAuto:UrlConfigFormat("/member/fadada/extsignAuto"),
    /**
     * 描述信息：手动签署
     * @author 孔伟杰
     * @date 2019/12/6
     */
    member_fadada_extsign:UrlConfigFormat("/member/fadada/extsign"),
    /**
     * 描述信息：合同归档
     * @author 孔伟杰
     * @date 2019/12/6
     */
    member_fadada_contractFiling:UrlConfigFormat("/member/fadada/contractFiling"),
    /**
     * 描述信息：基金重仓股排行
     * @author 孔伟杰
     * @date 2019/12/6
     */
    market_calculator_fundsList:UrlConfigFormat("/market/calculator/fundsList"),
    /**
     * 法大大签署结果异步回调
     * @author 孔伟杰
     * @date 2019-11-25
     */
    member_fadada_extsignNotify: UrlConfigFormat("/member/fadada/extsignNotify"),
    /**
     * 法大大签署结果同步回调校验
     * @author 孔伟杰
     * @date 2019-11-25
     */
    member_fadada_extsignResult: UrlConfigFormat("/member/fadada/extsignResult"),
    /**
     * 根据账号获取用户收货地址信息
     * @author 吴成林
     * @date 2019/12/9
     */
    market_receivingaddress_getByPars: UrlConfigFormat("/market/receivingaddress/getByPars"),
    /**
     * 描述信息：保存测评结果
     * @author 吴成林
     * @date 2019/12/10
     */
    market_testresult_setTestResult:UrlConfigFormat('/market/testresult/setTestResult'),
    /**
     * 描述信息：保存测评指标结果
     * @author 吴成林
     * @date 2019/12/10
     */
    market_subjectresult_setSubjectResult:UrlConfigFormat('/market/subjectresult/setSubjectResult'),
    /**
     * 获取会员名称
     */
    member_getMemberName:UrlConfigFormat('/member/member/getMemberName'),
    /**
     * 保存需求
     */
    member_demand_wx_addDemand:UrlConfigFormat('/member/demand/wx/addDemand'),
    /**
     * 显示用户需求列表
     */
    member_demand_wx_showMyDemandList:UrlConfigFormat('/member/demand/wx/showMyDemandList'),
    /**
     * 显示我用户需求详情
     */
    member_demand_wx_showDemandDetail:UrlConfigFormat('/member/demand/wx/showDemandDetail'),
    /**
     * 获取名片信息
     */
    mybusinesscard_getBusinessCardScreen: UrlConfigFormat("/management/mybusinesscard/getBusinessCardScreen"),
    /**
     * 获取评价
     */
    orderevaluation_getOrderEvaluationList: UrlConfigFormat("/management/orderevaluation/getOrderEvaluationList"),
    /**
     * 获取照片墙
     */
    mybusinesscard_getPhotoWallList: UrlConfigFormat("/management/mybusinesscard/getPhotoWallList"),
  /**
   * 描述信息：修改头像
   * @author 覃创斌
   * @date 2020/1/16
  */
    member_updateImgPath: UrlConfigFormat("/member/member/updateImgPath"),
    /**
     * 编辑
     */
    mybusinesscard_insertOrUpdateBusinessCard: UrlConfigFormat("/management/mybusinesscard/insertOrUpdateBusinessCard"),
    /**
     * 编辑（旧版名片）
     */
    mybusinesscard_insertOrUpdateBusinessCardOld: UrlConfigFormat("/management/mybusinesscard/insertOrUpdateBusinessCardOld"),
   /**
    * 描述信息：添加订单评价
    * @author 覃创斌
    * @date 2020/1/19
   */
    orderevaluation_insertOrderEvaluation: UrlConfigFormat("/management/orderevaluation/insertOrderEvaluation"),
    /**
     * 描述信息：更多评论
     * @author 覃创斌
     * @date 2020/1/19
     */
    orderevaluation_getMoreOrderEvaluationList: UrlConfigFormat("/management/orderevaluation/getMoreOrderEvaluationList"),
   /**
    * 描述信息：案例库
    * @author 覃创斌
    * @date 2020/2/20
   */
    caseLibrary_getCaseLibraryList: UrlConfigFormat("/management/caselibrary/getCaseLibraryList"),
    /**
     * 描述信息：行业分类
     * @author 覃创斌
     * @date 2020/2/20
     */
    industry_getList: UrlConfigFormat("/management/industry/list"),
    /**
     * 描述信息：我的案例库
     * @author 覃创斌
     * @date 2020/2/20
     */
    myCaseLibrary_getMyCaseLibraryList: UrlConfigFormat("/management/mycaselibrary/getMyCaseLibraryList"),
    /**
     * 描述信息：添加我的案例库
     * @author 覃创斌
     * @date 2020/2/20
     */
    myCaseLibrary_insertMyCaseLibrary: UrlConfigFormat("/management/mycaselibrary/insertMyCaseLibrary"),
    /**
     * 描述信息：根据ID获取案例库
     * @author 覃创斌
     * @date 2020/2/20
     */
    caseLibrary_getCaseLibrary: UrlConfigFormat("/management/caselibrary/getCaseLibrary"),
    /**
     * 描述信息：根据UUID查询信息 增加浏览量
     * @author 覃创斌
     * @date 2020/2/20
     */
    myCaseLibrary_getByUUIDAndAddBrowse: UrlConfigFormat("/management/mycaselibrary/getByUUIDAndAddBrowse"),
    /**
     * 描述信息：删除分享
     * @author 覃创斌
     * @date 2020/2/20
     */
    myCaseLibrary_deleteMyCaseLibrary: UrlConfigFormat("/management/mycaselibrary/deleteMyCaseLibrary"),
    /**
     * 描述信息：上传URL 抓取html页面内容
     * @author 覃创斌
     * @date 2020/2/26
    */
    caseLibrary_upload: UrlConfigFormat("/management/caselibrary/upload"),
    /**
     * 描述信息：团队销售目标保存
     * @author 孔伟杰
     * @date 2020/02/26
     */
    market_teamsalestarget_wx_save: UrlConfigFormat('/market/teamsalestarget/wx/save'),
    /**
     * 描述信息：团队活动通知保存
     * @author 孔伟杰
     * @date 2020/02/26
     */
    market_teamactivitynotice_wx_save: UrlConfigFormat('/market/teamactivitynotice/wx/save'),
    /**
     * 描述信息：加载团队任务用的分页团员列表
     * @author 孔伟杰
     * @date 2020/02/26
     */
    market_teammember_pageListByTesk: UrlConfigFormat('/market/teammember/pageListByTesk'),
    /**
     * 描述信息：销售目标列表
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamsalestarget_wx_listByTeamId: UrlConfigFormat('/market/teamsalestarget/wx/listByTeamId'),
    /**
     * 描述信息：活动通知列表
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamactivitynotice_wx_listByTeamId: UrlConfigFormat('/market/teamactivitynotice/wx/listByTeamId'),
    /**
     * 描述信息：销售目标情况
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamsalestargetmemberlist_wx_getStatusByTaskId: UrlConfigFormat('/market/teamsalestargetmemberlist/wx/getStatusByTaskId'),
    /**
     * 描述信息：活动通知情况
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamactivitynoticememberlist_wx_getStatusByTaskId: UrlConfigFormat('/market/teamactivitynoticememberlist/wx/getStatusByTaskId'),
    /**
     * 描述信息：销售目标详情
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamsalestarget_wx_getDetailsByTaskId: UrlConfigFormat('/market/teamsalestarget/wx/getDetailsByTaskId'),
    /**
     * 描述信息：活动通知详情
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamactivitynotice_wx_getDetailsByTaskId: UrlConfigFormat('/market/teamactivitynotice/wx/getDetailsByTaskId'),
    /**
     * 描述信息：销售目标可用标识改变
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamsalestarget_wx_enabled: UrlConfigFormat('/market/teamsalestarget/wx/enabled'),
    /**
     * 描述信息：活动通知可用标识改变
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamactivitynotice_wx_enabled: UrlConfigFormat('/market/teamactivitynotice/wx/enabled'),
    /**
     * 描述信息：海报图片转Base64
     * @author chengmingwei
     * @date 2020/04/02
     */
    market_poster_base64:UrlConfigFormat('/market/poster'),
    /**
     * 描述信息：海报列表
     * @author 覃创斌
     * @date 2020/2/26
    */
    market_getPosterList: UrlConfigFormat('/market/poster/getPosterList'),
    /**
     * 描述信息：我的海报列表
     * @author 覃创斌
     * @date 2020/2/26
     */
    market_getMyPosterList: UrlConfigFormat('/market/myposter/getMyPosterList'),
    /**
     * 描述信息：海报详情列表
     * @author 覃创斌
     * @date 2020/2/26
     */
    market_getPosterDetailsList: UrlConfigFormat('/market/poster/getPosterDetailsList'),
    /**
     * 描述信息：添加我的海报  type 1 个人作品 2 收藏
     * @author 覃创斌
     * @date 2020/2/26
     */
    market_insertMyPoster: UrlConfigFormat('/market/poster/addPoster'),
    /**
     * 描述信息：查询收藏状态
     * @author 覃创斌
     * @date 2020/2/26
     */
    market_getCollectionByPosterID: UrlConfigFormat('/market/poster/getCollectionByPosterID'),
    /**
     * 获取我的名片信息
     */
    myBusines_getMyBusinessCard: UrlConfigFormat("/management/mybusinesscard/getMyBusinessCard"),
    /**
     * 描述信息：取消收藏
     * @author 覃创斌
     * @date 2020/2/26
     */
    market_deleteMyPoster: UrlConfigFormat('/market/myposter/deleteMyPoster'),
    /**
     * 描述信息：添加收藏
     * @author 覃创斌
     * @date 2020/2/26
     */
    market_addMyPoster: UrlConfigFormat('/market/myposter/insertMyPoster'),
    /**
     * 描述信息：删除海报
     * @author 覃创斌
     * @date 2020/3/3
    */
    market_deletePoster: UrlConfigFormat('/market/poster/deletePoster'),
    /**
     * 描述信息：删除收藏
     * @author 覃创斌
     * @date 2020/3/3
     */
    market_deleteMyPoster: UrlConfigFormat('/market/poster/deleteMyPoster'),
    /**
     * 描述信息：根据ID获取信息
     * @author 覃创斌
     * @date 2020/3/3
     */
    market_getPoster: UrlConfigFormat('/market/poster/getPoster'),
    /**
     * 描述信息：团员销售目标情况
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamsalestargetmemberlist_wx_getDetailsByTaskMemberId: UrlConfigFormat('/market/teamsalestargetmemberlist/wx/getDetailsByTaskMemberId'),
    /**
     * 描述信息：团员活动通知情况
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamactivitynoticememberlist_wx_getDetailsByTaskMemberId: UrlConfigFormat('/market/teamactivitynoticememberlist/wx/getDetailsByTaskMemberId'),
    /**
     * 描述信息：团员参加任务
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamsalestargetmemberlist_wx_isTake: UrlConfigFormat('/market/teamsalestargetmemberlist/wx/isTake'),
    /**
     * 描述信息：团员参加活动
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamactivitynoticememberlist_wx_isTake: UrlConfigFormat('/market/teamactivitynoticememberlist/wx/isTake'),
    /**
     * 描述信息：团员完成销售目标
     * @author 孔伟杰
     * @date 2020/02/27
     */
    market_teamsalestargetmemberlist_wx_saveNowVal: UrlConfigFormat('/market/teamsalestargetmemberlist/wx/saveNowVal'),
    /**
     * 根据上传链接获取爬虫获取内容  保存数据
     */
    reprintarticle_uploadArticle: UrlConfigFormat("/management/reprintarticle/uploadArticle"),
    /**
     * 根据ID获取 实体
     */
    reprintarticle_getReprintArticleById: UrlConfigFormat("/management/reprintarticle/getReprintArticleById"),
    /**
     * 根据ID修改实体
     */
    reprintarticle_updateReprintArticleById: UrlConfigFormat("/management/reprintarticle/updateReprintArticleById"),
    /**
     * 根据用户ID获取名片id 和获取会员实体
     */
    myBusinessCard_getMyBusinessCardByMemberId: UrlConfigFormat("/management/mybusinesscard/getMyBusinessCardByMemberId"),
    /**
     * 获取产品列表
     * 	insuranceType == 1
     *  insuranceInfoIds
     */
    reprintarticle_getInsuranceInfoList: UrlConfigFormat("/management/reprintarticle/getInsuranceInfoList"),
    /**
     * 描述信息：转载文章 热门文章
     * @author 覃创斌
     * @date 2019-09-10
     */
    article_getArticleList:UrlConfigFormat("/member/article/getArticleList"),

    /**
     * 添加记录
     */
    reprintrecord_insertReprintRecord: UrlConfigFormat("/management/reprintrecord/insertReprintRecord"),
    /**
     * 记录列表
     */
    reprintrecord_getReprintRecordList: UrlConfigFormat("/management/reprintrecord/getReprintRecordList"),
    /**
     *谁看过我记录删除
     */
    management_whoLookMe_deleteBrowse: UrlConfigFormat("/management/wholookme/deleteBrowse"),
    /**
     *访问次数排行
     */
    management_whoLookMe_lookedMeRankWeek: UrlConfigFormat("/management/wholookme/lookedMeRankWeek"),
    /**
     *获取某个人的观看记录
     */
    management_browsewxinfo_getBrowseDetail: UrlConfigFormat("/management/browsewxinfo/getBrowseDetail"),
    /**
     *参加人数总和
     */
    integralRecords_getAttendSum: UrlConfigFormat("/management/integralRecords/getAttendSum"),
    /**
     *当前用户积分和排名
     */
    integralRecords_getCurrentByMemberId: UrlConfigFormat("/management/integralRecords/getCurrentByMemberId"),
    /**
     *排行榜
     */
    integralRecords_getRankingList: UrlConfigFormat("/management/integralRecords/getRankingList"),
    /**
     * 获取TA的动态
     */
    member_viewstatistic_getStatisticList: UrlConfigFormat('/member/viewstatistic/getStatisticList'),
    /**
     * 新人红包 - 关闭弹窗永久Redis缓存 H5
     */
    market_mobileCoupon_setNewbieActivitiesRedis:UrlConfigFormat('/market/mobileCoupon/setNewbieActivitiesRedis'),
    /**
     * 获取我的收入
     */
    member_userscoreinfo_getIncomeContent: UrlConfigFormat('/member/userscoreinfo/getIncomeContent'),
    /**
     * 获取提现记录
     */
    member_withdraw_getRecordContent: UrlConfigFormat('/member/withdraw/getRecordContent'),
    /**
     * 描述信息：文件上传 云空间
     * @author 覃创斌
     * @date 2020/3/12
    */
    upload_userCloudRecord:UrlConfigFormat('/upload/usercloudrecord/uploadCloud'),

    /**
     * 描述信息：根据id 获取智能媒体链接 可在线预览
     * @author 覃创斌
     * @date 2020/3/12
     */
    upload_getOfficePreviewURL:UrlConfigFormat('/upload/usercloudrecord/getOfficePreviewURL'),
    /**
     * 描述信息：我的资源列表
     * @author 覃创斌
     * @date 2020/3/12
     */
    upload_getMyCloudDiskList:UrlConfigFormat('/upload/usercloudrecord/getMyCloudDiskList'),
    /**
     * 描述信息：根据ID下架资源
     * @author 覃创斌
     * @date 2020/3/12
     */
    upload_deleteCloudFileById:UrlConfigFormat('/upload/usercloudrecord/deleteCloudFileById'),
    /**
     * 描述信息：我的云空间大小
     * @author 覃创斌
     * @date 2020/3/12
     */
    upload_getMyCloudSize:UrlConfigFormat('/upload/usercloudrecord/getMyCloudSize'),
    /**
     * 描述信息：添加
     * @author 覃创斌
     * @date 2020/3/12
     */
    upload_insertMyShareRecord:UrlConfigFormat('/upload/mysharerecord/insertMyShareRecord'),
    /**
     * 描述信息：分享列表
     * @author 覃创斌
     * @date 2020/3/12
     */
    upload_getMyShareRecordList:UrlConfigFormat('/upload/mysharerecord/getMyShareRecordList'),
    /**
     * 描述信息：浏览量
     * @author 覃创斌
     * @date 2020/3/19
    */
    upload_addBrowse:UrlConfigFormat('/upload/mysharerecord/addBrowse'),
    /**
     *添加数据
     */
    brochure_insertBrochure: UrlConfigFormat("/management/brochure/insertBrochure"),
    /**
     *查询数据
     */
    brochure_getBrochureList: UrlConfigFormat("/management/brochure/getBrochureList"),
    /**
     *查询详情数据
     */
    brochure_getBrochure: UrlConfigFormat("/management/brochure/getBrochure"),

    /**
     *增加浏览
     */
    brochure_getBrochureByIdAddViewNum: UrlConfigFormat("/management/brochure/getBrochureByIdAddViewNum"),

    /**
     *增加分享
     */
    brochure_getBrochureByIdAddShareNum: UrlConfigFormat("/management/brochure/getBrochureByIdAddShareNum"),
    /**
     * 根据参数获取邀请人列表
     */
    member_userrelationship_getInviteeList: UrlConfigFormat('/member/userrelationship/getInviteeList'),
    /**
     * 分析汇总
     */
    shareRecord_insertShareRecord: UrlConfigFormat("/management/sharerecord/insertShareRecord"),
    /**
     * 描述信息：加载看板数据
     * @author 覃创斌
     * @date 2020/3/25
    */
    market_loadTeamKanBan: UrlConfigFormat('/market/TeamKanBan/loadTeamKanBan'),

    /**
     * 描述信息：今日团情 ---- 新增团员 近30天数据
     * @author 覃创斌
     * @date 2020/3/25
     */
    market_getTeamNewMemberThirtyDays: UrlConfigFormat('/market/TeamKanBan/getTeamNewMemberThirtyDays'),

    /**
     * 描述信息：今日团情 ---- 新增子团 近30天数据
     * @author 覃创斌
     * @date 2020/3/25
     */
    market_getTeamChildTeamThirtyDays: UrlConfigFormat('/market/TeamKanBan/getTeamChildTeamThirtyDays'),

    /**
     * 描述信息：今日团情 ---- 团队保费 近30天数据
     * @author 覃创斌
     * @date 2020/3/25
     */
    market_getTeamAmountThirtyDays: UrlConfigFormat('/market/TeamKanBan/getTeamAmountThirtyDays'),

    /**
     * 描述信息：今日团情 ---- 子团保费 近30天数据
     * @author 覃创斌
     * @date 2020/3/25
     */
    market_getTeamChildAmountThirtyDays: UrlConfigFormat('/market/TeamKanBan/getTeamChildAmountThirtyDays'),

    /**
     * VIP会员 获取一对一咨询服务的经纪人 和 当前会员信息
     *  cmw 2020.03.25 17:09 add
     */
    member_vip_servicer: UrlConfigFormat("/member/vip"),
    /**
     * 获取会员身份类型
     *  cmw 2020.03.25 17:10 add
     */
    member_role_type: UrlConfigFormat("/member/vip/role-type"),
    /**
     * H5 咨询列表（进行中，历史）
     *  cmw 2020.03.25 17:10 add
     */
    msg_consultation_list: UrlConfigFormat("/msg/consultation"),
    /**
     * H5 Chat 中获取未读消息
     *  cmw 2020.03.26 15:55 add
     */
    msg_message_unread_list: UrlConfigFormat("/msg/message"),

    /**
     * 话术列表API
     */
    management_speechcraftconfiginfo_list: UrlConfigFormat("/management/speechcraftconfiginfo"),

    /**
     * 获取VIP价格
     */
    member_vipPrice_wx_list: UrlConfigFormat('/member/vipprice/wx/list'),
    /**
     * 购买VIP
     */
    member_memberVip_wx_buyVip: UrlConfigFormat('/member/vip/wx/buyVip'),
    /**
     * 描述信息：团员动态
     * @author 吴成林
     * @date 2020-3-27
     */
    market_getTeamDynamicList: UrlConfigFormat('/market/TeamKanBan/getTeamDynamicList'),

    /**
     * 通用支付接口
     */
    pay_commonPay: UrlConfigFormat("/pay/commonPay"),
    /**
     * 用户注销
     */
    member_cancelUser: UrlConfigFormat('/member/logincancellog/cancelUser'),
    /**
     * 获取VIP会员支付状态
     */
    member_vipPayRecords_wx_getPayStatus: UrlConfigFormat('/member/vippayrecords/wx/getPayStatus'),
    /**
     * 创建实时咨询数据
     */
    msg_consultation_wx_create: UrlConfigFormat('/msg/consultation/wx/create'),
    /**
     * 获取实时咨询支付状态
     */
    msg_consultation_wx_getPstatus: UrlConfigFormat('/msg/consultation/wx/getPstatus'),
    /**
     * 获取当前用户的VIP信息
     */
    member_memberVip_getVipData: UrlConfigFormat('/member/vip/getVipData'),
    /**
     * 描述信息：合成分享海报图
     * @author 吴成林
     * @date 2020-4-3
     */
    upload_attachment_mergePoster:UrlConfigFormat('/upload/attachment/mergePoster'),
    /**
     * 描述信息：添加阅读时间
     * @author 孔伟杰
     * @date 2020-4-7
     */
    management_whoLookMe_addTimesById:UrlConfigFormat('/management/wholookme/addTimesById'),
    /**
     * 发起下单---课程
     */
    member_pay_insertSubjectPay: UrlConfigFormat('/member/subjectpayrecords/insertSubjectPay'),
    /**
     * 查询支付状态
     */
    member_pay_getSubjectPayById: UrlConfigFormat('/member/subjectpayrecords/getSubjectPayById'),

    /**
     * 获取课堂详情
     */
    course_getCourseDetailsList: UrlConfigFormat("/member/course/getCourseList"),

    /**
     * 热门前三条数据
     */
    course_getCourseByLabelIdTop3: UrlConfigFormat("/member/course/getCourseByLabelIdTop3"),

    /**
     * 热门前三条数据
     */
    course_getCourseByLabelIdTop3: UrlConfigFormat("/member/course/getCourseByLabelIdTop3"),

    /**
     * 描述信息：立即报名
     * @author 覃创斌
     * @date 2020/4/16
    */
    management_insertSignUp:UrlConfigFormat('/management/userjoininfo/insertSignUp'),


    /**
     * 描述信息：所有题目
     * @author 覃创斌
     * @date 2020/4/22
     */
    management_getTestSubjectList:UrlConfigFormat('/management/userjoininfo/getTestSubjectList'),

    /**
     * 描述信息：保存结果
     * @author 覃创斌
     * @date 2020/4/16
     */
    management_insertTestSubject:UrlConfigFormat('/management/userjoininfo/insertTestSubject'),

    /**
     * 查询数据 专题购买ID
     */
    member_getByPayID: UrlConfigFormat('/member/subjectpayrecords/getByPayID'),

    /**
     * 免费购买
     */
    member_insertFreeSubject: UrlConfigFormat('/member/subjectpayrecords/insertFreeSubject'),

    /**
     * 描述信息：检查是否参加了打榜
     * @author 覃创斌
     * @date 2020/4/22
     */
    management_getCheckIsJoin:UrlConfigFormat('/management/actihitdetailinfo/getCheckIsJoin'),

    /**
     * 描述信息： 排行榜
     * @author 覃创斌
     * @date 2020/4/22
     */
    management_getRanKingList:UrlConfigFormat('/management/actihitdetailinfo/getRanKingList'),

    /**
     * 描述信息：打榜功能
     * @author 覃创斌
     * @date 2020/4/22
     */
    management_insertActiHitDetail:UrlConfigFormat('/management/actihitdetailinfo/insertActiHitDetail'),

    /**
     * （活动专用）发送短信验证码
     */
    msg_sendPhone: UrlConfigFormat("/msg/msg/sendPhoneCode"),

    /**
     * 描述信息：根据参训号查询信息
     * @author 覃创斌
     * @date 2020/4/22
     */
    management_getByParticipateNum:UrlConfigFormat('/management/userjoininfo/getByParticipateNum'),

    /**
     * 描述信息：根据ID查询信息
     * @author 覃创斌
     * @date 2020/4/22
     */
    management_getByUserJoinIdInfo:UrlConfigFormat('/management/userjoininfo/getByUserJoinIdInfo'),

    /**
     * 团队分享
     */
    shareRecord_getTeamShareList: UrlConfigFormat("/management/sharerecord/getTeamShareList"),

    /**
     * 描述信息：领航计划 登录
     * @author 吴成林
     * @date 2020/5/12
     */
    management_userjoininfo_login:UrlConfigFormat('/management/userjoininfo/login'),


    /**
     * 描述信息：获取领航计划活动列表
     * @author 孔伟杰
     * @date 2020/06/02
     */
    market_active_loadNperList:UrlConfigFormat('/market/active/loadNperList'),

    /**
     * 描述信息：获取领航计划用户消息
     * @author 吴成林
     * @date 2020/06/03
     */
    management_userjoininfo_getById: UrlConfigFormat("/management/userjoininfo/getById"),

    /**
     * 描述信息：根据ID获取系统参数表
     * @author 吴成林
     * @date 2020/06/03
     */
    sysbase_sysparams_info: UrlConfigFormat("/sysbase/sysparams/info"),

    /**
     * 绑定投保订单 -> 见费出单 -> 第三方支付数据
     * @Author 肖家添
     * @Date 2020/7/7 16:20
     */
    management_mobileInsuranceInfo_bindSellBillAtCostHandler: UrlConfigFormat("/management/mobileInsuranceInfo/bindSellBillAtCostHandler"),

    /**
     * 描述信息：新增我的名片动态
     * @author 吴成林
     * @date 2020/07/05
     */
    management_mybusinesscarddyn_save: UrlConfigFormat("/management/mybusinesscarddyn/save"),

    /**
     * 描述信息：修改我的名片 [邮箱、手机号]
     * @author 吴成林
     * @date 2020/07/07
     */
    market_growthrule_updateEmailAndPhone: UrlConfigFormat('/market/growthrule/updateEmailAndPhone'),

    /**
     * 描述信息：根据名片id查询访客记录
     * @author 吴成林
     * @date 2020/07/08
     */
    management_mybusinesscardvisit_getCardVisitList: UrlConfigFormat("/management/mybusinesscardvisit/getCardVisitList"),

    /**
     * 描述信息：我的名片 - 标签点赞 +1
     * @author 吴成林
     * @date 2020/07/08
     */
    management_mybusinesscardlabel_updateLabelPraiseCount: UrlConfigFormat("/management/mybusinesscardlabel/updateLabelPraiseCount"),

    /**
     * 描述信息：我的名片 - 删除动态
     * @author 吴成林
     * @date 2020/07/08
     */
    management_mybusinesscarddyn_updateCardDynIsenabled: UrlConfigFormat("/management/mybusinesscarddyn/updateCardDynIsenabled"),

    /**
     * 描述信息：我的名片 - 点赞动态
     * @author 吴成林
     * @date 2020/07/08
     */
    management_mybusinesscarddyn_updateCardDynPraiseCount: UrlConfigFormat("/management/mybusinesscarddyn/updateCardDynPraiseCount"),

    /**
     * 描述信息：我的名片 - 新增动态评论
     * @author 吴成林
     * @date 2020/07/08
     */
    management_mybusinesscardcomment_save: UrlConfigFormat("/management/mybusinesscardcomment/save"),

    /**
     * 描述信息：我的名片 - 点赞动态评论
     * @author 吴成林
     * @date 2020/07/09
     */
    management_mybusinesscardcomment_updateCommentPraiseCount: UrlConfigFormat("/management/mybusinesscardcomment/updateCommentPraiseCount"),

    /**
     * 描述信息：查找openId是否存在
     * @author 吴成林
     * @date 2020/07/13
     */
    member_weixinbase_findOpenId:UrlConfigFormat('/member/weixinbase/findOpenId'),

    /**
     * 描述信息：新增访客记录
     * @author 吴成林
     * @date 2020/07/13
     */
    management_mybusinesscardvisit_save: UrlConfigFormat("/management/mybusinesscardvisit/save"),

    /**
     * 保存事件记录
     * @Author 肖家添
     * @Date 2020/7/13 16:21
     */
    management_traceeventloginfo_save: UrlConfigFormat("/management/traceeventloginfo/sys/save"),
    /**
     * 更新事件修改时间
     * @Author 肖家添
     * @Date 2020/7/14 16:07
     */
    management_traceeventloginfo_update: UrlConfigFormat("/management/traceeventloginfo/update"),

    /**
     * 交易大厅首页查询
     * @Author 张豪
     * @Date 2020-7-23 09:48:58
     */
    member_demand_getDemandListToHome: UrlConfigFormat("/member/demand/getDemandListToHome"),
    /**
     * 【发布】我的发布-待接单
     * @Author 张豪
     * @Date 2020-7-23 11:53:53
     */
    member_demand_getDemandIssueList: UrlConfigFormat("/member/demand/getDemandIssueList"),
    /**
     * 【发布】我的发布-待接单（取消,完成-订单）
     * @Author 张豪
     * @Date 2020-7-23 11:53:53
     */
    member_demand_updateDemandState: UrlConfigFormat("/member/demand/updateDemandState"),
    /**
     * 【发布】我的发布-待接单（合作）
     * @Author 张豪
     * @Date 2020-7-24 09:26:33
     */
    member_demand_updateDemandApplyWay: UrlConfigFormat("/member/demand/updateDemandApplyWay"),
    /**
     * 【需求完成】评论
     * @Author 张豪
     * @Date 2020-7-24 11:01:14
     */
    member_demand_updateDemandComment: UrlConfigFormat("/member/demand/updateDemandComment"),
    /**
     * 【任务】
     * @Author 张豪
     * @Date 2020-7-24 11:21:08
     */
    member_demand_getDemandTaskList: UrlConfigFormat("/member/demand/getDemandTaskList"),

    /**
     * 【任务】申请中-撤销申请
     * @Author 张豪
     * @Date 2020-7-24 11:21:08
     */
    member_demand_updateApplyWay: UrlConfigFormat("/member/demandapplyinfo/updateApplyWay"),
    /**
     * 【任务】申请中-撤销申请
     * @Author 张豪
     * @Date 2020-7-24 11:21:08
     */
    member_demand_getMemberId: UrlConfigFormat("/member/demand/getMemberId"),

    member_traceeventloginfo_update: UrlConfigFormat("/management/traceeventloginfo/update"),
    /**
     * 交易大厅_交易大厅保存需求发布
     * @Author 吴国福
     * @Date 2020/7/22 17:07
     */
    member_demand_insertDemand: UrlConfigFormat("/member/demand/insertDemand"),
    /**
     * 交易大厅_查询需求详情
     * @Author 吴国福
     * @Date 2020/7/22 17:07
     */
    member_demand_getDemandById: UrlConfigFormat("/member/demand/getDemandById"),
    /**
     * 交易大厅_查看交易列表的列表数据
     * @Author 吴国福
     * @Date 2020/7/22 17:07
     */
    member_demand_getDemandBuyList: UrlConfigFormat("/member/demand/getDemandBuyList"),
    /**
     * 交易大厅_查询发布需求时所需要的险种标签集合
     * @Author 吴国福
     * @Date 2020/7/22 17:07
     */
    member_demand_getLabelList: UrlConfigFormat("/member/demand/getLabelList"),
    /**
     * 交易大厅_保存一个发送申请需求记录
     * @Author 吴国福
     * @Date 2020/7/22 17:07
     */
    member_demand_sendDemandApplyInfo: UrlConfigFormat("/member/demand/sendDemandApplyInfo"),
    /**
     * 交易大厅_取消一个申请记录
     * @Author
     * @Date 2020/7/22 17:07
     */
    member_demandapplyinfo_updateRevocation: UrlConfigFormat("/member/demandapplyinfo/updateRevocation"),
    /**
     * 交易大厅_在线预览接口
     * @Author
     * @Date 2020/7/22 17:07
     */
    member_demand_getOfficePreviewURL: UrlConfigFormat("/member/demand/getOfficePreviewURL"),
    /**
     * 交易大厅_轮播图获取移动端首页数据
     * @Author
     * @Date 2020/7/22 17:07
     */
    management_mobileHome_getHomeData: UrlConfigFormat("/management/mobileHome/getHomeData?terminal=5"),
    /**
     * 我的名片_验证名片是否完善
     * @Author
     * @Date 2020/7/29 19:53
     */
    management_mybusinesscard_verifyCard: UrlConfigFormat("/management/mybusinesscard/verifyCard"),
    /**
     * 交易大厅_在发布需求时上传的文件预览接口,传云id以及url和文件name
     * @Author
     * @Date 2020/8/06 18:07
     */
    member_demand_getCommOfficePreviewURL: UrlConfigFormat("/member/demand/getCommOfficePreviewURL"),

    /**
     * 描述信息：PV/UV/IP统计API
     * @author CMW
     * @date 2020/07/30
     */
    msg_accessstatistics:UrlConfigFormat('/msg/accessstatistics'),

    /**
     * 新版咨询 - 获取文章详情
     * @Author
     * @Date 2020/8/14 16:34
     */
    member_article_getByArticleIdNew: UrlConfigFormat("/member/article/getByArticleIdNew"),

    /**
     * 新版咨询 - 获取评论列表
     * @Author
     * @Date 2020/8/18 16:34
     */
    member_evaluation_getEvaluationListByObjectId: UrlConfigFormat("/member/evaluation/getEvaluationListByObjectId"),

    /**
     * 新版咨询 - 添加评论/回复评论
     * @Author
     * @Date 2020/8/18 16:34
     */
    member_evaluation_evaluationInsert: UrlConfigFormat("/member/evaluation/evaluationInsert"),

    /**
     * 获取会员总积分、可用积分、已用积分
     * @Author
     * @Date 2020/8/19 10:37
     */
    management_integral_getMemberIntegralInfo:UrlConfigFormat('/management/integral/getMemberIntegralInfo'),

    /**
     * 屏幕录制记录保存
     * @Author 肖家添
     * @Date 2020/8/20 10:26
     */
    management_traceeventscreenrecord_save: UrlConfigFormat("/management/traceeventscreenrecord/save"),

    /**
     * 获取新版首页 小白精选
     * @Author
     * @Date 2020/9/2 16:37
     */
    management_insuranceInfo_getNewHomeInsuranceInfoList: UrlConfigFormat('/management/insuranceInfo/getNewHomeInsuranceInfoList'),

    /**
     * 获取新版首页 热门资讯
     * @Author
     * @Date 2020/9/2 16:37
     */
    member_article_getNewArticleist: UrlConfigFormat('/member/article/getNewLArticleist'),

    /**
     * 获取新版首页 热门回答
     * @Author
     * @Date 2020/9/2 16:37
     */
    member_question_getNewArticleist: UrlConfigFormat('/member/question/getNewLArticleist'),

    /**
     * 获取新版首页 最新课堂
     * @Author
     * @Date 2020/9/2 16:37
     */
    member_course_getNewCourseList: UrlConfigFormat('/member/course/getNewCourseList'),

    /**
     * 店铺 - 创建店铺
     * @Author
     * @Date 2020-9-7 10:34:20
     */
    management_userShopMainInfo_save: UrlConfigFormat('/management/userShopMainInfo/save'),

    /**
     * 店铺 - 获取用户店铺详情
     * @Author
     * @Date 2020-9-7 10:34:20
     */
    management_userShopMainInfo_getUserShopMainList: UrlConfigFormat('/management/userShopMainInfo/getUserShopMainList'),

    /**
     * 店铺 - 修改店铺名称（title）、修改店铺类型（styleType = -1）
     * @Author
     * @Date 2020-9-7 10:34:20
     */
    management_userShopMainInfo_updateUserShop: UrlConfigFormat('/management/userShopMainInfo/updateUserShop'),

    /**
     * 店铺 - 新增店铺产品
     * @Author
     * @Date 2020-9-7 10:34:20
     */
    management_userShopProductInfo_save: UrlConfigFormat('/management/userShopProductInfo/save'),

    /**
     * 店铺 - 修改店铺产品
     * @Author
     * @Date 2020-9-7 10:34:20
     */
    management_userShopProductInfo_updateUserShopProduct: UrlConfigFormat('/management/userShopProductInfo/updateUserShopProduct'),

    /**
     * 店铺 - 重置店铺全部产品
     * @Author
     * @Date 2020-9-7 10:34:20
     */
    management_userShopProductInfo_resetUserShopProduct: UrlConfigFormat('/management/userShopProductInfo/resetUserShopProduct'),

    /**
     * 首页 - 领航达人
     * @Author 肖家添
     * @Date 2020/9/13 12:06
     */
    member_userNavInfo_getNewHomeUserNav: UrlConfigFormat('/member/usernaviinfo/getNewHomeUserNavi'),

    /**
     * 领航达人详情
     * @Author 肖家添
     * @Date 2020/9/13 15:23
     */
    member_userNavInfo_getUserNav: UrlConfigFormat('/member/usernaviinfo/getUserNavi')

};

function UrlConfigFormat(url){
    return SERVER_BASE_URL + url;
}
