

layui.define(function(exports){
  
  exports('test', {
    title: '子目录模块加载'
  })
});