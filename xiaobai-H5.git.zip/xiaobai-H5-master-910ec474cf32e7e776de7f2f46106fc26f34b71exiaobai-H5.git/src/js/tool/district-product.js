//省市级数据
const chinaAreas = [
    {
        "children": [
            {
                "label": "广元市",
                "value": 510800,
                "provinceId": 510000
            },
            {
                "label": "遂宁市",
                "value": 510900,
                "provinceId": 510000
            },
            {
                "label": "内江市",
                "value": 511000,
                "provinceId": 510000
            },
            {
                "label": "乐山市",
                "value": 511100,
                "provinceId": 510000
            },
            {
                "label": "南充市",
                "value": 511300,
                "provinceId": 510000
            },
            {
                "label": "眉山市",
                "value": 511400,
                "provinceId": 510000
            },
            {
                "label": "宜宾市",
                "value": 511500,
                "provinceId": 510000
            },
            {
                "label": "广安市",
                "value": 511600,
                "provinceId": 510000
            },
            {
                "label": "达州市",
                "value": 511700,
                "provinceId": 510000
            },
            {
                "label": "雅安市",
                "value": 511800,
                "provinceId": 510000
            },
            {
                "label": "巴中市",
                "value": 511900,
                "provinceId": 510000
            },
            {
                "label": "资阳市",
                "value": 512000,
                "provinceId": 510000
            },
            {
                "label": "阿坝藏族羌族自治州",
                "value": 513200,
                "provinceId": 510000
            },
            {
                "label": "甘孜藏族自治州",
                "value": 513300,
                "provinceId": 510000
            },
            {
                "label": "凉山彝族自治州",
                "value": 513400,
                "provinceId": 510000
            },
            {
                "label": "成都市",
                "value": 510100,
                "provinceId": 510000
            },
            {
                "label": "自贡市",
                "value": 510300,
                "provinceId": 510000
            },
            {
                "label": "攀枝花市",
                "value": 510400,
                "provinceId": 510000
            },
            {
                "label": "泸州市",
                "value": 510500,
                "provinceId": 510000
            },
            {
                "label": "德阳市",
                "value": 510600,
                "provinceId": 510000
            },
            {
                "label": "绵阳市",
                "value": 510700,
                "provinceId": 510000
            }
        ],
        "label": "四川省",
        "value": 510000
    },
    {
        "children": [
            {
                "label": "沈阳市",
                "value": 210100,
                "provinceId": 210000
            },
            {
                "label": "鞍山市",
                "value": 210300,
                "provinceId": 210000
            },
            {
                "label": "抚顺市",
                "value": 210400,
                "provinceId": 210000
            },
            {
                "label": "本溪市",
                "value": 210500,
                "provinceId": 210000
            },
            {
                "label": "丹东市",
                "value": 210600,
                "provinceId": 210000
            },
            {
                "label": "锦州市",
                "value": 210700,
                "provinceId": 210000
            },
            {
                "label": "营口市",
                "value": 210800,
                "provinceId": 210000
            },
            {
                "label": "阜新市",
                "value": 210900,
                "provinceId": 210000
            },
            {
                "label": "辽阳市",
                "value": 211000,
                "provinceId": 210000
            },
            {
                "label": "盘锦市",
                "value": 211100,
                "provinceId": 210000
            },
            {
                "label": "铁岭市",
                "value": 211200,
                "provinceId": 210000
            },
            {
                "label": "朝阳市",
                "value": 211300,
                "provinceId": 210000
            },
            {
                "label": "葫芦岛市",
                "value": 211400,
                "provinceId": 210000
            }
        ],
        "label": "辽宁省",
        "value": 210000
    },
    {
        "children": [
            {
                "label": "上海市",
                "value": 310100,
                "provinceId": 310000
            }
        ],
        "label": "上海市",
        "value": 310000
    },
    {
        "children": [
            {
                "label": "南京市",
                "value": 320100,
                "provinceId": 320000
            },
            {
                "label": "无锡市",
                "value": 320200,
                "provinceId": 320000
            },
            {
                "label": "徐州市",
                "value": 320300,
                "provinceId": 320000
            },
            {
                "label": "常州市",
                "value": 320400,
                "provinceId": 320000
            },
            {
                "label": "苏州市",
                "value": 320500,
                "provinceId": 320000
            },
            {
                "label": "南通市",
                "value": 320600,
                "provinceId": 320000
            },
            {
                "label": "连云港市",
                "value": 320700,
                "provinceId": 320000
            },
            {
                "label": "淮安市",
                "value": 320800,
                "provinceId": 320000
            },
            {
                "label": "盐城市",
                "value": 320900,
                "provinceId": 320000
            },
            {
                "label": "扬州市",
                "value": 321000,
                "provinceId": 320000
            },
            {
                "label": "镇江市",
                "value": 321100,
                "provinceId": 320000
            },
            {
                "label": "泰州市",
                "value": 321200,
                "provinceId": 320000
            },
            {
                "label": "宿迁市",
                "value": 321300,
                "provinceId": 320000
            }
        ],
        "label": "江苏省",
        "value": 320000
    },
    {
        "children": [
            {
                "label": "杭州市",
                "value": 330100,
                "provinceId": 330000
            },
            {
                "label": "宁波市",
                "value": 330200,
                "provinceId": 330000
            },
            {
                "label": "温州市",
                "value": 330300,
                "provinceId": 330000
            },
            {
                "label": "嘉兴市",
                "value": 330400,
                "provinceId": 330000
            },
            {
                "label": "湖州市",
                "value": 330500,
                "provinceId": 330000
            },
            {
                "label": "绍兴市",
                "value": 330600,
                "provinceId": 330000
            },
            {
                "label": "金华市",
                "value": 330700,
                "provinceId": 330000
            },
            {
                "label": "衢州市",
                "value": 330800,
                "provinceId": 330000
            },
            {
                "label": "舟山市",
                "value": 330900,
                "provinceId": 330000
            },
            {
                "label": "台州市",
                "value": 331000,
                "provinceId": 330000
            },
            {
                "label": "丽水市",
                "value": 331100,
                "provinceId": 330000
            }
        ],
        "label": "浙江省",
        "value": 330000
    },
    {
        "children": [
            {
                "label": "福州市",
                "value": 350100,
                "provinceId": 350000
            },
            {
                "label": "莆田市",
                "value": 350300,
                "provinceId": 350000
            },
            {
                "label": "三明市",
                "value": 350400,
                "provinceId": 350000
            },
            {
                "label": "泉州市",
                "value": 350500,
                "provinceId": 350000
            },
            {
                "label": "漳州市",
                "value": 350600,
                "provinceId": 350000
            },
            {
                "label": "南平市",
                "value": 350700,
                "provinceId": 350000
            },
            {
                "label": "龙岩市",
                "value": 350800,
                "provinceId": 350000
            },
            {
                "label": "宁德市",
                "value": 350900,
                "provinceId": 350000
            }
        ],
        "label": "福建省",
        "value": 350000
    },
    {
        "children": [
            {
                "label": "天津市",
                "value": 120100,
                "provinceId": 120000
            }
        ],
        "label": "天津市",
        "value": 120100
    },
    {
        "children": [
            {
                "label": "北京市",
                "value": 110100,
                "provinceId": 110000
            }
        ],
        "label": "北京市",
        "value": 110000
    },
    {
        "children": [
            {
                "label": "仙桃市",
                "value": 421400,
                "provinceId": 420000
            },
            {
                "label": "天门市",
                "value": 421500,
                "provinceId": 420000
            },
            {
                "label": "潜江市",
                "value": 421600,
                "provinceId": 420000
            },
            {
                "label": "神农架林区",
                "value": 421700,
                "provinceId": 420000
            },
            {
                "label": "武汉市",
                "value": 420100,
                "provinceId": 420000
            },
            {
                "label": "黄石市",
                "value": 420200,
                "provinceId": 420000
            },
            {
                "label": "十堰市",
                "value": 420300,
                "provinceId": 420000
            },
            {
                "label": "宜昌市",
                "value": 420500,
                "provinceId": 420000
            },
            {
                "label": "襄樊市",
                "value": 420600,
                "provinceId": 420000
            },
            {
                "label": "鄂州市",
                "value": 420700,
                "provinceId": 420000
            },
            {
                "label": "荆门市",
                "value": 420800,
                "provinceId": 420000
            },
            {
                "label": "孝感市",
                "value": 420900,
                "provinceId": 420000
            },
            {
                "label": "荆州市",
                "value": 421000,
                "provinceId": 420000
            },
            {
                "label": "黄冈市",
                "value": 421100,
                "provinceId": 420000
            },
            {
                "label": "咸宁市",
                "value": 421200,
                "provinceId": 420000
            },
            {
                "label": "随州市",
                "value": 421300,
                "provinceId": 420000
            },
            {
                "label": "恩施土家族苗族自治州",
                "value": 422800,
                "provinceId": 420000
            }
        ],
        "label": "湖北省",
        "value": 420000
    },
    {
        "children": [
            {
                "label": "清远市",
                "value": 441800,
                "provinceId": 440000
            },
            {
                "label": "广州市",
                "value": 440100,
                "provinceId": 440000
            },
            {
                "label": "韶关市",
                "value": 440200,
                "provinceId": 440000
            },
            {
                "label": "深圳市",
                "value": 440300,
                "provinceId": 440000
            },
            {
                "label": "珠海市",
                "value": 440400,
                "provinceId": 440000
            },
            {
                "label": "汕头市",
                "value": 440500,
                "provinceId": 440000
            },
            {
                "label": "佛山市",
                "value": 440600,
                "provinceId": 440000
            },
            {
                "label": "江门市",
                "value": 440700,
                "provinceId": 440000
            },
            {
                "label": "湛江市",
                "value": 440800,
                "provinceId": 440000
            },
            {
                "label": "茂名市",
                "value": 440900,
                "provinceId": 440000
            },
            {
                "label": "肇庆市",
                "value": 441200,
                "provinceId": 440000
            },
            {
                "label": "惠州市",
                "value": 441300,
                "provinceId": 440000
            },
            {
                "label": "梅州市",
                "value": 441400,
                "provinceId": 440000
            },
            {
                "label": "汕尾市",
                "value": 441500,
                "provinceId": 440000
            },
            {
                "label": "河源市",
                "value": 441600,
                "provinceId": 440000
            },
            {
                "label": "阳江市",
                "value": 441700,
                "provinceId": 440000
            },
            {
                "label": "东莞市",
                "value": 441900,
                "provinceId": 440000
            },
            {
                "label": "中山市",
                "value": 442000,
                "provinceId": 440000
            },
            {
                "label": "潮州市",
                "value": 445100,
                "provinceId": 440000
            },
            {
                "label": "揭阳市",
                "value": 445200,
                "provinceId": 440000
            },
            {
                "label": "云浮市",
                "value": 445300,
                "provinceId": 440000
            }
        ],
        "label": "广东省",
        "value": 440000
    },
    {
        "children": [
            {
                "label": "重庆市",
                "value": 500100,
                "provinceId": 500000
            }
        ],
        "label": "重庆市",
        "value": 500000
    }
];