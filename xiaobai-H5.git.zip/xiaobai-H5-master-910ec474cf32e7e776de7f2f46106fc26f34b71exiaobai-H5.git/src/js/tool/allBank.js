let bank = [
    {
        label : "北京银行",
        value : 0
    },
    {
        label : "广发银行",
        value : 1
    },
    {
        label : "华夏银行",
        value : 2
    },
    {
        label : "交通银行",
        value : 3
    },
    {
        label : "宁波银行",
        value : 4
    },
    {
        label : "平安银行",
        value : 5
    },
    {
        label : "上海浦东发展银行",
        value : 6
    },
    {
        label : "上海银行",
        value : 7
    },
    {
        label : "兴业银行",
        value : 8
    },
    {
        label : "中国银行",
        value : 9
    },
    {
        label : "中国工商银行",
        value : 10
    },
    {
        label : "中国农业银行",
        value : 11
    },
    {
        label : "中国建设银行",
        value : 12
    },
    {
        label : "中信银行",
        value : 13
    },
    {
        label : "中国光大银行",
        value : 14
    },
    {
        label : "中国民生银行",
        value : 15
    },
    {
        label : "招商银行",
        value : 16
    },
    {
        label : "中国邮政储蓄银行",
        value : 17
    }

]