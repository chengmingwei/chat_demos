

/**
 * Store [global configuration, toolkit, public resource loading] and so on.
 * Don't format code for this document.
 *
 * 此处存放 [全局配置、工具包、公共资源加载] 等内容
 * 不要格式化本文件的内容
 *
 * @Author 肖家添
 * @Date 2019/8/28 20:36
 */


//--------------------------------------- BASE APP START ---------------------------------------//


/**
 * [SERVER_BASE_URL] -> 服务后台的地址
 * [FRONT_PROJECT_NAME] -> H5项目的名称
 * @Author 肖家添
 * @Date 2019/8/28 18:39
 */
let SERVER_BASE_URL, FRONT_PROJECT_NAME, VERSION, PAGE_APP, WEBSOCKET_URL;

/**
 * 初始化应用环境
 * @Author 肖家添
 * @Date 2019/8/28 18:48
 */
(function() {

	//-- 系统环境
	const systemEnvironment = "Lin";
    //-- 系统版本 以当前日期为版本号
	VERSION = "20200330";
	switch(systemEnvironment) {
		case "Cmw": {
			//SERVER_BASE_URL = "https://wxtestapi.xiaobaibao.com";//生产环境
            // WEBSOCKET_URL = "ws://wxtestapi.xiaobaibao.com/ws";//生成环境
            // WEBSOCKET_URL = "ws://newtest.xiaobaibao.com/ws";//测试环境
            SERVER_BASE_URL = "http://eureka.com:8842";//newtest.xiaobaibao.com
			WEBSOCKET_URL = "ws://eureka.com:8088/ws";//newtest.xiaobaibao.com:8088
            //WEBSOCKET_URL = "ws://119.23.186.31:9099/ws";//newtest.xiaobaibao.com:8088
			FRONT_PROJECT_NAME = "/xiaobai-H5/";
			break;
		}
		case "Mr.Shaw": {
			// SERVER_BASE_URL = "http://eureka.com:8842";
			// SERVER_BASE_URL = "http://shaw.natapp1.cc";
            // SERVER_BASE_URL = "https://wxtestapi.xiaobaibao.com";				// 生产环境
			SERVER_BASE_URL = "http://newtestapi.xiaobaibao.com:8081";		    // 测试环境
			WEBSOCKET_URL = "ws:///eureka.com:8088/ws";
			FRONT_PROJECT_NAME = "/xiaobai-H5/";
			break;
		}
		case "Kong": {
            SERVER_BASE_URL = "http://127.0.0.1:8842";
			WEBSOCKET_URL = "ws:///eureka.com:8088/ws";
			FRONT_PROJECT_NAME = "/xiaobai/";
			break;
		}
		case "Lin": {
			//SERVER_BASE_URL = "http://192.168.0.121:8842";
			WEBSOCKET_URL = "ws:///eureka.com:8088/ws";
			//SERVER_BASE_URL = "https://wxtestapi.xiaobaibao.com";
			SERVER_BASE_URL = "http://newtestapi.xiaobaibao.com:8081";//测试环境
			FRONT_PROJECT_NAME = "/xiaobai/";
			break;
		}
		case "parzival": {
			SERVER_BASE_URL = "http://192.168.0.124:8842";
			WEBSOCKET_URL = "ws:///eureka.com:8088/ws";
			//SERVER_BASE_URL = "https://wxtestapi.xiaobaibao.com";
			//SERVER_BASE_URL = "http://newtestapi.xiaobaibao.com:8081";//测试环境
			FRONT_PROJECT_NAME = "/xiaobai/";
			break;
		}
		case "localhost":{
			SERVER_BASE_URL = "http://localhost:8842";
			WEBSOCKET_URL = "ws:///eureka.com:8088/ws";
			FRONT_PROJECT_NAME = "/xiaobai-H5/";
			break;
		}
		case "online": {
			SERVER_BASE_URL = "https://wxtestapi.xiaobaibao.com";  //生产环境
            WEBSOCKET_URL = "wss://mtadmin.xiaobaibao.com/ws";   //生产环境
			FRONT_PROJECT_NAME = "/";
			break;
        }
        case "onlinetest": {
            SERVER_BASE_URL = "http://newtestapi.xiaobaibao.com:8081";//测试环境
            WEBSOCKET_URL = "ws://newtest.xiaobaibao.com:9091/ws";//测试环境
            FRONT_PROJECT_NAME = "/";
            break;
        }
	}
	try{
		//-- 通过使用变量{InsuranceAPP}的方式, 来区分是H5还是APP
        console.log(InsuranceAPP);
        PAGE_APP = true;
    }catch (e) {
        PAGE_APP = false;
    }

})();

/**
 * 工具方法集合
 * @Author 肖家添
 * @Date 2019/8/28 18:43
 */
const ShawHandler = {

	/**
	 * 常量
	 * @Author 肖家添
	 * @Date 2019/9/4 11:23
	 */
	constant: {
		/**
		 * 登录成功后存放在客户端的 [Cache Key]
		 * @Author 肖家添
		 * @Date 2019/8/28 20:38
		 */
		tokenKey: "MYRCIB_USER_TOKEN",

		/**
		 * 线上服务端域名
		 * @Author 肖家添
		 * @Date 2019/11/15 14:48
		 */
		clientDomain: "mtadmin.xiaobaibao.com",

		/**
		 * OSS生产环境
		 * @Author 肖家添
		 * @Date 2019/11/15 14:46
		 */
		ossDomain_product: "https://pic.xiaobaibao.com",

        /**
         * PDF生产环境
         * @Author 肖家添
		 * @Modify 吴成林
         * @Date 2019/12/5 18:41
		 * @modifyDate 2020-9-24 19:30:47
         */
        //pdfDomain_product: "http://pdf.xiaobaibao.com",
        pdfDomain_product: "http://pic.xiaobaibao.com",

		/**
		 * OSS测试环境
		 * @Author 肖家添
		 * @Date 2019/11/15 14:46
		 */
		ossDomain_dev: "https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com",

        /**
         * PDF测试环境
         * @Author 肖家添
		 * @Modify 吴成林
         * @Date 2019/12/5 18:41
		 * @modifyDate 2020-9-24 19:30:47
         */
        //pdfDomain_dev: "http://pdftest.xiaobaibao.com",
        pdfDomain_dev: "http://pictest.xiaobaibao.com",

		/**
		 * 错误提示
		 * @Author 肖家添
		 * @Date 2019/8/29 18:04
		 */
		errorMsg: "系统繁忙，请稍后重试！",

		/**
		 * 成功提示
		 * @Author 肖家添
		 * @Date 2019/9/20 10:53
		 */
		successMsg: "操作成功",

		/**
		 * 冻结页面容器的Id
		 * @Author 肖家添
		 * @Date 2019/9/9 18:44
		 */
		frozenPage: `FROZEN-PAGE-APPLICATION-${Date.parse(new Date().toDateString())}`,

		/**
		 * 加载层
		 * @Author 肖家添
		 * @Date 2019/9/11 14:44
		 */
		loadingElement: null,

        /**
         * 分页默认参数
         * @Author 肖家添
         * @Date 2019/10/15 12:14
         */
        paginationDefault: {
            _pageSize: 10,
            _current: 1,
            _total: 0
		},

		/**
		 * 分页加载层 Class
		 * @Author 肖家添
		 * @Date 2019/10/22 12:21
		 */
		pagingLoadingClsName: "PAGING_SHAW",

		/**
		 * 微信授权类型
		 * @Author 肖家添
		 * @Date 2019/11/22 19:14
		 */
		weChatAuthorizeType: {
			/**
			 * 静默授权
			 */
			TYPE_10001: 10001,
			/**
			 * 用户授权
			 */
			TYPE_10002: 10002,
		},

		/**
		 * 微信授权业务类型
		 * @Author 肖家添
		 * @Date 2019/11/22 19:14
		 */
		weChatAuthorizeBusinessType: {
			/**
			 * 微信静默授权
			 */
			WX_AUTHORIZE_1: "WE_CHAT_AUTHORIZE_1",
			/**
			 * 微信内用户授权登录
			 */
			WX_AUTHORIZE_2: "WE_CHAT_AUTHORIZE_2",
            /**
             * 新人红包专享
             */
            WX_AUTHORIZE_3: "WE_CHAT_AUTHORIZE_3",
			/**
			 * 首页静默授权
			 */
			WX_AUTHORIZE_4: "WE_CHAT_AUTHORIZE_4",
			/**
			 * 浏览记录静默授权
			 */
			WX_AUTHORIZE_5: "WE_CHAT_AUTHORIZE_5",
			/**
			 * 浏览记录用户授权
			 */
			WX_AUTHORIZE_6: "WE_CHAT_AUTHORIZE_6",
            /**
             * 名片、评价 用户授权
             */
            WX_AUTHORIZE_7: "WE_CHAT_AUTHORIZE_7",
		},

		/**
		 * 推广费显示/关闭的 KEY
		 * @Author 肖家添
		 * @Date 2019/10/31 11:49
		 */
		promotionFeeDisplayKey: "PRODUCT_PROMOTION_FEE_SHOW_TIPS",

		/**
		 * 无结果集视图Id
		 * @Author 肖家添
		 * @Date 2019/10/31 18:19
		 */
		showNoResultViewClass: "SHOW_NO_RESULT_VIEW_ID",

		/**
		 * 分享提示窗口Id
		 * @Author 肖家添
		 * @Date 2019/11/12 15:49
		 */
		shareTipsViewId: "SHARE_TIPS_VIEW",

		/**
		 * 分享Logo
		 * @Author 肖家添
		 * @Date 2019/11/20 9:55
		 */
		shareLogo: "https://pic.xiaobaibao.com/app/appHomePic/2019/11/tempFilesb77d76a5f3dc42e4aa3b16b15e094b9b_small.png",

		/**
		 * 微信用户手动退出登录的 KEY
		 * @Author 吴成林
		 * @Date 2019/11/22 14:56
		 */
		weChatUserManualExitKey: "WE_CHAT_USER_MANUAL_exit",

		/**
		 * 会员默认头像
		 * @Author 肖家添
		 * @Date 2019/12/3 11:15
		 */
		memberDefaultImagePath: `${FRONT_PROJECT_NAME}src/images/my/defaultImg.png`,

		/**
		 * RSA公钥
		 * @Author 肖家添
		 * @Date 2020/7/8 16:36
		 */
		rsaPublicKey: `
			-----BEGIN PUBLIC KEY-----
			MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDZC9ZIANRrzd0GJVRmJwFO2/vz
			sWaKL3WDi5MzaGdGzbxpc4d6opzivmZuagExQXuGCOMVDfcE6cafhcO3hBhv5yZe
			4s2i6LfE0t5vlI3clo3k+D4TA87IrddseVa5OfAx0UscQcQeR6sNjtVOKB7nEOdR
			feKKU0uFhQi1nhHIcQIDAQAB
			-----END PUBLIC KEY-----
		`,

		/**
		 * 请求数据RSA标识
		 * @Author 肖家添
		 * @Date 2020/7/9 15:23
		 */
		requestRSATips: "REQUEST_RSA_TIPS",

		/**
		 * 数据库  `` database of loki
		 * @Author 肖家添
		 * @Date 2020/8/19 15:47
		 */
		db: {
			/**
			 * 屏幕录制
			 * @Author 肖家添
			 * @Date 2020/8/19 15:47
			 */
			screenRecording: {
				dbName: "XB_SCREEN_RECORDING",
				tables: {
					screen: "screen"
				}
			}
		}
	},

	/**
	 * 正则表达式
	 * @Author 肖家添
	 * @Date 2019/8/29 20:52
	 */
	reg: {
		/**
		 * 密码验证
		 * @Author 肖家添
		 * @Date 2019/8/29 20:50
		 */
		passwordReg : /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,16}$/,
		/**
		 * 手机验证
		 * @Author 肖家添
		 * @Date 2019/8/29 20:51
		 */
		phoneReg: /^0?(13[0-9]|14[0-9]|15[0-9]|16[0-9]|17[0-9]|18[0-9]|19[0-9])[0-9]{8}$/,
		/**
		 * 固定电话
		 * @Author 肖家添
		 * @Date 2020/2/14 18:08
		 */
		fixedTelephoneReg: /^\d{3}-\d{8}|\d{4}-\d{7}$/,
		/**
		 * 银行卡验证
		 * @Author 肖家添
		 * @Date 2019/9/29 21:27
		 */
		bankCardReg: /^\d{16,19}$/,
		/**
		 * 数字和字母组合
		 * @Author 肖家添
		 * @Date 2019/11/8 14:24
		 */
		numAndLetterReg: /^[0-9a-zA-Z]*$/,
		/**
		 * 数字和字母和括号组合
		 * @Author 肖家添
		 * @Date 2019/11/8 14:24
		 */
		numAndLetterAndBracketsReg: /^[0-9a-zA-Z()]*$/,
		/**
		 * 邮箱验证
		 * @Author 肖家添
		 * @Date 2019/11/13 10:41
		 */
		emailReg: /^([a-zA-Z0-9_\.\-])+[\@,\＠](([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/,

		/**
		 * 中国护照
		 */
		cPassportReg: /^([a-zA-z]|[0-9]){5,17}$/,
		/**
		 * 外国护照
		 */
		wPassportReg: /^[1][3,4,5,7,8][0-9]{9}$/,
		/**
		 * 出生证
		 */
		birthCardReg: /^[a-zA-Z0-9]{5,21}$/,
		/**
		 * 港澳台通行证、回乡证
		 */
		homeReg: /^[a-zA-Z0-9]{6,10}$/,
		/**
		 * 统一社会信用代码
		 */
		creditReg: /^([0-9A-HJ-NPQRTUWXY]{2}\d{6}[0-9A-HJ-NPQRTUWXY]{10}|[1-9]\d{14})$/,
		/**
		 * 组织机构代码证
		 */
		tissueReg: /^[a-zA-Z0-9]{10,20}$/,
		/**
		 * 税务登记号
		 */
		taxReg: /^[0-9a-zA-z_]{18}$/,
		/**
		 * 营业执照
		 */
		businessReg: /^[a-zA-Z0-9]{10,20}$/,
	},

	/**
	 * Request data
	 *
	 * [url]: Request url
	 * [pars]: Params
	 * [sfn]: Success callback
	 * [ffn]: Fail callback
	 * [loading]: Whether to display load mask, default is false
	 * [method]: Request method, default is post
	 * [sfnWaitTime]: The waiting time after the request succeeds, default is 0
	 * [requestBody]: When set to true, the background uses @RequestBody to accept
	 * [checkLogin]: If not login, go to login, default is false
	 *
	 * @Author 肖家添
	 * @Date 2019/8/28 19:36
	 */
	request: function(
		{
			url = "",
			pars = {},
			sfn = null,
			ffn = null,
			loading = false,
			method = "POST",
			sfnWaitTime = 0,
			requestBody = false,
			checkLogin = false,
			headers = { }
		}) {

		if(checkLogin){
			if(!ShawHandler.checkLogin()){
				ShawHandler.confirmLogin(() => {
					if(PAGE_APP){
						$$.pushAPP("/main", { "defaultPageIndex": 0 });
						return;
					}
					ShawHandler.push("newIndex");
				});
				return;
			}
		}

		if(loading) ShawHandler.loading();

		const tokenKey = ShawHandler.constant.tokenKey;
		if(!headers[tokenKey]){
			headers[tokenKey] = localStorage.getItem(tokenKey);
		}

		axios({
			url: url,
			method: method,
			headers: headers,
			timeout: 60 * 1000 * 10,
			params: requestBody ? "" : pars,
			data: requestBody ? pars : ""
		}).then(function(data) {
			if(sfn){
				setTimeout(function(){
					data = data.data;
					const { TIPS_HTTP_STATUS } = data;

					//-- statusCode -> [403: 自定义非正常操作业务范围]
					if(TIPS_HTTP_STATUS === 403){
						ShawHandler.closeLoading();

						if(ffn) {
							ffn(data);
						}else {
							ShawHandler.errorHandler("当前操作被终止！请稍后重试");
						}
						return;
					}

					sfn(data);
				}, sfnWaitTime);
			}
		}).catch(function(error){
			try{
				if(loading){
					ShawHandler.closeLoading();
				}

				if(error.response){
					const { data, status } = error.response;

					if(status === 401){

						//-- 登录页面401处理
						if(location.pathname.endsWith("login/login.html")){
							ShawHandler.throwTips("登录失败，请检查账号密码是否输入正确！");
						}else if(location.pathname.endsWith("login/getCode.html")){
							ShawHandler.throwTips("登录失败，请检查验证码是否输入正确！");
						}
						statusCodeFor401(data);
						return;
					}else if(status === 403){
						ShawHandler.alert("您无权限访问此页面！", function(){
							// ShawHandler.push("index");
                            ShawHandler.push('my/purchaseVIP/purchaseVIP');
						});
						return;
					}

					if(ffn) {
						ffn(data);
					}else{
						let errorMsg = data.message;
						if(errorMsg === "GENERAL"){
                            errorMsg = "系统维护中，请稍后重试！";
                        }

						ShawHandler.errorHandler(errorMsg);
					}
				}
			}catch (e) {
				console.error(e);

				ShawHandler.closeLoading();
			}
		});

		/**
		 * 状态码[401]未登录或会话超时处理
		 * @Author 肖家添
		 * @Date 2019/9/9 16:39
		 */
		function statusCodeFor401(responseJSON){

			//-- 冻结页面
			ShawHandler.frozenPage();

			//-- 清除登录记录
			localStorage.removeItem(ShawHandler.constant.tokenKey);

			if(!ShawHandler.isValidObj(responseJSON)){

				if (url.indexOf('newtest.xiaobaibao.com') > -1) {
                    ShawHandler.errorHandler('url:' + url);
                    setTimeout(function(){
                        ShawHandler.gotoLogin();
                    }, 5000);
                } else {
                    ShawHandler.errorHandler("会话超时，请重新登录！");
                    setTimeout(function(){
                        ShawHandler.gotoLogin();
                    }, 600);
                }
			}
		}
	},

	/**
	 * 打开登录页面，登录完成会跳转回当前页面
	 * @Author 肖家添
	 * @Date 2019/9/20 14:30
	 */
	gotoLogin: function(){
	    if(PAGE_APP){
	        $$.pushAPP("/account/login", {
				loginSuccessBack: true
			});
	        return;
        }
		ShawHandler.push("login/login", {
			returnUrl: encodeURIComponent(window.location.href)
		});
	},

	/**
	 * 判断object是否为空, [true]: 不为空, [false]: 为空
	 * @Author 肖家添
	 * @Date 2019/8/20 14:45
	 */
	isValidObj: function(obj, msg, stopThread) {
		if(obj == null || (obj + "") == "" || (obj + "").length <= 0 || obj == undefined) {

			if(msg) ShawHandler.layerToast(msg);
			if(stopThread) ShawHandler.throw(msg);

			return false;
		}

		return true;
	},

	/**
	 * 描述信息：判断头像是否为空，空就默认值
	 * @author 覃创斌
	 * @date 2019/11/7
	*/
	isValidHeadImg: function(HeadImg) {
		if(HeadImg == null || (HeadImg + "") == "" || (HeadImg + "").length <= 0 || HeadImg == undefined) {
			return 'https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com/picFile/2019/11/tempFilesed47803481e64b9cbb87c54feccf165a_small.png';
		}
		return HeadImg;
	},

	/**
	 * 判断object是否为空，为空中断线程
	 * @Author 肖家添
	 * @Date 2019/9/27 11:23
	 */
	isValidObjThrow: function(obj, msg){
		ShawHandler.isValidObj(obj, msg, true);
	},

	/**
	 * 验证正则表达式
	 * @Author 肖家添
	 * @Date 2019/11/13 10:32
	 */
	checkReg: function(obj, reg, msg = "格式有误！", isThrow = false){
		const checkResult = reg.test(obj);
		if(!checkResult && isThrow){
			ShawHandler.throwTips(msg);
		}

		return checkResult;
	},

	/**
	 * 验证正则表达式
	 * @Author 肖家添
	 * @Date 2019/11/13 10:35
	 */
	checkRegThrow: function(obj, reg, msg){
		ShawHandler.checkReg(obj, reg, msg, true);
	},

	/**
	 * 检查DOM是否存在某某样式
	 * @Author 肖家添
	 * @Date 2019/10/9 20:54
	 */
	checkHasCls: function({ele, clsName = "active", throws = true}){
		const canContinue = $(ele).hasClass(clsName);
		if(!canContinue){
			if(throws){
				ShawHandler.throw(`checkNotHasCls -> ${clsName}`);
			}
		}

		return canContinue;
	},

	/**
	 * 验证手机格式是否正确
	 * @Author 肖家添
	 * @Date 2019/8/28 19:43
	 */
	isValidPhone: function(tel, msg = null, throws = false){
		let reg = ShawHandler.reg.phoneReg;

		if(!reg.test(tel)){
			if(msg != null) ShawHandler.layerToast(msg);
			if(throws) ShawHandler.throw();

			return false;
		}
		return true;
	},

	/**
	 * 判断[value]是否为空，为空返回[transfer]内容
	 * @Author 肖家添
	 * @Date 2019/9/3 20:23
	 */
	changeIsNilVal: function(value, transfer){
		if(!ShawHandler.isValidObj(value)){
			return transfer;
		}

		return value;
	},

	/**
	 * 冻结页面
	 * @Author 肖家添
	 * @Date 2019/9/9 18:42
	 */
	frozenPage: function(){
		//-- 增加透明蒙版层，防止页面再触发事件
		const bodyElement = document.getElementsByTagName("body")[0];

		const appendCode = `
			<div id="${ShawHandler.constant.frozenPage}" style="position: fixed; left: 0px; top: 0px; height: 100%; width: 100%; opacity: 0; z-index: 999999999999999999;"></div>
		`;

		bodyElement.innerHTML += appendCode;
	},

	/**
	 * 获取地址栏参数
	 * @Author 肖家添
	 * @Date 2019/8/29 9:57
	 */
	getUrlParam: function(name) {
		const reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
		const r = window.location.search.substr(1).match(reg);

		if(r != null) return unescape(r[2]);

		return null;
	},

	/**
	 * 删除URL参数
	 * @Author 肖家添
	 * @Date 2020/9/18 10:47
	 */
	removeUrlParam: function(url, parameter){
		const urlParts = url.split('?');
		if(urlParts.length >= 2) {
			const prefix = encodeURIComponent(parameter) + '=';
			const pars = urlParts[1].split(/[&;]/g);
			for(let i = pars.length; i-- > 0;) {
				if(pars[i].lastIndexOf(prefix, 0) !== -1) {
					pars.splice(i, 1);
				}
			}
			return urlParts[0] + (pars.length > 0 ? '?' + pars.join('&') : '');
		}
		return url;
	},

    /**
     * 获取域名或者域名/项目名
     * @returns {string}
     */
	getBasePath: function() {
		let pathname = window.location.pathname;
		let bastPath = location.origin;
		if (pathname.indexOf(FRONT_PROJECT_NAME) > -1) {
			bastPath += FRONT_PROJECT_NAME;
			bastPath = bastPath.substring(0,bastPath.length - 1);
		}
		return bastPath;
	},

    /**
     * 获取带http协议host
     * @returns {string}
     */
    getFullHost: function(){
	    let fullHost = '';
	    if(window.location.host.indexOf(ShawHandler.constant.clientDomain) === -1){
            fullHost = "http://" + window.location.host;
        }else{
            fullHost = "https://" + window.location.host;
        }
        return fullHost;
    },

	/**
	 * 页面跳转，传入的路径是pages目录下的内容，如：[login/login]，无需传扩展名
	 * @Author 肖家添
	 * @Date 2019/8/29 10:40
	 */
	push: function(fileRelativePath, params = {}, blankWindow = false){
		if(!ShawHandler.isValidObj(params)){
			params = {};
		}
		try{
			ShawHandler.listenerHelper.push(fileRelativePath, params);
		}catch (e) { }
		const urlPars = ShawHandler.jsonToUrlParams(params),
			url = `${FRONT_PROJECT_NAME}src/pages/${fileRelativePath}.html${urlPars}`;

		if(blankWindow){
			window.open(url, "_blank");
		}else{
			location.href = url;
		}
	},

	/**
	 * 页面返回
	 * @Author 肖家添
	 * @Date 2019/8/29 10:43
	 */
	pop: function(){
		history.back();
	},

	/**
	 * 解除所有事件绑定
	 * @Author 肖家添
	 * @Date 2019/11/19 19:06
	 */
	unBindAll: function(){
		$("*").off();
	},

	/**
	 * 静态跳转自动绑定 -> 给任何元素添加[location-href]属性, 会绑定跳转事件
	 *
	 * location-href: 跳转地址相对路径
	 * 		== -1 -> 暂未开放
	 * 		== -2 -> 返回页面
	 * location-params: 跳转携带的参数, JSON格式
	 * location-login: 检测是否登录
	 *
	 * @Author 肖家添
	 * @Date 2019/10/9 11:33
	 */
	staticPushAutoBind: function(){
		const selected = "location-href";

		ShawHandler.listenerHelper.onTap(`[${selected}]`, function(e){
			let _that = $(e),
				location = _that.attr(`${selected}`),
				params = _that.attr("location-params"),
				checkLogin = _that.attr("location-login");

			if(location == "-1"){
				//-- 暂未开放
				ShawHandler.alert("此功能暂未开放！");
				return;
			}else if(location == "-2"){
				//-- 页面返回
				ShawHandler.pop();
				return;
			}

			try{
				if(ShawHandler.isValidObj(params)){
					params = JSON.parse(params);
				}else{
					ShawHandler.throw();
				}
			}catch (e) {
				params = {};
			}

			if(ShawHandler.isValidObj(checkLogin) && !ShawHandler.checkLogin()){
				ShawHandler.confirmLogin();
				return;
			}

			ShawHandler.push(location, {...params});
			e.stopPropagation();
		});
	},

	/**
	 * JSON 转 Url参数
	 * @Author 肖家添
	 * @Date 2019/8/29 11:01
	 */
	jsonToUrlParams: function(json){
		let urlPars = "";

		if(ShawHandler.isValidObj(json)){
			for(const key in json){
				const val = json[key];
				if(!ShawHandler.isValidObj(val))
					continue;
				urlPars += (!ShawHandler.isValidObj(urlPars) ? "?" : "&") + `${key}=${val}`;
			}
		}

		return urlPars;
	},

	/**
	 * 发送短信验证码
	 * 短信类型sendType -> [1]: 登录验证码, [2]: 注册验证码, [3]: 找回密码验证码
	 * @Author 肖家添
	 * @Date 2019/8/29 15:03
	 */
	sendPhoneCode: function(phone, sendType = 1, callback){
		ShawHandler.loading();

		ShawHandler.request({
			url: UrlConfig.msg_sendPhoneCode,
			loading: true,
			pars: {
				phone: phone,
				sendType: sendType
			},
			sfn: function(data){
				ShawHandler.closeLoading();

				if(data.success){
					if(ShawHandler.isValidObj(callback)){
						callback();
					}
				}else{
					ShawHandler.layerToast(data.msg);
				}
			},
		});
	},

	/**
	 * 重置Input，传入jQuery选择器
	 * @Author 肖家添
	 * @Date 2019/8/29 19:47
	 */
	reSetInput: function(select){
		jQuery(select).val("").focus();
	},

	/**
	 * 错误提示，会关闭加载层
	 * @Author 肖家添
	 * @Date 2019/8/29 18:05
	 */
	errorHandler: function(msg){
		if(!ShawHandler.isValidObj(msg)){
			msg = ShawHandler.constant.errorMsg;
		}

		ShawHandler.closeLoading();
		ShawHandler.alert(msg);
	},

	/**
	 * 页面加载需要一些必填参数的时候，可以调用此方法
	 * @Author 肖家添
	 * @Date 2019/8/29 19:49
	 */
	validPageParams: function(param, callbackUrl = "login/login", callbackParams = {}){
		if(!ShawHandler.isValidObj(param)){
			ShawHandler.frozenPage();
			ShawHandler.layerToast("页面超时...");

			setTimeout(function(){
				ShawHandler.push(callbackUrl, callbackParams);
			}, 1000);

			ShawHandler.throw();
		}
	},

	/**
	 * 登录
	 * @Author 肖家添
	 * @Date 2019/8/29 20:22
	 */
	login: function(account, password, loginType = 1, terminal = 1, callback){
		ShawHandler.request({
			url: UrlConfig.member_login,
			loading: true,
			pars: {
				username: account,
				password: password,
				ltype: loginType,
				terminal: terminal
			},
			sfn: function(data){
				ShawHandler.closeLoading();

				const token = data[ShawHandler.constant.tokenKey];

				if(ShawHandler.isValidObj(token)){
					localStorage.setItem(ShawHandler.constant.tokenKey, token);
					localStorage.setItem("memberId", data.memberId);

					if(!data.weChat) weChatAuthLogin();
					if(callback) callback();
				}
			},
			ffn: function(data){
				ShawHandler.layerToast(data.message);
			}
		});

		function weChatAuthLogin(){
			if(!ShawHandler.weChat.isWx() || location.href.indexOf(ShawHandler.constant.clientDomain) == -1) return;

			ShawHandler.request({
				url: UrlConfig.weChat_authorize,
				pars: {
					authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
					returnUrl: "newIndex.html",
					businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_2,
					otherParams: JSON.stringify({"_checkLogin": true})
				},
				loading: true,
				sfn: function(data){
					ShawHandler.closeLoading();

					if(data.success){
						location.href = data.datas;
					}else ShawHandler.alert(data.msg);
				}
			});

			ShawHandler.throw();
		}
	},

	/**
	 * 描述信息：用于分享记录
	 * @author 覃创斌
	 * @date 2020/3/24
	*/
	share: function(objectId,type){
		ShawHandler.request({
			url: UrlConfig.shareRecord_insertShareRecord,
			loading: true,
			pars: {
				objectId: objectId,
				type: type
			},
			requestBody:true,
			sfn: function(data){
				ShawHandler.closeLoading();
			},
			ffn: function(data){
				ShawHandler.layerToast(data.message);
			}
		});
	},

	/**
	 * 检测客户端是否已经登录，具体的会话超时需按后台的实际状态
	 * @Author 肖家添
	 * @Date 2019/9/17 17:32
	 */
	checkLogin: function(){
		const token = localStorage.getItem(ShawHandler.constant.tokenKey);
		if(ShawHandler.isValidObj(token) && token != "null"){
			return true;
		}else{
			return false;
		}
	},

	/**
	 * 确认登录框
	 * @Author 肖家添
	 * @Date 2019/10/18 10:24
	 */
	confirmLogin: function(onCancel){
		ShawHandler.confirm({
			title: "您还未登录，是否登录？",
			onOk: () => ShawHandler.gotoLogin(),
			onCancel: onCancel
		});
	},

	/**
	 * 图片地址兼容
	 * @Author 肖家添
	 * @Date 2019/9/3 15:39
	 */
	imageUrlCompatible: function(url){
		if(ShawHandler.isValidObj(url)){
			const isFullUrl = url.startsWith("http");

			if(isFullUrl){
				return url;
			}else{
				let prefix = window.location.href,
					{ clientDomain, ossDomain_product, ossDomain_dev } = ShawHandler.constant;
				if(prefix.indexOf(clientDomain) > -1){
					prefix = ossDomain_product;		// 生产环境
				}else{
					prefix = ossDomain_dev;			// 测试环境
				}
				return `${prefix}/${url}`;
			}
		}
	},

    /**
     * PDF地址兼容
     * @Author 肖家添
     * @Date 2019/9/3 15:39
     */
    pdfUrlCompatible: function(url){
        if(ShawHandler.isValidObj(url)){
            const isFullUrl = url.startsWith("http");

            if(isFullUrl){
                return url;
            }else{
                return `${ShawHandler.getPdfUrl()}/${url}`;
            }
        }
    },

    /**
     * 获取PDF前缀
     * @Author 肖家添
     * @Date 2019/12/5 18:45
     */
    getPdfUrl: function(){
        let prefix = window.location.href,
            { clientDomain, ossDomain_product, ossDomain_dev } = ShawHandler.constant;
        if(prefix.indexOf(clientDomain) > -1){
            prefix = ossDomain_product;		// 生产环境
        }else{
            prefix = ossDomain_dev;			// 测试环境
        }
        return prefix;
    },

	/**
	 * 获取一个字符串中指定字符串第n次出现的位置
	 * @Author 吴成林
	 * @Date 2020/9/24 17:36
	 */
	findStringPosition: function(str, field, num){
		let x = str.indexOf(field);
		for (let i = 1; i < num; i++) {
			x = str.indexOf(field, x + 1);
		}
		return x;
	},

	/**
	 * 判断[value]是否为空，为空返回[transfer]内容
	 * @Author 肖家添
	 * @Date 2019/9/3 20:23
	 */
	changeIsNilVal: function(value, transfer){
		if(!ShawHandler.isValidObj(value)){
			return transfer;
		}

		return value;
	},

	/**
	 * 获取当前时间戳
	 * @Author 肖家添
	 * @Date 2019/9/9 18:47
	 */
	getTimeStampNow: function(){
		return new Date().getTime().toString();
	},

	/**
	 * 加载资源文件，不从浏览器缓存中读取，如使用请将JS主体内容写到[window.onload]里面
	 * @Author 肖家添
	 * @Date 2019/9/10 17:41
	 */
	loaderRes: function(config = {css: [], scripts: []}, callback) {
		const css = config.css;
		const scripts = config.scripts;

		//-- 解决浏览器缓存 （有句话不知当讲不当讲[/微笑]）
		// const version = `?v=${ShawHandler.getTimeStampNow()}`;
		const version = ``;

		const transferUrl = function(url){
			if(!url.startsWith("http")){
				url = `${FRONT_PROJECT_NAME}src/${url}`;
			}

			return `${url}${version}`;
		}

		this.load = function() {
			this.loadCSS();
			this.loadScript();
		}

		this.loadCSS = function() {
			if(ShawHandler.isValidObj(css)){
				css.forEach(function(cssLink) {
					document.write(`<link rel="stylesheet" href="${transferUrl(cssLink)}">`)
				});
			}
		}

		this.loadScript = function() {
			if(ShawHandler.isValidObj(scripts)){
				scripts.forEach(function(scriptLink){
					document.write(`<script type="text/javascript" src="${transferUrl(scriptLink)}"></script>`);
				});
			}
		}

		this.load();
	},

	/**
	 * 清空HTML的注释
	 * @Author 肖家添
	 * @Date 2019/10/10 21:42
	 */
	clearHTMLNotes: function(){
		const tips = "data-iframe";
		$("iframe").attr(tips, true);
		$(`*[${tips}=null]`).contents().each(function() {
			if(this.nodeType === Node.COMMENT_NODE) {
				$(this).remove();
			}
		});
	},

	/**
	 * 禁止页面滚动
	 * @Author 肖家添
	 * @Date 2019/11/13 9:34
	 */
	forbidPageRolling: function(){
		$("body").css("overflow", "hidden");
	},

	/**
	 * 恢复页面滚动
	 * @Author 肖家添
	 * @Date 2019/11/13 9:35
	 */
	recoveryPageRolling: function(){
		$("body").css("overflow", "auto");
	},

	/**
	 * 打开加载层
	 * @Author 肖家添
	 * @Date 2019/8/28 20:20
	 */
	loading: function(msg = "加载中"){
		const loading = weui.loading(msg);

		ShawHandler.constant.loadingElement = loading;
	},

	/**
	 * 关闭加载层
	 * @Author 肖家添
	 * @Date 2019/8/28 20:23
	 */
	closeLoading: function(){
		const { loadingElement } = ShawHandler.constant;

		if(ShawHandler.isValidObj(loadingElement)){
			loadingElement.hide(function() {
				ShawHandler.constant.loadingElement = null;
			});
		}
	},

	/**
	 * LayUI Toast 提示
	 * @Author 肖家添
	 * @Date 2019/8/28 19:38
	 */
	layerToast: function(msg = "提示"){

		ShawHandler.closeLoading();

		setTimeout(function(){
			layer.open({
				content: msg,
				time: 3,
				skin: "msg"
			});
		}, 0);
	},

	/**
	 * 弹出提示
	 * @Author 肖家添
	 * @Date 2019/9/16 12:04
	 */
	alert: function(msg = "提示", onOk){
		ShawHandler.closeLoading();

		weui.alert(msg, function(){
			if(onOk) onOk();
		});
	},

	/**
	 * 确认提示
	 * @Author 肖家添
	 * @Date 2019/9/17 19:51
	 */
	confirm: function({title = "提示", onOkLabel = "确定", onCancelLabel = "取消", onOk, onCancel}){

		ShawHandler.closeLoading();

		weui.confirm(title, {
			buttons: [{
				label: onCancelLabel,
				type: "default",
				onClick: () => {
					if(onCancel) onCancel();
				}
			}, {
				label: onOkLabel,
				type: "primary",
				onClick: () => {
					if(onOk) onOk()
				}
			}]
		});
	},

	/**
	 * 异常抛出，终止线程
	 * @Author 肖家添
	 * @Date 2019/9/18 16:38
	 */
	throw: function(msg = "Thread termination"){
		throw msg;
	},

	/**
	 * 弹出toast提示，并终止线程
	 * @Author 肖家添
	 * @Date 2019/9/18 16:41
	 */
	throwTips: function(msg = ShawHandler.constant.errorMsg){
		ShawHandler.layerToast(msg);
		ShawHandler.throw(msg);
	},

	/**
	 * 弹出顶部tips提示，并终止线程
	 * @Author 肖家添
	 * @Date 2019/9/20 10:37
	 */
	throwTopTips: function(msg = ShawHandler.constant.errorMsg, time = 2000){
		ShawHandler.topTips(msg, time);
		ShawHandler.throw();
	},

	/**
	 * 顶部提示
	 * @Author 肖家添
	 * @Date 2019/9/20 10:51
	 */
	topTips: function(msg = ShawHandler.constant.errorMsg, time = 2000){
		weui.topTips(msg, time);
	},

	/**
	 * 微信Toast
	 * @Author 肖家添
	 * @Date 2019/9/20 10:54
	 */
	weChatToast(msg = ShawHandler.constant.successMsg, time = 2000){
		weui.toast(msg, time);
	},

	/**
	 * 关于WeChat的放在此处
	 * @Author 肖家添
	 * @Date 2019/9/11 14:30
	 */
	weChat: {
		/**
		 * 判断当前网页是否在微信内
		 * @Author 肖家添
		 * @Date 2019/10/13 11:37
		 */
		isWx: function(){
			try {
				return navigator.userAgent.toLowerCase().indexOf("micromessenger") !== -1;
			}catch (e) {
				console.error(e);
			}

			return false;
		},
		/**
		 * 获取数组的第一个元素，没有返回[null]，适用于[picker, datePicker]等组件设置默认值的时候使用
		 * @Author 肖家添
		 * @Date 2019/9/11 14:30
		 */
		getFirstItemKeyByArr: function(arr, valKey){
			if(ShawHandler.isValidObj(arr) && arr.length > 0){
				return arr[0][valKey];
			}

			return null;
		},

		/**
		 * 转换WeChat日期选择结果
		 * @Author 肖家添
		 * @Date 2019/12/3 17:27
		 */
		transferDateByWeChatSelect: function(result){
			let dateStr = "";
			for (let item in result) {
				let { value } = result[item];
				if(value < 10){
					value = "0" + value;
				}
				dateStr += (ShawHandler.isValidObj(dateStr) ? "-" : "") + value;
			}

			return dateStr;
		},

		pay: {
			/**
			 * 公众号支付
			 * @Author 肖家添
			 * @Date 2019/12/3 17:26
			 */
			publicAddressPayment: function(data, callback, ffn){
				if(typeof data == "string"){
					data = JSON.parse(data);
				}

				function onBridgeReady(){
					WeixinJSBridge.invoke('getBrandWCPayRequest', {...data}, function(res){
						if(res.err_msg == "get_brand_wcpay_request:ok" ){
							if(callback) callback();
						}else{
							if(ffn) ffn();
						}
					});
				}

				if (typeof WeixinJSBridge == "undefined"){
					if( document.addEventListener ){
						document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
					}else if (document.attachEvent){
						document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
						document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
					}
				}else{
					onBridgeReady();
				}
			}
		}
	},

	/**
	 * 日期工具
	 * @Author 肖家添
	 * @Date 2019/9/11 21:30
	 */
	dateUtils: {
		/**
		 * 日期格式化， yyyy-MM-dd HH:mm:ss
		 * @Author 肖家添
		 * @Date 2019/9/11 21:30
		 */
		dateFormat: function(date, type = ["y", "M", "d"]){
			type = new Set(type);

			const year = date.getFullYear();
			let month = date.getMonth() + 1;
			let day = date.getDate();
			const hour = date.getHours();
			const minute = date.getMinutes();
			const seconds = date.getSeconds();

			let dateString = "";

			if(type.has("y")){
				dateString += year;
			}
			if(type.has("M")){
				month = transferLt10(month);

				dateString += `-${month}`;
			}
			if(type.has("d")){
				day = transferLt10(day);

				dateString += `-${day}`;
			}
			if(type.has("H")){
				dateString += ` ${hour}`;
			}
			if(type.has("m")){
				dateString += `:${minute}`;
			}
			if(type.has("s")){
				dateString += `:${seconds}`;
			}

			function transferLt10(num){
				if(num < 10){
					num = "0" + num;
				}

				return num;
			}

			return dateString;
		},

		/**
		 * 字符串日期相减计算天数
		 * @Author 肖家添
		 * @Date 2019/9/11 17:30
		 */
		dateMinus: function(date1, date2){
			const sdate = new Date(ShawHandler.dateUtils.iosDate(date1));
			const now = new Date(ShawHandler.dateUtils.iosDate(date2));
			const days = now.getTime() - sdate.getTime();

			const day = Math.ceil(days / (1000 * 60 * 60 * 24));

			return day;
		},

		/**
		 * IOS日期
		 * @Author 肖家添
		 * @Date 2019/9/18 20:15
		 */
		iosDate: function(date){
			return date.replace(/\-/g,'/');
		},

		/**
		 * 根据身份证获取出生年月
		 * @Author 肖家添
		 * @Date 2019/9/25 16:27
		 */
		getBirthdayFromIdCard: function(idCard) {
			let birthday = "";

			if(ShawHandler.isValidObj(idCard)){
				if(idCard.length == 15){
					birthday = "19" + idCard.substr(6,6);
				} else if(idCard.length == 18){
					birthday = idCard.substr(6,8);
				}

				birthday = birthday.replace(/(.{4})(.{2})/, "$1-$2-");
			}

			return birthday;
		},

		/**
		 * 根据字符串日期获取周岁年龄
		 * @Author 肖家添
		 * @Date 2019/9/29 0:03
		 */
		getAgesByDateStr: function(lastTime, firstTimeStr){
			const r = firstTimeStr.match(/^(\d{1,4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
			if(r == null) return false;

			const birth = new Date(r[1], r[3]-1, r[4]);
			if (birth.getFullYear() == r[1] && (birth.getMonth() + 1) == r[3] && birth.getDate() == r[4]) {
				const today = new Date(lastTime),
					age = today.getFullYear() - r[1];

				if(today.getMonth() > birth.getMonth()){
					return age;
				}
				if(today.getMonth() == birth.getMonth()){
					if(today.getDate() >= birth.getDate()){
						return age;
					}else{
						return age - 1;
					}
				}
				if(today.getMonth() < birth.getMonth()){
					return age - 1;
				}
			}

			return "输入的日期格式错误！";
		}
	},

	/**
	 * 数据验证工具
	 * @Author 肖家添
	 * @Date 2019/9/25 10:19
	 */
	validUtil: {

		/**
		 * 通用验证函数
		 * @Author 肖家添
		 * @Date 2019/9/25 14:58
		 */
		validComment: function({type = "text", isEmpty = true, value = "", errorMsg = ""}){
			this.config = {
				"type": type,
				"isEmpty": isEmpty,
				"value": value,
				"errorMsg": errorMsg
			}

			/**
			 * 正则表达式验证身份证是否合法
			 * @param value
			 * @returns {Boolean}
			 */
			let verificationCity = {
				11: "北京", 12: "天津", 13: "河北", 14: "山西", 15: "内蒙古",
				21: "辽宁", 22: "吉林", 23: "黑龙江", 31: "上海", 32: "江苏",
				33: "浙江", 34: "安徽", 35: "福建", 36: "江西", 37: "山东", 41: "河南",
				42: "湖北", 43: "湖南", 44: "广东", 45: "广西", 46: "海南", 50: "重庆",
				51: "四川", 52: "贵州", 53: "云南", 54: "西藏", 61: "陕西", 62: "甘肃",
				63: "青海", 64: "宁夏", 65: "新疆", 71: "台湾", 81: "香港", 82: "澳门", 91: "国外"
			};

			this.check = function(){
				let _value = this.config['value'],
					_msg = this.config['errorMsg'],
					_isEmpty = this.config['isEmpty'],
					_type = this.config['type'];

				function checkType(fun){
					if(_isEmpty){
						if(fun(_value) != true){
							return _msg;
						}else{
							return true;
						};
					}else{
						if(_value == ""){
							return _type + "不能为空~";
						}else{
							if(fun(_value)!=true){
								return _msg;
							}else{
								return true;
							}
						}
					}
				}

				switch(_type){
					case '中文姓名':
						return checkType(this.checkNameForRegex);
						break;
					case '英文姓名':
						return checkType(this.checkEnglishName);
						break;
					case '身份证号码':
						return checkType(this.checkCardIdForRegex);
						break;
					case '手机号码':
						return checkType(this.checkPhoneForRegex);
						break;
					case '邮箱':
						return checkType(this.checkEmailForRegex);
						break;
				};
			}

			//-- 手机号码
			this.checkPhoneForRegex = function(value){
				let reg = ShawHandler.reg.phoneReg; //手机正则表达式
				if(!reg.test(value)){
					return false;
				}else{
					return true;
				}
			};

			//-- 中文姓名
			this.checkNameForRegex = function(value){
				// [\u4E00-\uFA29]|[\uE7C7-\uE7F3]汉字编码范围
				let reg = /^[\u4E00-\u9FA5\·\.]{2,20}$/;
				if (!reg.test(value)){
					return false;
				}else{
					return true;
				}
			};

			//-- 英文姓名
			this.checkEnglishName = function(value){
				if(value=="" || value.length<2){
					return false;
				}else{
					return true;
				}
			};
			//-- 邮箱
			this.checkEmailForRegex = function(value){
				let reg = ShawHandler.reg.emailReg; //邮箱正则表达式
				if(!reg.test(value)){
					return false;
				}else{
					return true;
				}
			};

			//-- 检查号码是否符合规范，包括长度，类型
			function isCardNo(card) {
				//身份证号码为15位或者18位，15位时全为数字，18位前17位为数字，最后一位是校验位，可能为数字或字符X
				let reg = /(^\d{15}$)|(^\d{17}(\d|X)$)/;
				if (reg.test(card) === false) {
					return false;
				}

				return true;
			};

			//-- 取身份证前两位,校验省份
			function checkProvince(card) {
				let province = card.substr(0, 2);
				if (verificationCity[province] == undefined) {
					return false;
				}
				return true;
			};

			//-- 排除大陆以外
			function checkProvince_dl(card) {
				let province = card.substr(0, 2);
				if(province == 71 || province == 81 || province == 82 || province==91){
					return false;
				};
				return true;
			};

			//-- 基于以上三个函数,合成一个方法来验证身份证号的准确性
			this.isIdCard = (card) => {
				if(isCardNo(card) && checkProvince(card) && checkProvince_dl(card)){
					return false;
				}
				return true;
			};

			this.checkCardIdForRegex = function(value) {
				let card = value.toUpperCase();
				//是否为空
				if (card === "") {
					return false;
				}
				//校验长度，类型
				if (isCardNo(card) === false) {
					return false;
				}
				//检查省份
				if (checkProvince(card) === false) {
					return false;
				}
				//校验生日
				if (checkBirthday(card) === false) {
					return false;
				}
				//检验位的检测
				if (checkParity(card) === false) {
					return false;
				}
				return true;
			};

			//-- 检查生日是否正确
			function checkBirthday(card) {
				let len = card.length;
				//身份证15位时，次序为省（3位）市（3位）年（2位）月（2位）日（2位）校验位（3位），皆为数字
				if (len == '15') {
					let re_fifteen = /^(\d{6})(\d{2})(\d{2})(\d{2})(\d{3})$/;
					let arr_data = card.match(re_fifteen);
					let year = arr_data[2];
					let month = arr_data[3];
					let day = arr_data[4];
					let birthday = new Date('19' + year + '/' + month + '/' + day);
					return verifyBirthday('19' + year, month, day, birthday);
				}
				//身份证18位时，次序为省（3位）市（3位）年（4位）月（2位）日（2位）校验位（4位），校验位末尾可能为X
				if (len == '18') {
					let re_eighteen = /^(\d{6})(\d{4})(\d{2})(\d{2})(\d{3})([0-9]|X)$/;
					let arr_data = card.match(re_eighteen);
					let year = arr_data[2];
					let month = arr_data[3];
					let day = arr_data[4];
					let birthday = new Date(year + '/' + month + '/' + day);
					return verifyBirthday(year, month, day, birthday);
				}
				return false;
			};

			//-- 校验日期
			function verifyBirthday(year, month, day, birthday) {
				let now = new Date();
				let now_year = now.getFullYear();
				//年月日是否合理
				if (birthday.getFullYear() == year && (birthday.getMonth() + 1) == month
					&& birthday.getDate() == day) {
					//判断年份的范围（3岁到100岁之间)
					let time = now_year - year;
					if (time >= 0 && time <= 100) {
						return true;
					}
					return false;
				}
				return false;
			};

			//-- 校验位的检测
			function checkParity(card) {
				//15位转18位
				card = changeFivteenToEighteen(card);
				let len = card.length;
				if (len == '18') {
					let arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8,
						4, 2);
					let arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3',
						'2');
					let cardTemp = 0, i, valnum;
					for (i = 0; i < 17; i++) {
						cardTemp += card.substr(i, 1) * arrInt[i];
					}
					valnum = arrCh[cardTemp % 11];
					if (valnum == card.substr(17, 1)) {
						return true;
					}
					return false;
				}
				return false;
			};

			//-- 15位转18位身份证号
			function changeFivteenToEighteen(card) {
				if (card.length == '15') {
					let arrInt = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8,
						4, 2);
					let arrCh = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3',
						'2');
					let cardTemp = 0, i;
					card = card.substr(0, 6) + '19' + card.substr(6, card.length - 6);
					for (i = 0; i < 17; i++) {
						cardTemp += card.substr(i, 1) * arrInt[i];
					}
					card += arrCh[cardTemp % 11];
					return card;
				}
				return card;
			};
		}
	},

	/**
	 * 分页助手
	 * @Author 肖家添
	 * @Date 2019/10/22 12:17
	 */
	pagingHelper: {

		/**
		 * 分页前数据判断
		 * @Author 肖家添
		 * @Date 2019/10/22 12:16
		 */
		before: function(pagingData){
			let { _current, _pageSize, _total } = pagingData;
			//-- 总页数
			const sumPageNum = Math.ceil(_total / _pageSize);
			if(_current >= sumPageNum)
				ShawHandler.throw("已经是最后一页！");
			if($(`.${ShawHandler.constant.pagingLoadingClsName}`).size() > 0)
				ShawHandler.throw("数据正在加载中！");

			++pagingData._current;

			return pagingData;
		},

		/**
		 * 分页加载层
		 * @Author 肖家添
		 * @Date 2019/10/22 12:14
		 */
		loading: function(selector){
			$(selector).append(`<p class="${ShawHandler.constant.pagingLoadingClsName}" style="text-align: center;font-size: 14px;margin: 15px 0px;">加载中...</p>`);
		},

		/**
		 * 关闭加载层
		 * @Author 肖家添
		 * @Date 2019/10/22 12:23
		 */
		closeLoading: function(){
			$(`.${ShawHandler.constant.pagingLoadingClsName}`).remove();
		}
	},

	/**
	 * 显示无结果集视图, z-index = 999, 视图上的所有平面控件不可超过此层, 弹出控件必须超过此层
	 * @Author 肖家添
	 * @Date 2019/10/31 17:57
	 */
	showNoResultView: function({parentJqSelector = "body", msg = "暂无数据", btnText, btnHref = "newIndex"}){
		const eleClass = ShawHandler.constant.showNoResultViewClass;
		$(parentJqSelector).css({"position": "relative", "min-height": "400px"});
		const element = $(parentJqSelector).find(`.${eleClass}`);
		if(element.size() > 0){
			element.stop().fadeIn();
			return;
		}

		const html = `
			<div class="${eleClass}" style="
				position: absolute;
				width: 142px;
				min-height: 112px;
				top: 50%;
				left: 50%;
				z-index: 999;
				transform: translate(-50%, -50%);
				border-radius: 4px;
			">
				<img src="${FRONT_PROJECT_NAME}src/images/blankView/noResult.png" style="height: 112px; width: 142px;" />
				<p style="
					text-align: center; 
					padding: 15px 0px; 
					color: #999999;
					font-size: 14px;
				">${msg}</p>
				${
					ShawHandler.isValidObj(btnText) ? `
						<div style="
							padding: 8px 0px;
							border-radius: 4px;
							background-color: #ff7052;
							color: white;
							font-size: 15px;
							text-align: center;
							margin: 0px auto;
							overflow: hidden;
							cursor: pointer;
						" location-href="${btnHref}">${btnText}</div>` : ``
				}
			</div>
		`;

		$(parentJqSelector).append(html);
		ShawHandler.staticPushAutoBind();
	},

	/**
	 * 关闭无结果集视图
	 * @Author 肖家添
	 * @Date 2019/10/31 18:23
	 */
	hideNoResultView: function(parentJqSelector = "body"){
		const element = $(parentJqSelector).find(`.${ShawHandler.constant.showNoResultViewClass}`);

		element.remove();
	},

	/**
	 * 右上角提示分享弹窗
	 * @Author 吴嘉洪
	 * @Modify 肖家添
	 * @Date 2019/11/12 15:35
	 */
	showShareView: function(tips = "点击右上角，发送给好友~") {
		const id = ShawHandler.constant.shareTipsViewId;

		const html = `
			<div id="${id}" style="
				width: 100%;
				height: 100%; 
				position: fixed; 
				top: 0px; 
				left: 0px;
				z-index: 999;
				display: none;
			">
				<div style="
					height: 100%;
					width: 100%;
					position: absolute;
					top: 0;
					left: 0;
					opacity: 0.5;
					background-color: black"></div>
	
				<div class="showFrame" style="
					position: absolute;
					width: 100%;
					height: 33.5%;
					display: flex;
					justify-content: center;
					align-items: center">
				
					<div style="
						position: absolute;
						background:url('${FRONT_PROJECT_NAME}src/images/my/arrow1.png') no-repeat;
						top: 1px;
						width: 23.74%;
						height: 36.7%;
						background-size: contain;
						right: 5.35%;"></div>
					  
					<div style="
						font-size: 15px;
						width: 70%;
						height: 30%;
						background-color: white;
						border-radius: 10px;
						display: flex;
						justify-content: center;
						align-items: center;
						padding: 5.4%" class="tips">${tips}</div>
				</div>
			</div>
		`;
		const selector = `#${id}`;
		if($(`#${id}`).size() <= 0){
			$("body").append(html);

			ShawHandler.listenerHelper.onTap(selector, function(){
				$(selector).fadeOut();
				return false;
			});
		} else{
			$('.tips').text(tips);
		}

		$(selector).stop().fadeIn();
	},

	/**
	 * 监听助手
	 * @Author 肖家添
	 * @Date 2019/10/15 10:56
	 */
	listenerHelper: {
		/**
		 * 页面滚动到底部监听器
		 * @Author 肖家添
		 * @Date 2019/10/15 10:57
		 */
		pageScrollToBottomListener: function(callback){
			ShawHandler.listenerHelper.bindEvent("scroll", window, function(){
				if (parseInt($(window).scrollTop()) == parseInt($(document).height() - $(window).height())) {
					if(callback) callback();
				}
			});
		},

		/**
		 * 输入框内容监听
		 * @Author 肖家添
		 * @Date 2019/10/31 9:45
		 */
		inputValListener: function(jQuerySelector, callback){
			ShawHandler.listenerHelper.bindEvent("input", jQuerySelector, callback);
		},

		/**
		 * 点击事件
		 * @Author 肖家添
		 * @Date 2019/11/12 12:18
		 */

		onTap: function(jQuerySelector, callback){
			ShawHandler.listenerHelper.bindEvent("click", jQuerySelector, callback);
		},

		/**
		 * 绑定事件
		 * @Author 肖家添
		 * @Date 2019/11/12 12:21
		 */
		bindEvent: function(action, jQuerySelector, callback){
			$(jQuerySelector).unbind(action).on(action, function(){
				if(callback) callback(this);
			});
		},

		/**
		 * 屏幕录制记录自动报送
		 * @Author 肖家添
		 * @Date 2020/8/19 16:03
		 */
		screenRecordSubmitted: function(){
			try{
				loki;
			}catch (e) {
				setTimeout(ShawHandler.listenerHelper.screenRecordSubmitted, 1000);
				return;
			}
			try{
				const { database, collection } = ShawHandler.getScreenRecordDB();
				window.XB_SCREEN_DB = { database, collection };
				let retryCount = 0;
				const retry = function(){
					retryCount++;
					if(retryCount < 3){
						loop();
						return;
					}
					throw "屏幕录制报送失败, 已中断轮巡！";
				}
				loop();
				function loop(){
					const datums = collection.find({});
					if(datums.length <= 0){
						setTimeout(loop, 3000);
						return;
					}
					ShawHandler.request({
						url: UrlConfig.management_traceeventscreenrecord_save,
						pars: {datums: datums},
						requestBody: true,
						loading: false,
						sfn: function(data){
							const { success } = data;
							if(success){
								collection.removeBatch(datums);
								database.save();
								setTimeout(loop, 3000);
							}else{
								retry();
							}
						},
						ffn: function(){
							retry();
						}
					});
				}
			}catch (e) {
				console.error(e);
			}
		},

		/**
		 * 路由跳转监听  ``可自行重载此方法达到自定义拦截
		 * @Author 肖家添
		 * @Date 2020/9/18 11:18
		 */
		push: function(fileRelativePath, params = {}){
			// Can't write code here.
		}
	},

	/**
	 * 禁止页面返回
	 * @Author 肖家添
	 * @Date 2019/12/5 12:07
	 */
	pushHistory: function(){
		let state = {
			title: "title",
			url: "#"
		};
		window.history.pushState(state, "title", "#");
	},

	/**
	 * APP交互
	 * @Author 肖家添
	 * @Date 2020/4/2 14:30
	 */
	postAPP: function(formType, datas = {}){
		if(!PAGE_APP) return;
		InsuranceAPP.postMessage(JSON.stringify({
			formType: formType,
			datas: datas
		}));
	},

	/**
	 * 打开APP页面
	 * @Author 肖家添
	 * @Date 2020/3/11 21:25
	 */
	pushAPP: function(routeName, routeParams, pushAndRemove = null){
		const data = {
			routeName,
			routeParams
		};
		if(ShawHandler.isValidObj(pushAndRemove)){
			data.pushAndRemove = pushAndRemove;
		}
		ShawHandler.postAPP(10001, data);
	},

	changeVersion : function () {
		let css = document.getElementsByTagName("css");
		let script = document.getElementsByTagName("script");
		//-- 获取当前时间戳
		let timestamp = new Date().getTime();
		for (let item of css) {
			item.href = item.href+'?v='+timestamp
		}
		for (let item of script) {
			item.src = item.src+'?v='+timestamp
		}
		ShawHandler.pageColorConfiguration(6);
	},

    /**
     * 获取阅读时长
     */
    setReadLongTimes : function () {
        const whoLookMeId = ShawHandler.getUrlParam("whoLookMeId");
        let times = 0;
        let timer = setInterval(function(){
            times++;
            // console.log(times)
        },1000);
        function finishTime(){
            clearInterval(timer);
            // console.log(whoLookMeId);
            if (ShawHandler.isValidObj(whoLookMeId)) {
                ShawHandler.request({
                    url: UrlConfig.management_whoLookMe_addTimesById,
                    pars:{
                        times:times,
                        whoLookMeId:whoLookMeId
                    },
                    loading:true,
                    method: "POST",
                    sfn: function(data){
                        if(data.success){
                        }else{
                            ShawHandler.layerToast(data.msg);
                        }
                    }
                });
            }
        }
        window.onbeforeunload = function(){
            finishTime();
        };
        if (ShawHandler.isValidObj(whoLookMeId)) {
            $$.pushHistory();
            window.addEventListener("popstate", function() {
                finishTime();
                const backUrl = localStorage.getItem('backUrl');
                if (window.location.href.indexOf(backUrl) > -1) {
                    localStorage.removeItem('backUrl');
                    if (typeof WeixinJSBridge == "undefined"){
                        if( document.addEventListener ){
                            document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
                        }else if (document.attachEvent){
                            document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
                            document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
                        }
                    }else{
                        onBridgeReady();
                    }
                }
            }, false);
        } else {
            localStorage.setItem('backUrl',window.location.href);
        }
        function onBridgeReady(){
            WeixinJSBridge.call('closeWindow');
        }
    },

	/**
	 * 获取全局颜色配置
	 * @Author 吴成林
	 * @Date 2020-6-8 12:14
	 */
	pageColorConfiguration: function(id){
		const cacheKey = "TECHNICAL_DATES_PAGE_COLOR";			//-- 页面颜色本地缓存KEY
		let cacheData = localStorage.getItem(cacheKey);			//-- 本地缓存数据
		let timestamp = $$.getTimeStampNow();					//-- 当前时间戳
		if (cacheData){
			let cacheDataTime = JSON.parse(cacheData).time;		//-- 缓存的时间戳
			let cacheDataVal = JSON.parse(cacheData).val;		//-- 缓存的颜色值
			const days = timestamp - cacheDataTime;
			const day = Math.ceil(days / (1000 * 60));  		//-- 间隔分钟
			if (day > 30){
				getInfo();
			} else if (cacheDataVal != "0"){
				$("html").addClass("specialColor")	//-- 全局特殊颜色配置
			}
		} else {
			getInfo();
		}

		//-- 获取全局颜色配置
		function getInfo()  {
			ShawHandler.request({
				url: UrlConfig.sysbase_sysparams_info,
				pars:{
					id
				},
				loading: false,
				method: "GET",
				sfn: function(data){
					if(data.success){
						let val = data.datas.val;
						localStorage.setItem(cacheKey, JSON.stringify({
							time: $$.getTimeStampNow(),
							val: val
						}));
						if (val != "0"){
							$("html").addClass("specialColor")	//-- 全局特殊颜色配置
						}
					}else{
						//ShawHandler.layerToast(data.msg);
						console.log(date.msg);
					}
				}
			});
		}
	},

	/**
	 * RSA加密
	 * @Author 肖家添
	 * @Date 2020/7/8 17:56
	 */
	rsaEncrypt: function(data){
		if(!ShawHandler.isValidObj(data)) return data;
		const encrypt = new JSEncrypt();
		encrypt.setPublicKey(ShawHandler.constant.rsaPublicKey);
		return encrypt.encrypt(data);
	},

	/**
	 * 记录事件日志
	 *
	 * 	requestToken -> 请求Token ``密文
	 * 	evenId -> 事件Code ``明文
	 * 	productId -> 产品库ID ``明文
	 * 	orderId -> 订单Token ``密文
	 * 	evenResult -> 事件结果
	 *
	 * @Author 肖家添
	 * @Date 2020/7/13 16:00
	 */
	recordEventLog: function({requestToken, evenId, productId, orderId, evenResult}){
		if(!ShawHandler.isValidObj(requestToken) || !ShawHandler.isValidObj(evenId)) return;
		let ip = null;
		try{
			ip = returnCitySN.cip;
		}catch (e) {}
		const evenResult_temp = !evenResult ? null : evenResult;
		ShawHandler.request({
			url: UrlConfig.management_traceeventloginfo_save,
			pars: {
				requestToken,
				evenId,
				productId,
				orderId,
				ip,
				evenResult
			},
			loading: false,
			requestBody: true,
			sfn: function(data){
				// console.log(`==${evenId}==${evenResult_temp}==> 事件记录成功！`);
			},
			ffn: function(){
				// console.log(`==${evenId}==${evenResult_temp}==> 事件记录失败！`);
			}
		});
	},

	/**
	 * 更新事件修改时间
	 * @Author 肖家添
	 * @Date 2020/7/14 16:08
	 */
	updateEventLog: function(requestToken, eventId, callback = () => {}){
		if(!ShawHandler.isValidObj(requestToken) || !ShawHandler.isValidObj(eventId)) return;
		ShawHandler.request({
			url: UrlConfig.management_traceeventloginfo_update,
			pars: {
				requestToken,
				eventId
			},
			loading: false,
			sfn: callback,
			ffn: callback
		});
	},

	/**
	 * Image标签的Src, 所有标签的BackgroundImage 转换成Base64
	 * @Author 肖家添
	 * @Date 2020/7/20 16:46
	 */
	imgEleSrc2base64: function(){
		try{
			$("img").each((index, element) => {
				const base64 = transferToBase64(element);
				if(base64 == null) return;
				$(element).attr("src", base64);
			});
			$("*").each((i, e) => {
				let url;
				try{
					const that = $(e);
					const backgroundImage = "background-image";
					url = that.css(backgroundImage);
					if(!url || url == "none") return;
					url = url.split('("')[1].split('")')[0];
					const tempImg = document.createElement("img");
					tempImg.src = url;
					tempImg.onload = function(){
						const base64 = transferToBase64(tempImg);
						if(base64 == null) return;
						that.css(backgroundImage, `url("${base64}")`);
					}
				}catch (e) {
					console.log(e);
				}
			});
		}catch (e) {
			console.error(e);
		}
		function transferToBase64(image){
			try{
				const { src, height, width } = image;
				if(src.indexOf("aliyuncs.com") != -1 || src.startsWith("data:")) return;
				const canvas = document.createElement("canvas");
				canvas.height = height;
				canvas.width = width;
				const ctx = canvas.getContext("2d");
				ctx.drawImage(image, 0, 0, width, height);
				return canvas.toDataURL();
			}catch (e) {
				console.error(e);
				return null;
			}
		}
	},

	/**
	 * 屏幕录制  ``页面加载只能调用一次
	 * @Author 肖家添
	 * @Date 2020/8/18 14:31
	 */
	screenRecording: function(eventLogToken){
		try{
			if(!window.XB_SCREEN_DB){
				setTimeout(function(){
					ShawHandler.screenRecording(eventLogToken);
				}, 600);
				return;
			}
			try{
				// if(ShawHandler.checkIsLocal()) throw '本地不做屏幕录制！';
				if(window.screenRecording) throw '已经在录制中！';
				if(!rrweb) throw '未引入屏幕录制库 RRWeb！';
				if(!$$.isValidObj(eventLogToken)) throw '事件Token不能为空！';
			}catch (e) {
				throw `【屏幕录制】 ${e}`;
			}
			ShawHandler.imgEleSrc2base64();
			const { database, collection } = window.XB_SCREEN_DB;
			rrweb.record({
				emit(event) {
					try{
						event = {
							...event,
							recordToken: ShawHandler.uuid(),
							requestToken: eventLogToken,
							data: JSON.stringify(event.data)
						};
						collection.insert(event);
					}catch (e) {}
				}
			});
			setInterval(function(){
				if(collection.data.length <= 0) return;
				database.save();
			}, 600);
			window.screenRecording = true;
		}catch (e) {
			console.error(e);
		}
	},

	/**
	 * 获取屏幕录制的数据库、数据表
	 * @Author 肖家添
	 * @Date 2020/8/19 16:11
	 */
	getScreenRecordDB: function(){
		const { dbName, tables: { screen } } = ShawHandler.constant.db.screenRecording;
		const databaseName = dbName, tableName = screen;
		const database = new loki(databaseName);
		database.loadDatabase();
		let collection = database.getCollection(tableName);
		if(collection == null){
			collection = database.addCollection(tableName);
		}
		return { database, collection };
	},

	/**
	 * 检查是否是本地
	 * @Author 肖家添
	 * @Date 2020/8/20 11:10
	 */
	checkIsLocal: function(){
		return window.location.href.indexOf("http://localhost") != -1;
	},

	/**
	 * 获取UUID值
	 * @returns {string}
	 */
	uuid() {
		var s = [];
		var hexDigits = "0123456789abcdef";
		for (var i = 0; i < 36; i++) {
			s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
		}
		s[14] = "4";  // bits 12-15 of the time_hi_and_version field to 0010
		s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1);  // bits 6-7 of the clock_seq_hi_and_reserved to 01
		s[8] = s[13] = s[18] = s[23] = "-";

		var uuid = s.join("");
		return uuid;
	},

	accessstatistics () {
		try{
			const href = window.location.href;
			// console.log("href = "+ href);
			let webPage = 'NO_PAGE';
			if(href){
				webPage = (href.lastIndexOf("?") != -1) ? href.substring(0, href.lastIndexOf("?")) : href;
				let firstIndex = webPage.indexOf("/");
				let lastIndex = webPage.lastIndexOf("/");
				if(firstIndex == lastIndex &&　firstIndex != -1){
					webPage = webPage.substring(firstIndex);
				}else{
					lastIndex = webPage.substring(0,lastIndex).lastIndexOf("/");
					webPage = webPage.substring(lastIndex);
				}
			}

			let visitorUserId = localStorage.getItem("visitor_userId");
			if(!visitorUserId){
				visitorUserId = ShawHandler.uuid();
				localStorage.setItem("visitor_userId", visitorUserId);
			}
			let devices_source = "XB_H5";
			try{
				if (PAGE_APP == true){
					switch(PAGE_APP_TERMINAL){
						case 2:{
							devices_source = "XB_APP@ANDROID";
							break;
						}
						case 3:{
							devices_source = "XB_APP@IOS";
							break;
						}
					}
				}
			}catch(e){}
			let _headers = {
				device_source: devices_source,
				web_page: webPage,
				visitor_userId: visitorUserId
			};

			const tokenKey = ShawHandler.constant.tokenKey;
			_headers[tokenKey] = localStorage.getItem(tokenKey);

			const url = SERVER_BASE_URL+'/msg/accessstatistics'; //可以随便指定一个不存在的地址
			// console.log("======== [ "+url+" ] ======");
			// console.log(_headers);
			axios({
				url: url,
				method: 'GET',
				headers: _headers,
				timeout: 60 * 1000 * 10
			}).then(function(data) {
				// console.log("get ： "+url+"  success...");
			}).catch(function(error){
				// console.log("get ： "+url+"  failure...");
				// console.error(error);
			});
		}catch (e) {
			console.error(e);
		}
	},
};

/**
 * 加载公共资源文件，请将JS主体写到[window.onload]中
 * @Author 肖家添
 * @Date 2019/9/10 18:27
 */
ShawHandler.loaderRes({
    css: [
        //-- WeChat UI frame CSS
        `js/tool/weui/css/weui.min.css`
    ],
    scripts: [
        //-- jQuery
        `js/tool/jquery-1.11.3.min.js`,
        //-- Layer of mobile
        `js/tool/layer/mobile/layer.js`,
        //-- Request client
        `js/tool/weui/js/axios.min.js`,
        //-- Request urls config center
        `js/tool/BaseUrls.js`,
        //-- WeChat UI frame body
		`js/tool/weui/js/weui.min.js`,
        //-- WeChat JS SDK  1.2.0
        `js/tool/weui/js/jweixin-1.2.0.js`,
        //-- Burial statistics
        `js/tool/burialStatistics.js`,
        //-- WeChat config
        `js/tool/weChatJSTool.js`,
		//-- IP地址
		`http://pv.sohu.com/cityjson?ie=utf-8`
    ]
});

/**
 * 简化 [ShawHandler.*] 写法，只在外部使用，本文件内调用依然使用 [ShawHandler.*]
 * @Author 肖家添
 * @Date 2019/8/28 20:30
 */
const $$ = ShawHandler,
	$Constant = ShawHandler.constant;
	$Reg = ShawHandler.reg,
	$Date = ShawHandler.dateUtils,
	$Valid = ShawHandler.validUtil,
	$WeChat = ShawHandler.weChat,
	$Listener = ShawHandler.listenerHelper;

/**
 * 模拟 window.onload 函数
 * @Author 肖家添
 * @Date 2020/8/19 15:56
 */
(function(){
	try{
		document.querySelector('meta[name="base-app-close-hook"]').getAttribute("content");
	}catch (e) {
		hook();
	}
	function hook(){
		try{
			jQuery;
			axios;
			onload();
		}catch (e) {
			window.setTimeout(hook, 1500);
		}
	}
	// Warning: please use try catch to capture inside the method!
	function onload(){
		try{
			//-- 站点数据埋点记录
			ShawHandler.accessstatistics();
			//-- 屏幕录制记录报送
			ShawHandler.listenerHelper.screenRecordSubmitted();
		}catch (e) {
			console.error(e);
		}
	}
})();
