var _mtac = {"performanceMonitor": 1, "senseQuery": 1};
(function () {
    var mta = document.createElement("script");
    mta.src = "//pingjs.qq.com/h5/stats.js?v2.0.4";
    mta.setAttribute("name", "MTAH5");
    mta.setAttribute("sid", "500704974");
    mta.setAttribute("cid", "500704975");
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(mta, s);


})();

//@param id {string} 自定义事件id
//@param params {object}
function countAction(id, params){
    try{
        appSync(id);
        if(window.MtaH5){
            MtaH5.clickStat(id, params);
        }else{
            setTimeout(function(){
                MtaH5.clickStat(id, params);
            },1500);
        }
    }catch(e){console.log(e)}

    /**
     * APP埋点拦截
     * @Author 肖家添
     * @Date 2020/9/29 15:25
     */
    function appSync(id){
        try{
            if(!PAGE_APP || id === "xb_6021") return;
            const mtaCode = parseInt(id.replace("xb_", ""));
            if(mtaCode < 6000 || mtaCode > 6022) return;
            $$.postAPP(10005, {eventId: id});
        }catch (e) {
            return;
        }
        $$.throw();
    }
};
// $(document).ready(function(){
//     let css = document.getElementsByTagName('link');
//     let scriptList = document.getElementsByTagName('script');
//     let version = VERSION;
//     for (let item of css) {
//         let url = item.href;
//         if (url){
//             if (url.indexOf("?") != -1){
//                 item.href  =url +"&v="+version;
//             }else {
//                 item.href = url+'?v='+version
//             }
//         }
//     }
//     for (let item of scriptList) {
//         let url = item.src;
//         if (url){
//             if (url.indexOf("?") != -1){
//                 item.src  =url +"&v="+version;
//             }else {
//                 item.src = url+'?v='+version
//             }
//         }
//
//     }
// });
