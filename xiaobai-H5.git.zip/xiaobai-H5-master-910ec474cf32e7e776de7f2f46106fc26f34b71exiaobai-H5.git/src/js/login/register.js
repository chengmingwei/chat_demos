
/**
 * 注册 ``JavaScript
 * @Author 肖家添
 * @Date 2019/8/29 20:47
 */

window.onload = function(){
    try {
        countAction('xb_3', null);
    } catch (error) {
        console.log(error);
    }
    const returnUrl = $$.getUrlParam("returnUrl");
    const weChatOpenId = $$.getUrlParam("weChatOpenId");
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){

        pageInit();

    }

    function goBack() {
        setTimeout(function(){
            if($$.isValidObj(returnUrl) && !(returnUrl.indexOf('personalCenter') > -1)){
                location.href = decodeURIComponent(returnUrl);
            }else{
                localStorage.removeItem($Constant.weChatUserManualExitKey);
                $$.push("newIndex");
            }
        }, 600);
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){
        /**
         * url参数带有weChatOpenId，给登录路径加上参数weChatOpenId
         */
        (function(){
            $(".goToLogin").on('click',function () {
                let params = {};
                $$.isValidObj(returnUrl)? params["returnUrl"] = encodeURIComponent(returnUrl) : params["weChatOpenId"] = weChatOpenId;
                $$.push('login/login', params);
            });
        })();

        /**
         * 清空手机号
         */
        $(".cancel").click(function () {
            $(".account").val("");
        });

        /**
         * 获取验证码
         */
        $(".codeBtn").click(function (e) {
            e.preventDefault();

            let accountValue = $(".account").val();

            const errorMsg = validationForm_phone();
            if(errorMsg != null){
                $$.layerToast(errorMsg);
                return;
            }

            $$.sendPhoneCode(accountValue, 2, function(){
                resetTime($(".codeBtn"));
            });
        });

        /**
         * 实时监控输入
         * @Author 肖家添
         * @Date 2019/8/29 9:42
         */
        $(".account, .code, .password").off().bind("input", function(){
            const className = this.className;

            if(className === "account"){
                inputMonitor_phone();
            }

            inputMonitor();
        });

        /**
         * 注册
         */
        $(".registerBtn").click(function (e) {
            e.preventDefault();

            const errorMsg = validationForm();

            if($$.isValidObj(errorMsg)){
                $$.layerToast(errorMsg);
                return;
            }

            const parentMemberId = $$.getUrlParam("memberId");
            const accountValue = $(".account").val();
            const codeValue = $(".code").val();
            const passwordValue = $(".password").val();
            const formType = $$.getUrlParam("formType");
            const formId = $$.getUrlParam("formId");
            const terminal = 4;
            const weChatOpenId = $$.getUrlParam("weChatOpenId");
            $$.request({
                url: UrlConfig.member_register,
                loading: true,
                pars: {
                    account: accountValue,
                    password: passwordValue,
                    validationCode: codeValue,
                    terminal: terminal,
                    parentMemberId: parentMemberId,
                    basePath:$$.getBasePath(),
                    formType:formType,
                    formId:formId,
                    weChatOpenId:weChatOpenId
                },
                sfn: function(data){
                    $$.closeLoading();

                    if(data.success){
                        $$.layerToast("注册成功！");
                        $$.login(accountValue, passwordValue, 1, terminal, function(){
                            //-- url参数带有weChatOpenId，根据openId更新微信消息memberId
                            (function(){
                                if($$.isValidObj(weChatOpenId)){
                                    $$.request({
                                        url: UrlConfig.member_weixinbase_updateMemberId,
                                        pars:{
                                            openId:weChatOpenId,
                                        },
                                        loading: true,
                                        sfn: function (data) {
                                            $$.closeLoading();
                                            if (data.success) {
                                                goBack();
                                            } else {
                                                $$.layerToast(data.msg);
                                            }
                                        },
                                        ffn: function (data) {
                                            $$.errorHandler();
                                        }
                                    });
                                }else{
                                    goBack();
                                    $$.push("index");
                                }
                            })();
                        });
                    }else{
                        $$.layerToast(data.msg);
                    }
                }
            });
        });

        $Listener.onTap(".password-right", function(e){
            const that = $(e),
                password = $(".password");
            if(that.hasClass("show-icon")){
                that.addClass("hide-icon").removeClass("show-icon");
                password.attr("type", "password");
            }else{
                that.removeClass("hide-icon").addClass("show-icon");
                password.attr("type", "text");
            }
        });

        /**
         * submit按钮样式自动调整
         * @Author 肖家添
         * @Date 2019/8/29 9:40
         */
        function inputMonitor(){
            const errorMsg = validationForm();

            if(errorMsg == null){
                $(".registerBtn").addClass("active");
            }else{
                $(".registerBtn").removeClass("active");
            }
        }

        /**
         * submit按钮样式自动调整
         * @Author 肖家添
         * @Date 2019/8/29 9:40
         */
        function inputMonitor_phone(){
            const errorMsg = validationForm_phone();

            if(errorMsg == null){
                $(".codeBtn").addClass("active");
            }else{
                $(".codeBtn").removeClass("active");
            }
        }
    }

    $('.goTo').click(function () {
       $$.push("my/userAgreement");
    });

};

/**
 * 验证码倒计时
 * @Author 肖家添
 * @Date 2019/8/29 21:14
 */
function resetTime(e){
    let second = 60;
    let timer = null;

    const timeFun = function(){
        second -= 1;
        if(second >0){
            $(e).attr("disabled", true).text(second + "s");
        }else{
            clearInterval(timer);

            $(e).attr("disabled", false).text("获取验证码");
        }
    }

    timeFun();
    timer = setInterval(function(){
        timeFun();
    },1000);
}

/**
 * 验证表单
 * @Author 肖家添
 * @Date 2019/8/29 9:28
 */
function validationForm(){
    const codeValue = $(".code").val();
    const passwordValue = $(".password").val();

    const passwordReg = $$.reg.passwordReg;

    //-- check form
    const errorMsg = validationForm_phone();
    if(errorMsg != null) return errorMsg;

    if(!$$.isValidObj(codeValue)){
        return "请输入验证码~";
    }
    if(!$$.isValidObj(passwordValue)){
        return "请输入密码~";
    }
    if(!passwordReg.test(passwordValue)){
        return "密码为6-16位字母+数字组合~";
    }

    return null;
}

/**
 * 验证手机号
 * @Author 肖家添
 * @Date 2019/8/29 21:14
 */
function validationForm_phone(){
    const accountValue = $(".account").val();
    const phoneReg = $$.reg.phoneReg;

    if(!$$.isValidObj(accountValue)) {
        return "请输入手机号~";
    }
    if(!phoneReg.test(accountValue)){
        return "请输入有效手机号~";
    }

    return null;
}
