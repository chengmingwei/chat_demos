
let phonePG = null;

//-- 验证码业务类型，[1]: 登录验证码, [3]: 找回密码验证码
let smsHandlerType = $$.getUrlParam("type");

window.onload = function () {

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        phonePG = sessionStorage.getItem("getValidCodePhone");

        if(!$$.isValidObj(phonePG)){
            $$.layerToast("页面超时...");

            setTimeout(function(){
                $$.push("login/login");
            }, 1000);
            return;
        }else{
            pageInit();
        }
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){

        smsHandlerTypeInit();
        countDownInit();

        /**
         * 登录
         * @Author 肖家添
         * @Date 2019/8/29 16:32
         */
        $(".finish").click(function (e) {
            e.preventDefault();

            let code = $(".code").val();

            const errorMsg = validationForm();

            if($$.isValidObj(errorMsg)){
                $$.layerToast(errorMsg);
                return;
            }

            switch (smsHandlerType) {
                case 1:{
                    phoneCodeLogin();
                    break;
                }
                case 3:{
                    resetPassword();
                    break;
                }
            }

            /**
             * 验证码登录处理
             * @Author 肖家添
             * @Date 2019/8/29 18:06
             */
            function phoneCodeLogin(){
                const terminal = 4;
                $$.login(phonePG, code, 3, terminal, function(){
                    const returnUrl = $$.getUrlParam("returnUrl");
                    setTimeout(function(){
                        if($$.isValidObj(returnUrl) && !(returnUrl.indexOf('personalCenter') > -1)){
                            location.href = decodeURIComponent(returnUrl);
                        }else{
                            localStorage.removeItem($Constant.weChatUserManualExitKey);
                            $$.push("newIndex");
                        }
                    }, 600);
                });
            }

            /**
             * 重置密码处理, Step 01
             * @Author 肖家添
             * @Date 2019/8/29 18:06
             */
            function resetPassword(){
                $$.request({
                    url: UrlConfig.member_forgetPassword,
                    loading: true,
                    pars: {
                        account: phonePG,
                        validationCode: code,
                        step: 1
                    },
                    sfn: function(data){
                        $$.closeLoading();

                        if(data.success){
                            const key = data.datas;
                            sessionStorage.setItem("REDIS_MEMBER_FORGET_STEP_01_KEY", key);

                            $$.push("login/resetPassword");
                        }else{
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function(data){
                        $$.errorHandler();
                    }
                });
            }
        });

        /**
         * 实时监控输入
         * @Author 肖家添
         * @Date 2019/8/29 9:42
         */
        $(".code").off().bind("input", function(){
            inputMonitor();
        });

        /**
         * 获取验证码
         * @Author 肖家添
         * @Date 2019/8/29 16:46
         */
        $(".codeBtn").click(function(){
            $$.sendPhoneCode(phonePG, smsHandlerType, function(){
                resetTime($(".codeBtn"));
            });
        });

        /**
         * 页面一加载是否开始倒计时
         * @Author 肖家添
         * @Date 2019/8/29 16:29
         */
        function countDownInit(){
            const sessionKey = "login.codeLogin.isShowCountDown";
            const isShowCountDown = sessionStorage.getItem(sessionKey);

            if($$.isValidObj(isShowCountDown)){
                sessionStorage.removeItem(sessionKey);

                resetTime($(".codeBtn"));
            }
        }

        /**
         * 不同业务显示不同标题
         * @Author 肖家添
         * @Date 2019/8/29 16:55
         */
        function smsHandlerTypeInit(){
            if(smsHandlerType == 3){
                document.title = "忘记密码";
            }else{
                document.title = "验证码登录";
                smsHandlerType = 1;
            }

            smsHandlerType = parseInt(smsHandlerType);
        }

        /**
         * submit按钮样式自动调整
         * @Author 肖家添
         * @Date 2019/8/29 9:40
         */
        function inputMonitor(){
            const errorMsg = validationForm();

            if(errorMsg == null){
                $(".finish").addClass("active");
            }else{
                $(".finish").removeClass("active");
            }
        }
    }
}

/**
 * 倒计时
 * @Author 肖家添
 * @Date 2019/8/29 16:39
 */
function resetTime(e) {
    let second = 60;
    let timer = null;
    timer = setInterval(function () {
        second -= 1;
        if (second > 0) {
            $(e).attr("disabled", true);
            $(e).text(second + "s");
        } else {
            clearInterval(timer);

            $(e).attr("disabled", false);
            $(e).text("获取验证码");
        }
    }, 1000);
}

/**
 * 验证表单
 * @Author 肖家添
 * @Date 2019/8/29 9:28
 */
function validationForm(){
    let codeValue = $(".code").val();

    //-- check form
    if(!$$.isValidObj(codeValue)) {
        return "请输入验证码~";
    }

    return null;
}
