
//-- 验证码业务类型，[1]: 登录验证码, [3]: 找回密码验证码
let smsHandlerType = $$.getUrlParam("type");

window.onload = function(){
    const returnUrl = $$.getUrlParam("returnUrl");
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){

        smsHandlerTypeInit();

        /**
         * 清除手机号
         * @Author 肖家添
         * @Date 2019/8/29 10:26
         */
        $("#clearPhone").off().click(function(){
            $$.reSetInput(".account");

            inputMonitor();
        });

        /**
         * 实时监控
         * @Author 肖家添
         * @Date 2019/8/29 9:42
         */
        $(".account").off().bind("input", function(){
            inputMonitor();
        });

        /**
         * 获取验证码
         * @Author 肖家添
         * @Date 2019/8/29 10:22
         */
        $(".getCodeBtn").off().click(function(){
            let accountValue = $(".account").val();

            const errorMsg = validationForm();

            if($$.isValidObj(errorMsg)){
                $$.layerToast(errorMsg);
                return;
            }

            $$.sendPhoneCode(accountValue, smsHandlerType, function(){
                sessionStorage.setItem("getValidCodePhone", accountValue);
                sessionStorage.setItem("login.codeLogin.isShowCountDown", true);

                $$.push("login/getCode", {
                    type: smsHandlerType,
                    returnUrl:encodeURIComponent(returnUrl)
                });
            });
        });

        $('.goToLogin').off().on('click',function () {
            $$.push("login/login", {
                returnUrl:encodeURIComponent(returnUrl)
            });
        });

        /**
         * submit按钮样式自动调整
         * @Author 肖家添
         * @Date 2019/8/29 9:40
         */
        function inputMonitor(){
            const errorMsg = validationForm();

            if(errorMsg == null){
                $(".getCodeBtn").addClass("active");
            }else{
                $(".getCodeBtn").removeClass("active");
            }
        }

        /**
         * 不同业务显示不同标题
         * @Author 肖家添
         * @Date 2019/8/29 16:55
         */
        function smsHandlerTypeInit(){
            try {
                if($$.isValidObj(smsHandlerType) && parseInt(smsHandlerType) === 3){
                    countAction('xb_7', null);
                    document.title = "忘记密码";
                }else{
                    countAction('xb_4', null);
                    document.title = "验证码登录";
                    smsHandlerType = 1;
                }
            } catch (error) {
                console.log(error);
            }
        }
    }
};

/**
 * 验证表单
 * @Author 肖家添
 * @Date 2019/8/29 9:28
 */
function validationForm(){
    let accountValue = $(".account").val();

    //-- check form
    if(!$$.isValidObj(accountValue)) {
        return "请输入手机号~";
    }

    if(!$$.isValidPhone(accountValue)){
        return "请输入有效手机号~";
    }

    return null;
}
