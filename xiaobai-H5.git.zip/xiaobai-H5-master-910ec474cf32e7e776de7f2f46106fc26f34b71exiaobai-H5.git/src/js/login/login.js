
const PAGE_STATE = {
	loginSuccessLocationUrl: null,
	popupLogin: false,					// 弹窗调用页面状态参数
};

window.onload = function(){
	try {
		countAction('xb_2', null);
	} catch (error) {
		console.log(error);
	}
	PAGE_STATE.loginSuccessLocationUrl = $$.getUrlParam("returnUrl");
	PAGE_STATE.popupLogin = $$.getUrlParam("popupLogin");

	inputMonitor();
	isConsent();

	/**
	 * 清空手机号
	 */
	$("#clearPhone").click(function() {
		$(".account").val("");
		inputMonitor();
	});

	/**
	 * 显示密码
	 */
	$("#showPwd").click(function() {
		const $pwd = $(".password");
		if($pwd.attr("type") == "password"){
			$pwd.attr('type','text');
			$(this).attr("src",'../../images/product/eyes.png');
		}else{
			$pwd.attr('type','password');
			$(this).attr("src",'../../images/product/closeEyes.png');
		}
		inputMonitor();
	});

	/**
	 * 登录处理
	 * @Author 肖家添
	 * @Date 2019/8/28 19:45
	 */
	$(".loginBtn").off().click(function(e) {
		e.preventDefault();
		let accountValue = $(".account").val();
		let password = $(".password").val();

		//-- check form
		const errorMsg = validationLogin();

		if($$.isValidObj(errorMsg)){
			$$.layerToast(errorMsg);
			return;
		}
		const terminal = 4;
		$$.login(accountValue, password, 1, terminal, function(){
			ShawHandler.layerToast("登录成功");
			//-- url参数带有weChatOpenId，根据openId更新微信消息memberId
			(function(){
				const weChatOpenId = $$.getUrlParam("weChatOpenId");
				if($$.isValidObj(weChatOpenId)){
					$$.request({
						url: UrlConfig.member_weixinbase_updateMemberId,
						pars:{
							openId:weChatOpenId,
						},
						loading: true,
						sfn: function (data) {
							$$.closeLoading();
							if (data.success) {

							} else {
								$$.layerToast(data.msg);
							}
						},
						ffn: function (data) {
							$$.errorHandler();
						}
					});
				}
			})();

			//-- 弹窗调用登录 - 登录成功关闭弹窗
			if (PAGE_STATE.popupLogin){
				setTimeout(function(){
					$(window.parent.document).find(".preview").hide();
				}, 1000);
			} else {
				setTimeout(function(){
					const { loginSuccessLocationUrl } = PAGE_STATE;
					if($$.isValidObj(loginSuccessLocationUrl) && !(loginSuccessLocationUrl.indexOf('personalCenter') > -1)){
						location.href = decodeURIComponent(loginSuccessLocationUrl);
					}else{
						localStorage.removeItem($Constant.weChatUserManualExitKey);
						$$.push("newIndex");
					}
				}, 1000);
			}
		});
	});

	/**
	 * 实时监控
	 * @Author 肖家添
	 * @Date 2019/8/29 9:42
	 */
	$(".account, .password").off().bind("input", function(){
		inputMonitor();
	});

	/**
	 * submit按钮样式自动调整
	 * @Author 肖家添
	 * @Date 2019/8/29 9:40
	 */
	function inputMonitor(){
		const errorMsg = validationLogin();

		if(errorMsg == null){
			$(".loginBtn").addClass("active");
		}else{
			$(".loginBtn").removeClass("active");
		}
	}

	/**
	 * 验证表单
	 * @Author 肖家添
	 * @Date 2019/8/29 9:28
	 */
	function validationLogin(){
		let accountValue = $(".account").val();
		let password = $(".password").val();

		//-- check form
		if(!$$.isValidObj(accountValue)) {
			return "请输入手机号~";
		}

		if(!$$.isValidPhone(accountValue)){
			return "请输入有效手机号~";
		}

		if(!$$.isValidObj(password)) {
			return "登录密码不能为空~";
		}

		return null;
	}


	/**
	 * 判断是否同意会员用户协议
	 */
	function isConsent() {

		const html = '<div class="goTo" style="color: #ff6b47;font-size: 16px">《小白保险会员注册协议》</div>' +
			'<br />\n\t\t\t<div style="font-size: 12px;">请仔细阅读以上协议,同意后方可使用本软件。</div>';

		$('.goToRegister').click(function () {
			layer.open({
				content: html,
				btn: ['同意','不同意'],
				yes: function () {
					const params = {
						returnUrl:encodeURIComponent(PAGE_STATE.loginSuccessLocationUrl),
						memberId:$$.getUrlParam("memberId"),
						weChatOpenId:$$.getUrlParam("weChatOpenId")
					};
					$$.push("login/register",params);
				}
			});

			$('.goTo').click(function () {
				$$.push("my/userAgreement");
			});
		});

		$('.codeLogin').click(function () {
			const params = {
				type:1,
				weChatOpenId:$$.getUrlParam("weChatOpenId"),
				memberId:$$.getUrlParam("memberId"),
				returnUrl:encodeURIComponent(PAGE_STATE.loginSuccessLocationUrl)
			};
			$$.push("login/codeLogin",params);
		});
	}

};
