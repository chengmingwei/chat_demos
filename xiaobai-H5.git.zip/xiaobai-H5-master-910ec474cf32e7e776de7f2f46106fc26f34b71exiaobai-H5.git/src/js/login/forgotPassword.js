
let step01KeyPG = null;

window.onload = function(){

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        step01KeyPG = sessionStorage.getItem("REDIS_MEMBER_FORGET_STEP_01_KEY");

        $$.validPageParams(step01KeyPG);

        pageInit();
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){
        /**
         * 清空手机号
         */
        $("#clearPhone").click(function () {
            $(".account").val("");
        });

        /**
         * 获取验证码
         */
        $(".getCode").click(function (e) {
            e.preventDefault();

            let accountValue = $(".account").val();
        });
    }
}

/**
 * 验证表单
 * @Author 肖家添
 * @Date 2019/8/29 9:28
 */
function validationForm(){
    let codeValue = $(".code").val();

    //-- check form
    if(!$$.isValidObj(codeValue)) {
        return "请输入验证码~";
    }

    return null;
}