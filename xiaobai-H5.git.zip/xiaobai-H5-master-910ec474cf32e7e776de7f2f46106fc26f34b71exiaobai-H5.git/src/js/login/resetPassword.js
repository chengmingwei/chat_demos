
/**
 * 重置密码 ``JavaScript
 * @Author 肖家添
 * @Date 2019/8/29 20:49
 */

let phonePG = null;
let step01KeyPG = null;

window.onload = function(){

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        phonePG = sessionStorage.getItem("getValidCodePhone");
        step01KeyPG = sessionStorage.getItem("REDIS_MEMBER_FORGET_STEP_01_KEY");

        $$.validPageParams(step01KeyPG);

        pageInit();
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){
        //-- 显示/隐藏 密码
        $(".cancel").click(function () {
            let thisType = $(this).prev().attr("type");

            if(thisType === "password"){
                thisType = "text";
            }else{
                thisType = "password";
            }

            $(this).prev().attr("type", thisType);
        });
        
        /**
         * 提交
         * @Author 肖家添
         * @Date 2019/8/29 20:03
         */
        $("#finish").click(function (e) {
            e.preventDefault();

            let pwdValue = $(".pwd").val();

            const errorMsg = validationForm();

            if($$.isValidObj(errorMsg)){
                $$.layerToast(errorMsg);
                return;
            }
            $$.request({
                url: UrlConfig.member_forgetPassword,
                loading: true,
                pars: {
                    account: phonePG,
                    newestPassword: pwdValue,
                    validationCode: step01KeyPG,
                    step: 2
                },
                sfn: function(data){
                    $$.closeLoading();

                    if(data.success){
                        $$.layerToast("密码修改成功");

                        setTimeout(function(){
                            $$.push("login/login");
                        }, 1000);
                    }else{
                        $$.layerToast(data.msg);
                    }
                },
            });
        });

        /**
         * 实时监控输入
         * @Author 肖家添
         * @Date 2019/8/29 9:42
         */
        $(".pwd, .repwd").off().bind("input", function(){
            inputMonitor();
        });

        /**
         * submit按钮样式自动调整
         * @Author 肖家添
         * @Date 2019/8/29 9:40
         */
        function inputMonitor(){
            const errorMsg = validationForm();

            if(errorMsg == null){
                $(".loginBtn").addClass("active");
            }else{
                $(".loginBtn").removeClass("active");
            }
        }
    }
}

/**
 * 验证表单
 * @Author 肖家添
 * @Date 2019/8/29 9:28
 */
function validationForm(){
    let pwdValue = $(".pwd").val();
    let repwdValue = $(".repwd").val();
    const reg = $$.reg.passwordReg;

    //-- check form
    if(!$$.isValidObj(pwdValue)) {
        return "请输入新密码~";
    }
    if(!reg.test(pwdValue)){
        return "密码为6-16位字母+数字组合~";
    }
    if(!$$.isValidObj(repwdValue)) {
        return "请输入确认密码~";
    }
    if(pwdValue != repwdValue) {
        return "两次密码输入不一致~";
    }

    return null;
}