window.onload = function () {
    $$.changeVersion();
    for (var i=0;i<1;i++){
        $("body").append($(".commentSection").clone());
        if (i=(2-1)){
            $("body").append("<div class=\"unfold\">\n" +
                "        打开APP查看更多\n" +
                "    </div>");
        }
    }
}