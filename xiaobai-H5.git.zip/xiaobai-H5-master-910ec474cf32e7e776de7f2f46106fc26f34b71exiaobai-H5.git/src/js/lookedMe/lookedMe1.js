let vipType = 0;        // 用户VIP状态（默认0：未开通）
window.onload = function () {
    $$.changeVersion();
    $('.selection .date .val').on('click',function () {
        $('.selection .date .val').removeClass('selected');
        $(this).addClass('selected');
        let selection = $(this).attr('id');
        getWhoLookMeList(selection);
    });
    if (!$$.checkLogin()) {
        ShawHandler.gotoLogin();
    } else {
        getWhoLookMeList();
        lookedMeRankWeek();
    }
    weChatShare();

    getVipData();       // 获取用户VIP状态
};
function weChatShare() {
    let imgUrl = 'https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com/market/posterImages/2019/10/tempFiles8ce01cc5fee944c49fd4a487c1c09376_small.jpg';

    let lineLink = $$.getFullHost() + "/src/pages/know/information.html";
    //分享知道栏目页面
    weChatJSTool.config();
    weChatJSTool.share({
        _imgUrl: imgUrl,
        _lineLink: lineLink,
        _shareTitle: '知道',
        _descContent: '点击查看更多文章!!!',
        _sfn: function () {
            console.log("成功注册分享链接：" + lineLink);
        }
    });
    weChatJSTool.hideMenuItems();
}


function getWhoLookMeList(selection = ''){
    $$.request({
        url: UrlConfig.whoLookMe_getWhoLookMeList,
        loading: true,
        pars:{selection:selection},
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let list = data.datas;
                if(list && typeof(list) != 'undefined') {
                    let html = [];
                    for (let i = 0; i < list.length; i++) {
                        html[i] = getHtmlByList(list[i]);
                    }
                    $('.detailList').html(html.join(''));
                    if (html.length > 0) {
                        $('.listIsNull').hide();
                        $('.lookedAt .jump').on('click',function () {
                            let object = $(this).attr('object');
                            let type = $(this).attr('type');
                            jump(object,type);
                        });
                        $('.addClient').on('click',function () {
                            if (vipType !== 0){
                                $$.push('my/addClient',{
                                    name:encodeURI(encodeURI($(this).parent().parent().find('.humanName').html()))
                                });
                            } else{
                                $$.confirm({
                                    title: "想查看访客详情，需您先开通展业功能包哦！点击确认即前往开通！",
                                    onOkLabel: "去开通",
                                    onCancelLabel: "取消",
                                    onOk: function () {
                                        $$.push('my/purchaseVIP/purchaseVIP');
                                    }
                                });
                            }
                        });
                        $('.delete').on('click',function () {
                            const unit = $(this).parent().parent().parent();
                            let browse = unit.attr('browse');
                            const jump = unit.find('.lookedAt .jump');
                            let object = jump.attr('object');
                            let type = jump.attr('type');
                            deleteBrowse(browse,object,type);
                        });
                        $('.human .left .humanPic,.human .left .humanName').on('click',function () {
                            const unit = $(this).parent().parent().parent();
                            const browse = unit.attr('browse');
                            if (vipType !== 0){
                                const unit = $(this).parent().parent().parent();
                                const browse = unit.attr('browse');
                                $$.push('looked/browseDetail',{browse:browse});
                            } else{
                                $$.confirm({
                                    title: "想查看访客详情，需您先开通展业功能包哦！点击确认即前往开通！",
                                    onOkLabel: "去开通",
                                    onCancelLabel: "取消",
                                    onOk: function () {
                                        $$.push('my/purchaseVIP/purchaseVIP');
                                    }
                                });
                            }
                        });
                        $('.myCard').on('click',function () {
                            let memberId = $(this).attr('memberId');
                            if (vipType !== 0){
                                const unit = $(this).parent().parent().parent();
                                const browse = unit.attr('browse');
                                $$.push('my/newMyVisitingCard/myVisitingCard',{memberId:memberId});
                            } else{
                                $$.confirm({
                                    title: "想查看访客详情，需您先开通展业功能包哦！点击确认即前往开通！",
                                    onOkLabel: "去开通",
                                    onCancelLabel: "取消",
                                    onOk: function () {
                                        $$.push('my/purchaseVIP/purchaseVIP');
                                    }
                                });
                            }
                        });
                    } else {
                        listIsNull();
                    }
                } else {
                    listIsNull();
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function getHtmlByList(xpro) {
    let createTime = xpro.createTime;
    let times = xpro.times;
    let nickname = xpro.nickname;
    nickname = nickname == null ? '暂无昵称' : nickname;
    nickname = nickname === '' ? '暂无昵称' : nickname;
    let headimgurl = xpro.headimgurl;
    headimgurl = headimgurl == null ? '../../images/lookedMe/lookedUnitMemberDef.png' : headimgurl;
    headimgurl = headimgurl === '' ? '../../images/lookedMe/lookedUnitMemberDef.png' : headimgurl;
    let lookCount = xpro.lookCount;
    let type = xpro.type;
    let objectId = xpro.objectId;
    let browseId = xpro.browseId;
    let courseTitle = xpro.courseTitle;
    let shareType = xpro.shareType;
    let mtype = xpro.mtype;
    let userStatus = xpro.userStatus;
    let lookedWhatHtml = '';
    let lookedWhat = '查看你分享的';
    let lookedAtHtml = '';
    let imgTop3Html = '';
    let brochure = '';
    let sex = xpro.sex;
    let memberId = xpro.openid;

    // brochure = '<img class="brochure" src="../../images/lookedMe/brochure.png" />';
    if (lookCount === 1) {
        lookedWhat = '首次' + lookedWhat;
    }
    switch (type) {
        case '1':
            lookedWhat += '文章';
            break;
        case '2':
            lookedWhat += '问答';
            break;
        case '3':
            lookedWhat += '课堂视频';
            break;
        case '4':
            lookedWhat += '课堂音频';
            break;
        case '5':
            lookedWhat += '素材库文章';
            break;
        case '6':
            lookedWhat += '名片';
            break;
    }
    let sexCode = "";
    if ($$.isValidObj(sex)){
        if (sex === 1){
            sexCode = '他';
        } else if (sex === 2){
            sexCode = '她';
        }
    }
    let look = '';
    let lookText = '';
    let lookTextNext = '';
    if (nickname === '暂无昵称' || headimgurl === '../../images/lookedMe/lookedUnitMemberDef.png'){
        look = '';
        lookText = '去添加';
        lookTextNext = '为客户';
    }else{
        look = '查看';
        lookText = '去看看';
        lookTextNext = '的动态';
    }

    //名片的courseTitle为undefined
    if (courseTitle === undefined) {
        lookedWhatHtml = '<div class="lookedWhat">' + lookedWhat + '</div>';
        lookedAtHtml = [
            '<div class="lookedAt">',
            '<div class="title">',
            '<span class="text">' + lookText + sexCode+ lookTextNext + '</span>',
            brochure,
            '</div>',
            '<span class="jump myCard" memberId="' + memberId + '" type="' + type + '">'+look+'</span>',
            '</div>'].join('');
    }else{
        lookedWhatHtml = '<div class="lookedWhat">' + lookedWhat + '</div>';
        lookedAtHtml = [
            '<div class="lookedAt">',
                '<div class="title">',
                    '<span class="text">' + courseTitle + '</span>',
                    brochure,
                '</div>',
                '<span class="jump" object="' + objectId + '" type="' + type + '">查看1</span>',
            '</div>'].join('');
    }
    let humanTypeHtml = '';
    let humanType = null;
    let addClientHtml = '';
    if (mtype === 4 && userStatus === 2) {
        humanType = '经纪人';
    } else if ($$.isValidObj(mtype)) {
        humanType = '客户';
    } else {
        switch (shareType) {
            case 'singlemessage':
                humanType = '好友分享访客';
                break;
            case 'groupmessage':
                humanType = '微信群访客';
                break;
            case 'timeline':
                humanType = '朋友圈访客';
                break;
            default:
                humanType = '访客';
                break;
        }
        addClientHtml = '<div class="addClient">添加为客户</div>';
    }
    if (humanType != null) {
        humanTypeHtml = '<div class="humanType">' + humanType + '</div>';
    }

    let sexImg = "";
    if ($$.isValidObj(sex)){
        if (sex === 1){
            sexImg = '../../images/lookedMe/man.png';
        } else if (sex === 2){
            sexImg = '../../images/lookedMe/woman.png';
        }
    }

    /*imgTop3Html = [
        '<div class="imgTop3">',
            '<div class="text">最感兴趣的TOP3页面</div>',
            '<div class="imgList">',
                '<img src="../../images/lookedMe/brochurePageBg.png" />',
                '<img src="../../images/lookedMe/brochurePageBg.png" />',
                '<img src="../../images/lookedMe/brochurePageBg.png" />',
            '</div>',
        '</div>'].join('');*/
    let unitHtml = [
        '<div class="unit" browse="' + browseId + '">',
            '<div class="human space-between">',
                '<div class="left flex-start">',
                    '<img class="humanPic" src="' + headimgurl + '" />',
                    '<span class="humanName overflow">' + nickname + '</span>',
                    $$.isValidObj(sexImg)?'<img class="humanSex" src="'+ sexImg +'" />':'',
                    '<div class="humanTag flex-start">',
                        humanTypeHtml,
                        addClientHtml,
                    '</div>',
                '</div>',
                '<div class="right">',
                    '<img class="delete" src="../../images/lookedMe/delete.png" />',
                '</div>',
            '</div>',
            lookedWhatHtml,
            lookedAtHtml,
            imgTop3Html,
            '<div class="footer">',
                '<div class="time">',
                    '<img src="../../images/lookedMe/time.png" />',
                    '<span>' + createTime + '</span>',
                '</div>',
                '<div class="residenceTime">',
                    '<img src="../../images/lookedMe/residenceTime.png" />',
                    '<span>' + times + '</span>',
                '</div>',
                '<div class="eyes">',
                    '<img src="../../images/lookedMe/eyes.png" />',
                    '<span>' + lookCount + '</span>',
                '</div>',
            '</div>',
        '</div>'];
    return unitHtml.join('');
}
function jump(id,type){
    if (type === '1'){
        $$.push("newKnow/articleDetails", { id:id });
    }else if (type === '2'){
        $$.push("know/questionDetail", { questionId:id });
    }else if (type === '3'){
        $$.push("newKnow/audioDetail", { videoId:id });
    }else if (type === '4'){
        $$.push("newKnow/audioDetail", { audioId:id });
    }else if (type === '5'){
        $$.push("my/shareArticleDetails", { id:id });
    }
}

function listIsNull(){
    $('.listIsNull').show();
    $('.toShare').off().on('click',function () {
        $$.push('know/information');
    });
}
function deleteBrowse(browse, object, type) {
    $$.request({
        url: UrlConfig.management_whoLookMe_deleteBrowse,
        loading: true,
        pars:{
            browseId:browse,
            objectId:object,
            type:type
        },
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                getWhoLookMeList($('.selection .date .val.selected').attr('id'));
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function lookedMeRankWeek() {
    $$.request({
        url: UrlConfig.management_whoLookMe_lookedMeRankWeek,
        loading: true,
        pars:{},
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let list = data.datas;
                if(list && typeof(list) != 'undefined') {
                    let html = [];
                    const top5 = list.length > 5 ? 5 : list.length;
                    for (let i = 0; i < top5; i++) {
                        const xpro = list[i];
                        let browseId = xpro.browseId;
                        let headimgurl = xpro.headimgurl;
                        headimgurl = headimgurl == null ? '../../images/lookedMe/lookedTopDef.png' : headimgurl;
                        html[i] = '<img src="' + headimgurl + '" browse="' + browseId + '" />';
                    }
                    $('.lookedTop5List').html(html.join(''));
                    $('.lookedAbout > span').html(list.length);
                    if (html.length > 0) {
                        $('.lookedTop5List img').on('click',function () {
                            if (vipType !== 0){
                                const browse = $(this).attr('browse');
                                $$.push('looked/browseDetail',{browse:browse});
                            } else{
                                $$.confirm({
                                    title: "想查看访客详情，需您先开通展业功能包哦！点击确认即前往开通！",
                                    onOkLabel: "去开通",
                                    onCancelLabel: "取消",
                                    onOk: function () {
                                        $$.push('my/purchaseVIP/purchaseVIP');
                                    }
                                });
                            }
                        });
                    } else {
                        $('.lookedTop5Text').html('本周暂无访问记录，去分享试试。');
                        $('.lookedAbout').css('display','none');
                    }
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}


//-- 获取当前用户的VIP信息
function getVipData() {
    $$.request({
        url: UrlConfig.member_memberVip_getVipData,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                vipType = data.vipType;
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
