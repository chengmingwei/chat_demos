
let imgUrl = 'https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com/market/posterImages/2019/10/tempFiles8ce01cc5fee944c49fd4a487c1c09376_small.jpg';

let lineLink = $$.getFullHost() + "/src/pages/know/information.html";

window.onload = function () {
    $$.changeVersion();
    if (!$$.checkLogin()) {
        ShawHandler.gotoLogin();
    }
    getWhoLookMeList();

    //点击分享
    $('.toShare').on('click', () => {
        $('#popup').show();
        return false;
    });

    $('#popup .bg,.showFrame').click(function () {
        $('#popup').hide();
        return false;
    });



    /*function emptyLookedMeList(){
        $$.request({
            url:UrlConfig.emptyLookedMeList,
            method: "POST",
            loading: true,
            sfn:function (data) {
                if (data.success){
                    $$.closeLoading();
                }
            }
        });
    }*/

    function getWhoLookMeList(){
        $$.request({
            url: UrlConfig.whoLookMe_getWhoLookMeList,
            loading: true,
            pars:{},
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let html = "";
                    if(data.datas.length>0){
                        for (let i = 0; i < data.datas.length; i++) {
                            html+=`<div class="list">`;
                            if (data.datas[i].headimgurl!=null){
                                html+=`<img class="headImg" src="${data.datas[i].headimgurl}"/>`;
                            }else{
                                html+=`<img class="headImg" src="http://thirdwx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTKRngxr5TKg1DOEVJGOfO4tCftKeXJepOrFuMXHJJZvC5XQNjyicSibcGYC2xOv9HGmoRQjucAD3picg/132"/>`;
                            }
                            if (data.datas[i].nickname!=null){
                                html+=`<p class="name">${data.datas[i].nickname}</p>`;
                            }else{
                                html+=`<p class="name">暂无昵称</p>`;
                            }
                            html+=`<div id="info">`;
                            if (data.datas[i].type == 1){
                                html+=`<div class="info_span">
                                       <span class="overflowOneRow"> ${data.datas[i].title}</span>
                                       <span onclick="jump(${data.datas[i].objectId},${data.datas[i].type})">查看</span>
                                       </div>`;
                            }else if (data.datas[i].type == 2){
                                html+=`<div class="info_span">
                                       <span class="overflowOneRow"> ${data.datas[i].questionContent}</span>
                                       <span onclick="jump(${data.datas[i].objectId},${data.datas[i].type})">查看</span>
                                       </div>`;
                            }else if (data.datas[i].type == 3){
                                html+=`<div class="info_span">
                                       <span class="overflowOneRow"> ${data.datas[i].courseTitle}</span>
                                       <span onclick="jump(${data.datas[i].objectId},${data.datas[i].type})">查看</span>
                                       </div>`;
                            }else if (data.datas[i].type == 4){
                                html+=`<div class="info_span">
                                       <span class="overflowOneRow"> ${data.datas[i].courseTitle}</span>
                                       <span onclick="jump(${data.datas[i].objectId},${data.datas[i].type})">查看</span>
                                       </div>`;
                            }else{
                                html+=`<div class="info_span">
                            <span>暂无数据</span><span>查看</span></div>`;
                            }
                            html+="</div>";
                            html+=`<div id="time"><ul>`;
                            if (data.datas[i].createTime!=null){
                                html+=`<li><img src="../../images/lookedMe/time.png"/>${data.datas[i].createTime}</li>`
                            }else{
                                html+=`<li><img src="../../images/lookedMe/time.png"/>2019-8-30 10:00</li>`
                            }
                            if (data.datas[i].count!=null){
                                html+=`<li><img src="../../images/lookedMe/eyes.png">${data.datas[i].count}</li>`;
                            }else{
                                html+=`<li><img src="../../images/lookedMe/eyes.png">0</li>`;
                            }
                            html+=`</ul></div></div>`;
                        }
                        $("#list").html(html);
                        // emptyLookedMeList();
                    }else{
                        getListIsNull();
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //分享知道栏目页面
    weChatJSTool.config();
    weChatJSTool.share({
        _imgUrl: imgUrl,
        _lineLink: lineLink,
        _shareTitle: '知道',
        _descContent: '点击查看更多文章!!!',
        checkLogin: false,
        _sfn: function () {
            console.log("成功注册分享链接：" + lineLink);
        }
    });
    weChatJSTool.hideMenuItems();
    countAction("xb_2070");
};
function jump(id,type){
    if (type === 1){
        $$.push("newKnow/articleDetails", { id:id });
    }else if (type === 2){
        $$.push("know/questionDetail", { questionId:id });
    }else if (type === 3){
        $$.push("newKnow/audioDetail", { videoId:id });
    }else if (type === 4){
        $$.push("newKnow/audioDetail", { audioId:id });
    }
}

let getListIsNull = ()=>{
    let html = `<div class="image"></div>
    <div class="tex">暂无访客记录</div>
    <div class="toShare" location-href="know/information">去分享</div>`;
    $('#list').remove();
    $('body').append(html);
    //-- 跳转自动绑定
    $$.staticPushAutoBind();
};
