window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_72', null);
    } catch (error) {
        console.log(error);
    }

    let productState = $$.getUrlParam("productState");
    if (productState){
        $(".all_header").hide();
        $(".addClient").hide();
    }
    let customerInformationList = {};        // 客户信息列表

    whoLookedMeList();                      // 访客（谁看过我）

    getVipData();                            // 获取当前用户的VIP信息

    //-- 客户信息列表
    /*$$.request({
        //userLinkMan_listAll
        //userLinkMan_getUserLinkManInfoByOrder
        url: UrlConfig.userLinkMan_getUserLinkManInfoByOrder,
        method: "GET",
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                if(data.datas.length !== 0){
                    $$.hideNoResultView();
                    const list = data.datas;
                    showUserLinkManElement(list,1);
                }else{
                    $$.showNoResultView({
                        parentJqSelector: "html",
                        msg: "暂无客户资料",
                    });
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });*/

    $('.weui-navbar__item').on('click', function () {
        const data_id = $(this).attr("data-id");
        if ((vipType === 0 && data_id === '2') || vipType > 0) {
            $(this).children(".underframe").addClass('weui-bar__item_on');
            $(this).siblings('.weui-bar__item_on').children(".underframe").removeClass('weui-bar__item_on');

            $(this).addClass('weui-bar__item_on').siblings('.weui-bar__item_on').removeClass('weui-bar__item_on');
            $($(this).attr("href")).show().siblings('.weui-tab__content').hide();
            $(".SHOW_NO_RESULT_VIEW_ID").remove();
        }
        if(data_id === '1'){/*有保单点击事件*/
            if (vipType === 0) {
                $$.confirm({
                    title: "此功能需开通VIP",
                    onOkLabel: "去开通",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
            } else {
                if (!$$.isValidObj(customerInformationList[1])){
                    $$.request({
                        url: UrlConfig.userLinkMan_getUserLinkManInfoByOrder,
                        method: "GET",
                        loading: true,
                        sfn: function (data) {
                            $$.closeLoading();
                            if (data.success) {
                                if(data.datas.length !== 0){
                                    customerInformationList[1] = data.datas;
                                    $$.hideNoResultView();
                                    const list = data.datas;
                                    showUserLinkManElement(list,1);
                                }else{
                                    $$.showNoResultView({
                                        parentJqSelector: "html",
                                        msg: "暂无客户资料",
                                    });
                                }
                            } else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });
                } else{
                    showUserLinkManElement(customerInformationList[2],1);
                }
                $(".sort_box").show();
                $(".sort_box_not").hide();
                $(".sort_box_other").hide();
            }
        }else if(data_id === '2'){/*无保单*/
            if (!$$.isValidObj(customerInformationList[2])){
                $$.hideNoResultView();
                $$.request({
                    url: UrlConfig.userLinkMan_listAll,
                    method: "GET",
                    loading: true,
                    sfn: function (data) {
                        $$.closeLoading();
                        if (data.success) {
                            if(data.datas.length !== 0){
                                customerInformationList[2] = data.datas;
                                $$.hideNoResultView();
                                const list = data.datas;
                                showUserLinkManElement(list,2);
                            }else{
                                $$.showNoResultView({
                                    parentJqSelector: "html",
                                    msg: "暂无客户资料",
                                });
                            }
                        } else {
                            $$.layerToast(data.msg);
                        }
                    },
                    ffn: function (data) {
                        $$.errorHandler();
                    }
                });
            } else {
                showUserLinkManElement(customerInformationList[2],2);
            }
            $(".sort_box_not").show();
            $(".sort_box").hide();
            $(".sort_box_other").hide();
        }else if(data_id === '3'){/*访客*/
            if (vipType === 0) {
                $$.confirm({
                    title: "此功能需开通VIP",
                    onOkLabel: "去开通",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
            } else {
                if (!$$.isValidObj(customerInformationList[3])) {
                    $$.hideNoResultView();
                    $$.request({
                        url: UrlConfig.userLinkMan_getVisitorsList,
                        method: "GET",
                        loading: true,
                        sfn: function (data) {
                            $$.closeLoading();
                            if (data.success) {
                                if (data.datas.length !== 0) {
                                    customerInformationList[3] = data.datas;
                                    $$.hideNoResultView();
                                    const list = data.datas;
                                    showUserLinkManElement(list, 3);
                                } else {
                                    $$.showNoResultView({
                                        parentJqSelector: "html",
                                        msg: "暂无客户资料",
                                    });
                                }
                            } else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });
                } else {
                    showUserLinkManElement(customerInformationList[3], 3);
                }
                $(".sort_box_other").show();
                $(".sort_box_not").hide();
                $(".sort_box").hide()
            }
        }
    });

    //-- 访客（谁看过我）
    function whoLookedMeList(){
        $$.request({
            url:UrlConfig.whoLookMe_getWhoLookMeList,
            method: "POST",
            loading: true,
            requestBody:true,
            sfn:function (data) {
                $$.closeLoading();
                if (data.success){
                    let count = 0;
                    // $(".msgCount").text(data.datas.length);
                    data.datas.forEach((Item,Index)=>{
                        if(Item.isenabled === 1){
                            count++;
                            if(count > 99){
                                count = "···";
                            }
                            $(".msgCount").show().text(count);
                        }
                    });
                }else{
                    $$.layerToast("查询失败");
                }
            }
        })
    }



    /**
     * 绑定客户列表
     */
    function showUserLinkManElement(list,type) {
        let html = "";
        if ($$.isValidObj(list)) {
            list.forEach((item, index) => {
                html += `
                <div class="sort_list" data-info="${item.id !== undefined ? item.id : ""}" data-name ="${item.name}" data-item='${JSON.stringify(item)}'>
                    <div class="num_logo">
                        <img src="../../images/lookedMe/TestA.png" alt=""/>
                    </div>
                    <div class="num_name"><p>${item.name}</p>
                        <p class="certificate">${item.mobile !== undefined ? item.mobile : ""}</p>
                    </div>
                 </div>
                `;
            });
            if (type === 1){
                $(".sort_box").html(html);
                $(".sort_box_not").html("");
                $(".sort_box_other").html("");
            }else if (type === 2){
                $(".sort_box").html("");
                $(".sort_box_not").html(html);
                $(".sort_box_other").html("");
            }else if (type === 3){
                $(".sort_box").html("");
                $(".sort_box_not").html("");
                $(".sort_box_other").html(html);
            }

            $(".sort_list").on('click', function () {
                if (productState){
                    let item = $(this).attr("data-item");
                    parent.getContactsInfo(item);
                    parent.layer.closeAll();
                } else {
                    let id = $(this).attr("data-info");
                    let name = encodeURI($(this).attr("data-name"));
                    const data_item = JSON.parse($(this).attr("data-item"));
                    $$.push('my/addClient', {
                        id : id,
                        name :encodeURI(name),
                        browseId : data_item.browseid,
                        fillInState: 1
                    });
                }

            });
        }
        initials(type);
    }


    goAddClient();
    //goToHowLookMe();

    window.onresize = function () {
        if ($(window).height() < 400) {
            $('.nav').hide();
        } else {
            $('.nav').show();
        }

    };

    $('[class*="-two"]').css('display', 'none');

    $('.header').click(function () {
        $('[class*="-two"]').css('display', 'block');
        $('.wrapper').hide();
        $('.SHOW_NO_RESULT_VIEW_ID').hide();
        $('#search').focus();
    });

    $('#search').bind('input propertychange', function () {
        $('.sort_box-two').html('');
        //进行相关操作
        const val = $(this).val();
        if (val === "") {
            return;
        }
        let str = "";
        //去查找原字符串及其拼音首字母是否包含此字符，若包含就把它加进去
        $(".sort_list").each(function () {
            const name = $(this).find('.num_name').text();
            if (name.toLowerCase().indexOf(val.toLowerCase()) !== -1) {//包含
                str += "<div class='sort_list-two' id='" + $(this).attr('id') + "'> " + $(this).html() + "</div>";
            } else {
                const PYarr = makePy(name);
                for (let i = 0; i < PYarr.length; i++) {

                    if (PYarr[i].toLowerCase().indexOf(val.toLowerCase()) !== -1) {//包含
                        str += "<div class='sort_list-two' id='" + $(this).attr('id') + "'> " + $(this).html() + "</div>";
                    } else {//不包含

                    }
                }
            }
        });
        $('.sort_box-two').html(str);

    });
    const Initials = $('.initials');
    const LetterBox = $('#letter');
    Initials.find('ul').append('<li>A</li><li>B</li><li>C</li><li>D</li><li>E</li><li>F</li><li>G</li><li>H</li><li>I</li><li>J</li><li>K</li><li>L</li><li>M</li><li>N</li><li>O</li><li>P</li><li>Q</li><li>R</li><li>S</li><li>T</li><li>U</li><li>V</li><li>W</li><li>X</li><li>Y</li><li>Z</li><li>#</li>');

    $(".initials ul li").click(function () {
        var _this = $(this);
        var LetterHtml = _this.html();
        LetterBox.html(LetterHtml).fadeIn();
        Initials.css('background', 'rgb(255,255,255)');

        setTimeout(function () {
            Initials.css('background', 'rgba(145,145,145,0)');
            LetterBox.fadeOut();
        }, 1000);

        const _index = _this.index();
        if (_index === 0) {
            $('html,body').animate({scrollTop: '0px'}, 300);//点击第一个滚到顶部
        } else if (_index === 27) {
            const DefaultTop = $('#default').position().top;
            $('html,body').animate({scrollTop: DefaultTop + 'px'}, 300);//点击最后一个滚到#号
        } else {
            const letter = _this.text();
            if ($('#' + letter).length > 0) {
                const LetterTop = $('#' + letter).position().top;
                $('html,body').animate({scrollTop: LetterTop - 45 + 'px'}, 300);
            }
        }
    });

    const windowHeight = $(window).height();
    const InitHeight = windowHeight - 110;
    Initials.height(InitHeight);
    const LiHeight = InitHeight / 28;
    Initials.find('li').height(LiHeight);
};
let vipType;//vip类型
function back() {
    $('[class*="-two"]').css('display', 'none');
    $('.wrapper').show();
    $('#search').val("");
    $('.sort_box-two').html("");
}


function initials(type) {//公众号排序
    const SortList = $(".sort_list");
    let SortBox;
    if (type === 1){
        SortBox = $(".sort_box");
        SortList.sort(asc_sort).appendTo('.sort_box');//按首字母排序
    }
    if (type === 2){
        SortBox = $(".sort_box_not");
        SortList.sort(asc_sort).appendTo('.sort_box_not');//按首字母排序
    }
    if (type === 3){
        SortBox = $(".sort_box_other");
        SortList.sort(asc_sort).appendTo('.sort_box_other');//按首字母排序
    }

   // SortList.sort(asc_sort).appendTo('.sort_box');//按首字母排序
    function asc_sort(a, b) {
        return makePy($(b).find('.num_name').text().charAt(0))[0].toUpperCase() < makePy($(a).find('.num_name').text().charAt(0))[0].toUpperCase() ? 1 : -1;
    }

    const initials = [];
    let num = 0;
    SortList.each(function (i) {
        const initial = makePy($(this).find('.num_name').text().charAt(0))[0].toUpperCase();
        if (initial >= 'A' && initial <= 'Z') {
            if (initials.indexOf(initial) === -1)
                initials.push(initial);
        } else {
            num++;
        }

    });

    $.each(initials, function (index, value) {//添加首字母标签
        SortBox.append('<div class="sort_letter" id="' + value + '">' + value + '</div>');
    });
    if (num !== 0) {
        SortBox.append('<div class="sort_letter" id="default">#</div>');
    }

    for (let i = 0; i < SortList.length; i++) {//插入到对应的首字母后面
        const letter = makePy(SortList.eq(i).find('.num_name').text().charAt(0))[0].toUpperCase();
        switch (letter) {
            case "A":
                $('#A').after(SortList.eq(i));
                break;
            case "B":
                $('#B').after(SortList.eq(i));
                break;
            case "C":
                $('#C').after(SortList.eq(i));
                break;
            case "D":
                $('#D').after(SortList.eq(i));
                break;
            case "E":
                $('#E').after(SortList.eq(i));
                break;
            case "F":
                $('#F').after(SortList.eq(i));
                break;
            case "G":
                $('#G').after(SortList.eq(i));
                break;
            case "H":
                $('#H').after(SortList.eq(i));
                break;
            case "I":
                $('#I').after(SortList.eq(i));
                break;
            case "J":
                $('#J').after(SortList.eq(i));
                break;
            case "K":
                $('#K').after(SortList.eq(i));
                break;
            case "L":
                $('#L').after(SortList.eq(i));
                break;
            case "M":
                $('#M').after(SortList.eq(i));
                break;
            case "O":
                $('#O').after(SortList.eq(i));
                break;
            case "P":
                $('#P').after(SortList.eq(i));
                break;
            case "Q":
                $('#Q').after(SortList.eq(i));
                break;
            case "R":
                $('#R').after(SortList.eq(i));
                break;
            case "S":
                $('#S').after(SortList.eq(i));
                break;
            case "T":
                $('#T').after(SortList.eq(i));
                break;
            case "U":
                $('#U').after(SortList.eq(i));
                break;
            case "V":
                $('#V').after(SortList.eq(i));
                break;
            case "W":
                $('#W').after(SortList.eq(i));
                break;
            case "X":
                $('#X').after(SortList.eq(i));
                break;
            case "Y":
                $('#Y').after(SortList.eq(i));
                break;
            case "Z":
                $('#Z').after(SortList.eq(i));
                break;
            default:
                $('#default').after(SortList.eq(i));
                break;
        }
    }
}


/*点击添加用户*/
let goAddClient = () => {
    $('.addClient').on('click', () => {
        $$.push('my/addClient',{
            fillInState: 0
        });
    });
};

//跳转到谁看过我
let goToHowLookMe = ()=>{
    $('.msg').click(()=>{
        $$.push('looked/lookedMe');
    });
};

//-- 获取当前用户的VIP信息
function getVipData() {
    $$.request({
        url: UrlConfig.member_memberVip_getVipData,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                console.log(data);
                let path = '';
                vipType = data.vipType;
                switch (data.vipType) {
                    case 0:{
                        // 未开通用户
                        path = 'looked/lookedMe';
                        break;
                    }
                    case 1:
                    case 2:{
                        // VIP用户 和 团长加速包用户
                        path = 'looked/lookedMe1';
                        break;
                    }
                }
                $('.weui-navbar__item')[1].click();
                $('.msg').click(()=>{
                    $$.push(path);
                });
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
