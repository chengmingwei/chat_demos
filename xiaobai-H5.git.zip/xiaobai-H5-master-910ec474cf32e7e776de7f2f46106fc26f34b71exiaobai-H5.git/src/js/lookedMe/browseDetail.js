window.onload = function () {
    $$.changeVersion();
    function jump(id,type,productId){
        if (type === '1'){
            $$.push("newKnow/articleDetails", { id:id });
        }else if (type === '2'){
            $$.push("newKnow/audioDetail", { videoId:id });
        }else if (type === '5'){
            const uuid = $$.getTimeStampNow();
            $$.push('product/productDetail',{
                sellId:id,
                productId:productId,
                uuid:uuid
            });
        }else if (type === '6'){
            $$.push("know/audioDetail", { audioId:id });
        }else if (type === '7'){
            $$.push("know/questionDetail", { questionId:id });
        }else if (type === '8'){
            $$.push("my/shareArticleDetails", { id:id });
        }
    }

    function getHtmlByList(xpro) {
        const viewNum = xpro.viewNum;
        const lookTime = xpro.lookTime;
        const type = xpro.type;
        const objectId = xpro.objectId;
        const courseTitle = xpro.courseTitle;
        const productId = xpro.productId;
        const share = xpro.share;
        let lookedWhat = '查看';
        if (viewNum === 1) {
            lookedWhat = '首次' + lookedWhat;
        }
        switch (type) {
            case 1:
                lookedWhat += '资讯';
                break;
            case 2:
                lookedWhat += '视频';
                break;
            case 5:
                lookedWhat += '产品';
                break;
            case 6:
                lookedWhat += '音频';
                break;
            case 7:
                lookedWhat += '问答';
                break;
        }
        const dateText = lookTime.split(' ')[0];
        const timeText = lookTime.split(' ')[1].substring(0,lookTime.split(' ')[1].lastIndexOf(':'));
        let productIdAttr = '';
        if (productId) {
            productIdAttr = ' product="' + productId + '"';
        }
        const shareListHtml = [];
        if ($$.isValidObj(share)) {
            shareListHtml.push(`<img src="${$('.browse > img').attr('src')}" />`);
            shareListHtml.push(`<span>&lt;</span>`);
            shareListHtml.push(`<img src="${share.headimgurl}" browse="${share.browseId}" />`);
            const share2 = share.share;
            if ($$.isValidObj(share2)) {
                shareListHtml.push(`<span>&lt;</span>`);
                shareListHtml.push(`<img src="${share2.headimgurl}" browse="${share2.browseId}" />`);
            }
        }
        return `<div>
                <div class="left">
                    <div class="date">${dateText}</div>
                    <div class="time">${timeText}</div>
                </div>
                <div class="right">
                    <div class="lookedWhat">${lookedWhat}</div>
                    <div class="lookedAt" object="${objectId}" type="${type}"${productIdAttr}>${courseTitle}</div>
                    <div class="shareList">${shareListHtml.join('')}</div>
                </div>
            </div>`;
    }

    function getStatisticList(memberId,openId) {
        $$.request({
            url: UrlConfig.member_viewstatistic_getStatisticList,
            loading: true,
            pars: {memberId: memberId,openId: openId},
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let list = data.list;
                    if(list && typeof(list) != 'undefined') {
                        let html = [];
                        for (let i = 0; i < list.length; i++) {
                            html[i] = getHtmlByList(list[i]);
                        }
                        $('.list .main').html(html.join(''));
                        $('.list .main > div .right .lookedAt').on('click',function () {
                            let object = $(this).attr('object');
                            let type = $(this).attr('type');
                            let productId = $(this).attr('product');
                            jump(object,type,productId);
                        });
                        $('.list .main > div .right .shareList > img').on('click',function () {
                            const browseId = $(this).attr('browse');
                            if ($$.isValidObj(browseId)) {
                                $$.push('looked/browseDetail',{browse:browseId});
                            }
                        });
                    }
                }
            }
        });
    }

    function getBrowse() {
        const browse = $$.getUrlParam("browse");
        $$.request({
            url: UrlConfig.management_browsewxinfo_getBrowseDetail,
            loading: true,
            pars:{browseId:browse},
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $('.browse > div .up .name').html(data.nickname);
                    let headimgurl = data.headimgurl;
                    headimgurl = $$.isValidObj(headimgurl) ? headimgurl : '../../images/lookedMe/lookedUnitMemberDef.png';
                    $('.browse > img').attr('src',headimgurl);
                    const countNumber = data.countNumber;
                    $('.countNumber > span').html(countNumber);
                    let disposition = 'TA对您非常感兴趣';
                    let disposition2 = '联系看看客户有什么需求';
                    let dispositionImg = '../../images/lookedMe/disposition2.png';
                    if (countNumber <= 5) {
                        disposition = 'TA对您感兴趣';
                        disposition2 = '继续保持联系';
                        dispositionImg = '../../images/lookedMe/disposition1.png';
                    } else if (countNumber > 10) {
                        disposition = 'TA对您十分感兴趣';
                        disposition2 = '赶紧去联系';
                        dispositionImg = '../../images/lookedMe/disposition3.png';
                    }
                    $('.disposition1 > span').html(disposition);
                    $('.disposition1 > img').attr('src',dispositionImg);
                    $('.disposition2').html(disposition2);
                    let humanType = '';
                    if (data.mtype === 4 && data.userStatus === 2) {
                        humanType = '经纪人';
                    } else if ($$.isValidObj(data.mtype)) {
                        humanType = '客户';
                    } else {
                        switch (data.shareType) {
                            case 'singlemessage':
                                humanType = '好友分享访客';
                                break;
                            case 'groupmessage':
                                humanType = '微信群访客';
                                break;
                            case 'timeline':
                                humanType = '朋友圈访客';
                                break;
                        }
                    }
                    $('.humanType').html(humanType);
                    const sex = data.sex;
                    const sexHtml = $('.browse .up > img');
                    if (sex === 0) {
                        sexHtml.hide();
                    } else {
                        let sexImg = '../../images/lookedMe/man.png';
                        if (sex === 2) {
                            sexImg = '../../images/lookedMe/woman.png';
                        }
                        sexHtml.attr('src',sexImg);
                    }
                    getStatisticList(data.memberId,data.openId);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    getBrowse();
};
