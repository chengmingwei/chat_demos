let labelArr= {};
let isAnonymous = 0;
window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_54', null);
    } catch (error) {
        console.log(error);
    }
    // 匿名发布
    $(".send").click(function () {
        $(this).toggleClass("isSelectCheckbox");
    });
    loadLabel();
    $(".sendBtn").on("click",function () {
        $$.loading();
        let supplement = $("#supplement").val().trim();
        let questionContent = $("#questionContent").val().trim();
        let isAnonymous =  $(".send").attr("class");
        if (isAnonymous.indexOf("isSelectCheckbox") !== -1 ){
            //匿名发布
            isAnonymous = 1;
        }else {
            isAnonymous = 0;
        }
        if (questionContent === ""){
            $$.layerToast("请输入你的提问内容！");
            return;
        }
        if (questionContent.length < 5){
            $$.layerToast("输入的内容不能少5个字！");
            return;
        }
        if (questionContent.length > 25){
            $$.layerToast("输入的内容超25个字！");
            return;
        }
        let labelId = Object.keys(labelArr).join(",");
        console.log(labelId);
        if (!ShawHandler.isValidObj(labelId)){
            $$.layerToast("请选择问题分类");
            return;
        }
        countAction("xb_2018");
        $$.request({
            url: UrlConfig.question_insertQuestion,
            pars: {
                questionContent:questionContent,
                supplement:supplement,
                labelId:labelId,
                IsAnonymous:isAnonymous
            },
            requestBody:true,
            sfn: function(data){
                if(data.success){
                    console.log(data);
                    $$.alert("保存成功！",function () {
                        $$.push("know/myAllQuestion");
                    })
                }else {
                    $$.alert(data.msg);
                }

            }
        });
    })
};
function loadLabel() {
    $$.request({
        url: UrlConfig.label_searchLabelList,
        pars: {
            state:1,
            classifyId:1
        },
        sfn: function(data){
            let html = "";
            for (let i = 0; i <data.datas.length ; i++) {
                html += "<li data-id='"+data.datas[i].id+"'>"+data.datas[i].labelName+"</li>";
            }
            $("#labelList").html(html);

            // 话题分类切换
            $(".type li").click(function () {
                const that = $(this);
                let id = that.attr("data-id");
                let arr = Object.keys(labelArr);
                if (arr.length < 3 || labelArr[id]){
                    if(labelArr[id]){
                        delete labelArr[id];
                        $(this).removeClass("active");
                    }else{
                        labelArr[id] = id;
                        $(this).attr("class","active");
                    }
                }
                countAction("xb_2019");
            });
        }
    });
}
