let questionId;
let shareMemberId;
let shareStatus;
window.onload = function () {
    $$.changeVersion();
    questionId = $$.getUrlParam("questionId");
    loadQuestion(questionId);
    loadSiftaAnswer(questionId);
    loadAllAnswer(questionId);
    checkShare();
    insertBrowse(questionId);

    $(".answerBtn").on("click",function(){
        //数据统计
        try {
            countAction('xb_52', null);
        } catch (error) {
            console.log(error);
        }

        if ($$.checkLogin()){
            $$.push("know/myAnswer",{
                questionId:questionId
            });
        } else{
            $$.confirmLogin();
        }

    });
    shareMemberId = $$.getUrlParam("shareMemberId");
    shareStatus = $$.getUrlParam("share");
    shareQuestionDetail(shareMemberId,shareStatus);
    $$.setReadLongTimes();
};

/*提问*/
function loadQuestion(id) {
    $$.request({
        url: UrlConfig.question_getDetailsByMemberId,
        pars: {questionId:id },
        method: "POST",
        requestBody:true,
        sfn: function (data) {
            console.log(data);
            if (data.success) {
                let resultHtml = ``;
                let name = ``;
                if (data.datas != null){
                    $('title').html(data.datas.questionContent);
                    resultHtml += `<h3>${data.datas.questionContent}</h3>`;
                    resultHtml += `<p class="message">`;

                    //判断是否是匿名发表
                    if(data.datas.isAnonymous === 1){
                        resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" />
                                       <span class="name">匿名</span>`;
                    }else{
                        //判断是否设置过昵称
                        if("" === data.datas.rname|| null == data.datas.rname){
                            name = data.datas.account;
                            //判断是否为正常发表
                            if("" === name || null == name){
                                name = "入侵者";
                                resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" />
                                               <span class="name" style="color: #ff7052;">${name}</span>`;
                            }else{
                                if("" == data.datas.imgPath || null == data.datas.imgPath){
                                    resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" />
                                               <span class="name">${name}</span>`;
                                }else{
                                    resultHtml += `<img class="headImg" src=${data.datas.imgPath} />
                                               <span class="name">${name}</span>`;
                                }
                            }
                        }else{
                            name = data.datas.rname;
                            if("" == data.datas.imgPath || null == data.datas.imgPath){
                                resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" />
                                               <span class="name">${name}</span>`;
                            }else{
                                resultHtml += `<img class="headImg" src=${data.datas.imgPath} />
                                               <span class="name">${name}</span>`;
                            }
                        }
                    }
                    resultHtml += `<span class="date">${data.datas.publishTime}</span>`;
                    resultHtml += `<span class="views">浏览${data.datas.browse}次</span>`;
                    resultHtml += `</p>`;
                    resultHtml += `<span class="share"></span>`;
                    $(".session1").html(resultHtml);
                    $('.share').click(function () {
                        $$.showShareView();
                    });
                    //分享
                    if ($$.checkLogin()){
                        let shareUrl = window.location.href+"&share=true&memberId="+data.memberId;
                        console.log(shareUrl);
                        weChatJSTool.share({
                            _imgUrl: $Constant.shareLogo,
                            _lineLink: shareUrl,
                            _shareTitle: data.datas.questionContent,
                            _descContent: '集思广益，这个问题的答案你知道吗？快来看看吧！',
                            _sfn: function () {
                                console.log("成功注册分享链接："+shareUrl);
                                check();
                                countAction("xb_2015");
                            }
                        });
                    }
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
function check() {
    $$.request({
        url: UrlConfig.integral_checkToDayShareArticle,
        pars: {},
        method: "POST",
        sfn: function (data) {
            console.log('<<<<<');
            console.log(data);
            if (!data) {
                $$.request({
                    url: UrlConfig.integral_handSendIntegral,
                    pars: {
                        code:"I0005"
                    },
                    method: "POST",
                    sfn: function (info) {
                        console.log('>>>');
                        console.log(info);
                        if (info.success){
                            $$.alert("积分赠送成功！")
                        }
                    }
                });
            }
        }
    });
}
/*精选*/
function loadSiftaAnswer(id) {
    $$.request({
        url: UrlConfig.answer_getTopDetailsByMemberId,
        pars: {questionId:id,isTop:1 },
        method: "POST",
        requestBody:true,
        sfn: function (data) {
            if (data.success) {
                let resultHtml = "";
                if (data.datas != null){
                    resultHtml += "<h3>精选答案</h3>";
                    resultHtml += "<p class=\"message\">";
                    if (data.datas[i].isAnonymous == 1){
                        resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" /><span class="name">匿名</span>`;
                    }else {
                        let name = data.datas[i].rname ? data.datas[i].rname : data.datas[i].account;
                        if("" == name || null == name){
                            name = "入侵者";
                            resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" /><span class="name" style='color: #ff7052;'>${name}</span>`;
                        }else{
                            if("" == data.datas[i].imgPath || null == data.datas[i].imgPath){
                                resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" /><span class="name">${name}</span>`;
                            }else{
                                resultHtml += `<img class="headImg" src=${data.datas[i].imgPath} /><span class="name">${name}</span>`;
                            }
                        }
                    }
                    resultHtml += "	<span class=\"date\">"+getDate(data.datas.answerDate)+"</span>";
                    resultHtml += "	<span class=\"support\">"+ data.datas.giveLike +"</span>";
                    resultHtml += "</p>";
                    resultHtml += "<div class=\"answer\">";
                    resultHtml += "	<span style=\"overflow: hidden\">"+ data.datas.answerContent +"</span>";
                    resultHtml += "</div>";
                    $(".session2").html(resultHtml);
                }else {
                    $(".session2").remove()
                }

            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
/*全部*/
function loadAllAnswer(id) {
    $$.request({
        url: UrlConfig.answer_getAllAnswer,
        pars: {questionId:id},
        method: "POST",
        requestBody:true,
        sfn: function (data) {
            if (data.success) {
                console.log(data);
                let resultHtml = "";
                for (let i = 0; i <data.datas.length; i++) {
                    resultHtml += "<li>";
                    resultHtml += "<p class=\"message\">";
                    if (data.datas[i].isAnonymous == 1){
                        resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" /><span class="name">匿名</span>`;
                    }else {
                        let name = data.datas[i].rname ? data.datas[i].rname : data.datas[i].account;
                        if("" == name || null == name){
                            name = "入侵者";
                            resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" /><span class="name" style='color: #ff7052;'>${name}</span>`;
                        }else{
                            if("" == data.datas[i].imgPath || null == data.datas[i].imgPath){
                                resultHtml += `<img class="headImg" src="../../images/my/mituLogo.png" /><span class="name">${name}</span>`;
                            }else{
                                resultHtml += `<img class="headImg" src=${data.datas[i].imgPath} /><span class="name">${name}</span>`;
                            }
                        }
                    }
                    resultHtml += "   <span class=\"date\">"+ getDate(data.datas[i].answerDate) +"</span>";
                    //resultHtml += "   <span class=\"support\" onclick='getGiveLike(this,data.datas[i].id,data.datas[i].giveLike)'>"+ data.datas[i].giveLike >= 0 ? data.datas[i].giveLike : 0 +"</span>";
                    resultHtml +=`<span class="support" onclick="getGiveLike(this,${data.datas[i].id},${data.datas[i].giveLike})">${data.datas[i].giveLike >= 0 ? data.datas[i].giveLike : 0}</span>`;
                    resultHtml += "</p>";
                    resultHtml += "<div class=\"answer\">";
                    resultHtml += "   <p>";
                    resultHtml += data.datas[i].answerContent ;
                    resultHtml += "   </p>";
                    resultHtml += "</div>";
                    resultHtml += "</li>";
                }

                $("#allAnswer").html(resultHtml);
                $("#allAnswer li:gt(1)").hide();

                if(data.datas.length == 0){
                    $(".getMore").text("暂无回答");
                }else{
                    $(".getMore").off().on("click",function(){
                        $("#allAnswer li:gt(1)").show();
                        $(".getMore").remove();
                        countAction("xb_2017");
                    });
                }

            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}

function shareQuestionDetail(shareMemberId,shareStatus) {
    if (shareMemberId !=null && shareStatus === 'true'){
       //alert("获取分享页");
        $$.request({
            url: UrlConfig.member_getShareMemberInfo,
            pars:{
                memberId:shareMemberId
            },
            loading:true,
            method: "POST",
            sfn: function(data){
                if(data.success){
                    $$.closeLoading();
                    if (data.datas.rname!=null && data.datas.rname!=""){
                        $(".name p").text(data.datas.rname);
                    }else{
                        $(".name p").text(data.datas.account);
                    }
                    if( (data.datas.imgPath!=null)&& (data.datas.imgPath!="")){
                        $(".head").attr("src",data.datas.imgPath);
                    }else {
                        $(".head").attr("src", "../../images/my/defaultImg.png");
                    }
                    $(".evaluate").hide();
                    $(".menu").hide();
                    $(".info").show();
                    $('.iphone').on('click',function () {
                        window.location.href = "tel:"+data.datas.phone;
                    });
                    if ($$.checkLogin()){
                        $(".answerBtn").show();
                        $(".loginApp").hide();
                    }else{
                        $(".answerBtn").hide();
                        $(".loginApp").show();
                    }
                    $('.loginApp').on('click',function (){
                            $$.push("login/login");
                    })
                }else{
                    $$.layerToast("系统出错");
                }
            }
        });
    }
}



function getDate(dateTimeStamp) {
    let myDate = new Date();
    let year = myDate.getFullYear(); //获取当前年
    let mon = myDate.getMonth() + 1; //获取当前月
    let date = myDate.getDate(); //获取当前日
    const h = myDate.getHours();//获取当前小时数(0-23)
    const m = myDate.getMinutes();//获取当前分钟数(0-59)
    // var s = myDate.getSeconds();//获取当前秒

    const timearr = dateTimeStamp.replace(" ", ":").replace(/\:/g, "-").split("-");
    if(timearr[0] == year && timearr[1] == mon && timearr[2] == date){
        if((h-timearr[3]) > 0){
            return (h-timearr[3])+"小时前";
        }else{
            if((m-timearr[4]) == 0){
                return "刚刚";
            }else{
                return (m-timearr[4])+"分钟前";
            }
        }
    }else{
        return timearr[0] +"-"+ timearr[1] +"-"+ timearr[2];
    }
}
//更新点赞数
function getGiveLike(doc,id,giveLike){
    $$.request({
        url: UrlConfig.praisestatistic_save,
        pars: {
            type:13,
            objectId:id
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                let n =  $(doc).text().trim();
                if (data.delete){
                    giveLike = parseInt(n)-1;
                    $$.layerToast('取消点赞！');
                    $(doc).html(giveLike)

                }else {
                    giveLike = parseInt(n)+1;
                    $(doc).html(giveLike);
                    $$.layerToast('点赞成功！');
                }
                $$.request({
                    url: UrlConfig.answer_updateAnswer,
                    pars: {
                        "id": id,
                        "giveLike": giveLike,
                    },
                    sfn: function (data) {

                    }
                });

            } else {
                if ($$.checkLogin()){
                    $$.layerToast(`${data.msg}`);
                } else{
                    $$.confirmLogin();
                }
            }
        }
    });
}

//微信授权登录
function checkShare() {
    let share = $$.getUrlParam("share");
    let memberId = $$.getUrlParam("memberId");
    let id = $$.getUrlParam("questionId");
    if (share === 'true'){
        let url = window.location.search;
        url = url.replace("true",'false');
        url = "know/questionDetail.html"+url;
        console.log('----url',url);
        ShawHandler.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: url,
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_6,
                otherParams: JSON.stringify({"objectId": id,"type":2,"memberId":memberId})
            },
            loading: true,
            sfn: function(data){
                $$.closeLoading();
                location.href = data.datas;
            }
        });
    }
}

/**
 * 描述信息：添加浏览记录
 * @author 覃创斌
 * @date 2019/10/12
 */
function insertBrowse(id) {
    let memberId = $$.getUrlParam("memberId");
    $$.request({
        url: UrlConfig.viewStatistic_insertViewStatistic,
        pars: {
            shareUserId:memberId,
            type:7,
            objectId:id,
            judge:1
        },
        method: "POST",
        sfn: function (data) {
            console.log('--------------Audio');
            console.log(data);
        }
    });
}
