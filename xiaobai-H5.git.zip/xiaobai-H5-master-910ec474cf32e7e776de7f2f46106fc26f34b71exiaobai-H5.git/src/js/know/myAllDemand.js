$(function(){
	pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        //-- 匹配后台数据更新
        $$.request({
            url: UrlConfig.member_demand_wx_showMyDemandList,
			requestBody:true,
            sfn: function(data){
            	console.log(data);
				if(data.success){
					//-- 加载
					bindList(data);
				}
            }
        });
    }
	function bindList(data){
		let html = [];
		if (data.list.length > 0){
			$$.hideNoResultView();
			for (let i = 0; i <data.list.length ; i++) {
				let id = data.list[i].id;
				let labelName = data.list[i].labelName;
				let createTime = data.list[i].createTime;
				let content = data.list[i].content;
				html[i] = [
					'<div class="unit" data-id="demandId' + id + '">',
						'<div class="main">',
							'<div class="up">',
								'<span class="labelName">#' + labelName + '#</span>',
								'<span class="createTime">需求发布于：' + createTime + '</span>',
							'</div>',
							'<div class="down">' + content + '</div>',
						'</div>',
					'</div>'].join('');
			}
			$(`.wrapper`).html(html.join(''));
			/**----- 跳转问答详情页面 事件绑定 ----**/
			$(".unit").on("click",function(){
				let demandId = $(this).attr("data-id");
				demandId = demandId.replace('demandId','');
				//-- 根据ID 获取后台地址
				$$.push('know/demandDetail',{
					demandId:demandId
				});
			});
		}else {
			$$.showNoResultView({
				parentJqSelector: "body" ,
				msg: "暂无内容",
			});
		}
	}
});
