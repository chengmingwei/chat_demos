let labelArr= {};
window.onload = function () {
    $$.changeVersion();
    loadLabel();
    member_Detailspage();
    $(".sendBtn").on("click",function () {
        $$.loading();
        let telephone = $("#telephone").val().trim();
        let demandContent = $("#demandContent").val().trim();
        if (demandContent === ""){
            $$.layerToast("请输入你的需求内容！");
            return;
        }
        if (demandContent.length < 20){
            $$.layerToast("请输入不少于20字数的需求描述");
            return;
        }
        if (demandContent.length > 300){
            $$.layerToast("输入的内容超300个字！");
            return;
        }

        let labelId = Object.keys(labelArr).join(",");
        console.log(labelId);
        if (!ShawHandler.isValidObj(labelId)){
            $$.layerToast("请选择方案分类");
            return;
        }
        if (telephone.length !== 11){
            $$.layerToast("请输入11位手机号码");
            return;
        }
        const phoneReg = $$.reg.phoneReg;
        if (!phoneReg.test(telephone)){
            $$.layerToast("请输入有效手机号码");
            return;
        }
        $$.request({
            url: UrlConfig.member_demand_wx_addDemand,
            pars: {
                demandContent:demandContent,
                telephone:telephone,
                labelId:labelId
            },
            requestBody:true,
            sfn: function(data){
            $$.closeLoading();
                if(data.success){
                    console.log(data);
                    $$.alert("您的需求已提交，小白客服会尽快联系您",function () {
                        $$.push('know/answers');
                    });
                }else {
                    $$.alert(data.msg);
                }

            }
        });
    });
    $('#demandContent').on('input',function () {
        let textLength = $(this).val().length;
        $('#textLength span').html(textLength);
    });
};
function loadLabel() {
    $$.request({
        url: UrlConfig.label_searchLabelList,
        pars: {
            state:1,
            classifyId:4
        },
        sfn: function(data){
            html = "";
            for (let i = 0; i <data.datas.length ; i++) {
                html += "<li data-id='"+data.datas[i].id+"'>"+data.datas[i].labelName+"</li>";
            }
            $("#labelList").html(html);

            // 话题分类切换
            $(".type li").click(function () {
                labelArr = {};
                $(".type li").removeClass("active");
                const that = $(this);
                that.attr("class","active");
                let id = that.attr("data-id");
                labelArr[id] = id;
            });
        }
    });
}

function member_Detailspage() {
    $$.request({
        url: UrlConfig.member_Detailspage,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success && data.datas) {
                const phone = data.datas.phone;
                const account = data.datas.account;
                const phoneReg = $$.reg.phoneReg;
                if (ShawHandler.isValidObj(phone) && phoneReg.test(phone)) {
                    $("#telephone").val(phone);
                } else if (ShawHandler.isValidObj(account) && phoneReg.test(account)) {
                    $("#telephone").val(account);
                }
            }
        }
    });
}
