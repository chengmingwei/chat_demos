let id;
window.onload = function () {
    $$.changeVersion();
    id = $$.getUrlParam("id");
    loadSubject(id);
    loadSubjectList(id);
    $(".showAll").on('click',function () {
        $$.push("know/specialTopicList");
    })
};


/**
 * 描述信息：加载
 * @author 覃创斌
 * @date 2019-09-11
*/
function loadSubject(id) {
    $$.request({
        url: UrlConfig.getSubject,
        pars: {
            subjectId: id
        },
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                console.log(data)
                if (data.datas != null){
                    $(".banner").css("background-image","url("+data.datas.coverImgUrl+")");
                    $(".content h3").html(data.datas.title)
                    $(".content p").html(data.datas.introduction)
                }
            } else {
                $$.layerToast(`获取专题失败！[${data.msg}]`);
            }
        }
    });
}

function loadSubjectList(id) {
    $$.request({
        url: UrlConfig.getBySubjectIdArticle,
        pars: {
            subjectId: id
        },
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                console.log(data)
                let resultHtml = "";
                for (let i = 0; i <data.articleList.length ; i++) {
                    resultHtml += "<li class=\"item\">";
                    resultHtml += "	<div class=\"left\">";
                    resultHtml += "		<p>"+data.articleList[i].title+"</p>";
                    resultHtml += "		<div class=\"label\">";
                    resultHtml += "			<span class=\"icon icon1\">"+data.articleList[i].classifyname+"</span>";
                    resultHtml += "			<div class=\"commentWrap\">";
                    resultHtml += "				<span class=\"comment\"></span><span class=\"commentNum\">"+data.articleList[i].ecount+"</span>";
                    resultHtml += "			</div>";
                    resultHtml += "			<div class=\"eyesWrap\">";
                    resultHtml += "				<span class=\"eyes\"></span><span class=\"eyesNum\">"+data.articleList[i].vscount+"</span>";
                    resultHtml += "			</div>";
                    resultHtml += "		</div>";
                    resultHtml += "	</div>";
                    resultHtml += "	<div class=\"right\">";
                    resultHtml += "		<a href=\"javascript:;\" style=background-image:url(" + data.articleList[i].coverimgurl + ") class=\"pic1\"></a>";
                    resultHtml += "	</div>";
                    resultHtml += "</li>";
                }
                $(".list").html(resultHtml);
            } else {
                $$.layerToast(`获取专题失败！[${data.msg}]`);
            }
        }
    });
}