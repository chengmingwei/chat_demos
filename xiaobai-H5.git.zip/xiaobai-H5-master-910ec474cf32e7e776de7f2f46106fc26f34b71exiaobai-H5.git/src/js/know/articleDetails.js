let id;
let memberId;
let share;
let weChatOpenId;
const PAGE_STATE = {
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: 'hi，这篇文章很有意思哦，快来一起学习吧'
    }
};
window.onload = function() {
    id = $$.getUrlParam("id");
    share = $$.getUrlParam("share");
    memberId = $$.getUrlParam("memberId");//分享用户id
    weChatOpenId = $$.getUrlParam("shareWeChatOpenId");//分享用户weChatOpenId
    if ($$.isValidObj(share) && share === 'true'){//点击分享地址后先获取weChatOpenId
        getWeChatOpenId(id,memberId,weChatOpenId);
    } else {
        loadData(id,memberId,weChatOpenId);
    }

    /**
     * 描述信息：收藏
     * @author 覃创斌
     * @date 2019-09-19
    */
    $(".menu-collection").on("click",function () {
        if ($$.checkLogin()){
            $$.request({
                url: UrlConfig.insertCollectstatistic,
                pars: {
                    type:1,
                    objectId:id
                },
                requestBody: true,
                method: "POST",
                sfn: function (data) {
                    if (data.success) {
                        const menu_collection = $(".menu-collection");
                        if (data.count === 1){
                            $$.layerToast(`取消收藏！`);
                            menu_collection.css("background","#5677FC");
                            menu_collection.text("收藏");
                        }else {
                            menu_collection.css("background","#CCCCCC");
                            menu_collection.text("已收藏");
                            $$.layerToast(`收藏成功！`);
                            countAction("xb_2012");
                        }

                    } else {
                        $$.layerToast(`失败！[${data.msg}]`);
                    }
                }
            });
        }else {
          $$.gotoLogin();
        }
    });

    /* 点击分享给客户填写  */
    $('.menu-forward,.loginApp-forward').on('click', function () {
        shareHandler();
    });
    $$.setReadLongTimes();
};

/**
 * 描述信息：提交评论
 * @author 覃创斌
 * @date 2019-09-19
*/
function submitBtn() {
    //数据统计
    try {
        countAction('xb_43', null);
        countAction("xb_2014");
    } catch (error) {
        console.log(error);
    }
    let  anonymity=$("#anonymity").prop("checked");
    let isAnonymous;
    if (anonymity){
        isAnonymous = 1;
    }else {
        isAnonymous = 0;
    }
    let evaluation = $("#evaluation").val();
    if (evaluation !==""){
        $$.request({
            url: UrlConfig.insertEvaluation,
            pars: {
                evaluationContent:evaluation,
                isAnonymous:isAnonymous,
                state:1,
                objectID:id,
                type:1,
                isTop:0,
                giveLike:0
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    loadEvaluation(id);
                } else {
                    $$.layerToast(`${data.msg}`);
                }
                $("#evaluation").val("");
            }
        });
    }else{
    	$$.layerToast("评论内容不能为空~");
    }
}
/**
 * 描述信息：加载收藏
 * @author 覃创斌
 * @date 2019/10/31
*/
function loadCollect(id) {
    if ($$.checkLogin()){
        $$.request({
            url: UrlConfig.getCountCollectstatistic,
            pars: {
                type:1,
                objectId:id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    const menu_collection = $(".menu-collection");
                    if (data.count > 0){
                        menu_collection.css("background","#CCCCCC");
                        menu_collection.text("已收藏");
                    }else {
                        menu_collection.css("background","#5677FC");
                        menu_collection.text("收藏");
                    }

                } else {
                    $$.layerToast(`失败！[${data.msg}]`);
                }
            }
        });
    }
}
/**
 * 描述信息：加载文章
 * @author 覃创斌
 * @date 2019-09-20
*/
function loadData(id,shareMemberId,shareWeChatOpenId) {
    $$.request({
        url: UrlConfig.getByArticleId,
        pars: {
            articleId: id,
            weChatOpenId: $$.getUrlParam("weChatOpenId")
        },
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                PAGE_STATE.shareDatums.title = data.article.title;
                PAGE_STATE.shareDatums.image = data.article.coverImgUrl;
                $(".title").html(PAGE_STATE.shareDatums.title);
                $("title").html(PAGE_STATE.shareDatums.title);
                $(".article-date").html(data.article.issueDate);
                $(".article-name").html(data.article.issuer);
                $(".article-content").html(data.article.articleContent);

                const params = {
                    id:id,
                    share:true
                };
                //登录判断
                const memberId = data.memberId;//当前用户
                const weChatOpenId = data.weChatOpenId;
                shareArticleDetails(shareMemberId,shareWeChatOpenId);//获取分享用户的信息
                insertBrowse(id,shareMemberId,shareWeChatOpenId,weChatOpenId);//添加浏览记录
                if ($$.isValidObj(memberId)){
                    params.memberId = memberId;
                    PAGE_STATE.shareDatums.image = data.imgPath;
                    $(".menu").show();
                    $(".evaluate").show();
                    loadEvaluation(id);
                    loadCollect(id);
                } else {
                    $('.loginApp').show();
                    $('.loginApp .loginApp-loginBtn').on('click',function (){
                        $$.gotoLogin();
                    });
                    if ($$.isValidObj(weChatOpenId)) {
                        params.shareWeChatOpenId = weChatOpenId;
                        PAGE_STATE.shareDatums.image = data.headimgurl;
                    }
                }
                let shareUrl = $$.getFullHost() + '/src/pages/know/articleDetails.html';
                shareUrl += $$.jsonToUrlParams(params);
                PAGE_STATE.shareDatums.url = shareUrl;
                weChatShare();        // 分享配置
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
function check() {
    if ($$.isValidObj(memberId)) {
        $$.request({
            url: UrlConfig.integral_checkToDayShareArticle,
            pars: {
                memberId: memberId
            },
            method: "POST",
            sfn: function (data) {
                if (!data) {
                    $$.request({
                        url: UrlConfig.integral_handSendIntegral,
                        pars: {
                            code:"I0005"
                        },
                        method: "POST",
                        sfn: function (info) {
                            if (info.success){
                                $$.alert("积分赠送成功！");
                                countAction("xb_2033");
                            }
                        }
                    });
                }
            }
        });
    }
}
/**
 * 描述信息：加载评论
 * @author 覃创斌
 * @date 2019-09-20
*/
function  loadEvaluation(id) {
    $$.request({
        url: UrlConfig.getListByHeatOrTime,
        requestBody: true,
        pars: {
            objectid: id,
            type:1
        },
        method: "POST",
        sfn: function (data) {
            let resultHtml = "";
            if (data.success) {
                $(".comments-count").html("评论（"+data.datas.length+"）");
                for (let i = 0; i < data.datas.length; i++) {
                    resultHtml += " <li data-id="+data.datas[i].id+"  data-user="+data.datas[i].memberId+">";
                    resultHtml += "	<div class=\"comments-info flex-container\">";
                    resultHtml += "		<div class=\"comments-img\" >";
                    if (data.datas[i].isanonymous == 1){
                        resultHtml += `			<img src="../../images/my/mituLogo.png" />`;
                        resultHtml += "		<div class=\"comments-name\">匿名</div>";
                    }else {
                        resultHtml += "			<img src=\""+defaultImg(data.datas[i].imgpath)+"\">";
                        let name = data.datas[i].rname ? data.datas[i].rname : data.datas[i].account;
                        if(null == name || "" == name){
                            name = "入侵者";
                            resultHtml += "		<div class=\"comments-name\" style='color: #ff7052;'>"+name+"</div>";
                        }else{
                            resultHtml += "		<div class=\"comments-name\">"+name+"</div>";
                        }
                    }
                    resultHtml += "			<div class=\"comments-time\">"+getDate(data.datas[i].createtime)+"</div>";
					resultHtml += "		</div>";
                    resultHtml += "		<div class=\"comments-give\" onclick='getGiveLike(this,"+data.datas[i].id+","+data.datas[i].givelike+")'>";
                    resultHtml += "			<img src=\"../../images/topicPK/like.png\" />";
                    resultHtml += "			<div class=\"comments-giveNum\">";
                    resultHtml += data.datas[i].givelike;
                    resultHtml += "			</div>";
                    resultHtml += "		</div>";
                    resultHtml += "	</div>";
                    resultHtml += "	<div class=\"comments-text\">"+"<span>"+data.datas[i].evaluationcontent+"</span>"+"</div>";
                    resultHtml += " </li>";
                }
                $(".comments-li").html(resultHtml);

                /**----- 评论内容超出 添加 详情  ----**/
                $(".comments-text span").each(function(){
                	let text1 = $(this).height();
	                let text2 = $(this).parent().height();
				    if(text2 < text1){
				    	let html = `<div class="unfold">详情</div>`;
				        $(this).parents("li").append(html);
				    }
				});
				/**----- 评论内容 点击详情 事件绑定 ----**/
				$(".unfold").on("click",function(){
					$(this).prev(".comments-text").css({"max-height":"100%","-webkit-line-clamp":"100"})
					$(".unfold").remove();
				});

				/* 评论 默认显示2条 添加展开 */
				$(".comments-li li:gt(1)").hide();
				let html = `<div class="unfolds">展开全部</div>`;

				if($(".comments-li li").length > 2){
					$(".comments-li").append(html);
				}
				/**----- 点击展开详情 事件绑定 ----**/
				$(".unfolds").on("click",function(){
					$(".comments-li li:gt(1)").show();
					$(".unfolds").remove();
				});

				$('.iphone').on('click',function () {
                    window.location.href = "tel:10086";
                });

				/**----- 点赞 事件绑定 ----**/
				// $(document).on('click','.comments-give',function (){
				// 	$(this).removeClass().addClass("comments-give-yes");
				// 	$(this).children("img").attr("src","../../images/know/information/goods.png");
				// 	$(this).children(".comments-giveNum").css("color","#FF7052");
				//
				// 	let id = $(this).parents("li").attr("data-id");
				// 	let giveLike = parseInt($(this).children(".comments-giveNum").text())+1;
				// 	$(this).children(".comments-giveNum").text(giveLike);
				// 	//更新点赞数
				// 	getGiveLike(id,giveLike);
				// });
				/**----- 取消点赞 事件绑定 ----**/
				// $(document).on('click','.comments-give-yes',function (){
				// 	$(this).removeClass().addClass("comments-give");
				// 	$(this).children("img").attr("src","../../images/topicPK/like.png");
				// 	$(this).children(".comments-giveNum").css("color","gray");
				//
				// 	let id = $(this).parents("li").attr("data-id");
				// 	let giveLike = parseInt($(this).children(".comments-giveNum").text())-1;
				// 	$(this).children(".comments-giveNum").text(giveLike);
				// 	//更新点赞数
				// 	getGiveLike(id,giveLike);
				// });
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }

        }
    });
}
//更新点赞数
function getGiveLike(doc,id,giveLike){
    $$.request({
        url: UrlConfig.praisestatistic_save,
        pars: {
            type:1,
            objectId:id
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                checkToDayRead();
                let n =  $(doc).text().trim();
                if (data.delete){
                    giveLike = parseInt(n)-1;
                    $$.layerToast('取消点赞！');
                    $(doc).children(".comments-giveNum").html(giveLike);

                }else {
                    giveLike = parseInt(n)+1;
                    $(doc).children(".comments-giveNum").html(giveLike);
                    $$.layerToast('点赞成功！');
                }
                $$.request({
                	url: UrlConfig.evaluation_updateGiveLike,
                	pars: {
                		"id": id,
                		"giveLike": giveLike,
                	},
                    sfn: function (data) {

                    }
                });

            } else {
                $$.layerToast(`${data.msg}`);
            }
        }
    });
}
function checkToDayRead() {
    $$.request({
        url: UrlConfig.integral_checkToDayRead,
        pars: {},
        method: "POST",
        sfn: function (data) {
            if (!data) {
                $$.request({
                    url: UrlConfig.integral_handSendIntegral,
                    pars: {
                        code:"I0006"
                    },
                    method: "POST",
                    sfn: function (info) {
                        if (info.success){
                            $$.alert("积分赠送成功！");
                            countAction("xb_2034");
                        }
                    }
                });
            }
        }
    });
}
//将时间戳格式化
function getMyDate(time){
    if(typeof(time)=="undefined"){
        return "";
    }
    var oDate = new Date(time),
        oYear = oDate.getFullYear(),
        oMonth = oDate.getMonth()+1,
        oDay = oDate.getDate(),
        oHour = oDate.getHours(),
        oMin = oDate.getMinutes(),
        oSen = oDate.getSeconds(),
        oTime = oYear +'-'+ getzf(oMonth) +'-'+ getzf(oDay) ;//最后拼接时间

    return oTime;
}
//补0操作,当时间数据小于10的时候，给该数据前面加一个0
function getzf(num){
    if(parseInt(num) < 10){
        num = '0'+num;
    }
    return num;
}

function getDate(old) {
    var returnText="";
    var nowDate=new Date().getTime();   //当前时间
    var setDate=new Date(old).getTime();
    var times=Math.floor((nowDate-setDate)/1000);
    if(times > 60*60*24){
        returnText= old.substring(0,10);
    }else if(times > 60*60){
        returnText=Math.floor(times / (60*60))+"小时前";
    }else if(times > 60){
        returnText=Math.floor(times / (60))+"分钟前";
    }else if(times > 0){
        returnText=Math.floor(times / 1)+"秒前";
    }else{
        returnText="刚刚";
    }
    return returnText;
}
/**
 * 描述信息：添加浏览记录
 * @author 覃创斌
 * @date 2019/10/12
 */
function insertBrowse(id,shareUserId,shareWeChatOpenId,weChatOpenId) {
    $$.request({
        url: UrlConfig.viewStatistic_insertViewStatistic,
        pars: {
            shareUserId:shareUserId,//分享用户memberId
            shareWeChatOpenId:shareWeChatOpenId,//分享用户微信OpenId
            weChatOpenId:weChatOpenId,//阅读用户微信OpenId
            type:1,
            objectId:id,
            judge:1
        },
        method: "POST",
        sfn: function (data) {
            console.log('--------------Audio');
            console.log(data);
        }
    });
}

function defaultImg(HeadImg) {
    if(HeadImg == null || (HeadImg + "") === "" || (HeadImg + "").length <= 0 || HeadImg === undefined) {
        return 'https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com/picFile/2019/11/tempFilesed47803481e64b9cbb87c54feccf165a_small.png';
    }
    return HeadImg;
}
//微信授权登录
function getWeChatOpenId(id,shareMemberId,shareWeChatOpenId) {
    let url = window.location.search;
    url = url.replace("true",'false');
    url = "know/articleDetails.html"+url;
    console.log('----url',url);
    ShawHandler.request({
        url: UrlConfig.weChat_authorize,
        pars: {
            authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
            returnUrl: url,
            businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_6,
            otherParams: JSON.stringify({
                "objectId": id,
                "type":1,
                "memberId":shareMemberId,
                'shareWeChatOpenId':shareWeChatOpenId
            })
        },
        loading: true,
        sfn: function(data){
            $$.closeLoading();
            location.href = data.datas;
        }
    });
}

/**
 * 获取分享用户的信息
 * @param shareUserId
 * @param shareWeChatOpenId
 */
function shareArticleDetails(shareUserId,shareWeChatOpenId) {
    if ($$.isValidObj(shareUserId) || $$.isValidObj(shareWeChatOpenId)){
        $$.request({
            url: UrlConfig.member_getShareMemberInfo,
            pars:{
                memberId:shareUserId,
                weChatOpenId:shareWeChatOpenId
            },
            loading:true,
            method: "POST",
            sfn: function(data){
                if(data.success){
                    $$.closeLoading();
                    if (data.datas.rname!=null && data.datas.rname!==""){
                        $(".name p").text(data.datas.rname);
                    }else{
                        $(".name p").text(data.datas.account);
                    }
                    if( (data.datas.imgPath!=null)&& (data.datas.imgPath!=="")){
                        $(".head").attr("src",data.datas.imgPath);
                    }else {
                        $(".head").attr("src", "../../images/my/defaultImg.png");
                    }
                    $(".info").show();
                    if (data.datas.phone) {
                        $('.iphone').on('click',function () {
                            window.location.href = "tel:"+data.datas.phone;
                        });
                    } else {
                        $('.iphone').hide();
                    }
                }else{
                    $$.layerToast("系统出错");
                }
            }
        });
    }
}

/**
 * 分享
 * @Author 吴成林
 * @Date 2020-5-15 11:36:31
 */
function weChatShare(){
    if (!$WeChat.isWx() && !PAGE_APP) {
        return;
    }
    console.log(PAGE_STATE.shareDatums);
    const { url, image, title, content } = PAGE_STATE.shareDatums;
    weChatJSTool.share({
        _imgUrl: image,
        _lineLink: url,
        _shareTitle: title,
        _descContent: content,
        _sfn: function () {
            check();
            countAction("xb_2013");
        }
    });
}

/**
 * 分享处理(APP和H5)
 * @Author 吴成林
 * @Date 2020-5-15 11:31:25
 */
function shareHandler(){
    if(PAGE_APP){
        //-- APP
        const { shareDatums } = PAGE_STATE;
        console.log(shareDatums);
        const params = {bussType: 10001, ...shareDatums};
        $$.postAPP(10002, params);
    }else{
        //-- 分享
        $$.showShareView('点击右上角，分享文章~');
    }
}
