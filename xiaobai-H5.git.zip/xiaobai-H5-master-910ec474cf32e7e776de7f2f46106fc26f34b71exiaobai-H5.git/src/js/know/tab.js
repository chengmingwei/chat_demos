$(document).ready(function() {
    $('.xl-tab-head-title').click(function() {
        var id = $(this).attr('id');
        var index = id.substr(id.length - 1);
        var contentClass = 'xl-tab-content-' + index;

        var preActive = $('.xl-tab-head-title-active:first').attr('id');
        var preIndex = preActive.substr(preActive.length - 1);
        var len = index - preIndex;
        $('.xl-tab-content').each(function() {
            var marginLeft = $(this).css('margin-left');
            console.log(len)
            var contentWidth = $('.xl-tab-content').width();
            marginLeft = marginLeft.substr(0, marginLeft.length - 2) - len * contentWidth;
            $(this).css({'margin-left': marginLeft + 'px'});
        });
        $('.xl-tab-head-title-active').removeClass('xl-tab-head-title-active');
        $(this).addClass('xl-tab-head-title-active');
    });
});
