let questionId;
window.onload = function () {
    $$.changeVersion();
    questionId = $$.getUrlParam("questionId");
    // 匿名发布
    $(".send").click(function () {
        $(this).toggleClass("isSelectCheckbox");
    })
    loadQuestion(questionId);
    $(".sendBtn").click(function () {
        let Cts = $(".send").attr('class');
        let answerContent = $("#answerContent").val().trim();
        let isAnonymous= 0;
        if(Cts.indexOf("isSelectCheckbox") >= 0 ) {
            isAnonymous=1;
        }else {
            isAnonymous=0;
        }
        if (answerContent.length < 5){
            $$.alert("回答内容不能少于5字数");
            return;
        }
        countAction("xb_2016");
        $$.request({
            url: UrlConfig.answer_insertAnswer,
            pars: {
                answerContent:answerContent,
                giveLike:0,
                IsAnonymous:isAnonymous,
                IsTop:0,
                state:1,
                questionId:questionId
            },
            method: "POST",
            requestBody:true,
            sfn: function (data) {
                if (data.success) {
                    $$.push("know/questionDetail",{
                        questionId:questionId
                    });
                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    })
}
/*提问*/
function loadQuestion(id) {
    $$.request({
        url: UrlConfig.question_getMyAnswerDetails,
        pars: { questionId: id },
        method: "POST",
        requestBody:true,
        sfn: function (data) {
            if (data.success) {
                if (data.datas != null){
                    $(".myAnswer h3").html(data.datas.questionContent);
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}