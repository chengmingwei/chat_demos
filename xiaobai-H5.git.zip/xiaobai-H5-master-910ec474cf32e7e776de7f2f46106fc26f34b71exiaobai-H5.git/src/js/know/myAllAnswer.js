$(function(){
	pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        //-- 匹配后台数据更新
        $$.request({
            url: UrlConfig.answer_getAnswerByMemberId,
	        pars: {},
			requestBody:true,
            sfn: function(data){
            	console.log(data);
                sfn(data);
            }
        });
        //-- 首页数据请求回调
        function sfn(data){
            if(data.success){
				//-- 加载我的关注列表数据
			    bindAnswerList(data);
            }
        }

    }

	/* 绑定回答列表 */
	function bindAnswerList(data){
		let html = "";
		if (data.datas.length > 0){
			$$.hideNoResultView();
			for (let i = 0; i <data.datas.length ; i++) {
				html += "<div class=\"unit\" data-id=\""+data.datas[i].questionId+"<\">";
				html += "	<div class=\"myAnswer\">";
				html += "		<div class=\"list-title\">"+data.datas[i].questionContent+"</div>";
				html += "		<div class=\"answer-list-time\">";
				html += `			<div><img src=${data.datas[i].imgPath ? $$.imageUrlCompatible(data.datas[i].imgPath) : "../../images/my/mituLogo.png"} /></div>`;
				html += `			<div class="answer-name">${data.datas[i].rname ? data.datas[i].rname : data.datas[i].account}</div>`;
				html += "			<div class=\"time\">"+data.datas[i].answerDate+"</div>";
				html += "		</div>";
				html += "	</div>";
				html += "	<div class=\"answer-time\">回答于"+data.datas[i].answerDate+"</div>";
				html += "</div>";
			}
			$(`.wrapper`).html(html);
		}else {
			//$$.push('my/noContent');
			$$.showNoResultView({
				parentJqSelector: "body" ,
				msg: "暂无内容",
			});
		}
	    /**----- 跳转问答详情页面 事件绑定 ----**/
		$(".unit").on("click",function(){
			let id = $(this).attr("data-id");
			//-- 根据ID 获取后台地址
			$$.push("know/questionDetail",{
				questionId:id
			})
		});
	}
});
