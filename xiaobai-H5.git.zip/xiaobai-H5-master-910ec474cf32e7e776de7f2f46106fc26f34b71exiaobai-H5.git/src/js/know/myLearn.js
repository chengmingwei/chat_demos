let id;
window.onload = function () {
	$$.changeVersion();
	$('#concerns').on('click',function(){//关注问题
		$$.push("know/myConcern");
	});
	$('#myQuestions').on('click',function(){//我的提问
		$$.push("know/myAllQuestion");
	});
	$('#myAnswer').on('click',function(){//我的回答
		$$.push("know/myAllAnswer");
	});
	$('#alreadyPurchased').on('click',function(){//已购买
		$$.push("know/myCourse");
	});
	$('#recentLearning').on('click',function(){//最近学习
		$$.push("know/myRecentLearn");
	});
	$('#collectionCourse').on('click',function(){//收藏课程
		$$.push("know/myCollectionCourse");
	});
	$('#collectionArticles').on('click',function(){//收藏文章
		$$.push("know/myArticles");
	});
	$('#messageCenter').on('click',function(){//消息中心
		$$.push("know/myMessage");
	});
	$('#myDemand').on('click',function(){//我的需求
		$$.push("know/myAllDemand");
	});
	load();
};
function load() {
	$$.request({
		url: UrlConfig.member_Detailspage,
		loading: true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				console.log(data);
				id = data.datas.id;
				$("#userName").html(data.datas.rname);
				$("#logo").attr("src",$$.isValidHeadImg(data.datas.imgPath));
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}
