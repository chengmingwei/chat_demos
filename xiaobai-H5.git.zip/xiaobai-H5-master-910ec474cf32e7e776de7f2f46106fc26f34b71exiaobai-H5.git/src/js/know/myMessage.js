$(function(){
	pageLoader();
	try {
		countAction('xb_10', null);
	} catch (error) {
		console.log(error);
	}
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        //-- 匹配后台数据更新
        $$.request({
            url: UrlConfig.course_getMessageCenterList,
	        pars: {},
			requestBody:true,
            sfn: function(data){
                sfn(data);
            }
        });
        //-- 首页数据请求回调
        function sfn(data){
        	console.log(data);
            if(data.success){
				//-- 加载我的关注列表数据
			    bindMessageList(data);
            }
        }

    }

	/* 绑定信息中心列表 */
	function bindMessageList(data){
		let html = "";

		if (data.datas.length > 0){
			$$.hideNoResultView();
			for (let i = 0; i <data.datas.length ; i++) {
				html += "<div class=\"unit\" data-id=\""+data.datas[i].objectID+"\">";
				html += "	<div class=\"message-left\">";
				html += "		<div class=\"message-type\"> 点赞</div>";
				html += "	</div>";
				html += "	<div class=\"message-centre\">";
				html += "		<div class=\"message-title\">用户"+data.datas[i].phone+"点赞了你的评论</div>";
				html += "		<div class=\"time\">"+data.datas[i].createTime+"</div>";
				html += "	</div>";
				html += "	<div class=\"message-right\">";
				html += "		<button class=\"unfollow\" data-type=\""+data.datas[i].type+"  data-id=\""+data.datas[i].objectID+"\">原文</button>";
				html += "	</div>";
				html += "</div>";
			}
			$(`.wrapper`).html(html);

			/**----- 跳转信息详情页面 事件绑定 ----**/
			$(".unfollow").on("click",function(){
				let id = $(this).attr("data-id");

				//-- 根据ID 获取后台地址

			});
		}else {
			//$$.push('my/noContent');
			$$.showNoResultView({
				parentJqSelector: "body" ,
				msg: "暂无内容",
			});
		}

	}
});
