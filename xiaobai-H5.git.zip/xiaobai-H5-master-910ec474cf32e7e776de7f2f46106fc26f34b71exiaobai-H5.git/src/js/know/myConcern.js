$(function(){
	pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        //-- 匹配后台数据更新
        $$.request({
            url: UrlConfig.focusquestion_getFocusQuestionList,
	        pars: {},
			requestBody:true,
            sfn: function(data){
                sfn(data);
            }
        });
        //-- 首页数据请求回调
        function sfn(data){
            if(data.success){
				//-- 加载我的关注列表数据
			    bindConcernList(data);
            }
        }
    }

	/* 绑定关注列表 */
	function bindConcernList(data){
		let html = "";
		console.log(data);
		if (data.datas.length > 0){
			$$.hideNoResultView();
			for (let i = 0; i < data.datas.length; i++) {
				html += "<div class=\"unit\" data-id=\""+data.datas[i].questionId+"\">";
				html += "	<div class=\"concern-list-title\">";
				html += "		<div class=\"list-title\">"+data.datas[i].questionContent+"</div>";
				html += "		<button class=\"unfollow\" data-id=\""+data.datas[i].questionId+"\">取消关注</button>";
				html += "	</div>";
				html += "	<div class=\"concern-list-time\">";
				if (data.datas[i].isAnonymous == 1){
					html += `		<div class="comment" ><img src="../../images/my/mituLogo.png"></div>`;
					html += "		<div class=\"concern-name\">匿名</div>";
				}else {
					html += `		<div class="comment" ><img src=${data.datas[i].imgPath ? $$.imageUrlCompatible(data.datas[i].imgPath) : "../../images/my/mituLogo.png"}></div>`;
					let name = data.datas[i].rname ? data.datas[i].rname : data.datas[i].account;
					if(name == null || name == ""){
						html += `		<div class="concern-name" style="color: #ef5b09">侵入者</div>`;
					}else{
						html += `		<div class="concern-name">${name}</div>`;
					}
				}
				html += "		<div class=\"time\"></div>";
				html += "	</div>";
				html += "	<div class=\"concern-list-details\">";
				if(data.datas[i].answerContent == null || data.datas[i].answerContent == ""){
					html += "暂无内容";
				}else{
					html += "		"+data.datas[i].answerContent+"";
				}
				html += "	</div>";
				// html += "	<div class=\"concern-list-type\">";
				// html += "		<div class=\"concern-type\">${item.type}</div>";
				// html += "		<div class=\"concern-comment\">";
				// html += "			<div class=\"comment\"></div>";
				// html += "			<div>${item.comment}</div>";
				// html += "		</div>";
				// html += "		<div class=\"concern-like\">";
				// html += "			<div class=\"comment\"></div>";
				// html += "			<div>${item.like}</div>";
				// html += "		</div>";
				// html += "	</div>";
				html += "</div>";
			}
			$(`.wrapper>.list`).html(html);
		}else {
			$(`.wrapper>.list`).html("");
			$$.showNoResultView({
				parentJqSelector: "body" ,
				msg: "暂无内容",
			});
		}


		/**----- 取消关注 事件绑定 ----**/
		$(".unfollow").on("click",function(e){
			//-- 根据ID 更新后台数据
			let id = $(this).attr("data-id");
			$$.request({
				url: UrlConfig.focusquestion_cancelFocus,
				pars: {
					questionId:id
				},
				requestBody:true,
				sfn: function(data){
					if(data.success){
						//-- 删除列表单元
						pageLoader()
					}
				}
			});
			e.stopPropagation();
		});
		/**----- 跳转问答详情页面 事件绑定 ----**/
		$(".unit").on("click",function(){
			//-- 根据ID 获取后台地址
			let id = $(this).attr("data-val");
			$$.push("know/questionDetail",{
				questionId:id
			})
		});
	}
});
