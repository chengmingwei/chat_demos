$(function(){
	pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        //-- 匹配后台数据更新
        $$.request({
            url: UrlConfig.course_getOrderByCourseList,
	        pars: {},
			requestBody:true,
            sfn: function(data){
            	console.log(data);
                sfn(data);
            }
        });
        //-- 首页数据请求回调
        function sfn(data){
            if(data.success){

				//-- 加载我的关注列表数据
			    bindVideoList(data);
            }
        }
    }

	/* 绑定回答列表 */
	function bindVideoList(data){
		let html = "";

		if (data.datas.length > 0){
			$$.hideNoResultView();
			for (let i = 0; i < data.datas.length; i++) {
				html += "<div class=\"unit\" data-id=\""+data.datas[i].formId+"\" productType=\""+data.datas[i].productType+"\">";
				html += "	<div class=\"img\">";
				html += "		<img src=\""+data.datas[i].listImgId+"\"/>";
				//html += "		<div class=\"videoPlay\">"+data.datas[i].listImgId+"</div>";
				html += "	</div>";
				html += "	<div class=\"right\">";
				html += "		<h3>"+data.datas[i].title+"</h3>";
				//html += "		<p class=\"content\">${item.content}</p>";
				html += "		<div class=\"list\">";
				//	html += "			<div class=\"type\">${item.type}</div>";
				html += "			<div class=\"comment\">";
				html += "				<div class=\"commentImg\"></div>";
				html += "				<div>"+data.datas[i].count+"</div>";
				html += "			</div>";
				html += "			<div class=\"like\">";
				html += "				<div class=\"commentImg\"></div>";
				html += "				<div>"+data.datas[i].pcount+"</div>";
				html += "			</div>";
				html += "		</div>";
				html += "	</div>";
				html += "</div>";
			}
			$('.wrapper').html(html);
		}else {
			//$$.push('my/noContent');
			$$.showNoResultView({
				parentJqSelector: "body" ,
				msg: "暂无内容",
			});
		}



		/**----- 跳转视频详情页面 事件绑定 ----**/
		$(".unit").on("click",function(){
			let id = $(this).attr("data-id");

			let productType = $(this).attr("productType");
			if(productType == 0){
				//-- 根据ID 获取后台地址
				$$.push("newKnow/audioDetail",{
					videoId:id
				});
			}else{
				$$.push("newKnow/articleDetails",{
					id:id
				});
			}
		});
	}
});
