window.onload = function () {
    $$.changeVersion();
    $$.request({
        url: UrlConfig.getSubjectAll,
        pars: { },
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                console.log(data)
                let resultHtml = "";
                if (data.datas != null){
                    for (let i = 0; i <data.datas.length ; i++) {
                        resultHtml += "<li class=\"list_li bigPic\" onclick='jumpSpecialDetails("+ data.datas[i].id +")' style=background-image:url(" + data.datas[i].coverimgurl + ")>";
                        resultHtml += "	<h3>"+data.datas[i].covertitle+"</h3>";
                        resultHtml += "	<span class=\"articleNumber\">"+data.datas[i].acount+"篇</span>";
                        resultHtml += "	<span class=\"visitNumberIcon\"></span>";
                        resultHtml += "	<span class=\"visitNumber\">"+data.datas[i].vcount+"</span>";
                        resultHtml += "	<ul class=\"smallPic_ul\">";
                        resultHtml += "		<li>";
                        resultHtml += "			<a href=\"javascript:;\" class=\"smallPic smallPic1\" style=background-image:url(" + data.datas[i].top2 + ")></a>";
                        resultHtml += "		</li>";
                        resultHtml += "		<li>";
                        resultHtml += "			<a href=\"javascript:;\" class=\"smallPic smallPic2\" style=background-image:url(" + data.datas[i].top1 + ")></a>";
                        resultHtml += "		</li>";
                        resultHtml += "	</ul>";
                        resultHtml += "</li>		";
                    }
                    $(".list").html(resultHtml);
                }
            } else {
                $$.layerToast(`获取专题失败！[${data.msg}]`);
            }
        }
    });
}
//跳转文章详情
function  jumpSpecialDetails(id) {
    $$.push("know/specialTopicDetail",{
        id:id
    });
}