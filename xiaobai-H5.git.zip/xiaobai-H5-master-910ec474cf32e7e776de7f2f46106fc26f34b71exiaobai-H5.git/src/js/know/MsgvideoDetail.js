let id;
$(function() {
    id = $$.getUrlParam("id");
    loadVideo(id);
    loadEvaluation(id);
    /**
     * 描述信息：提交评论
     * @author 覃创斌
     * @date 2019-09-20
    */
    $(".send").on("click",function(){
        let evaluation = $("#evaluation").val();
        $$.request({
            url: UrlConfig.insertEvaluation,
            pars: {
                evaluationContent:evaluation,
                isAnonymous:0,
                state:1,
                objectID:id,
                type:2,
                isTop:0,
                giveLike:0
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                console.log(data);
                if (data.success) {
                    loadEvaluation(id);
                } else {
                    $$.layerToast(`失败！[${data.msg}]`);
                }
                $("#evaluation").val("")
            }
        });
    });
    /**
     * 描述信息：收藏
     * @author 覃创斌
     * @date 2019-09-19
     */
    $(".collect").on("click",function () {
        $$.request({
            url: UrlConfig.insertCollectstatistic,
            pars: {
                type:2,
                objectId:id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                console.log(data);
                if (data.success) {
                    if (data.count === 0){
                        $$.layerToast(`取消收藏！`);
                        $(".menu-collection").css("background-image","url(../../images/know/information/collection.png)");
                    }else {
                        $(".menu-collection").css("background-image","url(../../images/know/information/collected.png)");
                        $$.layerToast(`收藏成功！`);
                    }
                } else {
                    $$.layerToast(`失败！[${data.msg}]`);
                }
            }
        });
    })
})

function loadVideo(id) {
    $$.request({
        url: UrlConfig.Video_data,
        requestBody: true,
        pars: {
            id: id
        },
        method: "POST",
        sfn: function (data) {
            console.log(data);
            if (data.success) {
                $("#player").attr("src",data.video.videoURL);
                $(".share>h3").html(data.video.title);
                $("#video-date").html(getMyDate(data.video.issueDate));
                $("#video-issuer").html(data.video.issue)
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
/**
 * 描述信息：加载评论
 * @author 覃创斌
 * @date 2019-09-20
 */
function  loadEvaluation(id) {
    $$.request({
        url: UrlConfig.getListByEvaluation,
        requestBody: true,
        pars: {
            objectid: id,
            type:2
        },
        method: "POST",
        sfn: function (data) {
            let resultHtml = "";
            if (data.success) {
                console.log(data)
                for (let i = 0; i < data.datas.length; i++) {
                    resultHtml += "<li>";
                    resultHtml += "	<div class=\"top\">";
                   resultHtml +=" <img src=\""+data.datas[i].imgpath+"\">";

                    if (data.datas[i].isanonymous == 1){
                        resultHtml += "		<span class=\"avatar\">匿名</span>";
                    }else {
                        resultHtml += "		<div class=\"avatar\">"+data.datas[i].rname+"</div>";
                    }
                    resultHtml += "		<span  class=\"time\">"+getDate(data.datas[i].createtime)+"</span>";
                    resultHtml += "	</div>";
                    resultHtml += "	<p class=\"content\">"+data.datas[i].evaluationcontent+"</p>";
                    resultHtml += "</li>";

                }
            $("#comment-ul").html(resultHtml);
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
//将时间戳格式化
function getMyDate(time){
    if(typeof(time)=="undefined"){
        return "";
    }
    var oDate = new Date(time),
        oYear = oDate.getFullYear(),
        oMonth = oDate.getMonth()+1,
        oDay = oDate.getDate(),
        oHour = oDate.getHours(),
        oMin = oDate.getMinutes(),
        oSen = oDate.getSeconds(),
        oTime = oYear +'-'+ getzf(oMonth) +'-'+ getzf(oDay) ;//最后拼接时间

    return oTime;
};
//补0操作,当时间数据小于10的时候，给该数据前面加一个0
function getzf(num){
    if(parseInt(num) < 10){
        num = '0'+num;
    }
    return num;
}

function getDate(dateTimeStamp) {
    var minute = 1000 * 60;
    var hour = minute * 60;
    var day = hour * 24;
    var halfamonth = day * 15;
    var month = day * 30;


    if (dateTimeStamp == undefined) {

        return false;
    } else {
        dateTimeStamp = dateTimeStamp.replace(/\-/g, "/");

        var sTime = new Date(dateTimeStamp).getTime();//把时间pretime的值转为时间戳

        var now = new Date().getTime();//获取当前时间的时间戳

        var diffValue = now - sTime;

        if (diffValue < 0) {
            console.log("结束日期不能小于开始日期！");
        }

        var monthC = diffValue / month;
        var weekC = diffValue / (7 * day);
        var dayC = diffValue / day;
        var hourC = diffValue / hour;
        var minC = diffValue / minute;

        if (monthC >= 1) {
            return  dateTimeStamp.substr(5,5).replace(/\//g,'月')+"日";
        } else if (weekC >= 1) {
            return  dateTimeStamp.substr(5,5).replace(/\//g,'月')+"日";
        } else if (dayC >= 1) {
            return  dateTimeStamp.substr(5,5).replace(/\//g,'月')+"日";
        } else if (hourC >= 1) {
            return parseInt(hourC) + "小时前";
        } else if (minC >= 1) {
            return parseInt(minC) + "分钟前";
        } else {
            return "刚刚";
        }
    }
}
