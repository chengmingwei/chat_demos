$(function(){
	pageLoader();


});
/**
 * 页面加载对必要的参数作处理
 */
function pageLoader(){
	//-- 匹配后台数据更新
	$$.request({
		url: UrlConfig.question_getQuestionByMemberId,
		pars: {},
		requestBody:true,
		sfn: function(data){
			sfn(data);
		}
	});
	//-- 首页数据请求回调
	function sfn(data){
		if(data.success){
			console.log(data);
			//-- 加载我的关注列表数据
			bindQuestionList(data);
		}
	}

}

/* 绑定提问列表 */
function bindQuestionList(data){
	let html = "";
	if (data.datas.length > 0){
		$$.hideNoResultView();
		for (let i = 0; i < data.datas.length; i++) {
			html += "<div class=\"unit\">";
			html += "	<div class=\"question-left\">";
			html += "		<div class=\"question-type\">"+data.datas[i].labelName+"</div>";
			html += "	</div>";
			html += "	<div class=\"question-centre\">";
			html += "		<div class=\"question-title\">"+data.datas[i].questionContent+"</div>";
			html += "		<div class=\"time\">"+data.datas[i].publishTime+"</div>";
			html += "	</div>";
			html += "	<div class=\"question-right\">";
			html += "		<button class=\"answer\" data-id=\""+data.datas[i].id+"\">"+data.datas[i].count+"人回答</button>";
			html += "	</div>";
			html += "</div>";

		}
		$(`.wrapper`).html(html);

		/**----- 跳转问答详情页面 事件绑定 ----**/
		$(".answer").on("click",function(){
			let id = $(this).attr("data-id");

			//-- 根据ID 获取后台地址
			//-- 根据ID 获取后台地址
			$$.push('know/questionDetail',{
				questionId:id
			});
		});
	}else {
		$$.showNoResultView({
			parentJqSelector: "body" ,
			msg: "暂无内容",
		});
		//$$.push('my/noContent');
	}

}
