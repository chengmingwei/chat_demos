var choose = 1;
let type = "";
window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_19', null);
    } catch (error) {
        console.log(error);
    }
    if (!$$.checkLogin()) {
        ShawHandler.gotoLogin();
    }
    //pageInit();

    let type = $$.getUrlParam("type");
    if (type == 'Video'){
        $(".tab>li").removeClass("active");
        $(".tab>li").eq(0).addClass("active");
        //getCourseList(null,null);
        choose =1;
        pageInit(choose);
    }else if (type == 'Audio'){
        $(".tab>li").removeClass("active");
        $(".tab>li").eq(1).addClass("active");
        //getCourseAudioList(null,null);
        choose= 0;
        pageInit(choose);
    }

    //视频or音频
    $(".tab>li").on("click",function(){
        $(".tab>li").removeClass("active");
        $(this).addClass("active");
        let conn = $(this).text();
        if (conn.trim() == "音频专区"){
            choose = 0;
            console.log(choose);
            $$.hideNoResultView();
            //getCourseAudioList(null,null);
            pageInit(choose);
            getLabelList(choose);
        }else {
            choose = 1;
            console.log(choose);
            $$.hideNoResultView();
            pageInit(choose);
            getLabelList(choose);
        }
    });


};
//视频
function  getCourseList(latest,most,classified) {
    $$.request({
        url: UrlConfig.course_getCourseList,
        pars: {
            ctype:1,
            obCt:latest,
            /*obp:most,*/
            isenabled:1,
            classified:classified
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            console.log(data);
            if (data.success) {
                const list = data.datas.list;
                if (list.length===0){
                    $$.showNoResultView(".section");
                }else{
                    $$.hideNoResultView();
                }
                let resultHtml = "";
                for (let i = 0; i <list.length ; i++) {
                    resultHtml += `
                        <li onclick='jumpCourseVideo(${list[i].id})'>
                            <span class="img img1" style='background: url(${data.datas[i].filePath}) no-repeat center center /100% 100%'>
                            </span>
                            <div class="right">
                                <h3>${list[i].title}</h3>
                                <p class="content">
                                    <p>&nbsp;</p>
                                </p>
                                <div class="label">
                                    <div class="commentWrap">
                                        <span class="comment"></span><span class="commentNum">${list[i].count}</span>
                                    </div>
                                    <div class="eyesWrap">
                                        <span class="eyes"></span><span class="eyesNum">${list[i].pcount}</span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    `;
                }
                $(".item").html(resultHtml);
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
/**
 * 描述信息：音频
 * @author 覃创斌
 * @date 2019/11/8
*/
function  getCourseAudioList(latest,most,classified) {
    $$.request({
        url: UrlConfig.course_getCourseList,
        pars: {
            ctype:2,
            isenabled:1,
            classified:classified,
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            console.log('--------------Audio');
            console.log(data);
            if (data.success) {
                const list = data.datas.list;
                if (list.length === 0){
                    $$.showNoResultView(".section");
                }else{
                    $$.hideNoResultView();
                }
                let resultHtml = "";
                for (let i = 0; i <list.length ; i++) {
                    resultHtml += "<li onclick='jumpCourseAudio("+ list[i].id +")'>";
                    resultHtml += "	<span class=\"img img1\" style=background-image:url(" + list[i].filePath + " no-repeat center center /100% 100%)>";
                    resultHtml += "	</span>";
                    resultHtml += "	<div class=\"right\">";
                    resultHtml += "		<h3>" + list[i].title + "</h3>";
                    resultHtml += "		<p class=\"content\"> <p>&nbsp;</p></p>";
                    resultHtml += "		<div class=\"label\">";
                    resultHtml += "			<div class=\"commentWrap\">";
                    resultHtml += "				<span class=\"comment\"></span><span class=\"commentNum\">" + list[i].count + "</span>";
                    resultHtml += "			</div>";
                    resultHtml += "			<div class=\"eyesWrap\">";
                    resultHtml += "				<span class=\"eyes\"></span><span class=\"eyesNum\">" + list[i].pcount + "</span>";
                    resultHtml += "			</div>";
                    resultHtml += "		</div>";
                    resultHtml += "	</div>";
                    resultHtml += "</li>";
                }
                $(".item").html(resultHtml);
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}

function getLabelList(choose) {

    let initDataKey=null;

        $$.request({
            url: UrlConfig.course_getClassClassification,
            pars: {
                classifyId:2
            },
            loading:true,
            //requestBody: true,
            method: "POST",
            sfn: function (data) {
                console.log(data);
                if (data.success) {
                    $$.closeLoading();
                    initDataKey=data.datas[0].id;
                    bindEvent(data.datas);
                    if (choose===1){
                        getCourseList(1,null,initDataKey);
                    }
                    if (choose===0){
                        getCourseAudioList(null,null,initDataKey);
                    }

                } else {

                }
            }
        });
}

function clickClassLabel(){
    //筛选
    $(".swiper-wrapper > .swiper-slide").on("click",function() {
        $(".swiper-wrapper > .swiper-slide").removeClass("changeColor");
        $(this).addClass("changeColor");
        let text = $(this).text();
        let key = $(this).attr("key");
        $(".item").empty();
        if (choose == 1) {
            //视频
            /*if (text == '最新'){
                getCourseList(1)
            }else if (text == '最多播放量'){
                getCourseList(null,1);
            }else if (text == '全部'){
                getCourseList(null,null);
            }*/
            getCourseList(1, null, key);
        } else {
            /*//音频
            if (text == '最新') {
                getCourseAudioList(1);
            } else if (text == '最多播放量') {
                getCourseAudioList(null, 1);
            } else if (text == '全部') {
                getCourseAudioList(null, null);
            }*/
            getCourseAudioList(null,null,key);
        }
        countAction("xb_2026");
    });
}


/**
 * 绑定事件
 * @Author 肖家添
 * @Date 2019/9/3 15:27
 */
function bindEvent(data) {
    let html=``;
    for (let i=0;i<data.length;i++){
        if (i===0){
            html+=`<div key="${data[i].id}" class="swiper-slide changeColor">${data[i].labelName}</div>`;
        }else{
            html+=`<div key="${data[i].id}" class="swiper-slide">${data[i].labelName}</div>`;
        }



    }
    $(".swiper-wrapper").html(html);

    clickClassLabel();

    //标题分类滑动
    new Swiper('.swiper-container', {
        slidesPerView: 'auto',
        //设置margin右边距
        spaceBetween: 15,
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
    });

    countAction("xb_2026");

}




function pageInit(choose) {
    //-- 初始化页面
    getLabelList(choose);
}

function jumpCourseVideo(id) {
    $$.push('../pages/newKnow/audioDetail',{
        videoId:id
    });
}
function jumpCourseAudio(id) {
    $$.push('../pages/know/audioDetail',{
        audioId:id
    });
}
