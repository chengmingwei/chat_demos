window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_51', null);
    } catch (error) {
        console.log(error);
    }

    /**
     * 一级菜单切换
     */
    //点击资讯
    $('#xl-tab-head-title-1').click(function () {
        $$.push('know/information');
    });

    //点击课堂
    $('#xl-tab-head-title-3').click(function () {
        $$.push('newKnow/classRoom');
    });

    // 我的学习
    $(".headLogo").click(function () {
        window.location.href = '../../pages/know/myLearn.html'
    });

    // 更多精品 ----  视频
    $(".moreVideo").click(function () {
        $$.push("know/courseList",{
            type:"Video"
        });
    });

    //音频
    $(".moreAudio").click(function () {
        $$.push("know/courseList",{
            type:"Audio"
        });
    });
    //提问
    $(".add").click(function () {
        layer.open({
            type: 1,
            content: addLayerOpenContent(),
            skin: 'footer',
            success: (layero, index) => {
                $('#' + layero.id + ' .layui-m-layercont').css({
                    'background-color':'white',
                    'border-radius':'5px'
                });
                $('.addQuestion').on('click',function () {
                    $$.push("know/myQuestion");
                });
                $('.addDemand').on('click',function () {
                    $$.push("know/myDemand");
                });
            }
        });
    });
    //问答 --- 加载问答分类标签
    loadLabel();

    // 底部菜单
    let oBtn = document.getElementById("menu");
    let uLi = oBtn.getElementsByTagName("a");
    let n = uLi.length;
    for (let i = 0; i < n; i++) {
        uLi[i].index = i;
        uLi[i].addEventListener("touchend", function () {
            for (let j = 0; j < n; j++) {
                uLi[j].className = "";
            }
            this.className = "active";
        }, false)
    }

    //-- 跳转自动绑定
    $$.staticPushAutoBind();
    if (!$$.checkLogin()){
        $$.gotoLogin();
    }

    //加载分类
    loadClassify();

};

function addLayerOpenContent() {
    let contentHtmlArr = [
    '<div class="addLayerOpenContent">',
        '<div class="addQuestion">',
            '<img src="../../images/know/information/addQuestion.png" />',
            '<div>发布问题</div>',
            '<span>（遇到不懂的，发个问题）</span>',
        '</div>',
        '<div class="addDemand">',
            '<img src="../../images/know/information/addDemand.png" />',
            '<div>发布需求</div>',
            '<span>（方案不会做，发个需求）</span>',
        '</div>',
    '</div>'];
    return contentHtmlArr.join('');
}
