window.onload = function () {
    $$.changeVersion();
    let demandId = $$.getUrlParam("demandId");
    showDemandDetail(demandId);
};

function showDemandDetail(demandId) {
    $$.request({
        url: UrlConfig.member_demand_wx_showDemandDetail,
        pars: {
            demandId:demandId
        },
        method: "POST",
        requestBody:true,
        sfn: function (data) {
            console.log(data);
            if (data.success) {
                const labelName = data.labelName;
                const createTime = data.createTime;
                const content = data.content;
                const telephone = data.telephone;
                $('.labelName span').html(labelName);
                $('.createTime span').html(createTime);
                $('.content').html(content);
                $('.telephone span').html(telephone);
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
