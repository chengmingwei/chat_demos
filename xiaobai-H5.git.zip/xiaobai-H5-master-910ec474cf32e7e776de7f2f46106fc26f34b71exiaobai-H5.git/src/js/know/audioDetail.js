let videoId;
let audioId;
let type;
let shareImg;//分享图片
let shareMemberId;
let shareStatus;
window.onload = function () {
    $$.changeVersion();
    videoId = $$.getUrlParam("videoId");
    audioId = $$.getUrlParam("audioId");
    //分享参数
    shareMemberId = $$.getUrlParam("shareMemberId");
    shareStatus = $$.getUrlParam("share");
    shareDetailPage(shareMemberId,shareStatus);
    if (videoId != null){
        $(".playBar").append("<video  width=\"100%\" height=\"100%\" controls id=\"video\"></video>");
        type = 1;
    }else if(audioId != null){
        $(".playBar").append("<audio id=\"audio\"    type=\"audio/mpeg\" controls=\"controls\"></audio>");
        type=2;
    }
    $(".single-slider").jRange({
        from: 0,
        to: 100,
        step: 1,
        // scale: [0, 25, 50, 75, 100],
        format: '%s',
        width: '60%',
        showLabels: false,
        showScale: false
    });
    loadBanner();
    loadInfo();
    loadEvaluation();
    insertBrowse();
    checkShare();
    /**
     * 描述信息：上一页
     * @author 覃创斌
     * @date 2019/10/10
    */
    $("#prev").on("click",function () {
        prevCourseItem(1);
    });
    /**
     * 描述信息：下一页
     * @author 覃创斌
     * @date 2019/10/10
    */
    $("#next").on("click",function () {
        prevCourseItem(2);
    });
    //点赞
    $(".like").on("click",function () {
        let id ;
        if (type === 1){
            id = videoId;
        }else if (type === 2){
            id = audioId;
        }
        $$.request({
            url: UrlConfig.praisestatistic_save,
            pars: {
                type:4,
                objectId:id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {

                    if (data.delete){
                        $$.layerToast('点赞成功！');
                        $(".like").html("已点赞");
                        $(".like").css("background","#C0C0C0");
                    }else {
                        $$.layerToast('取消点赞！');
                        $(".like").html("点赞");
                        $(".like").css("background","#ff7052");
                    }
                    countAction("xb_2021");
                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    });
    //评论
    $(".send").on("click",function () {
        //数据统计
        try {
            countAction('xb_58', null);
        } catch (error) {
            console.log(error);
        }
        let id ;
        if (type === 1){
            id = videoId;
        }else if (type === 2){
            id = audioId;
        }
        let speech = $("#speech").val();
        if (speech !== ""){
            $$.request({
                url: UrlConfig.insertEvaluation,
                pars: {
                    evaluationContent:speech,
                    isAnonymous:0,
                    state:1,
                    objectID:id,
                    type:4,
                    isTop:0,
                    giveLike:0
                },
                requestBody: true,
                method: "POST",
                sfn: function (data) {
                    if (data.success) {
                        checkToDayWatchAndLearn();
                        $$.layerToast('评论成功！');
                        loadEvaluation();
                    } else {
                        $$.layerToast(`${data.msg}`);
                    }
                    $("#speech").val('');
                    countAction("xb_2024");
                }
            });
        }
    });
    /**
     * 描述信息：收藏
     * @author 覃创斌
     * @date 2019-09-19
     */
    $(".collect").on("click",function () {
        let id ;
        if (type === 1){
            id = videoId;
        }else if (type === 2){
            id = audioId;
        }
        $$.request({
            url: UrlConfig.insertCollectstatistic,
            pars: {
                type:6,
                objectId:id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    if (data.count === 0){
                        $(".collect").html("已收藏");
                        $(".collect").css("background","#C0C0C0");
                        $$.layerToast(`收藏成功！`);
                    }else {
                        $(".collect").html("收藏");
                        $(".collect").css("background","#ff7052");
                        $$.layerToast(`取消收藏！`);
                    }
                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    });
    //购买
    $(".freeStudy").on("click",function () {
        let id ;
        if (type === 1){
            id = videoId;
        }else if (type === 2){
            id = audioId;
        }
        $$.request({
            url: UrlConfig.order_insertOrder,
            pars: {
                code:"123456789",
                btype:1,
                pclass:3,
                payType:0,
                amount:0.0,
                integrals:0,
                courseId:id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    if (data.msg === "已购买本课程，无需重复购买！"){
                        $(".freeStudy").html("已购买课程");
                        $(".freeStudy").css("background","#C0C0C0");
                    }else {
                        $(".freeStudy").html("免费学习");
                        $(".freeStudy").css("background","#5677fc");
                        countAction("xb_2025");
                    }
                    $$.alert(data.msg,function () {
                        $$.closeLoading();
                    });
                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    });

    //-- 找客服  加群学习 二维码 绑定事件
    $(".ask").on("click", function(){
        layer.open({
            content:
                `<div class="popupContent">
					<div class="question">
						<b>扫描下方二维码，加群学习</b>
						<img src="../../images/my/serviceQrCode.png"" />
						<span>长按识别二维码</span>
					</div>
				</div>`
        });
        countAction("xb_2023");
    });

    /* 点击分享给客户填写  */
    $('.share').click(function () {
        $('#popup').show();
        return false;
    });
    /* 取消 分享 */
    $('#popup .bg,.showFrame').click(function () {
        $('#popup').hide();
        return false;
    });
    $$.setReadLongTimes();
};
function checkToDayWatchAndLearn() {
    $$.request({
        url: UrlConfig.integral_checkToDayWatchAndLearn,
        pars: {},
        method: "POST",
        sfn: function (data) {
            if (!data) {
                $$.request({
                    url: UrlConfig.integral_handSendIntegral,
                    pars: {
                        code:"I0008"
                    },
                    method: "POST",
                    sfn: function (info) {
                        if (info.success){
                            $$.alert("积分赠送成功！");
                            countAction("xb_2036");
                        }
                    }
                });
            }
        }
    });
}

/**
 * 描述信息：加载Banner
 * @author 覃创斌
 * @date 2019/10/9
*/
function loadBanner() {
    let id ;
    if (type === 1){
        id = videoId;
    }else if (type === 2){
        id = audioId;
    }
    $$.request({
        url: UrlConfig.course_getCourseBannerList,
        pars: {
            id:id
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                let resultHtml = "";
                const bannerLength = data.datas.length;
                for (let i = 0; i < bannerLength; i++) {
                    resultHtml += "  <div class=\"swiper-slide\"><img src=\""+data.datas[i].url+"\"></div>";
                    shareImg =data.datas[i].url;
                }

                $("#banner").append(resultHtml);
                if (bannerLength > 1) {
                    //动态加载后需要重新渲染
                    const swiper = new Swiper('.swiper-container', {
                        observer: true,//修改swiper自己或子元素时，自动初始化swiper
                        observeParents: true,//修改swiper的父元素时，自动初始化swiper
                        autoplay: 2000,
                        loop: true,
                        prevButton: '.swiper-button-prev',
                        nextButton: '.swiper-button-next',
                    });
                } else {
                    $('.swiper-button-prev').hide();
                    $('.swiper-button-next').hide();
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
function videoOrAudio() {
    let id ;
    if (type === 1){
        id = videoId;
    }else if (type === 2){
        id = audioId;
    }
    $$.request({
        url: UrlConfig.courseItem_getByCourseId,
        pars: {
            courseId:id
        },
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                const courseItemLength = data.courseItem.length;
                if (courseItemLength>0){
                    console.log(data);
                    let shareUrl;
                    let url = data.courseItem[0].avattachId;
                    const data_val = data.courseItem[0].id;
                    if (type === 1){
                        url = url !== undefined ? url : data.courseItem[0].linkUrl;
                        $("#video").attr("src", url).attr("data-val", data_val);
                        //-- 视频播放监听
                        $("#video")[0].addEventListener("play", function(){
                            countAction("xb_2020");
                        });
                    }else if (type === 2){
                        $("#audio").attr("src",url);
                        $("#audio").attr("data-val",data_val);
                    }
                    shareUrl = window.location.href+"&share=true&memberId="+data.memberId;
                    $("#prev").hide();
                    $("title").html(data.courseItem[0].cname);
                    if (courseItemLength === 1) {
                        $("#next").hide();
                    }
                    //分享
                    if ($$.checkLogin()){
                        console.log(shareUrl);
                        weChatJSTool.share({
                            _imgUrl: url,
                            _lineLink: shareUrl,
                            _shareTitle: data.courseItem[0].cname,
                            _descContent: '小白保险小课堂，我在这里等你一起来学习哦',
                            _sfn: function () {
                                if (videoId !== undefined)
                                $$.share(videoId,5);
                                countAction("xb_2022");
                            }
                        });
                    } else {
                        WE_CHAT_MENU_FLAG = false;
                        weChatMenuHandler();
                    }
                }else{
                    $("#prev").hide();
                    $("#next").hide();
                    $$.layerToast("暂无数据");
                }

            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
function  loadInfo() {
    let id ;
    if (type === 1){
        id = videoId;
    }else if (type === 2){
        id = audioId;
    }
    $$.request({
        url: UrlConfig.course_getCourseList,
        pars: {
            id:id
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                const list = data.datas.list;
                for (let i = 0; i < list.length; i++) {
                    $("#title").html(list[i].title);
                    $("#lecturer").html(list[i].speaker);
                    $("#Play").html(list[i].pcount);
                    $("#time").html(list[i].createTime);
                    $("#content").html(list[i].txtattachPath);
                    videoOrAudio();
                    updatePlay(list[i].id,list[i].pcount);
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
function  updatePlay(id,pcount) {
    pcount = pcount+1;
    $$.request({
        url: UrlConfig.course_updateCourse,
        pars: {
            id:id,
            pcount:pcount
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {

            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
/**
 * 描述信息：加载评论
 * @author 覃创斌
 * @date 2019/10/10
*/
function loadEvaluation() {
    let id ;
    if (type === 1){
        id = videoId;
    }else if (type === 2){
        id = audioId;
    }
    $$.request({
        url: UrlConfig.getListByEvaluation,
        requestBody: true,
        pars: {
            objectid: id,
            type:4
        },
        method: "POST",
        sfn: function (data) {
            let resultHtml = "";
            if (data.success) {

                for (let i = 0; i < data.datas.length; i++) {
                    resultHtml += "<li>";
                    resultHtml += "	<p class=\"top\">";
                    if (data.datas[i].isanonymous === 1){
                        resultHtml += "<span class=\"avatar\">  <img src=\"https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com/picFile/2019/11/tempFilesed47803481e64b9cbb87c54feccf165a_small.png\" style=\"width: 16px; height: 16px;background-size: contain;display: inline;\"/>&nbsp;匿名</span>";
                    }else {
                        let name =data.datas[i].rname  ? data.datas[i].rname : data.datas[i].account;
                        resultHtml += "<span class=\"avatar\">  <img src=\"https://xiaobai-image-dev.oss-cn-shenzhen.aliyuncs.com/picFile/2019/11/tempFilesed47803481e64b9cbb87c54feccf165a_small.png\" style=\"width: 16px; height: 16px;background-size: contain;display: inline;\"/> &nbsp;"+name +"</span>";
                    }
                    resultHtml += "		<span style=\"\n" + "    position: relative;\n" + "    float: right;\n" +
                        "\">"+getDate(data.datas[i].createtime)+"</span>";
                    resultHtml += "	</p>";
                    resultHtml += "	<p class=\"content\">"+data.datas[i].evaluationcontent+"</p>";
                    resultHtml += "</li>";
                }
                $(".comments-li").html(resultHtml);
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
/**
 * 描述信息：添加浏览记录
 * @author 覃创斌
 * @date 2019/10/12
*/
function insertBrowse() {
    let id;
    let viewStatisticType;
    if (type === 1){
        id = videoId;
        viewStatisticType = 2;
    }else if (type === 2){
        id = audioId;
        viewStatisticType = 6;
    }
    let memberId = $$.getUrlParam("memberId");
    $$.request({
        url: UrlConfig.viewStatistic_insertViewStatistic,
        pars: {
            shareUserId:memberId,
            type:viewStatisticType,
            objectId:id,
            judge:1,
        },
        method: "POST",
        sfn: function (data) {

        }
    });
}


function getDate(dateTimeStamp) {
    let minute = 1000 * 60;
    let hour = minute * 60;
    let day = hour * 24;
    let halfamonth = day * 15;
    let month = day * 30;


    if (dateTimeStamp === undefined) {

        return false;
    } else {
        dateTimeStamp = dateTimeStamp.replace(/\-/g, "/");

        let sTime = new Date(dateTimeStamp).getTime();//把时间pretime的值转为时间戳

        let now = new Date().getTime();//获取当前时间的时间戳

        let diffValue = now - sTime;

        if (diffValue < 0) {
            console.log("结束日期不能小于开始日期！");
        }

        let monthC = diffValue / month;
        let weekC = diffValue / (7 * day);
        let dayC = diffValue / day;
        let hourC = diffValue / hour;
        let minC = diffValue / minute;

        if (monthC >= 1) {
            return  dateTimeStamp.substr(5,5).replace(/\//g,'月')+"日";
        } else if (weekC >= 1) {
            return  dateTimeStamp.substr(5,5).replace(/\//g,'月')+"日";
        } else if (dayC >= 1) {
            return  dateTimeStamp.substr(5,5).replace(/\//g,'月')+"日";
        } else if (hourC >= 1) {
            return parseInt(hourC) + "小时前";
        } else if (minC >= 1) {
            return parseInt(minC) + "分钟前";
        } else {
            return "刚刚";
        }
    }
}
//微信授权登录
function checkShare() {
    let share = $$.getUrlParam("share");
    let memberId = $$.getUrlParam("memberId");
    let videoId = $$.getUrlParam("videoId");
    let audioId = $$.getUrlParam("audioId");
    let id;
    let type;
    if (videoId !== undefined){
        id = videoId;
        type = 3;
    }else {
        id = audioId;
        type = 4;
    }

    if (share === 'true'){
        let url = window.location.search;
        url = url.replace("true",'false');
        url = "newKnow/audioDetail.html"+url;
        console.log('----url',url);
        ShawHandler.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: url,
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_6,
                otherParams: JSON.stringify({"objectId": id,"type":type,"memberId":memberId})
            },
            loading: true,
            sfn: function(data){
                $$.closeLoading();
                location.href = data.datas;
            }
        });
    }
}

function shareDetailPage(shareMemberId,shareStatus) {
    if (shareMemberId !=null && shareStatus === 'true'){
        //alert("获取分享页");
        $$.request({
            url: UrlConfig.member_getShareMemberInfo,
            pars:{
                memberId:shareMemberId
            },
            loading:true,
            method: "POST",
            sfn: function(data){
                if(data.success){
                    $$.closeLoading();
                    if (data.datas.rname != null && data.datas.rname !== ""){
                        $(".name p").text(data.datas.rname);
                    }else{
                        $(".name p").text(data.datas.account);
                    }
                    if( (data.datas.imgPath != null)&& (data.datas.imgPath !== "")){
                        $(".head").attr("src",data.datas.imgPath);
                    }else {
                        $(".head").attr("src", "../../images/my/defaultImg.png");
                    }
                    $(".evaluate").hide();
                    $(".menu").hide();
                    $(".info").show();
                    $('.iphone').on('click',function () {
                        window.location.href = "tel:"+data.datas.phone;
                    });
                    if ($$.checkLogin()){
                        $(".textarea").show();
                        $(".loginApp").hide();
                        $(".bottomBtn").show();
                    }else{
                        $(".textarea").hide();
                        $(".loginApp").show();
                        $(".bottomBtn").hide();
                    }
                    $('.loginApp').on('click',function (){
                        $$.push("login/login");
                    })
                }else{
                    $$.layerToast("系统出错");
                }
            }
        });
    }
}
function prevCourseItem(page) {
    let id;
    if (type === 1){
        id = videoId;
    }else if (type === 2){
        id = audioId;
    }
    let video = $("#video").attr("data-val");
    let audio = $("#audio").attr("data-val");
    let objId = video != null ? video:audio;
    if($$.isValidObj(objId)){
        $$.request({
            url: UrlConfig.courseItem_prevCourseItem,
            pars: {
                courseId:id,
                id:objId,
                page:page,//上一页 为1 下一页为2
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    if (type === 1){
                        let Media = document.getElementById("video");
                        Media.src = data.mapList.avattachId != null ? data.mapList.avattachId : data.mapList.linkUrl; //返回或设置当前资源的URL
                        Media.load();
                        $("#video").attr("data-val",data.mapList.id)
                    }else if (type === 2){
                        let Media = document.getElementById("audio");
                        Media.src = data.mapList.avattachId != null ? data.mapList.avattachId : data.mapList.linkUrl; //返回或设置当前资源的URL
                        Media.load();
                        $("#audio").attr("data-val",data.mapList.id)
                    }
                    $("title").html(data.mapList.cname);
                    $("#prev").show();
                    $("#next").show();
                    if (data.msg === 'noPrev') {
                        $("#prev").hide();
                    } else if (data.msg === 'noNext') {
                        $("#next").hide();
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            }
        });
    }else {
        $$.layerToast("暂无资源~~~")
    }
}
