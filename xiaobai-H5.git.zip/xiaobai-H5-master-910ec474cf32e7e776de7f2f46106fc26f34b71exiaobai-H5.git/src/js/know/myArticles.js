$(function(){
	pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        //-- 匹配后台数据更新
        $$.request({
            url: UrlConfig.course_getMyCollectByArticleList,
	        pars: {},
			requestBody:true,
            sfn: function(data){
                sfn(data);
            }
        });
        //-- 首页数据请求回调
        function sfn(data){
            if(data.success){
				//-- 加载我的关注列表数据
			    bindArticlesList(data);
            }
        }

    }

	/* 绑定收藏文章列表 */
	function bindArticlesList(data){
		let html = "";

		if (data.datas.length > 0){
			$$.hideNoResultView();
			console.log(data)
			for (let i = 0; i < data.datas.length; i++) {
				html += "<div class=\"unit\" data-id=\""+data.datas[i].objectID+"\">";
				html += "	<div class=\"articles-left\">";
				html += "		<div class=\"articles-left-title text-overflow\">"+data.datas[i].title+"</div>";
				html += "		<div class=\"articles-list\">";
				html += "			<div class=\"articles-type\">"+data.datas[i].classifyname+"</div>";
				html += "			<div class=\"articles-comment\">";
				html += "				<div class=\"comment\"></div>";
				html += "				<div>"+data.datas[i].ecount+"</div>";
				html += "			</div>";
				html += "			<div class=\"articles-like\">";
				html += "				<div class=\"comment\"></div>";
				html += "				<div>"+data.datas[i].vscount+"</div>";
				html += "			</div>";
				html += "		</div>";
				html += "	</div>";
				html += "	<div class=\"articles-right\">";
				html += "		<img src=\""+data.datas[i].coverImgUrl+"\"/>";
				html += "	</div>";
				html += "</div>";
			}

			$(`.wrapper`).html(html);
			/**----- 跳转文章详情页面 事件绑定 ----**/
			$(".unit").on("click",function(){
				let id = $(this).attr("data-id");
				console.log(id)
				//-- 根据ID 获取后台地址
				$$.push('newKnow/articleDetails',{
					id:id
				});
			});
		}else {
			//$$.push('my/noContent');
			$$.showNoResultView({
				parentJqSelector: "body" ,
				msg: "暂无内容",
			});
		}





	}
});
