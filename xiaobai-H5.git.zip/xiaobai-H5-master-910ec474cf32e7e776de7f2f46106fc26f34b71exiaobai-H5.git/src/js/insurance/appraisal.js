window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_18', null);
    } catch (error) {
        console.log('error:' + error);
    }
    $(".clock").click(()=>{
        $$.request({
            url: UrlConfig.market_insuranceTest_checkStatus,
            sfn: function(data){
                console.log(data);
                if(data.success){
                    if ( data.datas === 0 || data.datas === 1){
                       let html = `<div class="pop-up">
                        <div class="over">你已经参加过测评了</div>
                        <div class="know">我知道了</div>
                    </div>`;
                        layer.open({
                            content: html,
                            type: 1
                        });
                        $('.close,.know').click(() => {
                            layer.closeAll();
                        });
                    }else if (data.datas === -1 || data.datas !== 1 || data.datas !== 0) {
                        $$.push("insurance/appraisalPageFirst");
                    }
                }
            }
        });
    });

    weChatShare();
    /*$(".plan").on("click",function () {
        let html = `<div class="pop-up">

                        <div class="date">改功能暂未开放</div>
                        <div class="know">我知道了</div>
                    </div>`;

        layer.open({
            content: html,
            type: 1
        });

        $('.close,.know').click(() => {
            layer.closeAll();
        })
    });*/


    /*$(".plan").click(()=>{
        window.location.href="http://www.ygdatatech.com/creditCard_wx/page/evaluation/evaluation.html";
    })*/

    /**
     * 分享
     */
    function weChatShare() {
        if (!$WeChat.isWx()) {
            return;
        }
        let shareUrl = $$.getFullHost() + '/src/pages/insurance/appraisal.html';
        console.log('shareUrl:' + shareUrl);
        weChatJSTool.share({
            _imgUrl: $$.getFullHost() + '/src/images/appraisal/Research.png',
            _lineLink: shareUrl,
            _shareTitle: '保险测评',
            _descContent: '三分钟就能测一测你的风险指数，快来免费体验吧！',
            checkLogin: false,
            _sfn: function () {
                $$.layerToast("分享成功~");
            }
        });
    }
};
