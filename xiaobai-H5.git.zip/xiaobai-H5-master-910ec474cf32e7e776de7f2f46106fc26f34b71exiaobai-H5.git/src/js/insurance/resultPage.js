window.onload = function () {
    $$.changeVersion();
    let index=0;
    let transmit="";
    if (!(decodeURIComponent($$.getUrlParam("data"))=="null")){
        console.log("==有传输数据==");
        transmit=decodeURIComponent($$.getUrlParam("data"));
        console.log(transmit);
    }


    if (decodeURIComponent($$.getUrlParam("index"))){
        index=decodeURIComponent($$.getUrlParam("index"));
    }
    $(".question span span:first-child").text("Q"+(parseInt(index)+1)+":")
    let data=null;
    function isPoneAvailable($poneInput) {
        var myreg=/^[1][3,4,5,7,8][0-9]{9}$/;
        if (!myreg.test($poneInput)) {
            return false;
        } else {
            return true;
        }
    }

    selectPhone();

    let text=$(".question span span:first-child").text()
    console.log(text)


    $("#phone").click(function () {
        $(this).val("")
    })
    $("#phone").blur(function () {
        let phone=$(this).val();
        let length=$(this).val().length;
        let Isiphone=isPoneAvailable($(this).val());
        if (length==11&&Isiphone){
            $(".confirm").addClass("chooseColor_2");
            $(".confirm").removeClass("confirm_color");
            $$.request({
                url: UrlConfig.member_member_modifierRealName,
                pars:{phone:phone},
                sfn: function(data){
                    /*if(data.success){
                        $$.layerToast(`手机号码修改成功！[${data.msg}]`);
                    }else{
                        $$.layerToast(`手机号码失败！[${data.msg}]`);
                    }*/
                }
            });
        }else{
            $(".confirm").removeClass("chooseColor_2");
            $(".confirm").addClass("confirm_color");
        }

    })
    function selectPhone(){
        $$.request({
            url: UrlConfig.member_Detailspage,
            loading: true,
            sfn: function (data) {
                console.log(data);
                $$.closeLoading();
                if (data.success) {
                    if ((data.datas.phone)==null||(data.datas.phone)===""){
                        $("#phone").val("请输入你的手机号码")
                    }else{
                        $("#phone").val(data.datas.phone)
                    }
                    $(".confirm").addClass("chooseColor_2");
                    $(".confirm").removeClass("confirm_color");
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }



    $(".choose").blur(function () {
        let length=$(this).val().length;
        let Isiphone=isPoneAvailable($(this).val());
        if (length==11&&Isiphone){
            $(".confirm").addClass("chooseColor_2");
            $(".confirm").removeClass("confirm_color");
        }
    })



   $(".confirm").click(function () {
       console.log(transmit);
        console.log($("#iphone").val())
        if ($(this).hasClass("chooseColor_2")) {
            let html = `<div class="pop-up">
                        <img class="close" src="../../images/appraisal/close.png" />
                        <img class="check" src="../../images/appraisal/Check.png" />
                        <div class="date"><p>客服会尽快联系你</p><p>请留意020开头的电话</p></div>
                        <div class="know">我知道了</div>
                    </div>`;
            layer.open({
                content: html,
                type: 1
            });
            $('.close,.know').click(() => {
                layer.closeAll();
            })
            $('.know').click(() => {
                layer.closeAll();
                countAction("xb_2056");
                $$.request({
                    url: UrlConfig.market_insuranceTest_saveResult,
                    pars:{transmit:transmit+"|"},
                    sfn: function(data){
                        if(data.success){
                            $$.push('insurance/appraisal');
                        }else{
                            $$.layerToast(`保险测评失败！[${data.msg}]`);
                        }
                    }
                });



                console.log(transmit)
            })
        }
    })

}
