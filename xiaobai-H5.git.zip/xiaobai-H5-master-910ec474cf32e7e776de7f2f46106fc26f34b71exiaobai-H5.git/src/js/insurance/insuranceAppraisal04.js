window.onload = function () {
    $$.changeVersion();
    let data=null;
    $(".box").find("span").eq(0).css("background", "#ff7052");
    $(".box").find("span").eq(1).css("background", "#ff7052");
    $(".box").find("span").eq(2).css("background", "#ff7052");
    $(".box").find("span").eq(3).css("background", "#ff7052");
    /*$(".choose").click(function () {
        let data=$(this).text();
        /!*console.log(encodeURIComponent(data))*!/
        /!*map["gender"]=gender;*!/
        $(this).css({"background":"#ff7052"})
        $$.push('insurance/insuranceAppraisal02',{"data":encodeURI(encodeURI(data))});
    })*/

    function getStyle2(obj)
    {
        if(obj.currentStyle===undefined)
        {
            return getComputedStyle(obj);
        }else{
            return obj.currentStyle;//IE
        }
    }

    $(".choose").focus(function () {
        data="gender:"+$(this).text();
        /*$(this).css({"background":"#ff7052","color":"white"});*/
        $(this).removeClass("chooseColor_1");
        $(this).addClass("chooseColor_2");
        $(".confirm").addClass("chooseColor_2");
        $(".confirm").removeClass("confirm_color");

    })
    $(".choose").blur(function () {
        $(this).removeClass("chooseColor_2");
        $(this).addClass("chooseColor_1");
        $(".confirm").addClass("confirm_color");
        $(".confirm").removeClass("chooseColor_2");
    })
    
    $(".confirm").click(function () {
        if ($(".choose").hasClass("chooseColor_2")){
            console.log("++++");
        }
        let obj1=$(".content").find("div")[0];
        let obj2=$(".content").find("div")[1];

        /*let color=null;
        var currentStyle=getStyle2(this);
        color=currentStyle["color"];
        console.log(currentStyle["color"]);
        alert(currentStyle["color"]);
        if (color=="rgb(255, 112, 82)"){
            console.log("配对")

        }*/
        if (data!=null){
            /*$$.push('insurance/insuranceAppraisal02',{"data":encodeURI(encodeURI(data))});*/
            console.log("配对")
        }
    })
}