window.onload = function () {
    $$.changeVersion();
    let data = decodeURIComponent($$.getUrlParam("data"));
    console.log(data)
    $(".box").find("span").eq(0).css("background", "#ff7052");
    $(".box").find("span").eq(1).css("background", "#ff7052");
    $(".box").find("span").eq(2).css("background", "#ff7052");
    function getStyle2(obj)
    {
        if(obj.currentStyle===undefined)
        {
            return getComputedStyle(obj);
        }else{
            return obj.currentStyle;//IE
        }
    }

    /**
     * 当选择框全部没被选中的时候 确认键也变成灰色
     * @author hong
     * */
    $(".choose").click(function () {
        if ($(this).hasClass("chooseColor_1")){
            $(this).removeClass("chooseColor_1");
            $(this).addClass("chooseColor_2");
        }else {
            $(this).removeClass("chooseColor_2");
            $(this).addClass("chooseColor_1");
        }
        //改变确认键的背景颜色
        changeColor();

    })

    $(".confirm").click(function () {
        /*let obj1=$(".content").find("div")[0];
        let obj2=$(".content").find("div")[1];
        let obj3=$(".content").find("div")[2];
        let obj4=$(".content").find("div")[3];

        if ($(obj1).hasClass("chooseColor_2")){
            data+="family1:"+$(obj1).text();

        }
        if ($(obj2).hasClass("chooseColor_2")){
            data+="family2:"+$(obj2).text();

        }
        if ($(obj3).hasClass("chooseColor_2")){
            data+="family3:"+$(obj3).text();

        }
        if ($(obj4).hasClass("chooseColor_2")){
            data+="family4:"+$(obj4).text();

        }

        if ($(obj1).hasClass("chooseColor_2")||$(obj2).hasClass("chooseColor_2")||$(obj3).hasClass("chooseColor_2")||$(obj4).hasClass("chooseColor_2")){
            /!*$$.push('insurance/insuranceAppraisal02',{"data":encodeURI(encodeURI(data))});*!/
            alert("访问")
        }
        console.log(data)*/

        /*console.log($(".choose").hasClass("chooseColor_2"));

        if ($(".choose").hasClass("chooseColor_2")){

        }*/
        let text=getText();
        console.log(text)
    })



}


function  getText() {
    let $chose = $('.choose ');
    let count = $chose.length;
    console.log(count)
    let text = "";
    for(let i=0;i<count;i++){
        if($(".choose:eq("+i+")").hasClass('chooseColor_2')){
            text += $(".choose:eq("+i+")").text();
        }

    }
    return text;
}


function  changeColor() {
    let clicks=0;
    clicks++;
    let $chose = $('.choose ');
    let count = $chose.length;
    for(let i=0;i<count;i++){
        if($(".choose:eq("+i+")").hasClass('chooseColor_2')){
            $(".confirm").css({"background":"#ff7052","color":"white"});
            return;
        }else{
            $(".confirm").css({"background":"white","color":"#ff7052"});
        }

    }
}