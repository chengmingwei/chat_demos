window.onload = function () {
    $$.changeVersion();
    let answer=null;
    let index=0;
    let vals=null;
    let transmit="";
    let dataLength = 0;
    if (!(decodeURIComponent($$.getUrlParam("data"))=="null")){
        console.log("==有传输数据==");
        transmit=decodeURIComponent($$.getUrlParam("data"));

    }
    if (decodeURIComponent($$.getUrlParam("index"))){
        index=decodeURIComponent($$.getUrlParam("index"));
    }
    questionShow();
    function questionShow() {
        $$.request({
            url: UrlConfig.market_insuranceTest_questionShow,
            pars:{tempId:1},
            sfn: function(data){
                if(data.success){
                    console.log(data)
                    dataLength=data.datas.list.length;
                    bindingElement(data);
                    changeTopColor();
                }else{
                    $$.layerToast(`获取险种分类失败！[${data.msg}]`);
                }

            }
        });
    }
    
    function slicerDate(str) {
        str = str.split(",");//取消字符串中出现的所有逗号
        return str;
    }
    function bindingElement(data) {
        console.log(data.datas.list[index].ctype);
        if (data.datas.list[index].ctype == 1 && data.datas.list[index].judge!=1) {
            console.log("单选题")
            $(".question >span>span:first-child").text("Q"+(parseInt(index)+1)+":");
            $(".question >span>span:last-child").text(data.datas.list[index].question);
            vals = slicerDate(data.datas.list[index].vals);
            let html = "";
            for (var i = 0; i < vals.length; i++) {
                html += `<li>` +
                    `<div class="choose chooseColor_1" tabindex="0">${vals[i]}</div>` +
                    `</li>`;
            }
            $(".content ul").append(html);
            $('.content > ul > li > .choose').click(function () {
                $(this).addClass('chooseColor_2');
                $(this).parent().siblings().children('.choose').removeClass('chooseColor_2').addClass('chooseColor_1');
                changeColor();

                answer=data.datas.list[index].id+":"+$(this).text();
                transmit += "|" + answer;
                let length = data.datas.list.length;
                index++;
                console.log(transmit)
                index!=length ?  $$.push('insurance/appraisalPageSecond', {
                    "data": encodeURI(encodeURI(transmit)),
                    "index": encodeURI(encodeURI(index))
                }) : console.log("no");
                index==length ? $$.push('insurance/resultPage', {"data": encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))}) : console.log("no");
            });

        }


        if (data.datas.list[index].ctype == 2 && !(data.datas.list[index].judge==2)) {
            console.log("多选题");
            $(".question >span>span:first-child").text("Q"+(parseInt(index)+1)+":");
            $(".question >span>span:last-child").text(data.datas.list[index].question);
            vals = slicerDate(data.datas.list[index].vals);
            let html = "";
            for (var i = 0; i < vals.length; i++) {
                html += `<li>` +
                    `<div class="choose chooseColor_1" tabindex="0">${vals[i]}</div>` +
                    `</li>`;
            }
            $(".content ul").append(html);
            $(".next").append(`<div class="confirm confirm_color"><div>下一步</div></div>`);
            $(".choose").click(function () {
                if ($(this).hasClass("chooseColor_1")){
                    $(this).removeClass("chooseColor_1");
                    $(this).addClass("chooseColor_2");
                }else {
                    $(this).removeClass("chooseColor_2");
                    $(this).addClass("chooseColor_1");
                }
                changeColor();
            })

            $(".confirm").click(function () {
                let length=data.datas.list.length;
                answer=data.datas.list[index].id+":"+getText();
                transmit+="|"+answer;
                index++;
                if (index==length){
                    $$.push('insurance/resultPage',{"data":encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))});
                }
                else {
                    $$.push('insurance/appraisalPageFirst',{"data":encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))});
                }
            })
        }

        if (data.datas.list[index].ctype == 1&&(data.datas.list[index].judge==1)) {
            let length=data.datas.list.length;
            $(".question >span>span:first-child").text("Q"+(parseInt(index)+1)+":");
            $(".question >span>span:last-child").text(data.datas.list[index].question);
            console.log("年龄题")
            const age=[{label:"",value:0},{label:"",value:1},{label:"",value:3},{label:"",value:4},{label:"",value:5},
                {label:"",value:6},{label:"",value:7},{label:"",value:8},{label:"",value:9},{label:"",value:10},{label:"",value:11},
                {label:"",value:12},{label:"",value:13}];
            for (var i=0;i<age.length;i++){
                age[i].value=(slicerDate(data.datas.list[index].vals))[i];
                age[i].label=(slicerDate(data.datas.list[index].vals))[i];
            }
            let html = "";
            html += `<li>` +
                `<div class="chooseColor_1" tabindex="0">请选择你的年龄</div>` +
                `</li>`;
            $(".content ul").append(html);
            $('.chooseColor_1').on('click', function () {
                $(this).css({"background":"#ff7052","color":"white"});
                weui.picker(age, {
                    onConfirm: function (result) {
                        /*transmit+=",偷偷告诉我你的年龄:"+result;*/
                        answer=data.datas.list[index].id+":"+result;
                        transmit+="|"+answer;
                        index++;
                        if (index==length){
                            $$.push('insurance/resultPage',{"data":encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))});
                        }else {
                            $$.push('insurance/appraisalPageFirst',{"data":encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))});
                        }
                    },
                    title: '选择你的岁数'
                });
            });

        }

        if (data.datas.list[index].ctype == 2 && data.datas.list[index].judge==2) {
            console.log("一支独秀");
            $(".question >span>span:first-child").text("Q"+(parseInt(index)+1)+":");
            $(".question >span>span:last-child").text(data.datas.list[index].question);
            vals = slicerDate(data.datas.list[index].vals);
            let html = "";
            for (var i = 0; i < vals.length-1; i++) {
                html += `<li>` +
                    `<div class="choose chooseColor_1" tabindex="0">${vals[i]}</div>` +
                    `</li>`;
            }
            $(".single").text(vals[vals.length-1]);
            $(".single").css({"background-color":"#ff7052"})
            $(".content ul").append(html);
            $(".next").append(`<div class="confirm confirm_color"><div>下一步</div></div>`);
            $(".choose").click(function () {
                if ($(this).hasClass("chooseColor_1")){
                    $(this).removeClass("chooseColor_1");
                    $(this).addClass("chooseColor_2");
                }else {
                    $(this).removeClass("chooseColor_2");
                    $(this).addClass("chooseColor_1");
                }
                changeColor();
            })

            $(".confirm").click(function () {
                let length=data.datas.list.length;
                answer=data.datas.list[index].id+":"+getText();
                transmit+="|"+answer;
                index++;
                if (getStyle2(this)["background-color"]=="rgb(255, 112, 82)"){
                    if (index==length){
                        $$.push('insurance/resultPage',{"data":encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))});
                    }
                    else {
                        $$.push('insurance/appraisalPageFirst',{"data":encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))});
                    }
                }

            })
            
            $(".single").click(function () {
                let length=data.datas.list.length;
                answer+=data.datas.list[index].id+":"+$(this).text();
                transmit+="|"+answer;
                index++;
                if (getStyle2(this)["background-color"]=="rgb(255, 112, 82)"){
                    if (index==length){
                        $$.push('insurance/resultPage',{"data":encodeURI(encodeURI(transmit))});
                    }
                    else {
                        $$.push('insurance/appraisalPageFirst',{"data":encodeURI(encodeURI(transmit)),"index":encodeURI(encodeURI(index))});
                    }
                }
            })
        }


    }

    function getStyle2(obj)
    {
        if(obj.currentStyle===undefined)
        {
            return getComputedStyle(obj);
        }else{
            return obj.currentStyle;//IE
        }
    }


    function  getText() {
        let $chose = $('.choose ');
        let count = $chose.length;
        let text = "";
        for(let i=0;i<count;i++){
            if($(".choose:eq("+i+")").hasClass('chooseColor_2')){
                text +=$(".choose:eq("+i+")").text()+",";
            }

        }
        return text;
    }


    function  changeColor() {
        let clicks=0;
        clicks++;
        let $chose = $('.choose ');
        let count = $chose.length;
        for(let i=0;i<count;i++){
            if($(".choose:eq("+i+")").hasClass('chooseColor_2')){
                $(".confirm").css({"background":"#ff7052","color":"white"});
                return;
            }else{
                $(".confirm").css({"background":"white","color":"#ff7052"});
            }

        }
    }

    function changeTopColor() {
        let $box=$(".box");
        let boxWidth=parseInt($("#box").css("width"));
        let html="";
        let width=parseInt((boxWidth)/(dataLength+1))+"px";
        for (let i=0;i<dataLength;i++){
            html+=`<div id="progressBar" class="progressBar" style="width:${width}"></div>`;
            $("#progressBar").css({"background":"white","color":"#ff7052"})
        }
        $($box).append(html);
        for (let i=0;i<=index;i++){
            $(".box").find("div").eq(i).css("background", "#ff7052");
            if (i==0){
                $(".box").find("div").eq(i).css("border-radius", "8px 0 0 8px");
            }
            if (i==dataLength){
                $(".box").find("div").eq(i).css("border-radius", "0 8px 8px 0");
            }
        }
    }

}





