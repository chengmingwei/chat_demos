window.onload = function () {
    $$.changeVersion();
    $(".box").find("span").eq(0).css("background", "#ff7052");
    $(".box").find("span").eq(1).css("background", "#ff7052");

    /*let map ={};
    map=decodeURIComponent($$.getUrlParam("map"));*/
    let data = decodeURIComponent($$.getUrlParam("data"));
    let index=decodeURIComponent($$.getUrlParam("index"))
    console.log(data)
    console.log(index)
    const age=[{label:"18岁",value:0},{label:"19岁",value:1},{label:"20岁",value:3},{label:"21岁",value:4},{label:"22岁",value:5},
        {label:"23岁",value:6},{label:"24岁",value:7},{label:"25岁",value:8},{label:"26岁",value:9},{label:"27岁",value:10},{label:"28岁",value:11},
        {label:"29岁",value:12},{label:"30岁",value:13}];
    const age1="18,19,20,21,22,23,24,25,26,27,28,29,30";
    $('.choose').on('click', function () {
        $(this).css({"background":"#ff7052","color":"white"});
        weui.picker(age, {
            onConfirm: function (result) {
                data+="age:"+result;

                console.log(data);
            },
            title: '选择你的岁数'
        });
    });
}