$(function(){
	/* 获取地址url参数 */
	let error = $$.getUrlParam("error");
	let backUrl = $$.getUrlParam("backUrl");
	let errorMsg = $$.getUrlParam("errorMsg");
	console.log(backUrl+"-"+errorMsg)
	
	if(error == 1){
		$("div[data-id=1]").show();
	}else if(error == 2){
		$("div[data-id=2]").show();
	}else if(error == 3){
		$("div[data-id=3]").show();
	}else if(error == 4){
		if(backUrl != null){
			$(".backUrl").show();
		}else if(errorMsg != null){
			$(".errorMsg").text(errorMsg);
		}
		$("div[data-id=4]").show();
	}
	
	/* 返回 事件 */
	$(".backUrl").on("click", function(){
		$$.push(backUrl);
	})
})
