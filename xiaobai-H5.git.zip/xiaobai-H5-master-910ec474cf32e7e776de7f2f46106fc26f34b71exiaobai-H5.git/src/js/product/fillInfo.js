

/**
 * 投保资料 JS
 * 加密工具 -> 【https://www.sojson.com/jjencode.html】
 * @Author 肖家添
 * @Date 2019/9/23 19:22
 */

(function(){
    $$.loaderRes({
        css: [
            "js/tool/rrweb/rrweb.min.css",
            "js/tool/rrweb/style.css"
        ],
        scripts: [
            "js/product/productVersionControl.js",
            "js/tool/lrz/lrz.bundle.js",
            `js/tool/jsencrypt.js`,
            "js/tool/rrweb/rrweb.min.js",
            "js/tool/rrweb/index.js",
            "js/tool/loki-db.js"
        ]
    });
})();

let provinceAddress;
let cityAddress ;

window.onload = function () {

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    let PAGE_STATE = {
        //-- 计划关系 0-0-0
        insuredParam: null,
        //-- 展示产品Id
        parentSellProductId: null,
        //-- 产品库Id
        productId: null,
        //-- 产品计划Id
        insurancePlanId: null,
        //-- 立即投保所需数据
        insuranceNeedData: {},
        //-- 销售产品数据源
        sellProductData: {},
        //-- 职业数据源 -> [key: 销售产品Id]
        vocationInfoData: null,
        //-- 保障期限固定一年 -> [true: 固定, false: 按销售产品]
        fixedOptionOfOneYear: false,
        //-- 职业选择 -> [true: 显示, false: 隐藏]
        occupationDisplay: false,
        //-- 险种类型
        insuranceType: null,
        //-- 被保人关系数据源
        insuredRelationshipOptions: [],
        //-- 投保资料
        insureDatums: {
            //-- 投保人信息  ``JSONObject
            insureData: null,
            //-- 被保人信息  ``JSONObject, key = cardNumber, value = data
            beInsureData: {},
            //-- 发票信息 ``JSONObject
            invoiceData: {}
        },
        //-- 编辑被保人的HTML组件
        editBeInsureInfoEle: null,
        //-- 表单数据
        formData: {
            //-- 保障期限, [销售产品标识、真实销售产品Id、起保时间、终保时间]
            guaranteePeriod: {}
        },
        //-- 家财险
        homeInsureFlag: null,
        //-- 服务端时间: [yyyy-MM-dd]
        dateStrOfNow: null,
        //-- 不重复销售产品内容
        noRepeatSellProductsData: [],
        //-- 开户银行数据源
        bankOfDeposit: [],
        //-- 自动续保: [true: 显示, null: 隐藏]  ``Boolean
        tip_showAutoRenewal: null,
        //-- 物流公司  ``JSONArray
        logisticsInfoData: [],
        //-- 出租屋 -> 物流信息  ``JSONObject
        rentingHouse_logisticsInfo: {},
        //-- 产品分享Token
        beShareToken: null,
        //-- 订单Token
        orderToken: null,
        //-- 职业Id，三个，"-"隔开
        occupationIds: null,
        //-- 历史投保资料数据
        historyBindData: null,
        //-- 微信昵称
        weChatNickName: "",
        //-- 事件日志Token
        eventLogToken: null,

        policyProvinceCode: '',	    //投保人省份代码
        policyCityCode: '',		    //投保人市代码
        insuredProvinceCode: '',	//被投保人省份代码
        insuredCityCode: '',		//被投保人市代码
        policyProvinceValue: '',	//投保人省份
        policyCityValue: '',		//投保人市
        insuredProvinceValue: '',	//被投保人省份
        insuredCityValue: '',		//被投保人市
        insuredAreaCode: '',		//被投保人市区代码
        insuredAreaValue: '',		//被投保人市区
        insuredAddress: '',		    //被投保人详细街道
        //-- 易安产品
        petType: '',		        //宠物类型（01-猫；02-犬）
        petName: '',		        //宠物品种
        petId: '',		            //宠物电子识别码（最大长度64，全数字)
        petSex: '',		            //宠物性别（01-公；02-母；03-其他）
        petAge: '',		            //宠物年龄（2月-4年）
        petAgeValue: '',		    //宠物年龄 显示的值
        petSterilisation: '',
        //-- 平安产品燃气险
        houseAddress:'',            //燃气运送地址
        steelNo:'',                 //标签
        labelNo:'',                 //钢码
        facNo:'',                   //出厂编码
        sellOrderIdNum:'',          //渠道订单号
        sellCompanyId:'',           //推销公司id
    }

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        const orderToken = $$.getUrlParam("orderToken"),
            beShareToken = $$.getUrlParam("beShareToken"),
            eventLogToken = $$.getUrlParam("eventLogToken");
        $$.validPageParams(orderToken, "product/productList");
        PAGE_STATE.beShareToken = beShareToken;
        PAGE_STATE.orderToken = orderToken;
        PAGE_STATE.eventLogToken = eventLogToken;

        //-- 用户登录状态下 显示联系人
        if($$.checkLogin()){
            $('.ins').show();
        }

        //-- 页面初始化
        pageInit();
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent(true);

        //-- 初始化页面
        initPageState();

        //-- 加载投保资料
        loadInsuranceInformation();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent(setDefaultValue = false) {

        // 保障期限 -> 打开
        $("#timeSelect").off().click(function (e) {
            $("#insuranWrap").addClass('show');
            $("#wrapBg").addClass('noMove');
            countAction('xb_3001');
        });

        // 保障期限 -> 关闭
        $("#timeCancel, .insuran-wrap .bg").off().click(function () {
            $("#insuranWrap").removeClass('show');
            $("#wrapBg").removeClass('noMove');
        });

        //-- 保障期限 -> 保存
        $("#timeSave").off().click(function(){

            //-- 设置保障期限
            setGuaranteePeriodFormData();

            //-- 保费计算
            calculationReallyInsuranceMoney({});

            //-- 设置缓存
            pageStatusHandler();

            $("#sDate").html($("#startDate").val());
            $("#eDate").html($("#endDate").val());

            $(this).prev().click();
        });

        //-- 保障项目
        $("#watchGuaranteeProject").off().click(function(){
            const { insurancePlanId } = PAGE_STATE;

            if(!$$.isValidObj(insurancePlanId)) return;
            $$.push("product/guaranteeDetail", {
                planId: insurancePlanId
            }, false);
        });

        //-- 投保人 -> 证件类型
        $(".InsureCardType").off().click(function(){
            selectIdType($(this),1);
        });
        //-- 被投保人 -> 证件类型
        $(".byInsureCardType").off().click(function(){
            selectIdType($(this),2);
        });

        //-- 投保人、被投保人 -> 出生日期
        $(".insureBirthday").off().click(function(){
            const thisEle = $(this),
                defaultValue = $Date.dateFormat(new Date()),
                startDate = new Date();
            startDate.setFullYear(startDate.getFullYear() - 90);

            weui.datePicker({
                start: startDate,
                end: new Date(),
                defaultValue: defaultValue.split("-"),
                onConfirm: function(result){
                    let dateStr = $WeChat.transferDateByWeChatSelect(result);

                    thisEle.val(dateStr);
                },
                id: "insureBirthday_picker"
            });
        });
        if(setDefaultValue){
            //-- 出生日期
            $(".insureBirthday").val($Date.dateFormat(new Date()));
        }

        //-- 投保人、被投保人 -> 性别
        $(".sexBtn").off().click(function(){
            if($(this).hasClass("choose")){
                return;
            }

            $(this).addClass("choose");
            const prev = $(this).prev();
            const next = $(this).next();

            if(prev.length > 0) prev.removeClass("choose");
            if(next.length > 0) next.removeClass("choose");
        });

        //-- 保存投保人信息
        $("#saveInsure").off().click(function(){
            savePolicyHolder();
        });

        //-- 修改投保人信息
        $("#changeInsure").off().click(function(){
            $(this).parent().hide().next().show();
            $('#insCR').show();
            $('.ins').show();
        });

        //-- 被保人关系
        $(".relaWrap").off().click(function(){
            insuredRelationship($(this));
        });

        //-- 保存被保人信息
        $(".saveBeInsure").off().click(function(){
            saveInsuredPerson();
        });

        //-- 添加新的被保人
        $(".addNewestBeInsure").off().click(function(){
            addNewestBeInsure();
        });

        //-- 关闭被保人信息填写
        $(".noSaveBeInsure").off().click(function(){
            $(".beInsureContainer").hide();
            $('#beInsCR').hide();
        });

        //-- 是否需要发票
        $(".billInput").off().click(function(){
            const val = $(this).val();
            if(val == "1"){

                //-- 是否正在编辑投保人信息
                const insureListDisplay = $("#insureList").css("display");
                if(insureListDisplay != "none"){
                    $$.throwTips("请完成投保人信息填写~");
                }

                $("#invoiceWrap_section").stop().fadeIn();
            }else{
                $("#invoiceWrap_section").stop().fadeOut();
            }

            $(".billInput").removeClass("isCheck");
            $(this).addClass("isCheck");
            const afterFirstTips = $(this).attr("data-afterFirstTips");
            if($$.isValidObj(afterFirstTips)){
                //-- 设置缓存
                pageStatusHandler();
            }
            countAction("xb_3007");
            recordEventLog("T2020071315071841369632", val);
        });

        //-- 提交订单
        $("#submitOrder").off().click(function(){
            submitOrder();
        });

        /**
         * [#readStatusChange] -> 我已经理解并同意一下投保选项
         * [#allianzMedicalCare] -> 自动续保
         */
        $("#readStatusChange, .renewalModule, #renewalInformation_section .checkbox").off().click(function(){

            const id = $(this).attr("data-tip");
            const readStatus = $(this).find(".read-status");

            switch (id) {
                case "allianzMedicalCare":{
                    allianzMedicalCare();
                    break;
                }
            }

            readStatus.toggleClass("readed");

            //-- 安联
            function allianzMedicalCare(){
                const { insureDatums: { insureData } } = PAGE_STATE;

                if(!$$.isValidObj(insureData) || Object.keys(insureData).length <= 0){
                    $$.throwTips("请先保存被保人信息~");
                }

                //-- 自动续保
                const read = readStatus.hasClass("readed");
                if(read){
                    $("#renewalInformation_section").hide();
                }else{

                    //-- 自动投保数据同步
                    dataSynchronizationOfAutoInsurance();

                    $("#renewalInformation_section").show();
                }
                recordEventLog("T2020071315072346969632", !read);
            }
        });

        //-- 自动续保 -> 帮助
        $("#allianzMedicalCare .help").off().click(function(e){
            layer.open({
                content: `
                    <div class="allianzMedicalCareHelpModal">
                        <div class="closeTips"></div>
                        <p class="title">续保注意事项说明:</p>
                        <p>1、自动续保优势：保障不间断，续保无等待期，无需健康告知</p>
                        <p>2、续保时间和保费：上一年度保单终保日前30天、7天和2天将按照《保险费率表》自动扣费，可随时取消自动续费功能，如保单退保将不再自动扣费</p>
                        <p>3、续费方式：默认续费方式以您授权开通的银行卡为准</p>
                        <p>4、生效日期：续费成功后，续保保单生效日为保单终保日次日</p>
                        <p>5、续保产品：原产品方案</p>
                        <p>6、不适用自动扣费客户：首年投保时未如实告知健康状况的客户，我司根据调查结果确认客户未如实告知投保，通过短信或邮件方式通知客户后，可单方面停止自动扣费。</p>
                    </div>
                `
            });

            //-- 阻止事件穿透
            e.stopPropagation();
        });

        //-- 自动续保 -> 帮助 -> 关闭弹窗
        $("body").on("click", ".closeTips", function(){
            layer.closeAll();
        });

        //-- 缴费信息 -> 开户银行
        $("#renewalInformation_section .renew-bank").off().click(function(){
            renewBank();
        });

        //-- 缴费信息 -> 授权
        $(".renew-bank-agree .detail .authAgreement").off().click(function(){
            layer.open({
                content: `
                    <div class="PDF_MODAL" style="width: 100%; height: ${$(window).height() * 0.9}px; position: relative; left: 0; top: 0; overflow: hidden; background-color: white;">
                        <div class="closeTips"></div>
                        <iframe src="http://imagestest.xiaobaibao.com/pdfnew/pdf.html?path=http://imagestest.xiaobaibao.com/insClause/16/05/1567741767146.pdf" width="100%" frameborder="0" style="margin-top: 30px; border-radius: 8px; overflow: hidden; height: calc(100% - 30px)" />
                    </div>
                `,
            });
            // window.open("http://images.xiaobaibao.com/insClause/16/05/1567741767146.pdf", "target");
        });

        //-- 发票专区
        (function(){

            return;

            //-- 物流选择
            $(".invoiceWrap-logistics").off().click(function(){
                let { logisticsInfoData } = PAGE_STATE;

                logisticsInfoData = logisticsInfoData.map((item, index) => {
                    const { id, logisticsName } = item;

                    return {
                        label: logisticsName,
                        value: id
                    };
                });

                weui.picker(logisticsInfoData, {
                    id: "invoiceWrap-logistics-picker",
                    container: "body",
                    defaultValue: [logisticsInfoData.length > 0 ? logisticsInfoData[0].value : null],
                    onConfirm: function (result) {
                        const { label, value } = result[0];

                        $(".invoiceWrap-logistics-val").val(label).attr("data-id", value);
                    }
                });
            });

            //-- 城市选择
            $(".invoiceWrap-area").off().click(function(){
                weui.picker(chinaArea, {
                    id: "invoiceWrap-area-picker",
                    container: "body",
                    defaultValue: [1, 1, 1],
                    onConfirm: function (result) {
                        let names = "";
                        let ids = "";

                        for(const item of result){
                            names += `${item.label} `;
                            ids += `${item.value}-`;
                        }
                        if($$.isValidObj(names)){
                            names = names.substring(0, names.length - 1);
                            ids = ids.substring(0, ids.length - 1);
                        }

                        $(".invoiceWrap-area-val").val(names).attr("data-ids", ids);
                    }
                });
            });

            //-- 保存发票
            $(".saveInvoice-btn").off().click(function(){
                saveInvoiceHandler();
            });

            //-- 修改发票
            $("#invoiceInfo .invoiceInfo-update").off().click(function(){
                $(this).parent().parent().hide().next().show();
            });
        })();

        //-- 输入焦点离开事件记录
        (function(){
            const eventInputs = [
                "#insureName",                                           // 投保人姓名
                "#insureCardNum",                                        // 投保人证件号
                "#insurePhone",                                          // 投保人手机号
                "#insureMail",                                           // 投保人邮箱
                "#companyTel",                                           // 固定电话 占用单位电话
                "#postcode",                                             // 邮政编码
                "#locationAddress",                                      // 邮编地址
                "#beInsureList .beName",                                 // 被保人姓名
                "#beInsureList .beInsureCardNum",                        // 被保人证件号
                ".renew-bank-number",                                    // 银行账号
                "#other-info-address",                                   // 其他信息
            ];
            $(eventInputs.join(",")).off().blur(function(){
                const that = $(this),
                    val = that.val(),
                    eventId = that.attr("data-eventId");
                recordEventLog(eventId, val);
            });
        })();

        //-- 地址选择弹窗
        getAddress();

        //-- 易安产品
        yianProducts();

        //-- 清空HTML源代码注释
        $$.clearHTMLNotes();
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){
        PAGE_STATE.insuredRelationshipOptions = [
            {
                label: '本人',
                value: 0
            },
            {
                label: '父母',
                value: 1
            },
            {
                label: '子女',
                value: 2
            },
            {
                label: '配偶',
                value: 3
            },
            {
                label: '抚养或赡养关系家庭成员或近亲属',
                value: 4
            },
            {
                label: '劳务关系',
                value: 5
            },
            {
                label: '其他',
                value: 6
            }
        ];

        PAGE_STATE.bankOfDeposit = [
            {
                label: '工商银行',
                value: "102"
            },
            {
                label: '中国银行',
                value: "104"
            },
            {
                label: '建设银行',
                value: "105"
            },
            {
                label: '交通银行',
                value: "301"
            },
            {
                label: '邮政储蓄银行',
                value: "403"
            },
            {
                label: '广发银行',
                value: "306"
            },
            {
                label: '兴业银行',
                value: "309"
            },
            {
                label: '光大银行',
                value: "303"
            },
            {
                label: '平安银行',
                value: "307"
            },
            {
                label: '中信银行',
                value: "302"
            },
            {
                label: '浦发银行',
                value: "310"
            },
            {
                label: '北京银行',
                value: "4031000"
            },
            {
                label: '广州银行',
                value: "4135810"
            },
            {
                label: '上海银行',
                value: "04012900"
            },
        ];
    }

    /**
     * 加载投保资料
     * @Author 肖家添
     * @Date 2019/9/23 21:17
     */
    function loadInsuranceInformation(){
        let { orderToken, editBeInsureInfoEle, beShareToken } = PAGE_STATE;

        $$.request({
            url: UrlConfig.insuranceInfo_loadInsuranceInformation,
            pars: {
                orderToken,
                beShareToken
            },
            loading: true,
            sfn: (data) => {
                $$.closeLoading();

                if(data.success){
                    responseHandler(data.datas);
                }else{
                    const error_codes = {
                        E0001: "token参数异常，请重新投保！",
                        E0002: "订单不存在！",
                        E0003: "订单已经不可修改！",
                        E0004: "当前产品已下架，请重新选择产品投保！",
                    };
                    let msg = data.msg,
                        errorMsgForCode = error_codes[msg];
                    errorMsgForCode = $$.changeIsNilVal(errorMsgForCode, msg);

                    $$.unBindAll();
                    $$.alert(errorMsgForCode, function(){
                        if(msg == "E0003"){
                            goOrderDetail();
                        }
                    });
                }
            }
        });

        //-- 响应处理 -> 投保资料
        function responseHandler(data){
            const {
                //-- 投保所需数据
                insuranceNeedData,
                //-- 产品库Id
                productId,
                //-- 产品名称
                sellProductName,
                //-- 计划Id
                insurancePlanId,
                //-- 展示产品Id
                parentSellProductId,
                //-- 订单起保时间
                order_startDate,
                //-- 订单终保时间
                order_endDate,
                //-- 订单销售产品Id
                order_sellId,
                //-- 价格计算方式为天时为true
                sell_limitIsDay,
                //-- 职业数据源
                occupationData,
                //-- 职业Ids, 以'-'隔开有三个
                order_occupationIds,
                //-- 证件类型数据源
                credentialsTypeData,
                //-- 险种类型
                insuranceType,
                //-- 家财险标识
                homeInsureFlag,
                //-- 自动续保: [true: 显示, null: 隐藏]
                tip_showAutoRenewal,
                //-- 查看保障期限: [true: 显示, null: 隐藏]
                tip_showInsureEnsure,
                //-- 服务端时间：[yyyy-MM-dd]
                dateStrOfNow,
                //-- 物流公司  ``JSONArray
                logisticsInfoData,
                //-- 出租屋物流公司  ``JSONObject
                rentingHouse_logisticsInfo,
                //-- 保险公司全称
                insuranceCompanyFullName,
                //-- 历史投保资料数据
                historyBindData,
                //-- 微信昵称
                weChatNickName,
                //-- 海外重疾关系id
                insuredParam,
                //-- 被保人证件类型数据源
                byCredentialsTypeData,
            } = data;

            const startDate = order_startDate,
                endDate = order_endDate,
                {
                    //-- 销售产品
                    sellProductInfo,
                    //-- 销售产品数据源
                    sellProductData,
                    //-- 保障期限数据源
                    guaranteePeriodData,
                    //-- 起始时间，默认为当前时间第二天，不能为空
                    startingTimeOfInsurance,
                    //-- 保障期限 -> 固定一年
                    fixedOptionOfOneYear,
                    //-- 不重复销售产品内容
                    noRepeatSellProductsData
                } = insuranceNeedData;

            PAGE_STATE = {
                ...PAGE_STATE,
                insuranceNeedData,
                sellProductData,
                fixedOptionOfOneYear,
                parentSellProductId,
                productId,
                insurancePlanId,
                vocationInfoData: occupationData,
                credentialsTypeData,
                insuranceType,
                homeInsureFlag,
                dateStrOfNow,
                noRepeatSellProductsData,
                tip_showAutoRenewal,
                logisticsInfoData,
                rentingHouse_logisticsInfo,
                occupationIds: order_occupationIds,
                historyBindData,
                weChatNickName,
                order_sellId,
                insuredParam,
                byCredentialsTypeData
            };

            $("#sDate").html(startDate);
            $("#eDate").html(endDate);
            $("#sellProductName>div").html(sellProductName);

            //-- 可选择最大的年份
            let maxSelectDate = new Date();
            maxSelectDate.setFullYear(maxSelectDate.getFullYear() + 1);
            maxSelectDate = $$.dateUtils.dateFormat(maxSelectDate, ["y", "M", "d"]);

            //-- 保障期限
            (function(){
                if(fixedOptionOfOneYear){
                    return;
                }

                let defaultSelectItem = {value: null, label: "" };
                const guaranteePeriodDataSource = guaranteePeriodData.map((item, index) => {
                    const datum = {
                        value: item.id,
                        label: item.title,
                    };

                    if((defaultSelectItem.value == null && item.limitDay && sell_limitIsDay) || item.id == order_sellId){
                        defaultSelectItem = datum;
                        setLimitPageData(defaultSelectItem);
                    }

                    return datum;
                });

                $("#limitSelect").off().on("click", function(){
                    weui.picker(guaranteePeriodDataSource, {
                        defaultValue: [defaultSelectItem.value],
                        onConfirm: function (result) {

                            setLimitPageData(result[0]);

                            premiumCalculation(true, true);
                        },
                        id: "limitSelect_picker"
                    });
                });

                //-- 设置页面参数
                function setLimitPageData(data){
                    $("#limitSelect").val(data.label).attr("data-sellId", data.value);
                }
            })();

            //-- 职业选择
            (function(){
                //-- 销售产品的职业代码，数据库的
                const sellOccupationIds = sellProductInfo.occupationIds,
                    occupationDisplay = $$.isValidObj(sellOccupationIds);

                PAGE_STATE.occupationDisplay = occupationDisplay;

                if(occupationDisplay){
                    //-- 选择的职业Ids，三个，用户选择的
                    const {
                        occupationIds
                    } = PAGE_STATE;

                    if(!$$.isValidObj(occupationIds) || occupationIds.split("-").length != 3){
                        $$.frozenPage();
                        $$.throwTips("参数错误，请重新投保！");
                    }

                    const occupationIds_Arr = occupationIds.split("-"),
                        occupationItems_Arr = new Array(),
                        loopOccupationData = function(i, datum){
                            for(let item of datum){
                                let { id, name, children } = item;

                                if(occupationIds_Arr[i] == id){

                                    occupationItems_Arr.push(id);

                                    if(i + 1 == occupationIds_Arr.length){
                                        $("#occSelect").text(name).attr("data-occupationId", id);

                                        //-- 职业编号
                                        setAZCNCode(occupationItems_Arr);

                                    }else if($$.isValidObj(children) && children.length > 0){
                                        i++;
                                        loopOccupationData(i, children);
                                    }
                                    break;
                                }
                            }
                        };

                    loopOccupationData(0, occupationData);

                    //-- 选择职业
                    $("#occSelectContainer").show().off().click(function(){
                        selectedOccupation();
                    });
                }
            })();

            //-- 产品条件
            (function(){
                if(PAGE_STATE.insuranceType != 4){
                    return;
                }

                let defaultSelectItem = {value: null, label: "" ,remark : ""};
                const noRepeatSellProductDataSource = noRepeatSellProductsData.map((item) => {
                    const datum = {
                        value: item.id,
                        label: item.title,
                        remark:item.remark
                    };

                    if(defaultSelectItem.value == null && item.id == order_sellId){
                        defaultSelectItem = datum;
                        setLimitPageData(defaultSelectItem);
                    }

                    return datum;
                });

                //如果有产品计划的改变就调用
                jQuery("#conditionSelectContainer").show().off().click(function(){
                    weui.picker(noRepeatSellProductDataSource, {
                        defaultValue: [defaultSelectItem.value],
                        onConfirm: function (result) {
                            //回调将result的里的value 获取
                            setLimitPageData(result[0]);

                            calculationReallyInsuranceMoney({
                                resetTime: true
                            });
                        },
                        id: "conditionSelectContainer_picker"
                    });
                });

                //-- 设置页面参数
                function setLimitPageData(data){
                    const sellId = data.value;
                    $("#conditionSelect").val(data.label).attr({"data-sellId": sellId, "data-remark": data.remark});

                    //产品必须等于,海外重疾页面,
                    if (productId == "100398" ) {
                        //儿童计划 || 成人计划
                        if(  data.remark == "1-0-0" || data.remark == "0-1-0" ){
                            $(".addNewestBeInsure").hide();
                        }else{
                            //夫妻计划-亲子计划-亲子增强计划（1老人）-亲子增强计划（2老人）-家庭计划-家庭增强计划（1老人）-家庭增强计划（2老人）-家庭增强计划（3老人）-家庭增强计划（4老人）
                            $(".addNewestBeInsure").show();
                        }
                        /*  if(  data.remark == "0-2-0" || data.remark == "100-1-0" ||  data.remark == "100-1-1" ||
                               data.remark == "100-1-2" || data.remark == "100-2-0" || data.remark == "100-2-1" || data.remark == "100-2-2" || data.remark == "100-2-3" || data.remark == "100-2-4" ){
                              $(".addNewestBeInsure").show();
                          }*/
                        return;
                    }
                    recordEventLog("T2020071315074541969632", sellId);
                }
            })();

            //-- 起保时间
            (function(){
                $("#startDate").off().on("click", function(){
                    if($(this).hasClass("disabled")){
                        return;
                    }

                    weui.datePicker({
                        title: "起保时间",
                        start: startingTimeOfInsurance,
                        end: maxSelectDate,
                        defaultValue: startDate.split("-"),
                        onConfirm: function (result) {
                            let dateStr = $WeChat.transferDateByWeChatSelect(result);

                            $("#startDate").val(dateStr);

                            premiumCalculation(true, true);
                        },
                        id: "startDate_picker"
                    });
                }).val(startDate);
            })();

            //-- 终保时间
            (function(){
                $("#endDate").off().on("click", function(){
                    const isEnable = $(this).hasClass("disabled");
                    if(isEnable){
                        return;
                    }

                    weui.datePicker({
                        title: "终保时间",
                        start: startingTimeOfInsurance,
                        defaultValue: endDate.split("-"),
                        end: maxSelectDate,
                        onConfirm: function (result) {
                            let dateStr = $WeChat.transferDateByWeChatSelect(result);

                            $("#endDate").val(dateStr);

                            premiumCalculation(false, true);
                        },
                        id: "endDate_picker"
                    });
                }).val(endDate);
            })();

            //-- 证件选择
            (function(){
                if(!$$.isValidObj(credentialsTypeData) || credentialsTypeData.length <= 0)
                    return;

                const { id, credentials } = credentialsTypeData[0];
               /* const { byIds, byCredentials } = byCredentialsTypeData[0];*/

                selectIdType_setLimitPageData("insureList",{label: credentials, value: id});
                selectIdType_setLimitPageData("beInsureList",{label: credentials, value: id});
             /*   selectIdType_setLimitPageData("beInsureList",{label: byCredentials, value: byIds});*/
            })();

            //-- 设置被保人编辑HTML组件
            (function () {
                const outerHTML = $("#beInsureList .beInsureContainer").prop("outerHTML");

                if($$.isValidObj(outerHTML) && !$$.isValidObj(editBeInsureInfoEle)){
                    editBeInsureInfoEle = outerHTML;
                    PAGE_STATE.editBeInsureInfoEle = outerHTML;
                }
            })();

            //-- 页面控件展示控制
            (function(){

                //-- 保障项目 按钮
                if(tip_showInsureEnsure){
                    $("#watchGuaranteeProject").show();
                }

                //-- 自动投保 按钮
                if(tip_showAutoRenewal){
                    $("#allianzMedicalCare").show();
                }
            })();

            //-- 发票处理
            (function(){
                //-- 保险公司 [太平养老保险股份有限公司深圳分公司] 无发票处理
                if(insuranceCompanyFullName == "太平养老保险股份有限公司深圳分公司"){
                    $(".bill").html("").css("height", 0);
                    return;
                }

                let goodsName = "电子发票";  // 商品名称

                /**
                 * 出租屋
                 * 100316 -> 太平财险出租屋综合保险
                 * 100329 -> 平安出租屋保险
                 * 100317 -> 太平洋财险出租屋综合保险
                 */
                if(productId == 100316 || productId == 100329 || productId == 100317){
                    goodsName = "发票+纸质保单";

                    const { name, money } = rentingHouse_logisticsInfo,
                        logisticsCost = `${name}(${parseFloat(money).toFixed(2)}元)`;

                    //-- 物流公司
                    $("#invoiceWrap_section")
                        .find(".invoiceWrap-logistics").show()
                        .find(".invoiceWrap-logistics-val").val(logisticsCost);
                    $("#invoiceWrap_section").attr("tip-rentingHouse", "true");
                }else{
                    $("#invoiceWrap_section")
                    //-- 电子邮箱
                        .find(".invoiceWrap-mail").show();
                }

                $("#invoiceWrap_section .invoice-goodsName").html(goodsName);
            })();

            //-- 读取历史页面状态
            pageStatusHandler(2);

            //-- 保费计算
            premiumCalculation(false, true);

            //-- 设置保障期限内容
            setGuaranteePeriodFormData();

            //-- 特殊处理
            specialHandling();

            //-- 订单分享
            shareOrder();

            //-- 屏幕录制
            $$.screenRecording(PAGE_STATE.eventLogToken);
        }
    }

    /**
     * 地址选择弹窗
     * @Author 吴成林
     * @Date 2020-2-17 15:28:09
     * */
    function getAddress() {
        let provinceValue = 0;
        let cityValue = 0;
        let cityDatum = new Array();
        let provinceDatum = new Array();

        /* 选择省份 */
        $('.provincesUnit').on('click', function (){
            let trigger = $(this);
            let dataId = trigger.parents("#insuredProvincesWrap").attr("data-id");

            if ($$.isValidObj(dataId) && dataId.toString() == "0"){
                return;
            }

            $("#provincesWrap").show();
            const provinceDataSource = provinceAddr();
            let html = ``;
            for(let i=0; i<provinceDataSource.length; i++){
                html += `<li class="unit" data-id="${provinceDataSource[i].value}">${provinceDataSource[i].label}</li>`;
            }
            $(".provinceListWrap>ul").html(html);

            /* 选择市区 */
            $(".provinceListWrap ul li").on('click', function (){
                let provinceCode = $(this).attr("data-id");
                let province = $(this).text();	//获取省份

                $(".provinceListWrap ul li").css("color", "black");
                $(this).css("color", "#ff7052");
                $(".cityListWrap").show();

                let id = $(this).attr("data-id");
                provinceValue = id;
                const cityDataSource = cityAddr();
                let html = ``;
                for(let i=0; i<cityDataSource.length; i++){
                    html += `<li class="unit" data-id="${cityDataSource[i].value}">${cityDataSource[i].label}</li>`;
                }
                $(".cityListWrap>ul").html(html);

                $(".cityListWrap ul li").on('click', function (){
                    let cityCode = $(this).attr("data-id");
                    let city = $(this).text();	//获取市区

                    if(trigger.parent().hasClass("insure-provinces")){
                        PAGE_STATE.policyProvinceCode = provinceCode,	//投保人省份代码
                            PAGE_STATE.policyCityCode = cityCode,		//投保人市区代码
                            PAGE_STATE.policyProvinceValue = province,	//投保人省份
                            PAGE_STATE.policyCityValue = city,		//投保人市区

                            $("#insuredProvinces").val(province==city?province:province+city);
                        $("#insuredProvinces").css("color", "#ff7052");

                    }else if(trigger.parent().hasClass("recognizee-provinces")){
                        PAGE_STATE.insuredProvinceCode = provinceCode,	//被投保人省份代码
                            PAGE_STATE.insuredCityCode = cityCode,		//被投保人市区代码
                            PAGE_STATE.insuredProvinceValue = province,	//被投保人省份
                            PAGE_STATE.insuredCityValue = city;		//被投保人市区

                        $("#beinsuredProvinces").text(province==city ? province : province+city);
                        $("#beinsuredProvinces").css("color", "#ff7052");

                    }

                    $(".cityListWrap").hide();
                    $("#provincesWrap").hide();
                });
            });

            /* 点击遮罩关闭 */
            $(".shade").on('click', function (){
                $(".cityListWrap").hide();
                $("#provincesWrap").hide();
            });
        });

        /*获取省份数据*/
        function provinceAddr() {
            provinceDatum = [];
            chinaAreas.forEach((item, index) => {
                provinceDatum.push({
                    label: item.label,
                    value: item.value
                });
            });
            return provinceDatum;
        }
        /*获取市区数据*/
        function cityAddr() {
            if (provinceValue != 0) {
                for (const item of chinaAreas) {
                    const valueOfItem = item.value;
                    if (provinceValue == valueOfItem) {
                        const children = item.children;
                        cityDatum = [];
                        children.forEach((item, value) => {
                            cityDatum.push({
                                label: item.label,
                                value: item.value
                            });
                        });
                        return cityDatum;
                    }
                }
            }
        }
    }

    /**
     * 特殊处理
     * @Author 肖家添
     * @Date 2019/9/18 14:51
     */
    function specialHandling(){
        const startDate = jQuery("#startDate");
        const endDate = jQuery("#endDate");

        const { productId, insuranceType  ,order_sellId ,insuredParam ,beShareToken} = PAGE_STATE;

        //-- 太平百万健康险限制
        (function () {
            if (productId == "100325" || productId == "100326" || productId == "100328" || productId == "100383") {

                //-- [隐藏] -> 新增被投保人按钮
                $(".addNewestBeInsure").hide();

                //-- [禁用] -> 起保、终保时间
                startDate.addClass("disabled");
                endDate.addClass("disabled");
                return;
            }
        })();




        //-- 通讯地址
        (function () {
            //-- 现代通讯地址和平安逍遥游境外产品目的地显示
            const needShowAddress = [100340, 100341, 100355, 100356, 100361];

            if(needShowAddress.indexOf(productId) != -1){
                $(".insureAddressContainer").show().attr("data-show", true);

                if(productId == 100361){
                    //-- 平安任逍遥全球计划
                    $("#insureAddressContainer .tit").html("目的地");
                    $("#insureAddressContainer #insureAddress").attr("placeholder", "请输入目的地国家或地区");
                }
            }
        })();

        //-- 邮政编码
        (function () {

            if ( productId == "100396" || productId == "100398" ) {
                //-- [显示] -> 投保人地址选择 和  邮政编码  100396是康健保的id
                $(".postcode").show();
                $(".locationAddress").show();
                locations();
            }
        })();



        //-- 固定电话,只有 永安的产品才有.
        (function () {
            if ( productId == "100396" || productId == "100398" ) {
                //-- [显示] -> 固定电话
                $(".companyTel").show();
            }
        })();


        //--平安燃气意外险的特殊数据
        (function () {
            if ( productId == "100357" ) {
                //燃气先要先按beShareToken 去请求查询数据  如果 没有数据,就返回授权失败,跳出页面
                //-- [显示] -> 燃气险特定的5个特殊数据不可编辑
                $$.request({
                    url: UrlConfig.insuranceInfo_loadThirdPartyParam,
                    pars: {
                        'shareToken':beShareToken
                    },
                    loading: true,
                    sfn: (data) => {
                        $$.closeLoading();
                        if(data.success){
                            //渲染数据, 投保人信息填充,被保人信息
                            let datas = JSON.parse(data.datas);
                            const {houseAddress,
                                steelNo,
                                labelNo,
                                facNo,
                                sellOrderIdNum,
                                name,
                                idNumber,
                                sellCompanyId
                            } = datas;
                            //填充燃气险的投保人姓名和证件号
                            $('#insureName').val(name);
                            $('#insureCardNum').val(idNumber);
                            PAGE_STATE = {
                                ...PAGE_STATE,
                                houseAddress,
                                steelNo,
                                labelNo,
                                facNo,
                                sellOrderIdNum,
                                sellCompanyId,
                            }
                            $('.houseAddress').val(houseAddress);
                            $('.steelNo').val(steelNo);
                            $('.labelNo').val(labelNo);
                            $('.facNo').val(facNo);
                            $('.sellOrderIdNum').val(sellOrderIdNum);
                        }else{
                            $$.alert("授权超时,请重新打开页面", function () {
                                window.history.go(-1);
                            });
                        }
                    }
                });
                $(".gas").show();
            }
        })();

        //-- 地址 （都会天使百万医疗）
        (function () {
            if (productId == "100383") {
                //-- [显示] -> 投保人地址选择
                $("#policyProvincesWrap").show();

                //-- [显示] -> 被保险地址选择
                $("#insuredProvincesWrap").show();
            }
        })();

        //-- 被投保人按钮
        (function(){
            //-- [意外险、家财险、健康险] [隐藏] -> 新增被投保人按钮
            if(insuranceType == 1 || insuranceType == 3 || insuranceType == 4){
                $(".addNewestBeInsure").hide();
            }
        })();

        //-- 地址 （易安宠物医疗保险）
        (function () {
            if (productId == 100392) {
                //-- [显示] 宠物产品附加选项
                $(".yianProduct").show();
                PAGE_STATE.petType = "01";              // 宠物品种默认值 （猫）
                PAGE_STATE.petSterilisation = "02";     // 宠物是否绝育默认值（否）
            }
        })();

        //-- 家财险
        homeInsureHandler();

        //特殊处理 海外重疾险
        (function () {
            if (productId == "100398" ) {
                //儿童计划 //成人计划
                if(  insuredParam == "1-0-0" || insuredParam == "0-1-0"){
                    $(".addNewestBeInsure").hide();
                }else{
                    //夫妻计划-亲子计划-亲子增强计划（1老人）-亲子增强计划（2老人）-家庭计划-家庭增强计划（1老人）-家庭增强计划（2老人）-家庭增强计划（3老人）-家庭增强计划（4老人）
                    //显示添加被保人
                    $(".addNewestBeInsure").show();
                }
                return;
            }
        })();
    }

    /**
     * 职业选择
     * @Author 肖家添
     * @Date 2019/9/17 9:56
     */
    function selectedOccupation(){
        const { vocationInfoData, occupationIds } = PAGE_STATE;

        responseHandler(vocationInfoData);

        /**
         * 职业 -> 响应处理
         * @Author 肖家添
         * @Date 2019/9/17 11:43
         */
        function responseHandler(data){
            let j = 0;
            let defaultValue = occupationIds.split("-");
            const loopChild = function(dataSource){
                return dataSource.map((item, index) => {
                    const { id, name, children } = item;
                    let dataJSON = {
                        label: name,
                        value: id
                    };

                    if($$.isValidObj(children) && children.length > 0){
                        dataJSON["children"] = loopChild(children);
                    }
                    j++;
                    return dataJSON;
                });
            }

            const pickerDataSource = loopChild(data);

            weui.picker(pickerDataSource, {
                defaultValue: defaultValue,
                onConfirm: function (result) {
                    if(result.length == 3){
                        const occIds = new Array();
                        for (let i = 0; i < result.length; i++) {
                            occIds.push(result[i].value);
                        }
                        const { value, label } = result[2];

                        $("#occSelect").text(label).attr("data-occupationId", value);

                        //-- 职业编号
                        setAZCNCode(result);

                        //-- 保费计算
                        premiumCalculation(true);

                        //-- 设置缓存
                        pageStatusHandler();

                        //-- 事件日志
                        recordEventLog("T2020071315075991369632", occIds.join(","));
                    }
                },
                id: "selectedOccupation_picker"
            });
        }
    }

    /**
     * 设置选择的职业编码
     * @Author 肖家添
     * @Date 2019/9/17 11:39
     */
    function setAZCNCode(selectedResults){
        let occupationData = PAGE_STATE.vocationInfoData;

        let loopIndex = 0;
        function loop(dataSource){
            if(!$$.isValidObj(dataSource) || dataSource.length <= 0){
                return;
            }

            for(const index in dataSource){
                const datum = dataSource[index];

                if(datum.id == selectedResults[loopIndex]){
                    loopIndex++;

                    if(loopIndex == selectedResults.length){
                        then(datum);
                        break;
                    }

                    loop(datum.children);
                }
            }
        }

        function then(result){
            if(!$$.isValidObj(result)){
                return;
            }
            const { azcnCode } = result;

            jQuery("#occSelect").attr("data-azcnCode", azcnCode);
        }

        loop(occupationData);
    }

    /**
     * 清空职业
     * @Author 肖家添
     * @Date 2019/9/17 11:41
     */
    function clearOccupation(){
        jQuery("#occSelect")
            .text("")
            .removeAttr("data-occupationId")
            .removeAttr("data-azcnCode");
    }

    /**
     * 保费计算
     * @Author 肖家添
     * @Date 2019/9/11 15:28
     */
    function premiumCalculation(resetTime = false, calculationFormVal = false){
        let {
            //-- 立即投保所需数据
            insuranceNeedData: {
                //-- 天数相关 -> Id标识
                day_tips,
                //-- 天数相关 -> 最低天数
                day_minDate,
                //-- 天数相关 -> 最大天数
                day_maxDate,
            },
            //-- 销售产品数据源
            sellProductData,
            //-- 保障期限固定一年 -> [true: 固定, false: 按销售产品]
            fixedOptionOfOneYear,
            //-- 职业选择 -> [true: 显示, false: 隐藏]
            occupationDisplay,
            formData: {
                guaranteePeriod: {
                    sellId,
                    startDate,
                    endDate
                }
            }
        } = PAGE_STATE;

        let money = 0;
        if($$.changeIsNilVal(calculationFormVal, false)){
            sellId = $("#limitSelect").attr("data-sellId"),
                startDate = $("#startDate").val(),
                endDate = $("#endDate").val();
        }

        //-- 按天数计算的标识
        $("#limitSelect").removeAttr("data-reallySellId");

        //-- 终保日期
        let newestEndDate = new Date();
        newestEndDate.setDate(newestEndDate.getDate() + 1);
        newestEndDate = $$.dateUtils.dateFormat(newestEndDate);

        if(sellId && day_tips && sellId == day_tips){
            //-- 按天数计算
            byDay();
        }else{
            //-- 按单位计算
            byCompany();
        }

        //-- 按天数计算
        function byDay(){
            $("#endDate").removeClass("disabled");

            if(resetTime){
                //-- 重置日期
                $("#startDate, #endDate").val(startDate);

                startDate = $("#startDate").val();
                endDate = $("#endDate").val();
            }

            const selectedDays = checkMinAndMaxDay(day_minDate, day_maxDate);
            for(const index in sellProductData){
                const { moneyType, minDate, maxDate, sellMoney, id } = sellProductData[index];

                if(moneyType == 0){
                    if(minDate <= selectedDays && selectedDays <= maxDate){
                        money = sellMoney;
                        $("#limitSelect").attr("data-reallySellId", id);
                        recordEventLog("T2020071315071521169632", id);
                        break;
                    }
                }
            }
        }

        //-- 按单位计算
        function byCompany(){
            if(fixedOptionOfOneYear || occupationDisplay){
                //-- [健康险、意外险] -> 职业、产品条件 选择

                if(fixedOptionOfOneYear){
                    $("#limitSelect").val("一年");

                    //-- 固定期限为一年
                    handler_MonthOrYear(3, 1);
                }

                const occupationAZCNCode = $("#occSelect").attr("data-azcncode");
                const productCondition = $("#conditionSelect").val();

                for(const index in sellProductData){
                    const sellProductDatum = sellProductData[index];
                    let { id, occupationIds, conditionContent, sellMoney } = sellProductDatum;

                    if(PAGE_STATE.insuranceType == 4){
                        if(productCondition != conditionContent){
                            continue;
                        }
                    }

                    if(occupationDisplay){
                        if($$.isValidObj(occupationIds) && $$.isValidObj(occupationAZCNCode)){
                            occupationIds = occupationIds.split("-");

                            const hasOcc = occupationIds.includes(occupationAZCNCode.toString());
                            if(!hasOcc){
                                continue;
                            }else if(PAGE_STATE.insuranceType != 4) {
                                PAGE_STATE.formData.guaranteePeriod.sellId = id;
                                recordEventLog("T2020071315071521169632", id);
                            }
                        }
                    }

                    money = sellMoney;

                    break;
                }
            }

            if(!fixedOptionOfOneYear){
                for(const index in sellProductData){
                    const sellProductDatum = sellProductData[index];

                    if(sellProductDatum.id == sellId){
                        handler(sellProductDatum);

                        break;
                    }
                }
            }

            //-- 处理
            function handler(sellProductDatum){
                const { id, moneyUnit, maxDate, sellMoney } = sellProductDatum;

                money = parseFloat(sellMoney).toFixed(2);

                switch (moneyUnit) {
                    case 1:{
                        handler_Day(sellProductDatum);
                        break;
                    }
                    case 2:
                    case 3:{
                        handler_MonthOrYear(moneyUnit, maxDate);
                        break;
                    }
                }
                recordEventLog("T2020071315071521169632", id);
            }

            //-- 按单位 -> 天
            function handler_Day(sellProductDatum){
                const {
                    id,
                    moneyType,
                    minDate,
                    maxDate,
                    sellMoney,
                    beginMoney,
                    moneyNum
                } = sellProductDatum;
                $("#endDate").removeClass("disabled");
                let selectedDays = checkMinAndMaxDay(minDate, maxDate);
                if(moneyType == 6){
                    money = beginMoney;
                    if(selectedDays > minDate){
                        selectedDays--;
                        const sell = (selectedDays - minDate) / moneyNum + 1;
                        money = sellMoney * sell + beginMoney;
                    }
                }else{
                    $("#limitSelect").attr("data-reallySellId", id);
                }
            }

            //-- 按单位 -> 月或年
            function handler_MonthOrYear(moneyUnit, maxDate){
                $("#endDate").addClass("disabled");

                if(!resetTime) return;

                const startDate_obj = new Date(startDate);

                switch (moneyUnit) {
                    case 2:{
                        startDate_obj.setMonth(startDate_obj.getMonth() + maxDate)
                        break;
                    }
                    case 3:{
                        startDate_obj.setFullYear(startDate_obj.getFullYear() + maxDate);
                        startDate_obj.setDate(startDate_obj.getDate() - 1);
                        break;
                    }
                }

                newestEndDate = $$.dateUtils.dateFormat(startDate_obj);

                $("#endDate").val(newestEndDate);
            }
        }

        //-- 检查最低、最高的天数
        function checkMinAndMaxDay(minDay, maxDay){
            const selectedDays = $$.dateUtils.dateMinus(`${startDate} 00:00:00`,  `${endDate} 23:59:59`);

            try{

                if(selectedDays < minDay){
                    throw `日期不能小于最低保障天数:${minDay}`;
                }
                if(selectedDays > maxDay){
                    throw `日期不能大于最高保障天数:${maxDay}`;
                }
            }catch (e) {
                $("#money").html(0);

                if(!resetTime){
                    $$.throwTips(e);
                }

                throw e;
            }

            return selectedDays;
        }

        $("#money, #sumMoney").html(money);

        return money;
    }


    /**
     * 选择证件类型
     * @Author 肖家添
     * @Date 2019/9/25 9:43
     * @param type 1=投保人证件类型 2=被保人证件类型
     */
    function selectIdType(e,type){
        const { credentialsTypeData,byCredentialsTypeData } = PAGE_STATE;

        if(!$$.isValidObj(credentialsTypeData))
            return;

        const baseId = e.attr("data-baseId");
        let key = e.attr("data-key");
        if(!$$.isValidObj(key)){
            key = "";
        }

        if(baseId == "beInsureList" && e.parent().parent().hasClass("disabledForOneself")){
            return;
        }

        let applyCredentialsTypeData = null;
        if (type === 1){
            applyCredentialsTypeData = credentialsTypeData;
        }else {
            applyCredentialsTypeData = byCredentialsTypeData;
        }
        let defaultValue = [];
        const pickerNeedSource = applyCredentialsTypeData.map((item, index) => {
            const dataSource = {
                label: item.credentials,
                value: item.id
            };
            if(index == 0){
                defaultValue.push(item.id);
            }
            return dataSource;
        });

        weui.picker(pickerNeedSource, {
            defaultValue: defaultValue,
            onConfirm: function (result) {
                selectIdType_setLimitPageData(baseId, result[0]);
            },
            id: `selectIdType_picker_${key}`
        });
    }

    /**
     * 证件类型 -> 设置页面参数
     * @Author 肖家添
     * @Date 2019/9/25 14:42
     */
    function selectIdType_setLimitPageData(parentId, data){

        const { label, value } = data;
        parentId = `#${parentId}`;

        const notIdCardFormItem = $(`${parentId} .notIdCardFormItem`);

        if(value == 1){
            notIdCardFormItem.hide();
        }else{
            notIdCardFormItem.show();
        }

        $(`${parentId} .insureCardType`).html(label).attr("data-id", value);
        if(parentId == "#insureList"){
            recordEventLog("T2020071315071561469632", value);
        }else{
            recordEventLog("T2020071315070485769632", value);
        }
    }

    /**
     * 保存投保人信息
     * @Author 肖家添
     * @Date 2019/9/25 9:51
     */
    function savePolicyHolder(ispPageStatusHandler = true){
        const { productId } = PAGE_STATE;

        //-- CONSTANTS START
        let insureCardType = $("#insureList .insureCardType").attr("data-id"),
            insureCardTypeLabel = $("#insureList .insureCardType").html(),    // 被保人证件类型
            insureName = $("#insureList #insureName").val(),
            insureCardNum = $("#insureList #insureCardNum").val(),
            insurePhone = $("#insureList #insurePhone").val(),
            insureMail = $("#insureList #insureMail").val(),
            insureBirthday = $("#insureList .insureBirthday").val(),
            insureSex = $("#insureList .sexBtn.choose").attr("data-id"),
            insureAddress = $("#insureAddress").val(),
            postcode = $("#postcode").val(),
            address = $("#locationAddress").val(),
            companyTel = $("#companyTel").val();
        //-- CONSTANTS END

        let datum = { insureName, insureCardNum, insurePhone, insureMail };

        const afterHandler = new Function();

        if(insureCardType === "1"){
            //-- 证件类型 -> 身份证
            afterHandler.idCardAfter = function(){

                const bindCardResult = savePersonData_bingCard("#insureList", insureCardNum);

                insureBirthday = bindCardResult.insureBirthday;
                insureSex = bindCardResult.idCardSexTypeTips;
            }
        }else{
            //-- 证件类型 -> 其他
            datum = {
                englishName: insureName,
                insureCardNum,
                insurePhone,
                insureMail
            };
        }
        savePersonData_validDatum(datum, insureCardType, insureCardNum,1 );

        //-- 证件类型 -> 身份证
        if(afterHandler.idCardAfter) afterHandler.idCardAfter();

        //-- 通讯地址
        (function () {
            const element = $(".insureAddressContainer");
            const show = element.attr("data-show");

            if(!$$.isValidObj(show)) return;
            if(!$$.isValidObj(insureAddress)){
                const tipMsg = $("#insureAddress").attr("placeholder");

                $$.throwTips(`${tipMsg}~`);
            }
        })();

        //-- 未成年处理
        (function () {
            const now_Date = new Date();
            const insureBirthday_Date = new Date($Date.iosDate(insureBirthday));
            const subYear = now_Date.getFullYear() - insureBirthday_Date.getFullYear();
            /*  if(subYear < 18 && insureCardType != "6"){
                $$.throwTips("投保人年龄必须大于18周岁");
            }
            */
            if (['3', '4', '5', '7', '10'] .indexOf (insureCardType) >= 0 && subYear < 18 ){
                $$.throwTips("投保人年龄必须大于18周岁");
            }

        })();

        //-- 邮编验证 以及 固定电话的验证
        (function () {
            const { productId } = PAGE_STATE;
            var reg= new RegExp("^[0-9]{6}$");
            var regTwo= new RegExp("^(0\\d{2,3}-)\\d{7,8}$");
            if(productId.toString() == "100396" || productId.toString() == "100398"){
                //邮箱验证非等于空$$.isValidObj(postcode) 非等于空才进入
                if($$.isValidObj(postcode)){
                    if(!reg.test(parseInt(postcode)) ){
                        $$.throwTips("邮编只能是六位数字");
                    }
                }
                $$.checkRegThrow(companyTel, regTwo, "请输入有效的固定电话！（0开头区号(2-3位)-固话(7-8位)）");
            }
        })();

        //-- 保存投保人信息
        PAGE_STATE.insureDatums.insureData = { insureCardType, insureCardTypeLabel, insureName, insureCardNum, insurePhone, insureMail, insureBirthday, insureSex, insureAddress, postcode, address,companyTel };

        //-- 被保人数据同步
        dataSynchronizationOfInsuredPersons();

        //-- 订单发票数据同步
        (function(){
            const parent = $("#invoiceWrap_section");
            parent.find(".invoiceWrap-name-val").val(insureName);   // 姓名
            parent.find(".invoiceWrap-tel-val").val(insurePhone);   // 手机
            parent.find(".invoiceWrap-mail-val").val(insureMail);   // 邮箱
        })();

        if(ispPageStatusHandler) pageStatusHandler();

        $("#insureInfo>#iName").html(insureName).next().html(insureCardNum);
        $("#insureInfo").show().next().hide();
        $('#insCR').hide();
        $('.ins').hide();
        countAction('xb_3005');
    }

    /**
     * 被保人数据同步
     * @Author 肖家添
     * @Date 2019/9/26 19:23
     */
    function dataSynchronizationOfInsuredPersons(){
        const {
            insureDatums: {
                insureData,
                beInsureData
            },
            productId
        } = PAGE_STATE;

        if(!$$.isValidObj(insureData) || !$$.isValidObj(beInsureData))
            return;

        for(const key in beInsureData){
            const item = beInsureData[key];

            if(item.relationship != "0")
                continue;

            //-- 都会天使百万医疗
            if (productId == "100383") {
                PAGE_STATE.insuredProvinceCode = PAGE_STATE.policyProvinceCode;
                PAGE_STATE.insuredCityCode = PAGE_STATE.policyCityCode;
                PAGE_STATE.insuredProvinceValue = PAGE_STATE.policyProvinceValue;
                PAGE_STATE.insuredCityValue = PAGE_STATE.policyCityValue;
            }

            const cloneKeys = ["insureName", "insureCardType", "insureCardTypeLabel", "insureCardNum", "insureBirthday", "insureSex"];
            for(const cloneKey of cloneKeys){
                item[cloneKey] = insureData[cloneKey];
            }
            PAGE_STATE.insureDatums.beInsureData[key] = item;

            const insureElements = $("#beInsureList>.beInsureSaveData>dd");

            for(let i = 0; i < insureElements.length; i++){
                const ele = insureElements[i];

                const relationship = $(ele).attr("data-relationship");

                if(relationship != "0")
                    return;

                const { insureName, insureCardNum } = insureData;

                //-- 检查产品年龄
                checkProductAgeInfo($Date.getBirthdayFromIdCard(insureCardNum));

                $(ele).find(".tit-name").html(insureName);
                $(ele).find(".val").html(insureCardNum);
            }

            break;
        }

        //-- 自动续保数据同步
        dataSynchronizationOfAutoInsurance();
    }

    /**
     * 保存被保人信息
     * @Author 肖家添
     * @Date 2019/9/25 19:09
     */
    function saveInsuredPerson(updateItemIndex){

        //-- CONSTANTS START
        let {
            //-- 投保资料
            insureDatums: {
                //-- 投保人信息
                insureData,
                //-- 被保人信息
                beInsureData
            },
            productId,
            insuredProvinceCode,    // 省份代码
            insuredProvinceValue,   // 省份
            insuredCityCode,        // 城市代码
            insuredCityValue,       // 城市
            insuredAreaCode,        // 市区代码
            insuredAreaValue,       // 市区
            insuredAddress,         // 详情地址
            petType,                // 宠物类型
            petName,                // 品种
            petId,                  // 电子识别码
            petSex,                 // 性别
            petAge,                 // 年龄
            petSterilisation,       // 绝育
        } = PAGE_STATE;

        let relationship = $("#beInsureList .relationship").attr("data-id");                // 被保人与投保人的关系

        if(relationship == "0"){
            //-- 被保人为本人，数据同步
            setBeInsureElementsValue({relationship: "0", relationshipLabel: "本人", ...insureData});
        }

        let relationshipLabel = $("#beInsureList .relationship").html(),                    // 被保人与投保人的关系
            insureName = $("#beInsureList .beName").val(),                                  // 被保人姓名
            insureCardType = $("#beInsureList .insureCardType").attr("data-id"),      // 被保人证件类型
            insureCardTypeLabel = $("#beInsureList .insureCardType").html(),                // 被保人证件类型
            insureCardNum = $("#beInsureList .beInsureCardNum").val(),                      // 被保人证件号
            insureBirthday = $("#beInsureList .insureBirthday").val(),                      // 被保人生日
            insureSex = $("#beInsureList .sexBtn.choose").attr("data-id");            // 被保人性别
        //-- CONSTANTS END
        const afterHandler = new Function();
        let datum = { insureName, insureCardNum };

        (function(){
            $$.isValidObj(insureData, "请先保存投保人信息~", true);

            if(relationship == -1){
                $$.throwTips("请选择被保人与投保人关系~");
            }
        })();

        // 易安宠物产品特殊规则
        (function () {
            if (productId == 100392) {
                if (!($$.isValidObj(insuredProvinceCode) && $$.isValidObj(insuredProvinceValue) && $$.isValidObj(insuredCityCode) && $$.isValidObj(insuredCityValue) && $$.isValidObj(insuredAreaCode) && $$.isValidObj(insuredAreaValue))){
                    $$.throwTips("请选择省市区地址~");
                } else if (!$$.isValidObj(insuredAddress)){
                    $$.throwTips("请填写详情地址~");
                } else if (!$$.isValidObj(petType)){
                    $$.throwTips("请选择宠物类型~");
                } else if (!$$.isValidObj(petName)){
                    $$.throwTips("请填写宠物品种~");
                } else if (!$$.isValidObj(petId)){
                    $$.throwTips("请填写宠物电子识别码~");
                } else if (!$$.isValidObj(petSex)){
                    $$.throwTips("请选择宠物性别~");
                } else if (!$$.isValidObj(petAge)){
                    $$.throwTips("请选择宠物年龄~");
                } else if (!$$.isValidObj(petSterilisation)){
                    $$.throwTips("请选择宠物是否绝育~");
                }
            }
        })();


        if(insureCardType == "1"){
            //-- 证件类型 -> 身份证
            afterHandler.idCardAfter = function(){
                const bindCardResult = savePersonData_bingCard("#beInsureList", insureCardNum);

                insureBirthday = bindCardResult.insureBirthday;
                insureSex = bindCardResult.idCardSexTypeTips;
            }
        }else{
            //-- 证件类型 -> 其他
            datum = {
                englishName: insureName
            };
        }

        savePersonData_validDatum(datum, insureCardType, insureCardNum, 2);

        //-- 证件类型 -> 身份证
        if(afterHandler.idCardAfter) afterHandler.idCardAfter();

        const thisKey = `${insureCardType}_${insureCardNum}`;

        //-- 被投保人数据重复校验
        (function(){
            const policyHolder_insureCardType = insureData.insureCardType;
            const policyHolder_insureCardNum = insureData.insureCardNum;

            //-- 关系选择器非本人、被保人[证件类型、证件号] 等于 投保人[证件类型、证件号]
            if(relationship != 0 && insureCardType == policyHolder_insureCardType && insureCardNum == policyHolder_insureCardNum){
                $$.throwTips("该被保人信息与投保人相同，关系必须为“本人”");
            }

            let index = 0;
            const newestArray = {};
            for(let key in beInsureData){
                let item = beInsureData[key];
                const { insureCardType, insureCardNum } = item;
                const forKey = `${insureCardType}_${insureCardNum}`;

                if(forKey == thisKey && updateItemIndex != index){
                    $$.throwTips("被保人已存在~");
                }else if($$.isValidObj(updateItemIndex) && updateItemIndex == index){
                    key = thisKey;
                }

                newestArray[key] = item;
                index++;
            }

            //-- 防止顺序混乱
            beInsureData = newestArray;
        })();

        //-- 产品年龄信息校验
        const beInsureBirthday = $("#beInsureList .insureBirthday").val();
        checkProductAgeInfo(beInsureBirthday);

        //-- 保存被投保人信息
        beInsureData[thisKey] = {
            relationship, relationshipLabel, insureCardType, insureCardTypeLabel, insureName, insureCardNum, insureBirthday, insureSex
        };
        PAGE_STATE.insureDatums.beInsureData = beInsureData;

        generateBeInsureElements();
        pageStatusHandler();
        countAction('xb_3006');
    }

    /**
     * 生成被保人组件
     * @Author 肖家添
     * @Date 2019/9/26 9:34
     */
    function generateBeInsureElements(){
        let {
            insureDatums: {
                beInsureData
            },
            editBeInsureInfoEle
        } = PAGE_STATE;

        const beInsureSaveData = $("#beInsureList>.beInsureSaveData");
        let beInsureContainer = $("#beInsureList .beInsureContainer");

        const beInsureDataLength = Object.keys(beInsureData).length;
        if(beInsureDataLength > 0){
            let html = "";
            let i = 0;
            for(const key in beInsureData){
                const item = beInsureData[key];

                html += `
                    <dd class="wrap2" data-relationship="${item.relationship}">
                        <div class="m-parent beInsure-info clearfix wrap2" style="display: block; transform-origin: 0px 0px; opacity: 1; transform: scale(1, 1);">
                            <div class="tit fl">
                                <span class="num">${beInsureDataLength > 1 ? ((i + 1) + ".") : ""}</span>
                                <span class="tit-name">${item.insureName}</span>
                            </div>
                            <div class="val fl">${item.insureCardNum}</div>
                            <div class="text-btn fl" data-key="${key}" data-index="${i}">
                                <a href="javascript:;" class="del">删除</a>
                                &nbsp;
                                <a href="javascript:;" class="bChange">修改</a>
                                <a href="javascript:;" class="bFinish" style="display: none;">保存</a>
                            </div>
                        </div>
                    </dd>
                `;

                i++;
            }

            beInsureSaveData.html(html).show();
            beInsureContainer.hide();
            $('#beInsCR').hide();

            //-- 删除
            $(".beInsure-info .del").off().on("click", function(){

                valid_editing();

                $$.confirm({
                    title: "真的要删除该被保人？",
                    onOkLabel: "狠心删掉",
                    onCancelLabel: "再看看",
                    onOk: onOk
                });

                const key = $(this).parent().attr("data-key");

                function onOk(){
                    delete PAGE_STATE.insureDatums.beInsureData[key];
                    $(".noSaveBeInsure").hide();

                    //-- 易安 宠物产品
                    if (productId == 100392) {
                        //-- [显示] 宠物产品附加选项
                        $(".yianProduct").show();
                        PAGE_STATE.petType = "01";              // 宠物品种默认值 （猫）
                        PAGE_STATE.petSterilisation = "02";     // 宠物是否绝育默认值（否）
                        PAGE_STATE.petName = "";
                        PAGE_STATE.petId = "";
                        PAGE_STATE.petSex = "";
                        PAGE_STATE.petAge = "";
                        PAGE_STATE.petAgeValue = "";

                        // 地址
                        PAGE_STATE.insuredProvinceCode = "";
                        PAGE_STATE.insuredProvinceValue = "";
                        PAGE_STATE.insuredCityCode = "";
                        PAGE_STATE.insuredCityValue = "";
                        PAGE_STATE.insuredAreaCode = "";
                        PAGE_STATE.insuredAreaValue = "";
                        PAGE_STATE.insuredAddress = "";
                    }

                    setBeInsureElementsValue({});
                    generateBeInsureElements();
                    pageStatusHandler();
                }

                const {productId} = PAGE_STATE;
                if (productId == "100383") {
                    //-- [显示] -> 被保险地址选择
                    $("#insuredProvincesWrap").show();
                }
            });

            //-- 修改
            $(".beInsure-info .bChange").off().on("click", function(){
                $(".gas").show();
                valid_editing();

                const thisCtx = this,
                    key = $(thisCtx).parent().attr("data-key"),
                    beInsureDatum = PAGE_STATE.insureDatums.beInsureData[key],
                    beInsureContainer = $("#beInsureList .beInsureContainer");

                (function(){
                    const parentContainer = $(thisCtx).parent().parent().parent();

                    beInsureContainer.remove();
                    parentContainer.after(editBeInsureInfoEle);

                    $("#beInsureList .relaWrap, #beInsureList .beInsureIdType").attr("data-key", key);
                    $(".noSaveBeInsure").hide();

                    bindEvent();
                })();

                setBeInsureElementsValue(beInsureDatum);

                $(thisCtx).hide().next().show();
                $(".saveBeInsure").parent().hide();
                $("#beInsureList .beInsureContainer").show();
                const relationship = $("#beInsureList .relationship").attr("data-id");
                if(relationship != "0"){
                    $('#beInsCR').show();
                }

                const {productId} = PAGE_STATE;
                if (productId == "100383") {
                    //-- [显示] -> 被保险地址选择
                    $("#insuredProvincesWrap").show();
                }

                //平安燃气意外险显示被保人的相关信息
                if (productId == "100357") {
                    const {houseAddress,
                        steelNo,
                        labelNo,
                        facNo,
                        sellOrderIdNum,
                    } = PAGE_STATE;
                    $('.houseAddress').val(houseAddress);
                    $('.steelNo').val(steelNo);
                    $('.labelNo').val(labelNo);
                    $('.facNo').val(facNo);
                    $('.sellOrderIdNum').val(sellOrderIdNum);
                    $(".gas").show();
                }

                if (productId == 100392) {
                    //-- [显示] 宠物产品附加选项
                    $(".yianProduct").show();
                }
            });

            //-- 保存
            $(".beInsure-info .bFinish").off().on("click", function(){
                const updateItemIndex = $(this).parent().attr("data-index");
                saveInsuredPerson(updateItemIndex);

                $("#beInsureList").append(editBeInsureInfoEle).find(".beInsureContainer").hide();

                bindEvent();

                $(".saveBeInsure").parent().show();
                $("#beInsureList .relaWrap, #beInsureList .beInsureIdType").removeAttr("data-key");
            });

            //-- 验证是否正在编辑被保人
            function valid_editing(){
                validation_editingBeInsureInfo();
            }
        }else{
            beInsureSaveData.hide();
            beInsureContainer.show();
            $('#beInsCR').show();
        }

        //-- 保费计算
        calculationReallyInsuranceMoney({});
    }

    /**
     * [被投保人] -> 设置编辑表单参数
     * @Author 肖家添
     * @Date 2019/9/26 10:12
     */
    function setBeInsureElementsValue({relationship, relationshipLabel, insureCardType = 1, insureCardTypeLabel = "身份证", insureName = "", insureCardNum = "", insureBirthday = $Date.dateFormat(new Date()), insureSex = "boy"}){
        //-- 关系
        if(!$$.isValidObj(relationshipLabel)){
            relationship = "-1";
            relationshipLabel = "被保人是投保人的";
        }
        const relationshipEle = $("#beInsureList .relationship").html(relationshipLabel).attr("data-id", relationship);
        if(relationship == "-1"){
            relationshipEle.removeClass("active");
        }else relationshipEle.addClass("active");

        if(relationship == "0"){
            //-- 被保人关系为[本人], 禁用表单
            insuredRelationship_setOneselfDisabled();
        }

        //-- 证件类型
        selectIdType_setLimitPageData("beInsureList", {value: insureCardType, label: insureCardTypeLabel});

        //-- 生日和性别
        if(insureCardType == 1){
            savePersonData_bingCard("#beInsureList", insureCardNum);
        }

        $("#beInsureList .beName").val(insureName);
        $("#beInsureList .beInsureCardNum").val(insureCardNum);
        $("#beInsureList .insureBirthday").val(insureBirthday);
        $(`#beInsureList .sexBtn`).removeClass("choose");
        $(`#beInsureList .sexBtn[data-id="${insureSex}"]`).addClass("choose");

        const {productId} = PAGE_STATE;
        //-- 都会天使百万医疗
        if (productId == "100383") {
            PAGE_STATE.insuredProvinceCode = PAGE_STATE.policyProvinceCode;
            PAGE_STATE.insuredCityCode = PAGE_STATE.policyCityCode;
            PAGE_STATE.insuredProvinceValue = PAGE_STATE.policyProvinceValue;
            PAGE_STATE.insuredCityValue = PAGE_STATE.policyCityValue;

            const {policyProvinceValue, policyCityValue} = PAGE_STATE;
            if ($$.isValidObj(policyProvinceValue) && $$.isValidObj(policyCityValue)){
                $("#beinsuredProvinces").text(policyProvinceValue==policyCityValue ? policyProvinceValue : policyProvinceValue+policyCityValue);
                $("#beinsuredProvinces").css("color", "#ff7052");
            }

        }

        //-- 易安 宠物产品
        if (productId == 100392) {
            const {insuredProvinceValue,       // 省份
                insuredCityValue,           // 城市
                insuredAreaValue,           // 市区
                insuredAddress,             // 详情地址
                petType,                    // 宠物类型
                petName,                    // 品种
                petId,                      // 电子标识码
                petSex,                     // 性别
                petAge,                     // 年龄
                petAgeValue,                // 年龄中文
                petSterilisation,           // 绝育
            } = PAGE_STATE;
            if ($$.isValidObj(insuredProvinceValue) &&
                $$.isValidObj(insuredCityValue) &&
                $$.isValidObj(insuredAreaValue) &&
                $$.isValidObj(insuredAddress) &&
                $$.isValidObj(petType) &&
                $$.isValidObj(petName) &&
                $$.isValidObj(petId) &&
                $$.isValidObj(petSex) &&
                $$.isValidObj(petAge) &&
                $$.isValidObj(petSterilisation)
            ) {
                $("#beInsureList #petInsuredProvinces").text(insuredProvinceValue +" "+ insuredCityValue +" "+ insuredAreaValue).addClass('active');
                $("#beInsureList .insuredAddress").val(insuredAddress).addClass('active');
                $(".petInsuredAddress").show();
                $('.petType input').removeClass('isCheck');
                if (petType == '01'){
                    $('.petType').children('label:nth-child(2)').children('input').addClass("isCheck");
                } else {
                    $('.petType').children('label:nth-child(3)').children('input').addClass("isCheck");
                }
                $('#beInsureList #petName').val(petName);                      // 品种
                $('#beInsureList #petId').val(petId);                          // 电子标识码
                $("#beInsureList #petSex").text(petSex == '01'?'公':(petSex == '02'?'母':'其他')).addClass('active');
                $("#beInsureList #petAge").text(petAgeValue).addClass('active');
                $('.petSterilisation input').removeClass('isCheck');
                if (petSterilisation == '01'){
                    $('.petSterilisation').children('label:nth-child(2)').children('input').addClass("isCheck");
                } else {
                    $('.petSterilisation').children('label:nth-child(3)').children('input').addClass("isCheck");
                }
            }
        }
    }

    /**
     * [编辑投保人、被投保人] -> 根据证件号绑定数据、验证数据
     *
     * parentId: 父级元素Id
     * insureCardNum: 证件号码
     *
     * @Author 肖家添
     * @Date 2019/9/25 19:43
     */
    function savePersonData_bingCard(parentId, insureCardNum){
        const { productId } = PAGE_STATE;

        //-- 身份证性别类型 [1: 男, 0: 女]
        const idCardSexType = parseInt(insureCardNum.substr(16, 1)) % 2;

        //-- 设置身份证出生年月
        const insureBirthday = $Date.getBirthdayFromIdCard(insureCardNum);
        $(`${parentId} .insureBirthday`).val(insureBirthday);

        //-- 选中男/女
        const idCardSexTypeTips = idCardSexType == 0 ? 'girl' : 'boy';
        $(`${parentId} .sexBtn[data-id="${idCardSexTypeTips}"]`).click();
        // PAGE_STATE.insureDatums[parentId == "#insureList" ? "insureData" : "beInsureData"].insureSex = idCardSexTypeTips;

        //-- 针对女性（安联百万玫瑰、乐享人生女性保障、平安女神、史带爱家庭女性）
        const needFilterPds = [100370, 100203, 100220, 100206];
        if(needFilterPds.indexOf(productId) != -1){
            if(idCardSexType == 1){
                $$.throwTips("该产品只针对女性~");
            }
        }

        return { idCardSexType, idCardSexTypeTips, insureBirthday };
    }

    /**
     * [编辑投保人、被投保人] -> 验证数据
     *
     * insureCardType: 证件类型
     * insureCardNum: 证件号码
     * handlerType: [1: 投保人, 2: 被保人]
     *
     * @Author 肖家添
     * @Date 2019/9/25 20:02
     */
    function savePersonData_validDatum(datum, insureCardType, insureCardNum, handlerType = 1){
        let prefix = "投保人";
        if(handlerType == 2){
            prefix = "被保人";
        }
        for(const key in datum){
            console.log(datum)
            let type;
            let msg;
            switch (key) {
                case 'insureName':
                    type = "中文姓名";
                    msg = "姓名格式不正确~";
                    break;
                case 'englishName':
                    type = "英文姓名";
                    msg = "姓名格式不正确~";
                    break;
                case 'insureCardNum':
                    type = "身份证号码";
                    msg = "身份证号码格式有误~";
                    break;
                case 'insurePhone':
                    type = "手机号码";
                    msg = "手机号码格式不正确~";
                    break;
                case 'insureMail':
                    type = "邮箱";
                    msg = "电子邮箱格式不正确~";
                    break;
                default:
                    break;
            }

           /* if(key == "insureCardNum" && insureCardType != "1"){
                //-- 证件类型非身份证
                $$.isValidObj(insureCardNum, "证件号不能为空", true);

                if(!$Reg.numAndLetterAndBracketsReg.test(insureCardNum)){
                    $$.throwTips("证件号只能是数字、字母、括号");
                }
                break;
            }*/

            function expand_check(Reg,num,error) {
                if(!Reg.test(num)){
                    $$.throwTips(error);
                }
            }
            //-- 证件扩张验证
            if (insureCardType !== "1"){
                switch (insureCardType) {
                    case "3":
                        expand_check($Reg.cPassportReg,insureCardNum,"中国护照格式不合法!!");
                        break;
                    case "10":
                        expand_check($Reg.wPassportReg,insureCardNum,"外国护照格式不合法!");
                        break;
                    case "7":
                        expand_check($Reg.birthCardReg,insureCardNum,"出生证格式不合法!");
                        break;
                    case "5":
                        expand_check($Reg.homeReg,insureCardNum,"港澳台通行证、回乡证格式不合法!");
                        break;
                    case "6":
                        expand_check($Reg.creditReg,insureCardNum,"统一社会信用代码格式不合法！");
                        break;
                    case "11":
                        expand_check($Reg.tissueReg,insureCardNum,"组织机构代码证格式不合法！");
                        break;
                    case "12":
                        expand_check($Reg.taxReg,insureCardNum,"税务登记号格式不合法！");
                        break;
                    case "13":
                        expand_check($Reg.businessReg,insureCardNum,"营业执照格式不合法！");
                        break;
                }
                return false;
            }

            const checkMsg = new $Valid.validComment({
                "type": type,
                "isEmpty": false,
                "value": datum[key],
                "errorMsg": prefix + msg
            }).check();

            if(checkMsg != true){
                $$.throwTips(checkMsg);
            }
        }
    }

    /**
     * [被保人关系] -> 选择器
     * @Author 肖家添
     * @Date 2019/9/25 19:10
     */
    function insuredRelationship(e){
        const { productId } = PAGE_STATE;

        //-- 安盛百万医疗/都会天使百万医疗
        if (productId == 100375 || productId == 100376 || productId == 100377 || productId == 100378 || productId == 100383 ) {
            PAGE_STATE.insuredRelationshipOptions = [
                {
                    label: '本人',
                    value: 0
                },
                {
                    label: '父母（不含配偶父母）',
                    value: 1
                },
                {
                    label: '子女',
                    value: 2
                }
            ];
        }
        if (productId == 100380 || productId == 100381 || productId == 100398) {
            PAGE_STATE.insuredRelationshipOptions = [
                {
                    label: '本人',
                    value: 0
                },
                {
                    label: '父母（包括配偶的父母）',
                    value: 1
                },
                {
                    label: '子女',
                    value: 2
                },
                {
                    label: '配偶',
                    value: 3
                }
            ];
        }
        if (productId == 100388 || productId == 100392 ) {
            PAGE_STATE.insuredRelationshipOptions = [
                {
                    label: '本人',
                    value: 0
                }
            ];
        }

        const { insureDatums: { insureData, beInsureData }, insuredRelationshipOptions } = PAGE_STATE;

        let defaultVal = 0;
        let dataKey = e.attr("data-key");
        dataKey = $$.changeIsNilVal(dataKey, "");

        //-- 被保人有选中[本人]时, 禁用[本人]选项处理
        (function(){
            const relationship = $$.isValidObj(dataKey) ? beInsureData[dataKey].relationship : null;

            if(relationship == "0"){
                insuredRelationshipOptions[0].disabled = false;
                return;
            }

            for(const key in beInsureData){
                const item = beInsureData[key];

                if(item.relationship == "0"){
                    defaultVal = 1;
                    insuredRelationshipOptions[0].disabled = true;
                    dataKey = $$.getTimeStampNow();
                    break;
                }
            }

            if(defaultVal == 0){
                insuredRelationshipOptions[0].disabled = false;
            }
        })();

        weui.picker(insuredRelationshipOptions, {
            defaultValue: [defaultVal],
            onConfirm: function (result) {

                const { label, value } = result[0];

                //-- 证件类型为：本人，将投保人数据设置到被保人
                if(value == 0){
                    $('#beInsCR').hide();
                    $('.btnRight>.beIns').hide();
                    if($$.isValidObj(insureData)){
                        setBeInsureElementsValue(insureData);

                        insuredRelationship_setOneselfDisabled();
                    }
                }else{
                    $('#beInsCR').show();
                    $('.btnRight>.beIns').show();
                    insuredRelationship_removeOneselfDisabled();

                    const relationship = $("#beInsureList .relationship").attr("data-id");
                    if(relationship == "0"){
                        setBeInsureElementsValue({});
                    }
                }

                $("#beInsureList .relationship").html(label).attr("data-id", value).addClass("active");
                recordEventLog("T2020071315075991269632", value);
            },
            id: `insuredRelationship_picker_${dataKey}`
        });
    }

    /**
     * [被保人关系] -> 本人则禁用表单
     * @Author 肖家添
     * @Date 2019/9/26 19:21
     */
    function insuredRelationship_setOneselfDisabled(){
        const beInsureContainer = $(".beInsureContainer");

        beInsureContainer.addClass("disabledForOneself").find("input[tip-readonly]").attr("readonly", "readonly");
        beInsureContainer.find(".insureBirthday, .sexBtn").off();

        const {productId} = PAGE_STATE;
        if (productId == "100383") {
            $("#insuredProvincesWrap").addClass("beAddressType").attr("data-id", 0);
        }
    }

    /**
     * [被保人关系] -> 表单解禁
     * @Author 肖家添
     * @Date 2019/9/26 19:21
     */
    function insuredRelationship_removeOneselfDisabled(){
        const beInsureContainer = $(".beInsureContainer");

        beInsureContainer.removeClass("disabledForOneself").find("input[tip-readonly]").removeAttr("readonly", "readonly");

        const {productId} = PAGE_STATE;
        if (productId == "100383") {
            $("#insuredProvincesWrap").removeClass("beAddressType").attr("data-id", 1);
        }
        bindEvent();
    }

    /**
     * 验证是否正在编辑被保人信息
     * @Author 肖家添
     * @Date 2019/9/26 15:30
     */
    function validation_editingBeInsureInfo(){
        const beInsureContainer = $("#beInsureList .beInsureContainer");

        if(beInsureContainer.css("display") != "none"){
            $$.throwTips("请先保存正在填写的被保人信息~");
        }

        return beInsureContainer;
    }

    /**
     * 添加新的被保人
     * @Author 肖家添
     * @Date 2019/9/26 15:27
     */
    function addNewestBeInsure(){
        validation_editingBeInsureInfo().show();
        insuredRelationship_removeOneselfDisabled();
        setBeInsureElementsValue({});

        $(".noSaveBeInsure").show();
        $('#beInsCR').show();
    }

    /**
     * 设置保障期限内容
     * @Author 肖家添
     * @Date 2019/9/26 21:34
     */
    function setGuaranteePeriodFormData(){
        const sellId = $("#limitSelect").attr("data-sellId"),
            reallySellId = $("#limitSelect").attr("data-reallySellId"),
            startDate = $("#startDate").val(),
            endDate = $("#endDate").val();

        PAGE_STATE.formData.guaranteePeriod = { sellId, reallySellId, startDate, endDate };
    }

    /**
     * 家财险处理
     * @Author 肖家添
     * @Date 2019/9/27 15:46
     */
    function homeInsureHandler(){
        const { homeInsureFlag } = PAGE_STATE;

        switch (homeInsureFlag) {
            //-- 太平洋财险-深圳分
            case "cpic":
            //-- 平安财东莞分
            case "pa":{
                cpicInit();
                break;
            }
            //-- 新疆前海联合财险广东分
            case "qhgd":{
                $("#otherInfoSection").show();
                $(".other-read-info").hide();
                break;
            }
            default:{
                $("#otherInfoSection").hide();
                return;
            }
        }

        //-- 太平洋出租屋初始
        function cpicInit(){
            const readContent = "1、本产品承保广东地区出租屋。<br>2、贵公司所提供的投保已附保险条款，已对保险合同的条款内容履行了说明义务，并对免除保险人责任的条款履行了提供和明确说明义务。本人所填投保单各项及告知事项均属实并确无欺瞒。上述一切陈诉及本声明将成为贵公司承保的依据，并作为保险合同一部分。如有不实告知，贵公司有权在法定期限内接触合同，并依法决定是否对合同解除前发生的保险事故承担保险责任。<br>3、本人谨此授权凡知道或拥有任何有关本人健康及其它情况的任何医生、医院、保险公司、其它机构或人士，均可将有关资料提供给贵公司。此授权书的影印本也同样有效。";
            $("#otherRead").html(readContent);
            $("#otherInfoSection").show();
        }
    }

    /**
     * 检查产品年龄信息
     *
     * beInsureBirthday: 被保人生日
     *
     * @Author 肖家添
     * @Date 2019/9/29
     */
    function checkProductAgeInfo(beInsureBirthday ){
        //-- CONSTANT START
        const {
            //-- 服务端时间: [yyyy-MM-dd]
            dateStrOfNow,
            insuranceNeedData: {
                //-- 完整销售产品
                fullSellProductData
            },
            formData
        } = PAGE_STATE;
        const { reallySellId } = formData.guaranteePeriod,
            guaranteePeriod = formData.guaranteePeriod.sellId,
            productCondition = $("#conditionSelect").attr("data-sellId");
        let selectedSellId;
        if(PAGE_STATE.insuranceType == 4){
            selectedSellId = productCondition;
        }else{
            if($$.isValidObj(reallySellId)){
                selectedSellId = reallySellId;
            }else{
                selectedSellId = guaranteePeriod;
            }
        }
        //-- CONSTANT END
        fullSellProductData.forEach((item) => {
            if(item.id == selectedSellId){
                then(item);
            }
        });

        function then(sellData) {
            const {
                planMinAge,
                planMinAgeType,
                planMaxAge,
                planMaxAgeType
            } = sellData;

            if(planMaxAge == 0) return;

            //-- 日期转换
            const transferDate = function(dateStr){
                const dateArr = dateStr.split("-");
                const date = new Date();
                date.setFullYear(dateArr[0], dateArr[1] -1, dateArr[2]);

                return date;
            }

            //-- 当前时间
            const today = transferDate(dateStrOfNow);
            //-- 被保人生日
            const birthday = transferDate(beInsureBirthday);
            //-- 间隔天数
            const spacingDay = parseInt((Math.abs(today - birthday) / 1000 / 60 / 60 / 24) + "");
            //-- 间隔周岁
            const age = $Date.getAgesByDateStr(today, beInsureBirthday);

            let companyMin = "天",companyMax = "天";
            let number = spacingDay;
            if(planMinAgeType == 0){
                companyMin = "周岁";
                number = age;
            }
            if(number < planMinAge){
                if(PAGE_STATE.productId == "100398"  || PAGE_STATE.productId == "100396"){
                    $$.throwTips(`被保人年龄必须${planMinAge}${companyMin}≤被保险人年龄≤${planMaxAge}${companyMax}（含）`);
                }else{
                    $$.throwTips(`被保人年龄必须大于等于${planMinAge}${companyMin}`);
                }
            }
            if(planMaxAgeType == 0){
                companyMax = "周岁";
                number = age;
            }else{
                number = spacingDay;
            }
            if(number > planMaxAge){
                if(PAGE_STATE.productId == "100398" || PAGE_STATE.productId == "100396"){
                    $$.throwTips(`被保人年龄必须${planMinAge}${companyMin}≤被保险人年龄≤${planMaxAge}${companyMax}（含）`);
                }else{
                    $$.throwTips(`被保人年龄必须小于等于${planMaxAge}${companyMax}`);
                }
            }
            //大都会产品特殊规则
            if(PAGE_STATE.productId == "100383"){
                let relationship = $("#beInsureList .relationship").attr("data-id");
                if(relationship == '2' && number > 17){
                    $$.throwTips(`只能为18周岁以下的子女投保`);
                }
            }

            if(PAGE_STATE.productId == "100398"){
                //成人计划是 被保人关系是2子女时,可以给  成年的子女买,,,,,其他计划子女都不能年满18
                let relationship = $("#beInsureList .relationship").attr("data-id");
                let remark = $("#conditionSelect").attr("data-remark");
                if(relationship == '2'  &&  number > 17 && remark != "0-1-0"){
                    $$.throwTips(`只能为18周岁以下的子女投保`);
                }
            }
        }
    }

    /**
     * 缴费信息 -> 开户银行
     * @Author 肖家添
     * @Date 2019/9/29 15:44
     */
    function renewBank(){
        const { bankOfDeposit } = PAGE_STATE;
        let defaultVal = [];
        if($$.isValidObj(bankOfDeposit) && bankOfDeposit.length > 0){
            defaultVal.push(bankOfDeposit[0].value);
        }

        weui.picker(bankOfDeposit, {
            defaultValue: defaultVal,
            onConfirm: function (result) {

                const { label, value } = result[0];

                $("#renewalInformation_section .renew-bank-label").html(label).attr("data-id", value).addClass("active");
                recordEventLog("T2020071315074427769632", value);
            },
            id: `insuredRelationship_picker_renewBank`
        });
    }

    /**
     * 自动投保持卡人数据同步
     * @Author 肖家添
     * @Date 2019/9/29 18:24
     */
    function dataSynchronizationOfAutoInsurance(){
        const {
            insureDatums: {
                insureData: {
                    insureName
                }
            }
        } = PAGE_STATE;

        $("#renewalInformation_section").find(".renew-bank-insureName").val(insureName);
        recordEventLog("T2020071315073040469632", insureName);
    }

    /**
     * 提交订单
     * @Author 肖家添
     * @Date 2019/9/27 10:54
     */
    function submitOrder(){

        const {
            //-- 产品库Id
            productId,
            //-- 投保资料
            insureDatums: {
                //-- 投保人信息  ``JSONObject
                insureData,
                //-- 被保人信息  ``JSONObject, key = cardNumber, value = data
                beInsureData
            },
            //-- 保障期限固定一年 -> [true: 固定, false: 按销售产品]
            fixedOptionOfOneYear,
            //-- 职业选择 -> [true: 显示, false: 隐藏]
            occupationDisplay,
            //-- 自动续保: [true: 显示, null: 隐藏]
            tip_showAutoRenewal,
            formData,
            //-- 分享Token
            beShareToken,
            //-- 订单Token
            orderToken
        } = PAGE_STATE;

        const { startDate, endDate, reallySellId } = formData.guaranteePeriod,
            guaranteePeriod = formData.guaranteePeriod.sellId;

        const occSelect = $("#occSelect").attr("data-occupationId"),
            //-- 产品条件
            productCondition = $("#conditionSelect").attr("data-sellId"),
            //-- 自动续保: [true: 需要, null or false: 无需]
            needAutoRenewal = $("#allianzMedicalCare>.renewalModule .read-status").hasClass("readed"),
            //-- 自动续保 -> 开户行Id
            autoRenewal_bank = $("#renewalInformation_section .renew-bank-label").attr("data-id"),
            //-- 自动续保 -> 开户行
            autoRenewal_bankName = $("#renewalInformation_section .renew-bank-label").html(),
            //-- 自动续保 -> 银行卡号
            autoRenewal_bankNumber = $("#renewalInformation_section .renew-bank-number").val(),
            //-- 自动续保 -> 协议条款 -> [true: 同意, null or false: 不同意]
            autoRenewal_agree = $("#renewalInformation_section .read-status").hasClass("readed"),
            //-- 其他信息 -> 通信地址
            otherInfoAddress = $("#other-info-address").val(),
            //-- 其他信息 -> 投保事项 -> [true: 同意, null or false: 不同意]
            otherInfo_agree = $("#otherInfoSection .read-status").hasClass("readed"),
            //-- 是否正在编辑投保人信息
            insureListDisplay = $("#insureList").css("display"),
            //-- 需要发票
            needInvoices = $(".bill input[name=needInvoices]:checked").val(),
            //-- 产品计划关系判断
            remark = $("#conditionSelect").attr("data-remark")

        const params = {
            //-- 订单Token
            orderToken,
            //-- 如果固定一年则是产品条件，否则是产品期限
            sellProductId: PAGE_STATE.insuranceType == 4 ? productCondition : guaranteePeriod,
            //-- 起保时间
            startDate,
            //-- 终保时间
            endDate,
            //-- 分享Token
            beShareToken
        };

        const extendLists = [];

        //-- 数据校验
        (function(){
            !fixedOptionOfOneYear && $$.isValidObjThrow(guaranteePeriod, "请选择保障期限");
            $$.isValidObjThrow(startDate, "请选择起保时间");
            $$.isValidObjThrow(endDate, "请选择终保时间");
            $$.isValidObjThrow(insureData, "请保存投保人信息~");

            if(insureListDisplay != "none"){
                $$.throwTips("请完成投保人信息填写~");
            }

            if($(".beInsureContainer").css("display") != "none"){
                $$.throwTips("请完成被保人信息填写~");
            }
            if(Object.keys(beInsureData).length <= 0){
                $$.throwTips("请保存被保人信息~");
            }

            //-- 职业
            if(occupationDisplay)
                $$.isValidObjThrow(occSelect, "请选择职业~");

            //-- 产品条件
            if(PAGE_STATE.insuranceType == 4){
                $$.isValidObjThrow(productCondition, "请选择产品条件~");

                //-- 检查产品年龄信息
                if(productId !="100398"){
                    for(const key in beInsureData){
                        const item = beInsureData[key],
                            { insureBirthday  } = item;

                        checkProductAgeInfo(insureBirthday );
                    }
                }

            }

            //-- 自动续保
            if(tip_showAutoRenewal && needAutoRenewal){
                $$.isValidObjThrow(autoRenewal_bank, "请选择自动续保的开户银行~");
                $$.isValidObjThrow(autoRenewal_bankNumber, "请输入自动续保银行账号~");

                if(!$Reg.bankCardReg.test(autoRenewal_bankNumber)){
                    $$.throwTips("银行账号格式不正确~");
                }
                if(!autoRenewal_agree){
                    $$.throwTips("请勾选自动续保协议条款~");
                }

                //-- [扩展信息] -> 自动续保
                extendLists.push({
                    accountBankName: autoRenewal_bankName,
                    accountBankCode: autoRenewal_bank,
                    accountNo: $$.rsaEncrypt(autoRenewal_bankNumber)
                });
            }

            //大都会-都会天使产品
            if(productId == 100383){
                const policyProvinceCode = PAGE_STATE.policyProvinceCode,
                    policyCityCode = PAGE_STATE.policyCityCode,
                    insuredProvinceCode = PAGE_STATE.insuredProvinceCode,
                    insuredCityCode = PAGE_STATE.insuredCityCode,
                    policyProvinceValue = PAGE_STATE.policyProvinceValue,
                    policyCityValue = PAGE_STATE.policyCityValue,
                    insuredProvinceValue = PAGE_STATE.insuredProvinceValue,
                    insuredCityValue = PAGE_STATE.insuredCityValue;

                extendLists.push({
                    policyProvinceCode: policyProvinceCode,
                    policyCityCode: policyCityCode,
                    insuredProvinceCode: insuredProvinceCode,
                    insuredCityCode: insuredCityCode,
                    policyProvinceValue: policyProvinceValue,
                    policyCityValue: policyCityValue,
                    insuredProvinceValue: insuredProvinceValue,
                    insuredCityValue: insuredCityValue
                });
            }

            // 易安 宠物产品
            if(productId == 100392){
                const petType = PAGE_STATE.petType,
                    petName = PAGE_STATE.petName,
                    petId = PAGE_STATE.petId,
                    petSex = PAGE_STATE.petSex,
                    petAge = PAGE_STATE.petAge,
                    petSterilisation = PAGE_STATE.petSterilisation,
                    // 地址
                    insuredProvinceCode = PAGE_STATE.insuredProvinceCode,
                    insuredProvinceValue = PAGE_STATE.insuredProvinceValue,
                    insuredCityCode = PAGE_STATE.insuredCityCode,
                    insuredCityValue = PAGE_STATE.insuredCityValue,
                    insuredAreaCode = PAGE_STATE.insuredAreaCode,
                    insuredAreaValue = PAGE_STATE.insuredAreaValue,
                    insuredAddress = PAGE_STATE.insuredAddress;

                extendLists.push({
                    petType: petType,
                    petName: petName,
                    petId: petId,
                    petSex: petSex,
                    petAge: petAge,
                    petSterilisation: petSterilisation,

                    insuredProvinceCode: insuredProvinceCode,
                    insuredProvinceValue: insuredProvinceValue,
                    insuredCityCode: insuredCityCode,
                    insuredCityValue: insuredCityValue,
                    insuredAreaCode: insuredAreaCode,
                    insuredAreaValue: insuredAreaValue,
                    insuredAddress: insuredAddress,
                });
            }


            // 平安燃气意外险
            if(productId == 100357){
                extendLists.push({
                    salecompid: PAGE_STATE.sellCompanyId,
                    bulidingAddress: PAGE_STATE.houseAddress,
                    steelNo: PAGE_STATE.steelNo,
                    labelNo: PAGE_STATE.labelNo,
                    facNo: PAGE_STATE.facNo,
                    sellOrderIdNum: PAGE_STATE.sellOrderIdNum
                });
            }

            //-- 目的地显示
            const needShowAddress = [
                //-- 出租屋, 纸质发票邮寄使用
                100316, 100317, 100329, 100388
            ];
            if(needShowAddress.indexOf(productId) != -1){
                $$.isValidObjThrow(otherInfoAddress, "请输入其他信息中的详细地址~");
                if(productId == 100329){
                    if(!otherInfo_agree) $$.throwTips("请勾选并同意投保事项条款~");
                }

                //-- 其他信息 -> 通信地址, (此地址非投保人通信地址)
                params.otherInfoAddress = otherInfoAddress;
            }

            // 万欣和海外重疾
            if(productId == 100398){
                //被保人数量
                let me = 0;//本人数量0下标
                let parents = 0 ;//父母1
                let son = 0 ;//子女2
                let spouse = 0;//配偶3
                //性别
                let meSex = "";//本人性别
                let spouseSex ="";//配偶性别
                let parentsSex = {boy : 0, girl:0 };
                //父母性别
                for(const key in beInsureData){
                    const item = beInsureData[key];

                    if(item.relationship == "0"){
                        me = me + 1;
                        meSex =   item.insureSex;
                    }
                    if(item.relationship == "1"){
                        parents = parents + 1;
                        if (item.insureSex == "boy"){
                            parentsSex.boy += 1;
                        }
                        if (item.insureSex == "girl"){
                            parentsSex.girl += 1;
                        }
                    }
                    if(item.relationship == "2"){
                        son = son + 1;
                    }
                    if(item.relationship == "3"){
                        spouse = spouse + 1;
                        spouseSex = item.insureSex;
                    }
                }

                //remark  关系为 儿童计划为一个  成人为一个 就不用判断
                if(remark == "1-0-0"){
                    if(Object.keys(beInsureData).length == 1){
                        //当 计划为儿童 和成人是就不需要做被保人判断
                        //加一个提交判断防止bug 成人计划添加本人后再来儿童提交
                        for(const key in beInsureData){
                            const item = beInsureData[key],
                                { insureBirthday } = item;
                            checkProductAgeInfo(insureBirthday);
                        }
                        if (son == 1 || me == 1){
                            return;//成功提交先~
                        }else {
                            $$.throwTips("被保人的关系只能是本人或者子女哦~");
                        }
                    }else {
                        $$.throwTips("只能有一个被保人哦~");
                    }
                }
                //成人计划为一个 就不用判断, 成年的子女以及夫妇本人配偶都可以买
                if(remark == "0-1-0"){
                    if(Object.keys(beInsureData).length == 1){
                        return;//成功提交先~
                    }else {
                        $$.throwTips("只能有一个被保人哦~");
                    }
                }
                //还有一个需求所有下面的计划 都必须要有本人 的为被投保人
                //夫妻计划
                if(remark == "0-2-0"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    if(parents == 0 &&  son == 0){
                        if(spouse == 1 || spouse  ==0){
                            if(spouse == 1){
                                //配偶的性别验证
                                if((meSex == "boy" && spouseSex == "girl") || (meSex == "girl" && spouseSex == "boy")){
                                    return; //成功提交
                                }else {
                                    $$.throwTips("被投保人的配偶关系是一男一女制的夫妻哦~");
                                }
                            }
                            return; //成功提交
                        }else{
                            $$.throwTips("被投保人只能是本人和配偶两位~");
                        }
                    }else{
                        $$.throwTips("被投保人只能是本人和配偶两位~");
                    }
                }
                //亲子计划
                if(remark == "100-1-0"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    //判断投保人是否是只有子女以及本人
                    if(parents == 0 && spouse  == 0){
                        if(son < 100){
                            //当前是只能是本人一位以及子女,有或无
                            return; //成功提交
                        }else{
                            $$.throwTips("你的孩子太多了~");
                        }
                    }else{
                        $$.throwTips("被投保人只能是本人以及子女哦~");
                    }
                }
                //亲子增强计划（1老人）
                if(remark == "100-1-1"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    //判断投保人是否是只有n个子女以及父母一位
                    if(spouse  == 0){
                        if(parents == 1 || parents == 0){
                            if(son < 100 ){
                                //当前是只能是本人一位以及子女,有或无
                                return; //成功提交
                            }else{
                                $$.throwTips("你的孩子太多了~");
                            }
                        }else{
                            $$.throwTips("父母最多是一位哦~");
                        }

                    }else{
                        $$.throwTips("被投保人只能是您本人和您的父母以及子女哦~");
                    }
                }
                //亲子增强计划（2老人）
                if(remark == "100-1-2"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    if(parentsSex.boy > 1 && parentsSex.girl >1){
                        $$.throwTips("父母关系是一男一女制的夫妻哦并且最多只能两位~");
                    }
                    //判断投保人是否是只有n子女以及父母两位
                    if(spouse  == 0){
                        if(parents == 1 || parents == 0 || parents == 2){
                            if(son < 100 ){
                                //当前是只能是本人一位以及子女,有或无
                                return; //成功提交
                            }else{
                                $$.throwTips("你的孩子太多了~");
                            }
                        }else{
                            $$.throwTips("父母最多是两位哦~");
                        }
                    }else{
                        $$.throwTips("被投保人最多只能是您本人和您的父母以及子女哦~");
                    }
                }
                //家庭计划
                if(remark == "100-2-0"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    if(parents == 0){
                        if(spouse == 1 || spouse  ==0 ){
                            if(spouse == 1){
                                //配偶的性别验证
                                if((meSex == "boy" && spouseSex == "girl") || (meSex == "girl" && spouseSex == "boy")){
                                    if(son < 100 ){
                                        //当前是只能是本人一位以及子女,有或无
                                        return; //成功提交
                                    }else{
                                        $$.throwTips("你的孩子太多了~");
                                    }
                                }else {
                                    $$.throwTips("被投保人的配偶关系是一男一女制的夫妻哦~");
                                }
                            }
                            return; //成功提交
                        }else{
                            $$.throwTips("被投保人最多只能有一位配偶~");
                        }
                    }else{
                        $$.throwTips("被投保人最多只能是本人和配偶两位以及子女不限~");
                    }
                }
                //家庭增强计划（1老人）
                if(  remark == "100-2-1"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    if(parents == 0 || parents == 1){
                        if(spouse == 1 || spouse  == 0){
                            if(spouse == 1){
                                //配偶的性别验证
                                if((meSex == "boy" && spouseSex == "girl") || (meSex == "girl" && spouseSex == "boy")){
                                    if(son < 100 ){
                                        //当前是只能是本人一位以及子女,有或无
                                        return; //成功提交
                                    }else{
                                        $$.throwTips("你的孩子太多了~");
                                    }
                                }else {
                                    $$.throwTips("被投保人的配偶关系是一男一女制的夫妻哦~");
                                }
                            }
                            return; //成功提交
                        }else{
                            $$.throwTips("被投保人最多只能有一位配偶~");
                        }
                    }else{
                        $$.throwTips("被投保人最多只能是本人和配偶两位以及子女不限制以及一位父母~");
                    }
                }
                //家庭增强计划（2老人）
                if(  remark == "100-2-2" ){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    if(parents == 0 || parents == 1 || parents == 2){
                        if(spouse == 1 || spouse  ==0 ){
                            if(spouse == 1){
                                //配偶的性别验证
                                if((meSex == "boy" && spouseSex == "girl") || (meSex == "girl" && spouseSex == "boy")){
                                    if(son < 100 ){
                                        //当前是只能是本人一位以及子女,有或无
                                        //$$.throwTips("投保需求成功但不提交测试~");
                                        return; //成功提交
                                    }else{
                                        $$.throwTips("你的孩子太多了~");
                                    }
                                }else {
                                    $$.throwTips("被投保人的配偶关系是一男一女制的夫妻哦~");
                                }
                            }
                            return; //成功提交
                        }else{
                            $$.throwTips("被投保人最多只能有一位配偶~");
                        }
                    }else{
                        $$.throwTips("被投保人最多只能是本人和配偶两位以及子女不限制以及两位父母~");
                    }
                }
                //1014227家庭增强计划（3老人）
                if(  remark == "100-2-3"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    if(parents == 0 || parents == 1 || parents == 2 || parents == 3){
                        if(parentsSex.boy >= 3 || parentsSex.girl >= 3 ){
                            $$.throwTips("父母关系是一男一女制的夫妻哦并且单一性别最多只能两位哦~");
                        }
                        if(spouse == 1 || spouse  ==0 ){
                            if(spouse == 1){
                                //配偶的性别验证
                                if((meSex == "boy" && spouseSex == "girl") || (meSex == "girl" && spouseSex == "boy")){
                                    if(son < 100 ){
                                        //当前是只能是本人一位以及子女,有或无
                                        return;//成功提交
                                    }else{
                                        $$.throwTips("你的孩子太多了~");
                                    }
                                }else {
                                    $$.throwTips("被投保人的配偶关系是一男一女制的夫妻哦~");
                                }
                            }
                            return; //成功提交
                        }else{
                            $$.throwTips("被投保人最多只能有一位配偶~");
                        }
                    }else{
                        $$.throwTips("被投保人最多只能是本人和配偶两位以及子女不限制以及三位父母~");
                    }
                }
                //1014228家庭增强计划（4老人）
                if(  remark == "100-2-4"){
                    if(me == 0){
                        $$.throwTips("必须有本人哦~");
                    }
                    if(parents == 0 || parents == 1 || parents == 2 || parents == 3 || parents == 4){
                        if(parentsSex.boy >= 3  ||  parentsSex.girl >= 3){
                            $$.throwTips("父母关系是一男一女制的夫妻哦并且单一性别最多只能两位哦~");
                        }
                        if(spouse == 1 || spouse  == 0){
                            if(spouse == 1){
                                //配偶的性别验证
                                if((meSex == "boy" && spouseSex == "girl") || (meSex == "girl" && spouseSex == "boy")  ){
                                    if(son < 100 ){
                                        //当前是只能是本人一位以及子女,有或无
                                        return; //成功提交
                                    }else{
                                        $$.throwTips("你的孩子太多了~");
                                    }
                                }else {
                                    $$.throwTips("被投保人的配偶关系是一男一女制的夫妻哦~");
                                }
                            }
                            return; //成功提交
                        }else{
                            $$.throwTips("被投保人最多只能有一位配偶~");
                        }
                    }else{
                        $$.throwTips("被投保人最多只能是本人和配偶两位以及子女不限制以及四位父母~");
                    }
                }
                $$.throwTips("被投保人的人数不对~");
            }
        })();

        //-- 数据处理
        (function(){
            //-- 被保人数据处理
            for(const key in beInsureData){
                const item = beInsureData[key];
                //-- 职业绑定
                item.occupationId = occSelect;
                item.occupationDisplay = occupationDisplay;
            }
            //-- 投保人信息  ``JSONObject
            params.insureData = JSON.stringify(insureData);
            //-- 被保人信息  ``JSONObject, key = cardNumber, value = data
            params.beInsureData = JSON.stringify(beInsureData);
            //-- 扩展信息
            params.extendLists = JSON.stringify(extendLists);

            //-- 按天数的销售产品
            if($$.isValidObj(reallySellId)){
                params.sellProductId = reallySellId;
            }
            //-- 发票信息
            if(needInvoices == "1"){
                params.needInvoices = true;
            }
        })();

        //-- 数据脱敏
        (function(){
            const tips = $Constant.requestRSATips;
            if(!tips) return;
            const keys = ["insureCardNum", "insurePhone", "insureMail"],
                insureData = JSON.parse(params.insureData),
                beInsureData = JSON.parse(params.beInsureData);

            //-- 投保人
            rsa(insureData);
            //-- 被保险人
            for(let key in beInsureData){
                rsa(beInsureData[key]);
                beInsureData[$$.rsaEncrypt(key)] = beInsureData[key];
                delete beInsureData[key];
            }
            function rsa(data){
                data[$Constant.requestRSATips] = true;
                for(const key of keys){
                    data[key] = $$.rsaEncrypt(data[key]);
                }
            }
            params.insureData = JSON.stringify(insureData);
            params.beInsureData = JSON.stringify(beInsureData);
        })();

        //-- 订单处理
        (function(){
            $$.request({
                url: UrlConfig.insuranceInfo_submitOrderHandler,
                pars: params,
                loading: true,
                requestBody: true,
                sfn: function(data){
                    $$.closeLoading();
                    countAction("xb_3008");
                    recordEventLog("T2020071315072306269632");
                    const { success, msg, datas } = data;
                    if(success){
                        goOrderDetail();
                    }else{
                        $$.alert(msg);
                    }
                }
            })
        })();
    }

    /**
     * 保存发票处理
     * @Author 肖家添
     * @Date 2019/10/10 15:31
     */
    function saveInvoiceHandler(){
        //-- Constant start
        const parentCommonEle = $("#invoiceWrap_section"),
            findEle = function(selected){
                return parentCommonEle.find(selected);
            };
        const logisticsId = findEle(".invoiceWrap-logistics-val").attr("data-id"),
            logisticsName = findEle(".invoiceWrap-logistics-val").val(),
            invoiceName = findEle(".invoiceWrap-name-val").val(),
            invoiceTelephone = findEle(".invoiceWrap-tel-val").val(),
            invoiceAreaIds = findEle(".invoiceWrap-area-val").attr("data-ids"),
            invoiceStreet = findEle(".invoiceWrap-street-val").val();
        //-- Constant end

        //-- 数据验证
        (function(){
            $$.isValidObjThrow(logisticsId, "请选择物流公司~");
            $$.isValidObjThrow(invoiceName, "请填写收件人姓名~");
            $$.isValidObjThrow(invoiceTelephone, "请填写手机号码~");
            $$.isValidPhone(invoiceTelephone, "手机号码格式不正确~", true);
            $$.isValidObjThrow(invoiceAreaIds, "请选择城市~");
            $$.isValidObjThrow(invoiceStreet, "请填写街道~");
        })();

        //-- 数据保存
        (function(){
            const datum = {
                logisticsId,
                logisticsName,
                invoiceName,
                invoiceTelephone,
                invoiceAreaIds,
                invoiceStreet,
            };

            $("#invoiceInfo")
                .find(".tit").html(logisticsName)
                .parent().find(".val").html(`${invoiceName} ${invoiceTelephone}`)
                .parent().show().next().hide();
            PAGE_STATE.insureDatums.invoiceData = datum;
        })();
    }

    /**
     * 页面状态处理
     * handlerType[1: 设置, 2: 读取]
     * @Author 肖家添
     * @Date 2019/11/11 9:52
     */
    function pageStatusHandler(handlerType = 1){
        const {
                //-- 投保资料
                insureDatums,
                //-- 编辑被保人的HTML组件
                editBeInsureInfoEle,
                //-- 表单数据
                formData,
                //-- 订单Token
                orderToken
            } = PAGE_STATE,
            cacheKey = `FILL_INFO_CACHE_FOR_ORDER_TOKEN_${orderToken}`,
            limitSelectElement = $("#limitSelect"),                             // 保障期限``ELEMENT
            occupationElement = $("#occSelect"),                                // 职业``ELEMENT
            conditionElement = $("#conditionSelect");                           // 产品条件``ELEMENT

        switch (handlerType) {
            case 1:{
                let limitValue = limitSelectElement.val(),                              // 保障期限
                    limitSellId = limitSelectElement.attr("data-sellId"),               // 保障期限 -> 销售产品标识编号
                    limitReallySellId = limitSelectElement.attr("data-reallySellId"),   // 保障期限 -> 销售产品真实编号
                    startDate = $("#startDate").val(),                                  // 起保时间
                    endDate = $("#endDate").val(),                                      // 终保时间
                    occupationValue = occupationElement.text(),                          // 职业名称
                    occupationId = occupationElement.attr("data-occupationId"),         // 职业编号
                    occupationAzcnCode = occupationElement.attr("data-azcnCode"),       // 职业编码
                    conditionValue = conditionElement.val(),                            // 产品条件 -> 销售产品名称
                    conditionSellId = conditionElement.attr("data-sellId"),             // 产品条件 -> 销售产品编号
                    billCheckValue = $(".bill input[name=needInvoices]:checked").val(); // 发票选中的值
                billCheckValue = $$.changeIsNilVal(billCheckValue, 0);

                const jsonDatum = {
                    PAGE_STATE: {
                        insureDatums,
                        // editBeInsureInfoEle,
                        formData
                    },
                    limit: {
                        limitValue,
                        limitSellId,
                        limitReallySellId
                    },
                    startDate,
                    endDate,
                    occupation: {
                        occupationValue,
                        occupationId,
                        occupationAzcnCode
                    },
                    condition: {
                        conditionValue,
                        conditionSellId
                    },
                    billCheckValue
                };

                localStorage.setItem(cacheKey, JSON.stringify(jsonDatum));
                break;
            }
            case 2:{
                let cacheDatums = PAGE_STATE.historyBindData;
                if(!$$.isValidObj(cacheDatums)){
                    cacheDatums = localStorage.getItem(cacheKey);
                    if(!$$.isValidObj(cacheDatums))
                        return;
                }

                if(typeof cacheDatums == "string")
                    cacheDatums = JSON.parse(cacheDatums);

                let {
                    PAGE_STATE: {
                        insureDatums: {
                            insureData,
                            invoiceData
                        },
                        formData: {
                            guaranteePeriod: {
                                dayTips
                            }
                        }
                    },
                    limit: {
                        limitValue,
                        limitSellId,
                        limitReallySellId
                    },
                    startDate,
                    endDate,
                    occupation: {
                        occupationValue,
                        occupationId,
                        occupationAzcnCode
                    },
                    condition: {
                        conditionValue,
                        conditionSellId
                    },
                    billCheckValue,
                    extend: {
                        otherInfoAddress,
                        accountBankName,
                        accountBankCode,
                        accountNo
                    }
                } = cacheDatums;

                PAGE_STATE = {
                    ...PAGE_STATE,
                    ...cacheDatums.PAGE_STATE
                };

                //-- 保障期限
                (function(){
                    $("#sDate").html(startDate);
                    $("#eDate").html(endDate);
                    limitSelectElement.val(limitValue).attr("data-sellId", limitSellId).attr("data-reallySellId", limitReallySellId);
                    $("#startDate").val(startDate);
                    $("#endDate").val(endDate);
                    occupationElement.text(occupationValue).attr("data-occupationId", occupationId).attr("data-azcnCode", occupationAzcnCode);
                    conditionElement.val(conditionValue).attr("data-sellId", conditionSellId);

                    //-- 天数
                    if($$.isValidObj(dayTips)){
                        PAGE_STATE.insuranceNeedData.day_tips = dayTips;
                    }
                })();

                //-- 投保人
                (function(){
                    if(!$$.isValidObj(insureData) || Object.keys(insureData).length <= 0)
                        return;

                    const {
                        insureCardType,
                        insureCardTypeLabel,
                        insureName,
                        insureCardNum,
                        insurePhone,
                        insureMail,
                        insureBirthday,
                        insureSex,
                        insureAddress,
                        postcode,
                        address,
                        companyTel,
                    } = insureData;

                    $("#insureList .insureCardType").html(insureCardTypeLabel).attr("data-id", insureCardType);
                    $("#insureList #insureName").val(insureName);
                    $("#insureList #insureCardNum").val(insureCardNum);
                    $("#insureList #insurePhone").val(insurePhone);
                    $("#insureList #insureMail").val(insureMail);
                    $("#insureList .insureBirthday").val(insureBirthday);
                    $(`#insureList .sexBtn[data-id=${insureSex}]`).click();
                    $("#insureAddress").val(insureAddress);


                    $("#companyTel").val(companyTel);
                    $("#locationAddress").val(address);
                    $("#postcode").val(postcode);
                    const notIdCardFormItem = $(`#insureList .notIdCardFormItem`);
                    if(insureCardType === 1){
                        notIdCardFormItem.hide();
                    }else{
                        notIdCardFormItem.show();
                    }

                    savePolicyHolder(false);
                })();

                //-- 被保人
                generateBeInsureElements();

                //-- 发票
                (function(){
                    if($$.isValidObj(invoiceData) && Object.keys(invoiceData).length > 0){
                        billCheckValue = 1;
                    }
                    $(`.bill input[name=needInvoices][value=${billCheckValue}]`).click();
                    $(`.bill input[name=needInvoices]`).attr("data-afterFirstTips", true);
                })();

                //-- 其他信息 -> 通讯地址
                (function(){
                    if(!$$.isValidObj(otherInfoAddress))
                        return;

                    $("#other-info-address").val(otherInfoAddress);
                    $("#readStatusChange>.read-status").addClass("readed");
                })();

                //-- 自动续保
                (function(){
                    if(!$$.isValidObj(accountBankName) || !$$.isValidObj(accountBankCode) || !$$.isValidObj(accountNo))
                        return;

                    const renewalInformation = $("#renewalInformation_section"),
                        bankLabel = renewalInformation.find(".renew-bank-label"),
                        bankNumber = renewalInformation.find(".renew-bank-number");

                    bankNumber.val(accountNo);
                    bankLabel.html(accountBankName).attr("data-id", accountBankCode).addClass("active");
                    $("#allianzMedicalCare").find(".read-status").addClass("readed");
                    renewalInformation.show();
                })();

                //-- 保费计算
                calculationReallyInsuranceMoney({});

                break;
            }
        }
    }

    /**
     * 计算真实保费
     * @Author 肖家添
     * @Date 2019/11/11 18:11
     */
    function calculationReallyInsuranceMoney({resetTime = false, calculationFormVal = false}){
        if(PAGE_STATE.productId != 100398){
            const money = premiumCalculation(resetTime, calculationFormVal);
            $("#sumMoney").html(money * Object.keys(PAGE_STATE.insureDatums.beInsureData).length);
        }

    }

    /**
     * 订单分享
     * @Author 肖家添
     * @Date 2019/11/21 10:33
     */
    function shareOrder(){
        const imgUrl = $Constant.shareLogo,
            { weChatNickName, orderToken, beShareToken } = PAGE_STATE;

        if(!$WeChat.isWx() || !$$.isValidObj(weChatNickName) || !$$.isValidObj(beShareToken)){
            WE_CHAT_MENU_FLAG = false;
            weChatMenuHandler();
            return;
        }

        let linkUrl = window.location.href.split("?")[0];
        linkUrl += $$.jsonToUrlParams({
            orderToken,
            beShareToken
        });

        weChatJSTool.share({
            _imgUrl: imgUrl,
            _lineLink: linkUrl,
            _shareTitle: `Hi！我是${weChatNickName}，这份保单需要你填写`,
            _descContent: `请填写被保险人的具体信息，完善保单。`
        });
    }

    function goOrderDetail(){
        const { orderToken, beShareToken, eventLogToken } = PAGE_STATE;
        $$.push("product/orderDetail", {orderToken, beShareToken, eventLogToken});
    }

    //扫描身份证
    $('.uploadIdCard').on('change',function () {
        let insType = $(this).parent('.idCardRecognition').attr('id');
        fileUploadHandler(this, "30002", insType);
    });
    $('.idCardRecognition').on('click',function () {
        $(this).find('.uploadIdCard')[0].click();
    });
    $('.ins').on('click',function () {
        layer.open({
            content: `
                <div class="POPUP_MODAL" style="width: 100%; height: ${$(window).height() * 0.9}px; position: relative; left: 0; top: 0; overflow: hidden; background-color: white;">
                    <div class="closeTips"></div>
                    <!--<iframe src="https://mtadmin.xiaobaibao.com/src/pages/looked/client.html?productState=true" width="100%" frameborder="0" style="margin-top: 30px; border-radius: 8px; overflow: hidden; height: calc(100% - 30px)" />-->
                    <iframe src="../looked/client.html?productState=true" width="100%" frameborder="0" style="margin-top: 30px; border-radius: 8px; overflow: hidden; height: calc(100% - 30px)" />
                </div>
            `,
        });
        recordEventLog("T2020071315075462269632");
    });

    /**
     * 文件上传处理  ``因考虑到【营业执照识别】和【OSS文件上传】分开请求存在网络损耗，证件识别时OSS文件也会一起上传上去
     * @Author 肖家添
     * @Date 2019/11/12 11:41
     */
    function fileUploadHandler(e, formType = '30002', insType = 'insCR') {
        const files = e.files,
            image = files[0];

        lrz(image).then(function(resultObj) {
            const { file } = resultObj,
                formData = new window.FormData();
            formData.append("file", file);
            formData.append("formType", formType);

            $$.request({
                url: UrlConfig.upload_attachment_uploadFileByComplex,
                pars: formData,
                requestBody: true,
                loading: true,
                sfn: function(data){
                    $$.closeLoading();

                    if(data.success){
                        data = data.datas;
                        switch (formType) {
                            case '30002':{
                                responseHandler_30002(data, insType);
                                break;
                            }
                        }
                    }else{
                        $$.alert(data.msg);
                    }
                }
            });
        });
    }

    //-- 身份证识别 -> 响应处理
    function responseHandler_30002(data, insType){
        const { name, idCardNumber } = data;

        if($$.isValidObj(idCardNumber)){
            let insTypeStr = 'insure';
            if (insType === 'beInsCR') {
                insTypeStr = 'beInsure';
                $("#" + insTypeStr + "List .beName").val(name);
                $("#" + insTypeStr + "List .beInsureCardNum").val(idCardNumber);
            } else {
                $("#" + insTypeStr + "List #insureName").val(name);
                $("#" + insTypeStr + "List #insureCardNum").val(idCardNumber);
            }
            $$.layerToast("识别成功！");
            countAction("xb_3003");
            const { credentialsTypeData } = PAGE_STATE;

            if(!$$.isValidObj(credentialsTypeData) || credentialsTypeData.length <= 0)
                return;

            const { id, credentials } = credentialsTypeData[0];

            selectIdType_setLimitPageData(insTypeStr + 'List',{label: credentials, value: id});
        }else{
            $$.throwTips("未识别到证件号，请重试！");
        }
    }

    /**
     * 易安产品 选项弹窗
     * @Author 吴成林
     * @Date 2020-4-26 16:51:14
     */
    function yianProducts() {
        //-- 宠物产品 地址选择
        $(".petProductAddress").off().click(function(){
            weui.picker(chinaAreas_pet, {
                id: "petProductAddress-picker",
                container: "body",
                defaultValue: [110000, 110100, 110101],
                onConfirm: function (result) {
                    let names = "";
                    let ids = "";

                    for(const item of result){
                        names += `${item.label} `;
                        ids += `${item.value}-`;
                    }
                    if($$.isValidObj(names)){
                        names = names.substring(0, names.length - 1);
                        ids = ids.substring(0, ids.length - 1);
                    }

                    $("#petInsuredProvinces").text(names).addClass('active');
                    let idsList = ids.split("-");
                    let namesList = names.split(" ");
                    PAGE_STATE.insuredProvinceCode = $$.isValidObj(idsList[0]) ? idsList[0]:"";
                    PAGE_STATE.insuredProvinceValue = $$.isValidObj(namesList[0]) ? namesList[0]:"";
                    PAGE_STATE.insuredCityCode = $$.isValidObj(idsList[1]) ? idsList[1]:"";
                    PAGE_STATE.insuredCityValue = $$.isValidObj(namesList[1]) ? namesList[1]: "";
                    PAGE_STATE.insuredAreaCode = $$.isValidObj(idsList[2]) ? idsList[2]:"";
                    PAGE_STATE.insuredAreaValue = $$.isValidObj(namesList[2]) ? namesList[2]:"";
                    $('.petInsuredAddress').show();
                }
            });
        });

        //-- 宠物产品 宠物性别
        $(".petSex").off().click(function(){
            const _this = $(this);
            let defaultList = [];
            defaultList = [{label: "公", value: "01"},{label: "母", value: "02"},{label: "其他", value: "03"}];
            weui.picker(defaultList, {
                defaultValue: ["01"],
                onConfirm: function (result) {
                    _this.attr('data-value', result[0].value);
                    $('#petSex').text(result[0].label).addClass('active');
                    PAGE_STATE.petSex = result[0].value;
                }
            });
        });

        //-- 宠物产品 宠物年龄
        $(".petAge").off().click(function(){
            const _this = $(this);
            let petAgeList = [];
            petAgeList = petAgeLists();
            weui.picker(petAgeList, {
                id: "petAgeList-picker",
                container: "body",
                defaultValue: [0, 2],
                onConfirm: function (result) {
                    let names = "";
                    let ids = "";
                    for(const item of result){
                        /*if (item.label != "0年"){
                            names += `${item.label}-`;
                        }*/
                        names += `${item.label}-`;
                        ids += `${item.value}-`;
                    }
                    if($$.isValidObj(names)){
                        names = names.substring(0, names.length - 1);
                        ids = ids.substring(0, ids.length - 1);
                    }

                    _this.attr('data-value', ids);
                    $('#petAge').text(names).addClass('active');
                    PAGE_STATE.petAge = ids;
                    PAGE_STATE.petAgeValue = names;
                }
            });
        });

        //-- 宠物产品 宠物类型/是否绝育
        $(".petInput").off().click(function(){
            let name = $(this).attr('name');
            let val = $(this).val();
            if (name == 'petType'){                     // 宠物类型
                PAGE_STATE.petType = val;
            } else if (name == 'petSterilisation'){     // 是否绝育
                PAGE_STATE.petSterilisation = val;
            }
            $(this).addClass("isCheck").parent('label').siblings('label').children('.petInput').removeClass("isCheck");
        });

        // 详情地址
        $('.insuredAddress').on("input", function () {
            let insuredAddress = $(this).val();
            PAGE_STATE.insuredAddress = insuredAddress;
        })

        // 品种
        $('#petName').on("input", function () {
            let petName = $(this).val();
            PAGE_STATE.petName = petName;
        })

        // 电子标识码
        $('#petId').on("input", function () {
            let petId = $(this).val();
            PAGE_STATE.petId = petId;
        })
    }

    /**
     * 保存事件日志
     * @Author 肖家添
     * @Date 2020/7/13 17:30
     */
    function recordEventLog(eventId, evenResult){
        const { eventLogToken, productId, orderToken } = PAGE_STATE;
        $$.recordEventLog({
            requestToken: eventLogToken,
            evenId: eventId,
            productId: productId,
            orderId: orderToken,
            evenResult
        });
    }

};
function getContactsInfo(items) {
    let item = JSON.parse(items);
    let name = item.name ;
    let idCardNum = item.idCardNum;
    let mobile = item.mobile;
    let email = item.email;
    $("#insureList #insureName").val(name);
    $("#insureList #insureCardNum").val(idCardNum);
    $("#insureList #insurePhone").val(mobile);
    $("#insureList #insureMail").val(email);
    countAction('xb_3004');
}

//-- 生成 宠物年龄范围列表
function petAgeLists() {
    let petAgeList = [{"label": "0年","value": 0,"children": []},{"label": "1年","value": 1,"children": []},{"label": "2年","value": 2,"children": []},{"label": "3年","value": 3,"children": []},{"label": "4年","value": 4,"children": []}];
    for (let i = 0; i < 5; i++) {
        for (let j = 0; j < 12; j++) {
            let list = {};
            list['label'] = j.toString() + '个月';
            list['value'] = j;
            list['year'] = i;
            if (i == 0){
                if (j<2) continue;
            } else if (i == 4){
                if (j>0) break;
            }
            petAgeList[i].children.push(list);
        }
    }
    return petAgeList;
}

/* 获取GPS定位wgs84（经度,纬度）转换百度 坐标BD09 加载地图*/
function locations(){
    //点坐标
    let point;
    //创建点坐标
    // 创建地图实例
    let map = new BMap.Map("map");

    if($WeChat.isWx()){
        //如果是微信登录就获取微信的
        weChatJSTool.getLocation(function (res) {
            let longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
            let latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
            //创建点坐标
            point = new BMap.Point(longitude, latitude);
            //根据微信地理位置转换百度详细地址
        });
    }else{
        //如果不是就是用百度的浏览器获取
        var geolocation = new BMap.Geolocation();
        geolocation.getCurrentPosition(function(r){
            if(this.getStatus() == BMAP_STATUS_SUCCESS){
                var mk = new BMap.Marker(r.point);
                map.addOverlay(mk);
                map.panTo(r.point);
                console.log(map.addOverlay(mk));
                console.log( map.panTo(r.point));
                //alert('您的位置：'+r.point.lng 维度+','+r.point.lat);
                point = new BMap.Point(r.point.lng, r.point.lat);
            }
            else {
                //alert('failed'+this.getStatus());
            }
        },{enableHighAccuracy: true})
    }
    if(point!= null){
        //地图初始化
        map.centerAndZoom(point, 15);
    }

    //坐标转换完之后的回调函数
    translateCallback = function (data){
        if(data.status === 0) {
            //开启加载层
            $$.loading();
            //获取坐标位置的省市并返回
            let geoc = new BMap.Geocoder();
            geoc.getLocation(data.points[0], function(rs){
                let addComp = rs.addressComponents;
                let detailedAddress = addComp.province + addComp.city + addComp.district + addComp.street + addComp.streetNumber;
                //在外面定义一个全局变量,然后将  省  addComp.province 和市 addComp.city  存起来去 找邮政编码
                provinceAddress = addComp.province;
                cityAddress  = addComp.city;
                //把地址传给控件
                $('#locationAddress').val(detailedAddress);
                //获取邮编
                getPostalCode();
                $$.closeLoading();
            });
        }
    };
    //GPS坐标wgs84 转 百度 坐标BD09 先执行 这个定时器,
    setTimeout(function(){
        let convertor = new BMap.Convertor();
        let pointArr = [];
        pointArr.push(point);
        convertor.translate(pointArr, 1, 5, translateCallback);
    }, 1000);
}

function getPostalCode() {
    let postcode = "";
    if(provinceAddress == "北京市"){
        postcode = "100000";
    } else if(provinceAddress == "上海市"){
        postcode = "200000";
    } else if(provinceAddress == "天津市"){
        postcode = "300000";
    } else if(provinceAddress == "重庆市"){
        postcode = "400000";
    } else {
        for(const item in yonganPostCode){
            //判断key是否等于省
            if (provinceAddress == item){
                const valueOfItem = yonganPostCode[item];

                for( const it in valueOfItem){
                    for(const p in valueOfItem[it]){
                        //cityAddress.indexOf(p) != -1匹配
                        if (cityAddress.indexOf(p) != -1){
                            postcode  = valueOfItem[it][p];
                        }
                    }
                }
            }
        }
    }
    if($$.isValidObj(postcode)){
        $('#postcode').val(postcode);
    }
}

