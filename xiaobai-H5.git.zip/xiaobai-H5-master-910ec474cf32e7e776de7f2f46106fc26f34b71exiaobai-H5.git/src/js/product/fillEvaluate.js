window.onload = function () {
    $$.changeVersion();
    $(".submit").click(function () {
        layer.open({
            title: [
                '感谢您的评价！',
            ],
            content: '本次评价送您20积分~'
            ,btn: '好的'
        });
    })
}
