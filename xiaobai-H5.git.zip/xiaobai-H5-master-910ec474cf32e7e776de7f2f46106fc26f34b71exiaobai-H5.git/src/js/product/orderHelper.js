

/**
 * 订单处理助手 JS
 * @Author 肖家添
 * @Date 2019/10/14 21:35
 */


const OrderHelper = {

    /**
     * 险种
     * @Author 肖家添
     * @Date 2019/10/16 16:10
     */
    insuranceType: {
        /**
         * 企业险
         */
        INSURANCE_TYPE_19: 19,
        /**
         * 雇主责任险
         */
        INSURANCE_TYPE_20: 20,
        /**
         * 公众责任险
         */
        INSURANCE_TYPE_24: 24,
    },

    /**
     * 订单状态
     * @Author 肖家添
     * @Date 2019/10/16 16:10
     */
    orderStatus: {
        /**
         * 待确认
         */
        ORDER_STATUS_0: 0,
        /**
         * 待支付
         */
        ORDER_STATUS_1: 1,
        /**
         * 支付成功
         */
        ORDER_STATUS_2: 2,
        /**
         * 长时间未支付
         */
        ORDER_STATUS_3: 3,
        /**
         * 已取消
         */
        ORDER_STATUS_4: 4,
        /**
         * 退款中
         */
        ORDER_STATUS_5: 5,
        /**
         * 退款中
         */
        ORDER_STATUS_6: 6,
        /**
         * 退款失败
         */
        ORDER_STATUS_7: 7,
        /**
         * Wap投保中的状态，表示订单未可显示
         */
        ORDER_STATUS_8: 8,
        /**
         * 积分支付
         */
        ORDER_STATUS_9: 9,
        /**
         * 领取成功(已支付)
         */
        ORDER_STATUS_10: 10,
        /**
         * 支付成功积分不够无法投保
         */
        ORDER_STATUS_11: 11,
        /**
         * 积分 + 支付
         */
        ORDER_STATUS_12: 12,
        /**
         * 正在核对转账流水号
         */
        ORDER_STATUS_13: 13,
        /**
         * 保全退款结算完成
         */
        ORDER_STATUS_14: 14,
        /**
         * 顺丰专用不明确支付流程
         */
        ORDER_STATUS_21: 21,
    },

    /**
     * 订单支付服务类型
     * @Author 肖家添
     * @Date 2019/10/21 12:32
     */
    orderPaymentServiceType: {
        /**
         * 微信H5支付
         */
        PAYMENT_TYPE_1: 1,
        /**
         * 微信公众号支付
         */
        PAYMENT_TYPE_2: 2,
        /**
         * APP支付
         */
        PAYMENT_TYPE_3: 3
    },

    /**
     * 销售产品价格计算单位
     * @Author 肖家添
     * @Date 2019/11/7 10:52
     */
    sellProductMoneyUnit: {
        /**
         * [价格计算单位] -> [1: 天]
         */
        MONEY_UNIT_1: 1,
        /**
         *  [价格计算单位] -> [2: 月]
         */
        MONEY_UNIT_2: 2,
        /**
         * [价格计算单位] -> [3: 年]
         */
        MONEY_UNIT_3: 3,
    },

    /**
     * 支付业务类型
     * @Author 肖家添
     * @Date 2020/3/25 18:03
     */
    payDoComplexFormType: {
        /**
         * 投保订单
         */
        FORM_TYPE_10001: 10001,
        /**
         * VIP会员时间购买
         */
        FORM_TYPE_10004: 10004,
        /**
         * 一对一咨询购买
         */
        FORM_TYPE_10005: 10005,
        /**
         * 课堂购买
         */
        FORM_TYPE_10006: 10006,
        /**
         * 资讯购买
         */
        FORM_TYPE_10009: 10009
    },

    /**
     * 订单生成
     * @Author 肖家添
     * @Date 2019/9/20 12:15
     */
    orderHandler: function(params){
        $$.request({
            url: UrlConfig.insuranceInfo_orderHandler,
            pars: params,
            loading: true,
            requestBody: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){
                    responseHandler(data.datas);
                }else{
                    $$.layerToast(data.msg);
                }
            }
        });

        //-- 订单 -> 响应处理
        function responseHandler(data){
            const { insureTimeWarn, orderToken, beShareToken } = data;
            let { eventLogToken } = params;

            if($$.isValidObj(insureTimeWarn) && insureTimeWarn){
                $$.confirm({
                    title: "您好，当前投保时间和您选的起保时间非常接近，可能会导致投保不成功。若投保不成功，您所支付的保费我们将全额退款",
                    onOkLabel: "我要继续投保",
                    onCancelLabel: "重选起保时间",
                    onOk: () => {
                        submit();
                    }
                });

                return;
            }

            submit();

            function submit(){
                sessionStorage.setItem(`PRODUCT_DETAIL_TO_FILL_INFO_${orderToken}`, JSON.stringify(data));

                $$.push("product/fillInfo", {
                    orderToken,
                    beShareToken,
                    eventLogToken
                });
            }
        }
    },

    /**
     * 订单支付前作数据校验
     * @Author 肖家添
     * @Date 2019/10/14 20:57
     */
    orderPaymentBefore: function(orderToken, beShareToken, sfn, closeLoading = true){
        $$.request({
            url: UrlConfig.insuranceInfo_orderPaymentBefore,
            pars: { orderToken, beShareToken },
            loading: true,
            sfn: function(data){
                if(closeLoading) $$.closeLoading();

                if(data.success){
                    if(sfn) sfn();
                }else{
                    $$.unBindAll();
                    OrderHelper.orderPaymentBefore_codeHandler(data, orderToken);
                }
            }
        });
    },

    /**
     * 订单支付前作数据校验 -> 响应编码处理
     * @Author 肖家添
     * @Date 2019/10/14 21:09
     */
    orderPaymentBefore_codeHandler: function(data, orderToken){
        const error_codes = {
            E0001: "订单不存在！",
            E0002: "当前产品已下架，请重新选择产品投保！",
            E0003: "当前订单已经支付！",
            E0004: "当前订单已经不可支付！！",
            E0005: "订单起保时间小于等于当前时间！",
            E0006: "系统维护中，请于00:00之后再试！",
        };

        let msg = data.msg,
            errorMsgForCode = error_codes[msg];
        errorMsgForCode = $$.changeIsNilVal(errorMsgForCode, msg);

        $$.alert(errorMsgForCode, function(){
            if(msg == "E0001" || msg == "E0002"){

                $$.push("product/productList");

            }else if(msg == "E0003" || msg == "E0004"){

                $$.push("product/orderDetail", {
                    orderToken
                });

            }
        });
    },

    /**
     * 企业险 -> 创建订单
     * @Author 肖家添
     * @Date 2019/11/6 18:06
     */
    enterprise_createOrder: function(params = {}){
        $$.request({
            url: UrlConfig.businessInsurance_createOrder,
            pars: params,
            loading: true,
            sfn: function(data){
                const { success, msg, datas } = data;
                if(success){
                    $$.push("product/enterprise/insuranceInformation", { orderToken: datas.orderToken });
                }else{
                    $$.alert(msg);
                }
            }
        });
    },

    /**
     * 订单支付完成处理
     * @Author 肖家添
     * @Date 2019/12/5 10:56
     */
    orderPaymentOverHandler: function(orderToken, shareToken, callback){
        $$.loading("支付处理中");
        let loopIndex = 0;
        loop();
        function loop(){
            loopIndex++;
            $$.request({
                url: UrlConfig.mobileOrderInfoLog_getOrderStatus,
                pars: { orderToken, shareToken },
                sfn: function(data){
                    if(data.success){
                        const orderStatus = data.datas.orderStatus;
                        if(orderStatus == OrderHelper.orderStatus.ORDER_STATUS_2){
                            $$.closeLoading();
                            $$.alert("支付成功！", function(){
                                if(callback) callback(true);
                            });
                        }else{
                            if(orderStatus == OrderHelper.orderStatus.ORDER_STATUS_1){
                                //-- 待支付状态
                                if(loopIndex >= 10){
                                    $$.closeLoading();
                                    $$.alert("订单似乎没支付成功！", function(){
                                        if(callback) callback(false);
                                    });
                                }else{
                                    setTimeout(function(){
                                        loop();
                                    }, 1000);
                                }
                            }else{
                                if(callback) callback(false);
                            }
                        }
                    }else{
                        $$.closeLoading();
                    }
                }
            });
        }
    }
};
