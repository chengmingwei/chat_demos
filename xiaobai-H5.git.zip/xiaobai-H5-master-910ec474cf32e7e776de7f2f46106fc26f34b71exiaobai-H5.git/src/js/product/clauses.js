

/**
 * 保险条款 JS
 * @Author 肖家添
 * @Date 2019/9/19 15:21
 */


let productId_PG = null;

window.onload = function(){

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader() {

        productId_PG = $$.getUrlParam("productId");

        $$.validPageParams(productId_PG, "product/productList");

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        // bindEvent();

        //-- 加载保险条款
        findInsuranceClauses();

        $$.changeVersion();
        countAction("xb_2004");

    }

    /**
     * 获取保险条款
     * @Author 肖家添
     * @Date 2019/9/5 19:58
     */
    function findInsuranceClauses(){

        $$.request({
            url: UrlConfig.insuranceClause_data,
            sfnWaitTime: 500,
            loading: true,
            pars: {
                productId: productId_PG
            },
            sfn: function(data){
                if(data.success){

                    responseHandler(data.datas);

                }else{
                    $$.errorHandler(data.msg);
                }
            }
        });

        /**
         * 保险条款 -> 相应处理
         * @Author 肖家添
         * @Date 2019/9/5 20:05
         */
        function responseHandler(data){
            try{
                let html = "";

                if($$.isValidObj(data)){
                    data.forEach((item) => {
                        html += `
                                <li data-id="${item.id}" data-url="${item.tikuanUrl}">${item.tikuanName}</li>
                            `;
                    });
                }

                $(".containerMain>ul").html(html);

                (function(){
                    $(".containerMain>ul>li").off().click(function(){
                        const url = $(this).attr("data-url");
                        let prefix = window.location.href,
                            { clientDomain, pdfDomain_product, pdfDomain_dev } = $$.constant;
                        if(prefix.indexOf(clientDomain) > -1){
                            prefix = pdfDomain_product;		// 生产环境
                        }else{
                            prefix = pdfDomain_dev;			// 测试环境
                        }
                        location.href = `${prefix}/pdfnew/pdf.html?path=`
                            + (url.indexOf("http") > -1 ? url : `${prefix}/` + url);
                    });
                })();
            }finally {
                $$.closeLoading();
            }
        }
    }
};
