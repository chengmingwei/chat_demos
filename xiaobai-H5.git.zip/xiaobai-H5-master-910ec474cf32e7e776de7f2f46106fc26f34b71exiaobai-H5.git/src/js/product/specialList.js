window.onload = function () {
    $$.changeVersion();
    let subjectData=null;

    //标签的背景颜色
    let labColor=["rgb(255,106,75)","rgb(255,168,39)","rgb(86,119,252)","rgb(140, 192, 27)"];
    //let labColor="";
    if (!$$.checkLogin()) {
        ShawHandler.gotoLogin();
    }
    //数据统计
    try {
        countAction('xb_17', null);
    } catch (error) {
        console.log(error);
    }
    $$.request({
        url: UrlConfig.getAllSubject,
        sfn: function(data){
            if(data.success){
                subjectData=data.datas;
                console.log(subjectData);
                $$.request({
                    url: UrlConfig.getAllLabel,
                    sfn: function(data){
                        if(data.success){
                            console.log(data);
                            let html="";
                            labColor.length=data.datas.length;
                            for (let i=0;i<data.datas.length;i++){
                                //labColor[i]="rgb("+parseInt(70*i+80)+","+parseInt(20*i+60)+","+parseInt(50*i+40)+")";
                                html+=`<div class="label" key="${data.datas[i].id}" style="background-color: ${labColor[i]}" >`+
                                    data.datas[i].name+`</div>`;
                            }
                            $('.list').html(getList(data.datas[0].id,subjectData));

                            $(".selectModule").append(html);
                            clicks(subjectData);
                            onClickList();
                        }else{
                            $$.layerToast(`无法获取信息[${data.msg}]`);
                        }
                    }
                });

            }else{
                $$.layerToast(`无法获取信息[${data.msg}]`);
            }
        }
    });

  function clicks(subjectData) {
      $('.label').on('click',function () {
          $$.hideNoResultView("body");
          let labId=parseInt($(this).attr("key"));
          let subjectLadId=0;
          let count=0;
          for (let i=0;i<subjectData.length;i++){
              subjectLadId= parseInt(subjectData[i].tabId);
              if (subjectLadId!=labId){
                  count++;
              }
          }
          if (count==subjectData.length){
              $$.showNoResultView(".body");
          }
          $('.list').html(getList($(this).attr("key"),subjectData));
          onClickList();
          countAction("xb_2055");
      });
  }
    function getList (id,subjectData){
        let html = "";
        for (let i=0;i<subjectData.length;i++){
            if(subjectData[i].tabId == id){
                html +=
                    `<li class="subjectList" style="background-image: url(${subjectData[i].imgUrl})" key="${subjectData[i].id}">
                 <div class="theme">${subjectData[i].title}</div>
                 <div class="tex">${subjectData[i].intro}</div>
                 </li>`;
            }
            //console.log(html);
        }
        onClickList();
        if (html==null||html==""){
            $$.showNoResultView(".body");
        }
        return html;
    }


    function onClickList  (){
        $(".subjectList").click(function () {
            $$.push('product/specialDetails',{"id":encodeURI(encodeURI($(this).attr("key")))});
        });

    }

};

/**
 * 点击跳转专题详情页面函数
 */

