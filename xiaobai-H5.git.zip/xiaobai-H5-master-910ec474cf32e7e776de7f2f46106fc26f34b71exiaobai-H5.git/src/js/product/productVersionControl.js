

/**
 *
 * Product version control.
 * Don't format code for this document.
 *
 * @Author 肖家添
 * @Date 2020/9/16 15:18
 */


(function(){
    /**
     * 版本控制器
     * @Author 肖家添
     * @Date 2020/9/16 15:41
     */
    function versionHandler(){
        const that = this;
        this.config = {
            vSelector: "#versionChangeIcon",
            vParamName: "_VC",
            vPage: null,
            //-- 版本分配
            vDatums: [
                "v1"
            ],
            //-- 参与版本切换的路由
            vRoutes: [
                "product/productDetail",        // 产品详情
                "product/health",               // 健康告知
                "product/fillInfo",             // 资料填写
                "product/orderDetail",          // 订单详情
                "product/paymentDetail"         // 订单支付
            ]
        };
        this.init = function(){
            this.pageLoader();
            this.addHtml2Page();
            this.bindEvent();
        }
        /**
         * 页面加载时版本切换
         * @Author 肖家添
         * @Date 2020/9/18 10:04
         */
        this.pageLoader = function() {
            try{
                const { vParamName, vDatums, vRoutes } = this.config;
                let versionToDisplay = $$.getUrlParam(vParamName);
                const { pathname } = window.location;
                let tips = 0;
                for(const keyword of vRoutes){
                    if(pathname.indexOf(keyword) != -1){
                        tips++;
                    }
                }
                if(tips < 0) return;
                if(!versionToDisplay || vDatums.indexOf(versionToDisplay) == -1){
                    versionToDisplay = vDatums[vDatums.length - 1];
                }
                this.config.vPage = versionToDisplay;
                versionControl(versionToDisplay);
            }catch (e) {
                console.error(e);
            }
        }
        /**
         * 添加页面版本切换组件
         * @Author 肖家添
         * @Date 2020/9/18 10:04
         */
        this.addHtml2Page = function(){
            const { vSelector } = this.config;
            $(vSelector).remove();
            $("body").append(`<div id="${vSelector.substring(1)}"></div>`);
            $(vSelector).css({
                "width": "45px",
                "height": "30px",
                "background": `url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFEAAAA5CAYAAABOKMcBAAAACXBIWXMAAAsSAAALEgHS3X78AAAD2klEQVR4nO2cTUgUURzAfzuzFWIfSl9UB5cggoKyQ+c2ukWQULGnaCEwiSgzqIkOphRtUqKSlyDSiGIjwqCrZBcvXfJQ3cougolpqWnR7HaYWfdL23F7M29mnN9p57Dv/ffH/715839vNpROp7GbmKbXAlW2dySH4bDoFk1hdUAUqAXWie7DZbQIkRjT9AjQiCGvRkSbXuK/JMY0PQpcBw6ICMarlCXRzLwelrm8DMpSvxDT9OvAZwKB81jOxJimVwF9BPKKsCTRvOMO4P87bVmUHM6BwNL8U2Ig0BqLSgwEWmdBieZNpIdAoCUWy8QOYK+TgXiZIokxTa8DTkmIxbPkSTSHcYekWDxLYSY2YnMBIbI1xP7dITu7cJz5xbaZhY12dnb8kMLRgyFWhuFKV4rhEftrmU6Q+8QSx8a7ccMxhYP7jQycnoWxCX8IhHyJtmVha4PCzoghcO433HmUYmbWrt6cJwzzC2tb5sJcgT/noK03xcfP/slCyGZi3I7Gr53OCpyeBa1LZ2zCjp7kkpFYJ7rh9iaVbZuMz6PjcPWe7qshnEvYrFILG8qVFdB2QWWDubc3OeVvgWBkYq2oxiorjAysWmNcT05BU7u/BYJAiZUVcOtcvsDOpylqtti/sB6bSEuda8NARERDzfUqm9dnr6vWQHP9krdwyuKPDt3PUgwOybnrKwiSqKoiWimPdBqq18p7lBR2AuJSu86u7XJ+iBuGszA+fPLXItoqzkxaPkdYJm6shrMn5EyMEz/SPHgp73lcmMQbZ7PLG+cJEVIUOp+kpPQextjR++9TDb2vUpw8rKA79DvWroZVK4zPf3R4+17efBwGJkU0NDiUZnBIF9FUSY4fUjgaNVYCs7/g/gt5a0QwJL6T1nsZ5BZ3p2bg7mP5pTUlmVAHpEawBFobsgLnfrtDIGSXOG+kRmGBwuJu4qE7BEJWYp/UKEpQWNy93Km7RiB4QOLt8yp7dhgCR8fhfJv7quMKQDKhDuOyIV1ZAd2aSmSrce3m4m7uY5+rTj6cOqLkVcfdXNydl5hMqH3AF4mx5PH1m7GIHh6BMzfdKxCKH/viwGsJcRTxvD/F837ZUVgjr4pjrhldNTd6gYVKYXHgu8NxeJoiiead2taDTX5jwaJsMqH2AL3OhuJdFq1sJxNqHBhyLBIPU2p7IEogsiT/lJhMqJMEIksSsvrmfUzTewgOxC9Ei+XdPnOOvGhbKB5mSVumyYTaAewjWJDnYXk4FxLT9DjGW/fL7u8KCmgpW2KGQKYAiRnMc99xlt+faYiTmIt5+jaKcfYxc/7Rr2/st/wFwn8xypv+jLMAAAAASUVORK5CYII=") no-repeat center center /100% 100%`,
                "position": "fixed",
                "right": 0,
                "top": "56px",
                "z-index": 9999 * 9999
            });
        }
        /**
         * 绑定元素事件
         * @Author 肖家添
         * @Date 2020/9/18 10:04
         */
        this.bindEvent = function(){
            const { vSelector, vDatums, vPage } = this.config;
            const vDatums2Picker = vDatums.map(item => {
                return { value: item, label: item };
            });
            $Listener.onTap(vSelector, () => {
                weui.picker(vDatums2Picker, {
                    id: "productVersionPicker",
                    title: "版本切换",
                    defaultValue: [vPage],
                    onConfirm: function (result) {
                        if(!result || result.length <= 0) return;
                        const { label } = result[0];
                        versionControl(label);
                    }
                });
            });

            //-- 路由切换监听
            $Listener.push = (fileRelativePath, params = {}) => {
                if(!fileRelativePath || !params) return;
                const { vParamName, vRoutes } = that.config;
                if(vRoutes.indexOf(fileRelativePath) == -1) return;
                params[vParamName] = vPage;
            };
        }
        /**
         * 版本切换  ``通过页面文件名直接映射版本信息，不可通过参数判断，因为参数可变性太大
         * @Author 肖家添
         * @Date 2020/9/18 10:03
         */
        function versionControl(label){
            const { vParamName } = that.config;
            let { href, pathname, search } = window.location;
            const pathSplit = pathname.split("/");
            const routePrefix = href.substring(0, href.split(".html")[0].lastIndexOf("/") + 1);
            let thisPageName = pathSplit[pathSplit.length - 1];
            let index = thisPageName.lastIndexOf("-v");
            if(label == "v1"){
                if(index == -1) return;             // 当前已经在v1页面, 无需跳转
                thisPageName = thisPageName.substring(0, index);
            }else{
                const labelIndex = thisPageName.lastIndexOf(label);
                if(labelIndex != -1) return;        // 当前已经在选择的版本页面, 无需跳转
                if(index == -1) index = thisPageName.lastIndexOf(".");
                thisPageName = thisPageName.substring(0, index);
                thisPageName += `-${label}`;
            }
            search = $$.removeUrlParam(search, vParamName);
            search += (search.indexOf("&") != -1) ? "&" : "?";
            search += `${vParamName}=${label}`;
            const pushUrl = `${routePrefix}${thisPageName}.html${search}`;
            window.location.replace(pushUrl);
        }
    }
    hook();
    function hook(){
        try{
            jQuery;
            $$;
            $Listener;
            onload();
        }catch (e) {
            window.setTimeout(hook, 1500);
        }
    }
    function onload(){
        try{
            new versionHandler().init();
        }catch (e) {
            console.error(e);
        }
    }
})();