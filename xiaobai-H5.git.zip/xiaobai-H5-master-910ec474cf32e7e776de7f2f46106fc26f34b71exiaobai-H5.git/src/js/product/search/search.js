

/**
 * 全局搜索 JS
 * @Author 肖家添
 * @Date 2019/10/6 16:13
 */


window.onload = function(){

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
		//-- 分页参数
		pagingData : {...$Constant.paginationDefault, _pageSize: 30},
		//-- 历史关键字
		keywordHistory: {},
		//-- 历史关键字缓存KEY
		keywordHistoryCacheKey: "SEARCH_HISTORY_KEYWORD"
    }

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){

    	let { keywordHistoryCacheKey } = PAGE_STATE,
			keywordHistory = localStorage.getItem(keywordHistoryCacheKey);
		keywordHistory = $$.changeIsNilVal(keywordHistory, "{}");
		keywordHistory = JSON.parse(keywordHistory);
		PAGE_STATE.keywordHistory = keywordHistory;

        //-- 页面初始化
        pageInit();

		countAction("xb_9");
		$$.changeVersion();
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

		//-- 搜索
		$(".confirmSearch, .searchIcon").on("click", function(){
			//数据统计
			try {
				countAction('xb_31', null);
			} catch (error) {
				console.log(error);
			}
			$(".searchResult").html("");
			globalSearch({});

			let searchContent = $(".searchContent").val();
			//-- 执业认证 - 弱搜索匹配
			if (searchContent == "执业" || searchContent == "认证"  || searchContent == "执业认证"){
				countAction("xb_2047");
				$$.push("my/professionalCertification");
			}
		});

		$(".searchContent").focus();
		$("#searchForm").submit(function(){
			$(".confirmSearch").click();
			return false;
		});

		//-- 热门搜索
		$(".hotContent, .historyContent").on("click", "span", function(){
			const keyword = $(this).html();
			$(".searchContent").val(keyword);

			$(".confirmSearch").click();

			//-- 执业认证 - 弱搜索匹配
			if (keyword == "执业" || keyword == "认证"  || keyword == "执业认证"){
				$$.push("my/professionalCertification");
			}
		});

		//-- 热门搜索 -执业认证
		$(".professionalCertification").on("click",function(e){
			e.stopPropagation();
			$$.push("my/professionalCertification");
		});

		//-- 详情跳转
		$(".searchResult").on("click", ".searchResult-item", function(){
			const _that = $(this),
				id = $(this).attr("data-id"),
				type = $(this).attr("data-type");

			switch(type){
				case "1":{
					//-- 产品
					const ids = id.split("-");
					$$.push("product/productDetail", {
						productId: ids[0],
						sellId: ids[1]
					});
					break;
				}
				case "2":{
					//-- 文章
					$$.push("newKnow/articleDetails", { id });
					break;
				}
				case "3":{
					//-- 视频
					$$.push("know/MsgvideoDetail", { id });
					break;
				}
				case "4":{
					$$.push("newKnow/audioDetail", { videoId: id });
					//-- 课程
					break;
				}
			}
		});

		//-- 页面滑动到底部监听
		$Listener.pageScrollToBottomListener(function(){
			PAGE_STATE.pagingData = $$.pagingHelper.before(PAGE_STATE.pagingData);
			$$.pagingHelper.loading(".searchResult");

            globalSearch({
                loading: false,
                handlerOverCallback: function(){
                    $$.pagingHelper.closeLoading();
                }
            });
		});

		$(".clearHistoryKeywords").click(function(){
			const { keywordHistoryCacheKey } = PAGE_STATE;
			PAGE_STATE.keywordHistory = {};
			localStorage.setItem(keywordHistoryCacheKey, JSON.stringify(PAGE_STATE.keywordHistory));

			generateSearchHistory();
		});
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){
		//-- 获取用户信息，判断是否已执业认证
		if($$.checkLogin()){
			getUserinfo();
		}

    	$$.clearHTMLNotes();

		generateSearchHistory();
	}

	/**
	 * 全局搜索
	 * @Author 肖家添
	 * @Date 2019/10/22 10:48
	 */
	function globalSearch({loading = true, handlerOverCallback}){
		const { pagingData, keywordHistory, keywordHistoryCacheKey } = PAGE_STATE,
		searchContent = $(".searchContent").val(),
		params = {...pagingData, keyword: searchContent};

		if($$.isValidObj(searchContent)){
			keywordHistory[searchContent] = searchContent;
			const keys = Object.keys(keywordHistory),
				keywordSize = keys.length;
			if(keywordSize > 5){
				delete keywordHistory[keys[0]];
			}

			PAGE_STATE.keywordHistory = keywordHistory;
			localStorage.setItem(keywordHistoryCacheKey, JSON.stringify(keywordHistory));
		}

		$$.request({
			url: UrlConfig.mobileHome_globalSearch,
			pars: params,
			loading: loading,
			sfn: function(data){
				$$.closeLoading();

				if(data.success){
					responseHandler(data.datas);
					countAction("xb_2046");
				}else{
					$$.layerToast(data.msg);
				}
			}
		});

		//-- 全局搜索 -> 响应处理
		function responseHandler(data){
			const { list, pagination } = data;

			//-- paging handler
			(function(){
				const { current, pageSize, total } = pagination,
				pagingData = {"_current": current, "_pageSize": pageSize, "_total": total};

				PAGE_STATE.pagingData = pagingData;
			})();

			//-- html handler
			(function(){

				if($$.isValidObj(list) && list.length > 0){
					$$.hideNoResultView();
				}else{
					$$.showNoResultView({
						msg: "无搜索结果",
						parentJqSelector: ".searchResult"
					});
				}

				let html = "";
				for(const item of list){
					const { itemId, title, detail, createTime, type } = item;
					html += `
						<div class="searchResult-item" data-id="${itemId}" data-type="${type}">
							<h2 class="searchResult-item-title">${title}</h2>
							${$$.isValidObj(detail) ? `<p class="searchResult-item-detail">${detail}</p>` : ""}
							${$$.isValidObj(createTime) ? `<p class="searchResult-item-time">${createTime}</p>` : ""}
						</div>
					`;
				}

				$(".searchResult").append(html);
			})();

			generateSearchHistory();
			if(handlerOverCallback) handlerOverCallback();
		}
	}

	/**
	 * 生成历史搜索记录
	 * @Author 肖家添
	 * @Date 2019/11/7 20:50
	 */
	function generateSearchHistory(){
		const { keywordHistory } = PAGE_STATE;
		let html = "";
		for(const key in keywordHistory){
			html = `<span>${key}</span>` + html;
		}
		$(".historyContent").html(html);

		if($$.isValidObj(html)){
			$(".clearHistoryKeywords").fadeIn();
		}else{
			$(".clearHistoryKeywords").fadeOut();
		}
	}

	/**
	 * 获取用户信息，判断是否已执业认证
	 * @Author 吴成林
	 * @Date 2019/12/9
	 */
	function getUserinfo() {
		$$.request({
			url: UrlConfig.member_Detailspage,
			loading: true,
			sfn: function(data){
				$$.closeLoading();
				if(data.success){
					//-- 1、初始用户 3、认证未通过用户 显示执业认证连接
					let userStatus = data.datas.userStatus;
					if (userStatus === 0 || userStatus === 3 ) {
						$('.professionalCertification').show();
					}
				}else{
					$$.layerToast(data.msg);
				}
			}
		});
	}
};
