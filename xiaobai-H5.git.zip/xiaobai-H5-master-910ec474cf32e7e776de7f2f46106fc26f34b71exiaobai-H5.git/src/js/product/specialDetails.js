

/**
 * 产品列表 JS
 * @Author 肖家添
 * @Date 2019/9/3 11:58
 */


/**
 * 分页参数
 * @Author 肖家添
 * @Date 2019/8/22 15:09
 */
let pagingData = {
    _pageSize: 1000,
    _current: 1,
    _total: 0
};
let id=null;

let sellId="";
window.onload = function(){



    if (!(decodeURIComponent($$.getUrlParam("id")) =="null")){
        id=decodeURIComponent($$.getUrlParam("id"));
    }
    function selectData(id) {
        //获取大图数据
        $$.request({
            url: UrlConfig.getSubjectDetails,
            pars:{id:id},
            sfn: function(data){
                console.log(data);
                if(data.success){
                    //$(".title img").attr("src",data.datas.imgUrl);
                    //$(".explain p:first-child").text(data.datas.title);
                    $('title').html(data.datas.title);
                    $(".explain p:last-child").html(data.datas.detailsContent);
                    sellId=data.datas.sellId;
                    findInsuranceInfo(null,null,null,sellId);
                    weChatShare(data.datas);
                }else{
                    $$.layerToast(`无法获取信息[${data.msg}]`);
                }
            }

        });

    }

     function setSpecial(id) {
         let html="";
         $$.request({
             url: UrlConfig.getSubjectOrder,
             pars:{id:id},
             sfn: function(data){
                 if(data.success){
                     if (data.datas.length>0){
                         for (let i=0;i<data.datas.length;i++){
                             html+= `<div key="${data.datas[i].id}" class="swiper-slide"  style="background-image: url(${data.datas[i].imgUrl})">${data.datas[i].title}</div>`;
                         }
                         $('.swiper-wrapper').html(html);
                         setSlide();
                         $(".swiper-slide").click(function () {
                             $$.push('product/specialDetails',{"id":encodeURI(encodeURI($(this).attr("key")))});
                         })
                     }else {
                         //$$.showNoResultView(".swiper-wrapper")
                            $(".under_hide").show();
                            $(".under_show").hide();
                     }
                 }else{
                     $$.layerToast(`无法获取信息[${data.msg}]`);
                 }

             }
         });

    }

    /*底部滑动*/
    function setSlide (){
        const swiper = new Swiper('.swiper-container', {
            slidesPerView: 'auto',
            //设置margin右边距
            spaceBetween:10,
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
        });
    }


    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 险种类型, [1: 个人险, 2: 企业险]
        // insuranceType: 1
    };

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        //-- 险种类型, [1: 个人险, 2: 企业险]
        /*let insuranceType = $$.getUrlParam("insuranceType");
        if(!$$.isValidObj(insuranceType)) insuranceType = "1";
        if(insuranceType === "1" || insuranceType === "2"){
            $("title").html(insuranceType === "1" ? "个人险" : "企业险");
            PAGE_STATE.insuranceType = parseInt(insuranceType);
        }*/

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){
        setSpecial(id);
        selectData(id);
    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent(){

        //-- 显示/隐藏 险种分类
        $(".selectWrapper>span:first-child").off().on("click", function (e) {
            e.stopPropagation();

            $("#searchWrap").toggleClass("show");
        });

        //-- 点击视窗关闭 险种分类
        document.onclick = function () {
            $("#searchWrap").removeClass("show");
        };

        //-- 选中 险种分类
        $("#searchCon").off().on("click", ".search-tit", function () {
            $(".search-tit").removeClass("choose-search");
            $(this).addClass('choose-search');
            $(".select").text($(this).text());
            $("#searchWrap").removeClass("show");
        });

        //-- 显示/隐藏 推广费
        $(".showOrHideMakeProfits").off().click(function () {
            $(this).toggleClass("eyes").toggleClass("closeEyes");
            //-- [true: 显示, false: 隐藏]
            const cacheKey = $Constant.promotionFeeDisplayKey;
            if ($(this).hasClass("eyes")){
                localStorage.setItem(cacheKey, "true");
                $(".makeProfits").css("opacity","1");
            }else{
                localStorage.removeItem(cacheKey);
                $(".makeProfits").css("opacity","0");
            }
        });




        $$.staticPushAutoBind();
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    /*function initPageState(){
        //-- 推广费显示隐藏
        const promotionFeeDisplay = localStorage.getItem($Constant.promotionFeeDisplayKey);
        if(promotionFeeDisplay == null){
            $(".showOrHideMakeProfits").click();
        }
    }*/

    /**
     * 获取险种分类
     * @Author 肖家添
     * @Date 2019/9/3 15:03
     */
    /*function findInsuranceType(){
        $$.request({
            url: UrlConfig.insuranceType_data,
            method: "GET",
            sfn: function(data){
                if(data.success){
                    bindInsuranceTypeElement(data.datas);
                }else{
                    $$.layerToast(`获取险种分类失败！[${data.msg}]`);
                }
            }
        });

        /!**
         * 绑定险种元素
         * @Author 肖家添
         * @Date 2019/9/3 15:24
         *!/
        function bindInsuranceTypeElement(data){
            const { insuranceType } = PAGE_STATE;

            $("#searchCon>li:gt(0)").off().remove();
            let html = "";

            if($$.isValidObj(data)){
                data.forEach((item) => {
                    let insuranceTypeList;

                    if(insuranceType === 1){
                        //-- 个人险
                        insuranceTypeList = [0, 1, 3, 4];

                    }else{
                        //-- 企业险
                        insuranceTypeList = [19, 20];
                    }
                    if(insuranceTypeList.indexOf(item.id) === -1) return;
                    html += `
                        <li>
                            <a href="javascript:;" class="search-tit" data-id="${item.id}">${item.type}</a>
                        </li>
                    `;
                });
            }

            $("#searchCon").append(html);
        }
    }*/

    /**
     * 获取保险产品库
     * @Author 肖家添
     * @Date 2019/9/3 15:25
     */
    function findInsuranceInfo(loading = true, clearList = false, overCallback,sellId){

        let params = JSON.parse(JSON.stringify(pagingData));
        // const { insuranceType } = PAGE_STATE;

        //-- params handler
        (function(){
            //-- 险种分类
            const insuranceTypeId = $(".search-tit.choose-search").attr("data-id");

            if($$.isValidObj(insuranceTypeId)){
                params["insuranceTypeId"] = insuranceTypeId;
            }

            //-- 产品库名称
            const insuranceInfoName = $(".search").val();
            if($$.isValidObj(insuranceInfoName)){
                params["insuranceInfoName"] = insuranceInfoName;
            }

            //-- 险种类型, [1: 个人险, 2: 企业险]
            // params.insuranceType = insuranceType;

            if(clearList){
                pagingData._current = 0;
                params._current = 0;
            }
            if (sellId){
                params.insuranceInfoIds=sellId;
                params.pageSize=1000;
                $(".none").hide();
            }else {
                params.insuranceInfoIds="0,0,0";
                return false;
            }

        })();
        console.log(params);
        $$.request({
            url: UrlConfig.insuranceInfo_data,
            loading: loading,
            pars: params,
            sfn: function(data){
                console.log(data);
                if (data.datas.list.length === 0){
                    $(".none").show();
                }else{
                    $(".none").hide();
                }
                if(data.success){
                    const { tips_promotionFeeDisplay } = data,
                        { list, pagination } = data.datas;
                        bindInsuranceInfoElement(list, pagination, tips_promotionFeeDisplay);
                }else{
                    $$.errorHandler(`获取保险产品失败！[${data.msg}]`);
                }
            }
        });
    }

    /**
     * 绑定保险产品元素
     * @Author 肖家添
     * @Date 2019/9/3 15:37
     */
    function bindInsuranceInfoElement(list, pagination, tips_promotionFeeDisplay){
        let promotionFeeDisplay =null;
        try{
            //const showOrHideMakeProfits = $(".showOrHideMakeProfits").hasClass("closeEyes");
            console.log(tips_promotionFeeDisplay);
            //-- paging handler
            (function(){
                pagingData._current = pagination.current;
                pagingData._pageSize = pagination.pageSize;
                pagingData._total = pagination.total;

                if($$.isValidObj(tips_promotionFeeDisplay)){
                    //console.log("dadasdas");
                    promotionFeeDisplay = localStorage.getItem($Constant.promotionFeeDisplayKey);
                }
            })();

            //-- html hndler
            (function(){
                let html = "";
                if($$.isValidObj(list)){
                    $$.hideNoResultView();
                    list.forEach((item) => {
                        const { listShowCover, labelList } = item;

                        //-- product labels handler start
                        let labelsHtml = "";
                        if($$.isValidObj(labelList)){
                            labelList.forEach((item) => {
                                labelsHtml += `<span>${item.labelName}</span>`;
                            });
                        }
                        //-- product labels handler end

                        //-- insureEnsure handler start
                        let insureEnsureHtml = "";
                        const insureEnsureData = item.insureEnsureData;

                        if($$.isValidObj(insureEnsureData)){
                            insureEnsureData.forEach((item) => {
                                insureEnsureHtml += `
                                        <li>
                                            <span style="padding-right: 10px;text-align: justify;">${item.name}</span>
                                            <span style="white-space:nowrap;">${item.money}</span>
                                        </li>
                                    `;
                            });
                        }
                        //-- insureEnsure handler end

                        html += `
                                <li data-id="${item.insuranceInfoId}" data-sellId="${item.id}">
                                    <span class="left productImage" style="background-image: url(${$$.isValidObj(listShowCover) ? listShowCover : $$.imageUrlCompatible(item.plogo)});"></span>
                                    <div class="right">
                                        <div class="top">
                                            <h3>${item.name}</h3>
                                            <p class="icon" style="${$$.isValidObj(labelsHtml) ? `` : `padding-top: 0px;`}">
                                                ${labelsHtml}
                                            </p>
                                            <p class="desc">${item.productIntroduce}</p>
                                        </div>
                                        <div class="bottom">
                                            <!--<ul class="list">
                                                ${insureEnsureHtml}
                                            </ul>-->
                                            <p class="price">${parseFloat($$.changeIsNilVal(item.sellMoney, 0)).toFixed(2)}元起</p>
                                            <p class="makeProfits" style="opacity: ${!$$.isValidObj(tips_promotionFeeDisplay) ? 0 : 1}">立赚${$$.changeIsNilVal(item.tiMoney, 0)}%</p>
                                        </div>
                                    </div>
                                </li>
                            `;
                    });
                }else {
                    return false;
                }

                if(!$$.isValidObj($(".search").val()) && list.length > 0){
                    $(".searchIcon").stop().fadeOut();
                }



                $(".content>.list").html(html);

                if (promotionFeeDisplay !== "true"){
                    $(".makeProfits").hide();
                }
                //-- 跳转 产品详情
                $(".content .list li").off().click(function () {
                    const hasShawSearchWrap = $("#searchWrap").hasClass("show");
                    if(!hasShawSearchWrap){
                        const productId = $(this).attr("data-id");
                        const sellId = $(this).attr("data-sellId");
                        $$.push("product/productDetail", {productId, sellId, channel: "productSpecial"});
                    }
                });
            })();
        }catch (e) {
            console.error(e);
        }finally {
            $$.closeLoading();
            $$.clearHTMLNotes();

            //if(overCallback) overCallback();
        }
    }

    function weChatShare(featureActivity) {
        let _lineLink = $$.getFullHost() + "/src/pages/product/specialDetails.html";
        _lineLink += $$.jsonToUrlParams({
            id: featureActivity.id
        });
        weChatJSTool.share({
            _imgUrl: featureActivity.imgUrl,
            _lineLink: _lineLink,
            _shareTitle: `你需要的系列保险产品在这`,
            _descContent: featureActivity.intro
        });
    }
};
