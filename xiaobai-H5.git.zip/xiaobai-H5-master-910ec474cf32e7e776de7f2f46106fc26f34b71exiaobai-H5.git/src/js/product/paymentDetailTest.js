

/**
 * 订单支付 JS
 * @Author 肖家添
 * @Date 2019/10/10 9:29
 */


ShawHandler.loaderRes({
    scripts: [
        //-- Order helper
        `js/product/orderHelper.js`,
    ]
});

window.onload = function(){

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    let PAGE_STATE = {
        //-- 默认选中的支付方式, [weChatPay: 微信支付, aliPay: 支付宝支付]
        defaultPaymentWay: "weChatPay",
        //-- 订单 token
        orderToken: null,
        //-- 产品分享Token
        beShareToken: null
    }

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){

        let orderToken = $$.getUrlParam("orderToken"),
            beShareToken = $$.getUrlParam("beShareToken");
        
        const cacheKey = "PAYMENT_ORDER_TOKEN",
        cacheOrderToken = localStorage.getItem(cacheKey);

        if($$.isValidObj(orderToken)){
            if(orderToken != cacheOrderToken){
                localStorage.setItem(cacheKey, orderToken);
            }
        }else if($$.isValidObj(cacheOrderToken)){
            orderToken = cacheOrderToken;
        }else{
            $$.validPageParams(orderToken, "product/productList");
        }

        PAGE_STATE = {...PAGE_STATE, orderToken, beShareToken};

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 订单支付前数据校验
        orderPaymentBefore();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 支付类型选择
        $(".checkbox").off().click(function(){
            const readStatus = $(this).find(".unselected-status");

            $(".unselected-status").removeClass("readed");

            readStatus.toggleClass("readed");
        });

        //-- 马上支付
        $(".confirmPayment").off().click(function(){
            paymentHandler();
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){

        const { defaultPaymentWay } = PAGE_STATE;

        //-- payment way selected by default
        if($$.isValidObj(defaultPaymentWay))
            $(".paymentWay").find(`[data-tips=${defaultPaymentWay}]`).click();

        //-- Clear HTML notes
        $$.clearHTMLNotes();
    }

    /**
     * 订单支付前数据校验
     * @Author 肖家添
     * @Date 2019/10/13 10:46
     */
    function orderPaymentBefore(){
        const { orderToken, beShareToken } = PAGE_STATE;
        
        OrderHelper.orderPaymentBefore(orderToken, beShareToken, function(){

            //-- 绑定事件
            bindEvent();

            //-- 初始化页面
            initPageState();

        });
    }

    /**
     * 支付处理
     * @Author 肖家添
     * @Date 2019/10/13 11:49
     */
    function paymentHandler(){
        let paymentWay = null;
        try{
            paymentWay = $(".paymentWay .checkbox .unselected-status.readed").parent().attr("data-tips");
        }catch (e) {
            $$.alert("请勾选支付方式！");
        }
        const { orderToken, beShareToken } = PAGE_STATE;
        $$.push("product/payment", {
            paymentType: paymentWay,
            doComplexFormType: OrderHelper.payDoComplexFormType.FORM_TYPE_10001,
            otherParams: JSON.stringify({orderToken, beShareToken})
        });
    }
}