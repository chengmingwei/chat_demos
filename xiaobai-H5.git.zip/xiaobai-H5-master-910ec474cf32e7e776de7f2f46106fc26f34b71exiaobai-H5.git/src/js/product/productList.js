

/**
 * 产品列表 JS
 * @Author 肖家添
 * @Date 2019/9/3 11:58
 */


/**
 * 分页参数
 * @Author 肖家添
 * @Date 2019/8/22 15:09
 */
let pagingData = {
    _pageSize: 10,
    _current: 1,
    _total: 0,
    _selectedType: false,
    _selectedSum: 0,
};

window.onload = function(){

    //数据统计
    try {
        countAction('xb_33', null);
    } catch (error) {
        console.log(error);
    }
    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 险种类型, [1: 个人险, 2: 企业险]
        insuranceType: 1
    }

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){

        //-- 险种类型, [1: 个人险, 2: 企业险]
        let insuranceType = $$.getUrlParam("insuranceType");
        if(!$$.isValidObj(insuranceType)) insuranceType = "1";
        if(insuranceType == "1" || insuranceType == "2"){
            PAGE_STATE.insuranceType = parseInt(insuranceType);
        }

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

        //-- 加载险种分类
        findInsuranceType();

        //-- 加载产品库
        findInsuranceInfo(true, true, null, true);

        //-- 跳转自动绑定
        $$.staticPushAutoBind();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent(){

        //-- 显示/隐藏 险种分类
        $(".selectWrapper>span:first-child").off().on("click", function (e) {
            e.stopPropagation();

            $("#searchWrap").toggleClass("show");
        });

        //-- 点击视窗关闭 险种分类
        document.onclick = function () {
            $("#searchWrap").removeClass("show");
        };

        //-- 选中 险种分类
        $("#searchCon").off().on("click", ".search-tit", function () {
            $(".search-tit").removeClass("choose-search");
            $(this).addClass('choose-search');
            try {
                if("全部"==$(this).text()){
                    countAction('xb_25', null);
                } else if("意外险"==$(this).text()){
                    countAction('xb_27', null);
                }else if("健康险"==$(this).text()){
                    countAction('xb_29', null);
                }else if("家财险"==$(this).text()){
                    countAction('xb_28', null);
                }else if("旅游险"==$(this).text()){
                    countAction('xb_26', null);
                }
            } catch (error) {
                console.log(error);
            }
            $(".select").text($(this).text());
            $("#searchWrap").removeClass("show");

            findInsuranceInfo(true, true);
        });

        //-- 显示/隐藏 推广费
        $(".showOrHideMakeProfits").off().click(function () {
            //数据统计
            try {
                countAction('xb_32', null);
            } catch (error) {
                console.log(error);
            }
            $(this).toggleClass("eyes").toggleClass("closeEyes");
            //-- [true: 显示, false: 隐藏]
            const cacheKey = $Constant.promotionFeeDisplayKey;
            if ($(this).hasClass("eyes")){
                localStorage.setItem(cacheKey, "true");
                $(".makeProfits").css("opacity","1");
            }else{
                localStorage.removeItem(cacheKey);
                $(".makeProfits").css("opacity","0");
            }
        });

        //-- 搜索
        $(".searchIcon").off().click(function(){
            findInsuranceInfo(true, true);
        });

        //-- 搜索内容输入监听
        $Listener.inputValListener(".search", function(e){
            const thisVal = $(e).val();

            if($$.isValidObj(thisVal)){
                $(".searchIcon").stop().fadeIn();
            }else if($(".content .list li").size() > 0 && !$(e).is(":focus")){
                $(".searchIcon").stop().fadeOut();
            }
        });

        //-- 页面滚动事件监听
        $(window).scroll(function () {
            if ($(window).scrollTop() == $(document).height() - $(window).height()) {
                let { _current, _pageSize, _total } = pagingData;

                //-- 总页数
                const sumPageNum = Math.ceil(_total / _pageSize);

                if(_current >= sumPageNum){
                    return;
                }

                if($(".pageLoading").size() > 0){
                    return;
                }

                pagingData._current++;

                $(".content>.list").append(`<p class="pageLoading" style="text-align: center;font-size: 14px;margin: 15px 0px;">加载中...</p>`);
                findInsuranceInfo(false, false, function(){
                    $(".pageLoading").remove();
                }, true);
            }
        });

        //-- 搜索表单
        $("#searchForm").submit(function(){
            $(".searchIcon").click();
            return false;
        });

        $$.staticPushAutoBind();
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){
        //-- 推广费显示隐藏
        const promotionFeeDisplay = localStorage.getItem($Constant.promotionFeeDisplayKey);
        if(promotionFeeDisplay == null){
            $(".showOrHideMakeProfits").click();
        }

        //-- 页面加载显示
        if($$.isValidObj($(".search").val())){
            $(".searchIcon").show();
        }
    }

    /**
     * 获取险种分类
     * @Author 肖家添
     * @Date 2019/9/3 15:03
     */
    function findInsuranceType(){
        $$.request({
            url: UrlConfig.insuranceType_data,
            method: "GET",
            sfn: function(data){
                if(data.success){
                    bindInsuranceTypeElement(data.datas);
                }else{
                    $$.layerToast(`获取险种分类失败！[${data.msg}]`);
                }
            }
        });

        /**
         * 绑定险种元素
         * @Author 肖家添
         * @Date 2019/9/3 15:24
         */
        function bindInsuranceTypeElement(data){
            $("#searchCon>li:gt(0)").off().remove();
            let html = "";

            if($$.isValidObj(data)){
                data.forEach((item) => {
                    let insuranceTypeList = [0, 1, 3, 4, 19, 24];
                    if(insuranceTypeList.indexOf(item.id) == -1) return;
                    html += `
                        <li>
                            <a href="javascript:;" class="search-tit" data-id="${item.id}">${item.type}</a>
                        </li>                        
                    `;
                });
            }

            $("#searchCon").append(html);
        }
    }

    /**
     * 获取产品库
     * @Author 肖家添
     * @Date 2019/9/3 15:25
     */
    function findInsuranceInfo(loading = true, clearList = false, overCallback, isPageLoad = false){
        let params = JSON.parse(JSON.stringify(pagingData));
        let { insuranceType } = PAGE_STATE;

        //-- params handler
        (function(){
            //-- 险种分类
            const insuranceTypeId = $(".search-tit.choose-search").attr("data-id");
            if(insuranceTypeId == 19 || insuranceTypeId == 20){
                params.insuranceType = 2;
                //数据统计
                try {
                    countAction('xb_14', null);
                } catch (error) {
                    console.log(error);
                }
            }else{
                //数据统计
                try {
                    countAction('xb_13', null);
                } catch (error) {
                    console.log(error);
                }
                if($$.isValidObj(insuranceTypeId)){
                    params["insuranceTypeId"] = insuranceTypeId;
                }else{
                    //-- 险种类型, [1: 个人险, 2: 企业险]
                    if(isPageLoad)
                        params.insuranceType = insuranceType;
                }
            }

            //-- 产品库名称
            const insuranceInfoName = $(".search").val();
            if($$.isValidObj(insuranceInfoName)){
                params["insuranceInfoName"] = insuranceInfoName;
            }

            if(clearList){
                pagingData._current = 1;
                params._current = 1;
            }
        })();

        $$.request({
            url: UrlConfig.insuranceInfo_data,
            loading: loading,
            pars: params,
            sfn: function(data){
                if(data.success){
                    console.log(data);
                    const { tips_promotionFeeDisplay } = data,
                        { list, pagination } = data.datas;

                    bindInsuranceInfoElement(list, pagination, tips_promotionFeeDisplay);
                }else{
                    $$.errorHandler(`获取产品失败！[${data.msg}]`);
                }
            }
        });

        /**
         * 绑定保险产品元素
         * @Author 肖家添
         * @Date 2019/9/3 15:37
         */
        function bindInsuranceInfoElement(list, pagination, tips_promotionFeeDisplay){
            try{
                const showOrHideMakeProfits = $(".showOrHideMakeProfits").hasClass("closeEyes");

                //-- paging handler
                (function(){
                    pagingData._current = pagination.current;
                    pagingData._pageSize = pagination.pageSize;
                    pagingData._total = pagination.total;

                    if($$.isValidObj(tips_promotionFeeDisplay)){
                        $(".showOrHideMakeProfits").show();
                    }
                })();

                //-- html handler
                (function(){
                    let html = "";
                    if($$.isValidObj(list)){

                        $$.hideNoResultView();

                        if ($(".wrapper>div:first").hasClass("articleTop")){
                            pagingData._selectedType = true;
                        }

                        list.forEach((item) => {

                            const { listShowCover, labelList } = item;

                            //-- product labels handler start
                            let labelsHtml = "";
                            if($$.isValidObj(labelList)){
                                labelList.forEach((item) => {
                                    const { labelName } = item;
                                    labelsHtml += `<span>${labelName}</span>`;
                                });
                            }
                            //-- product labels handler end

                            html += `
                                <li data-id="${item.insuranceInfoId}" data-sellId="${item.id}">
                                    ${pagingData._selectedType? `<div class="unselected" data-sellId="${item.id}"></div>`:`<div></div>`}
                                    <span class="left productImage" style="background-image: url(${$$.isValidObj(listShowCover) ? listShowCover : $$.imageUrlCompatible(item.plogo)});"></span>
                                    <div class="right">
                                        <div class="top">
                                            <h3>${item.name}${(item.insuranceInfoId === 100155 || item.insuranceInfoId === 100153) ? (item.ageType === 1 ? "（成年版）" : "（未成年版）") : ''}</h3>
                                            <p class="icon" style="${$$.isValidObj(labelsHtml) ? `` : `padding-top: 0px;`}">
                                                ${labelsHtml}
                                            </p>
                                            <p class="desc" style="${$$.isValidObj(labelsHtml) ? `-webkit-line-clamp:2;` : `-webkit-line-clamp:3;`}">${item.productIntroduce}</p>
                                        </div>
                                        <div class="bottom">
                                            <p class="price">${parseFloat($$.changeIsNilVal(item.sellMoney, 0)).toFixed(2)}元起</p>
                                            <p class="makeProfits" style="opacity: ${showOrHideMakeProfits || !$$.isValidObj(tips_promotionFeeDisplay) ? 0 : 1}">立赚${$$.changeIsNilVal(item.tiMoney, 0)}%</p>
                                        </div>
                                    </div>
                                </li>
                            `;
                        });
                    }else if(list.length <= 0){
                        $$.showNoResultView({
                            msg: "搜索不到该产品"
                        });
                    }

                    if(!$$.isValidObj($(".search").val()) && list.length > 0){
                        $(".searchIcon").stop().fadeOut();
                    }

                    if(clearList){
                        $(".content>.list").html(html);
                    }else{
                        $(".content>.list").append(html);
                    }

                    if (pagingData._selectedType){
                        $(".content .list li .right").css("width", "calc(100% - 175px)");
                        //-- 选择 推荐产品
                        $(".content .list li").off().click(function () {
                            let selectedType = $(this).children("div:first").hasClass("unselected");
                            if (selectedType){
                                pagingData._selectedSum++;
                                if (pagingData._selectedSum > 5){   //-- 推荐产品 最多可选5个
                                    pagingData._selectedSum = 5;
                                    $$.layerToast("推荐产品最多可选5个~");
                                } else {
                                    $(this).children("div:first").removeClass("unselected").addClass("selected");
                                }
                            } else {
                                pagingData._selectedSum--;
                                $(this).children("div:first").removeClass("selected").addClass("unselected");
                            }


                        });
                    } else {
                        //-- 跳转 产品详情
                        $(".content .list li").off().click(function () {
                            const hasShawSearchWrap = $("#searchWrap").hasClass("show");
                            if(!hasShawSearchWrap){
                                const productId = $(this).attr("data-id"),
                                    sellId = $(this).attr("data-sellId"),
                                    uuid = $$.getTimeStampNow();
                                $$.push("product/productDetail", {productId, sellId, uuid});
                            }
                        });
                    }



                })();
            }catch (e) {
                console.error(e);
            }finally {
                $$.closeLoading();
                $$.clearHTMLNotes();

                if(overCallback) overCallback();
            }
        }
    }
};
