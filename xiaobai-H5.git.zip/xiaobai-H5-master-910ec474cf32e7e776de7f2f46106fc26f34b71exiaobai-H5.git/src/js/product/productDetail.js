

/**
 * 产品库详情 JS
 * 加密工具 -> 【https://www.sojson.com/jsobfuscator.html】
 * @Author 肖家添
 * @Date 2019/9/4 14:54
 */


(function(){
    $$.loaderRes({
        css: [
            "js/tool/rrweb/rrweb.min.css",
            "js/tool/rrweb/style.css"
        ],
        scripts: [
            "js/product/orderHelper.js",
            "js/product/productVersionControl.js",
            "js/tool/qrcode/qrcode.js",
            "js/tool/qrcode/utf.js",
            "js/tool/qrcode/jquery.qrcode.js",
            "js/tool/rrweb/rrweb.min.js",
            "js/tool/rrweb/index.js",
            "js/tool/loki-db.js",
            "js/product/min/yianInsuranceDeclaration.js"
        ]
    });
})();



window.onload = function () {

    //-- 产品库Id
    let productId_PG = null;
    //-- 销售产品Id
    let sellProductInfoId_PG = null;

    let shareImg,shareContent;

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 立即投保所需数据
        insuranceNeedData: {},
        //-- 销售产品数据源
        sellProductData: {},
        //-- 职业数据源 -> [key: 销售产品Id]
        vocationInfoData: {},
        //-- 保障期限固定一年 -> [true: 固定, false: 按销售产品]
        fixedOptionOfOneYear: false,
        //-- 职业选择 -> [true: 显示, false: 隐藏]
        occupationDisplay: false,
        //-- 订单token （2019-11-01修改：此token非订单创建时的订单号，用于跳转健康告知时抓取数据使用）
        orderToken: null,
        //-- 保费计算数据
        calculationDatum: null,
        //-- 投保标识
        terminal: "",
        //-- 企业险参数
        enterpriseInsuranceInsurance: {
            //-- 是否是企业险,
            isEnterprise: false,
            //-- 起保人数
            numberOfInsuredPersons: 5,
            //-- 企业险产品 -> [true: 是, false: 否]
            isEnterpriseInsuranceProduct: false
        },
        //-- 推广费 -> [not null: 隐藏, null: 显示]
        promotionFeeDisplay: null,
        //-- 险种类型
        insuranceType: null,
        //-- 微信昵称
        weChatNickName: null,
        //-- 页面Id
        pageUUID: null,
        //-- 分享Token
        shareToken: null,
        //-- 被分享Token
        beShareToken: null,
        //-- 事件日志Token
        eventLogToken: null,
        //-- 产品条件 -> [true: 显示, false: 隐藏]
        productConditionSelect: false,
        //-- 投保须知
        ensureExplainContent: null,
        //-- APP分享参数
        shareDatums: {
            url: "",
            image: $Constant.shareLogo,
            title: "",
            content: ""
        },
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader() {

        productId_PG = $$.getUrlParam("productId");
        sellProductInfoId_PG = $$.getUrlParam("sellId");
        PAGE_STATE.terminal = $$.getUrlParam("terminal");
        PAGE_STATE.pageUUID = $$.getUrlParam("uuid");
        PAGE_STATE.beShareToken = $$.getUrlParam("beShareToken");

        $$.validPageParams(productId_PG, "product/productList");
        $$.validPageParams(sellProductInfoId_PG, "product/productList");


        //-- 页面初始化
        pageInit();

        //-- 浏览记录
        browsingHistory(sellProductInfoId_PG);

        $$.alert('尊敬的客户，您即将进入投保流程，请您仔细阅读《投保须知》及投保险种的《保险条款》，并特别注意条款中的保险责任、' +
            '责任免除、投保人被保险人义务、保险金申请与给付等内容。为保护您的合法权益，在确保您个人信息安全的前提下，您的投保操作将被系统记录并保存。', function () {
            timeoutVerification();
        });
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

        //-- 加载产品库详情
        findInsuranceInfoDetail();

        //-- 分享产品
		share();

		mta();
        $$.changeVersion();
    }

    function mta(){
        countAction("xb_2001");
        //-- 渠道事件
        const channel = $$.getUrlParam("channel");
        switch (channel) {
            case "topicPK":{  // 话题PK
                countAction("xb_3019");
                break;
            }
            case "productSpecial":{  // 产品专题
                countAction("xb_3020");
                break;
            }

        }
    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 产品介绍产品详情切换
        const infoTit = $(".main-info .tit");
        infoTit.on("click", function () {
            const _that = $(this),
                tips = _that.attr("data-tips");

            infoTit.removeClass("active");
            _that.addClass("active");

            if(tips === "0"){
                countAction("xb_2001");
            }else if(tips === "1"){
                countAction("xb_2002");
            }
            tabsHeightChange(tips);
        });

        //-- 点击立即投保
        $("#next").off().click(function () {
            //-- 协议条款
            checkTermsOfAgreement();
            countAction("xb_2006");

            const insuranWrapEle = $("#insuranWrap");

            if(insuranWrapEle.hasClass("show")){
                //-- `真`立即投保
                immediateInsurance();
            }else{
                //-- 打开投保窗口  (关闭登录流控限制)
                // if(!$$.checkLogin()){
                    // $$.gotoLogin();
                    // $$.confirm({
                    //     title: "亲，您登录后才有投保奖励哦！",
                    //     onOkLabel: "马上登录",
                    //     onCancelLabel: "继续投保",
                    //     onCancel: () => open(),
                    //     onOk: () => $$.gotoLogin()
                    // });
                //     return;
                // }

                function open(){
                    //-- 投保窗口底部边距
                    const paddingBottom = $("footer").height();
                    $(".insuran-con").css("padding-bottom", paddingBottom);

                    insuranWrapEle.addClass('show');
                }

                open();
                recordEventLog("T2020071315073025269632");
            }
        });

        //-- 点击背景关闭 [立即投保窗口]
        $("#insuranWrap .bg").off().click(function () {
            $("#insuranWrap").removeClass('show');
        });

        //-- 跳转 保障详情
        $(".plan-detail").off().click(function(){
            const planId = $("#planList>.planItem.choose").attr("data-planId");

            $$.push("product/guaranteeDetail", {planId});
        });

        //-- 跳转 保险条款
        $("#tkLink").off().click(function(){
            $$.push("product/clauses", {productId: productId_PG});
        });

        //-- 是否同意 -> [保险条款、客户告知书]
        $(".whetherAgree>.checkbox").off().click(function(){
            $(this).hide();

            const isCheckEle = $(this).hasClass("isCheck"),
                hideStyle = {display: "inline"};
            if(isCheckEle){
                recordEventLog("T2020071315071863169632", 0);
                $(this).prev().css(hideStyle);
            }else{
                $$.alert('本人已阅读并知悉同意《投保须知》、《客户告知书》、《被保险人同意声明》、《个人信息保护政策》、《服务协议》及《保险条款》中的保险责任、责任免除、投保人被保险人义务、保险金申请与给付等内容。');
                recordEventLog("T2020071315071863169632", 1);
                $(this).next().css(hideStyle);
            }

            //-- 页面状态缓存
            pageStatusHandler(1);
        });

        //-- 收藏产品
        $("#collectionBtn").off().click(function(){
            collectionProduct($(this));
        });

        //-- 页面滚动监听
        $(window).unbind("scroll").scroll(function () {
            const tips = $(".main-info .tit.active").attr("data-tips");
            tabsHeightChange(tips);
        });

        //-- 找客服 二维码 绑定事件
        $(".customerIcon").on("click", function(){
            layer.open({
                content:
                    `<div class="popupContent">
						<div class="question">
							<b>扫描下方二维码，添加小白专属客服</b>
							<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMEAAADBCAYAAAB2QtScAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAADv9SURBVHhe7Z0JkF1XeecltXZL8r6yOOwF2EklqcKQTBIqhACVOCFAwJJ6kWRjEwImgyHAgDPDzGQCxBtFBYZsgDPlpDAEh5gQVqdYQwB5kWV509qyWntr6305c3739b/7e1+f9+59r1+32tH9y3/f2/d+5zvfWf7n3nO3tyCUKHGGoxRBiTMepQhKnPEoRVDijEcpghJnPEoRlDjjUYqgxBmPUgQlzniUIihxxqMUQYkzHqUISpzxaEgE4+Pj2XJsbCxbn2uS72wA3yBVrjx4+6K0eXmonEXjYXvKdi6YQspurtgMGhLB6OhoVtkjIyPJAGabwK63AviiTHBoaGjSf5F8/H6ftgipUwu2EQvb8+IZHh6e3I69tZsrWpyufmHZDBo+HSKju+++O7zzne88bWw1KBMd7+abb24oL1X8O97xjmnp6vFd73rXZFpooW10ap/uxhtvnLCqwNo0GkMreMstt0xEUkEq5rkk/bIZNHU6RIYLFiw4LVy4cGEWQyuhcj372c+ell8eSOvTFKHyTEH7KKtNs2jRomy7hbeZS1511VUTUUyBeE5XTAwEzaAUQYTK9axnPWtafnloVgRF4NOkROBt5pIpEaTs5oqlCGaAUgTNsRRBIoi5YCmCanibuWQpAhfAbOHVr3515l/nmVYEiuflL395VSzQ4yUveclkei2FmYigKLxfz5S4vU0REZxzzjkTe2qju7t7WjpP6svD2xQRwW/8xm9M7Gk9fF6lCEws0KMUwRRKEVSjFEFEKYLpLEVQA0VFgJ1sZ4oiIvilX/qlqligx0tf+tLJ9FoKrRJBvTJbn+RNh1Ys2iZwzwK0tbVVpUuJwJYHnnvuuRN7aqOWCGw8sykClW+m8HnNuyPBpz/96dDV1RU2btyYLYvSI08EVOhXvvKV8NnPfraK3u8nP/nJbPtnPvOZ8LnPfS5bF+qJwPupxw0bNoTOzs7szqmH92tj9fHojrG1gcTu81Ra9rH867/+62k2ntdff32V3zvvvDMTGHFp2WoR2AGCOkrFVYvY05/8IOPzmnciaG9vz7avWLEiq9ii9MgTAZ1lcHAwW7e0PhlRH3zwwar9Fvo7JQLrpx6Ja8mSJdmyr68v82dhfdoy6NEHgXWJYGBgYDJeyDabJ+XSowqkYXnkyJHMP7S2ltwUtH6hYtPRZzaOBMpr6dKlybhqkZg6Ojqy8lv4vOadCFAwDUGB1ShF6FHkdEgdwNL6lAgA+7C3YBtIicD6ySP50GjeP/B+AfnSsLXi8eXC1ua3ePHiTETYycexY8eqbFKknNYvtGVlfbZOh8jLxlKE1CtHA9Ja+LzmpQjYTiG8bT161BNBPVifcOvWrdl2yqAOw7oIUo9NNEri850apGw0sqXiUUwW2Hk/3r63t7fKJsVnPvOZma1AWnyJ2EgENg7tE5udE3ibIkQEHt6mFIGD9QmtCOzSdkBGSPxbej95JE1KBNYnRwsfh0BatmlpwTbrhxFS25UnIrA2Kfojgfzq9INyIAJrA7CxZS1F4ALwmM8iUDnYzimFOsCePXuy7RbeTx7xpQ5ZC4pBdjYe4lBZi/jBDjFA1pu5OkSegCOTJvXUl/YTj+rIpitF4ALwmO8igDSqOh2cKxFYKBageOQnD6STLWT9vPPOm9hbG14EysvGIhFY356lCFwAHvNJBKShUemcGukoizocoyg2u3fvnuwIovUjqrPaDqt9rBcVAf6tLf5Iz9GJdfb5eCzYrzwVz9lnnz3NziN1n8DDikDlVHwiNyk9rE9YiiBup7K8bT16tFIEQJckOfTbxoW7du2a7Gyi9SOxsK7TKFE2rOeJgLzlX+uKx/q0dqIF+ciW2EjPHeO8/BsVAcS3L3MpAheAx3w7HcLPG97whip+8YtfzPiP//iP2ZKK9jbWBx2BG0tK94UvfCFb2jKyntcJ2e/zgfIrvulNb6ra/8Y3vnHCwxSsPfF8+ctfniYWj2ZEgMhUXvG+++6bsJ6C91uKIG63HaQIPVolAh+H9aNype4TeHL1BSgNS7sfv3kiANZeSw/ZiIjQI6/Dp9CICETiK5KXTQNLEcTtauSi9GiVCDytH5Xr6SiCZtCsCIrApoGlCOJ2NXJRepQimGIpgmp4m1IEDtZnitZPKYJSBIXRiAhahXoiUDyp9wk8aVSgNM2Cqy/4UzyebG+VCDzwq3S1mHqfwNv4xyaAt5mtZ4daCZ9XKQITS4qlCKZYiqAapQgaRCmCKZYicAHMFn7zN3+zKp+ZikCwYtB66mUYDysC24Htsogf7HxaoVY8tURAWvmZbyJgEGs1uIlIXajM4mkXAYVtNRlFzj///KrCpjpLSgRf//rXq3jNNddkgoL4xT8ViQ+N3OvWrZsWg4c/EjBZtfl84xvfmOYj5Udxyk+qXN4Hsfu8yF9xsJxPIiCmCy64YFo5WkHa0PYLeNpFQIFbTQqp52jqdZaUCNgn0sl/7ud+bjI9/liXCPjwLXjhC19YlT/0sCLQYxRAsbDUIwz1/CjOVLl0BPBv5VEXKpPykx/2sZxvRwJI2aAtS7O0flVm8bSLQAVtNX3B2SYoniIiuPLKKyfTi4Ke0eGlGrvf2ghWBKLy0WHaP2MDPRQn+7QUJE6bHiIu5SVqn+ppPonAxt4qWt82LzgnIgA0NJn5AOaCqgj7YBlIicCDRpUPLQX5Sd0nsMCOR5V1BJCNOq1s2G99QA9tT8UjyEako1uQF9tsPHqfgH3EBWys0ItAfqBsX/ziF1eVC3g/XgTYYmP9zCXn/EhAIeeaVC6FJQ4RzKYIbF50CjqZ0msJZAPmSgQMBjY9S44EilUxsc+Sclp4PxARKD0E6twi9W4hP6eLc3YkoHI1wsw1qGTyZgnUOLMpAk/S2U4ufxqN9benh7bLnqWHbEQvAuYOvi2OHj2a2RKPBo08eD/Uh+padQPsegpK83RDQyLwlTLX8Hnr77kUgehHRf2dsoUe2q40LD1kI3oRCMSvMkgENqaisH6AXdfAUwTez3xHQyJoFTRaqLKaJQ3D8hWveEXW2JYW2CACtmsUZ11xyE9qYpyiOqT8eGqfpYe223TEAFgSm00P8cu+WgT2kyu6sqbBy9vWAzapdioKm8am838XBWkUD2jWTwqnRQTqdEVuKtWDGreoCOhI6hi2c2h5+eWXT/NjSRqt29MNyDb5Zl3bRQ9tlz8o6LTCXwLEdz2QhiMBdiLpGhnFAX4E6kXx2O0pWDtv24gfD9njYyZ+auG0iABQmPe///3ZqcxMiADuuuuu8MMf/rCKHvfff/80G+/n3nvvnWZj+b3vfS+sWrVqsvOqw//7v/97+MEPfpDZsFTns/TQdtKz5Ot1ikNLtslOtDGn+MpXvrIqZuLhW63W5nd+53cmokiDzrVjx47M1sZDm9UDnVN5KJ3/m2UzIuBTm6SdiZ9aOC0iUGXyyqBv5EaoEZTGbhTE4P2kvjbhYe8TaOnRjAhaxWbvE3i06lFqz6J+PPjmaiv8pFCKwPgpRTCFUgSzjFIEpQgaRSmCGqQiYCmCKZYiaBwNiUCdN/XskCffvQdK4zsdSz7b4SEbkaclQcpPPbYK3m+rXq/0SPnxwK+1gR7EZ/cX7Sw2DeRqmoe3KfIAXep9Am+TYhH4NKf9ATrPUgSNIeXHoxRBNXyaUgSOrYL3W4pgiqUIXACeEgEgHaRBJADIF808rA8oEQDvR76sTzEPKgvQeurmnffLL8HIniUd08fTzE1AfCkP+fFiSomAa/O2LFYEigmbPOjZJ6WVCPAt/3Y/TIlAecqWF2A8rI9aVL7KW0tAPUA/9zrtImAiZfn2t789XHHFFRmpUKh9W7ZsyZbHjx/P/FnIRly7dm1NPw8//HC21AszlrKtR3/n8dd//den2VifNOyLXvSibDs/BCgbH4+2W+aBWJReS57ktD7IU3nBRx55pCp+YEVAJ6FzWx8pkg+26lSUkxd6bBkh+dn877nnnqr90O6HO3funIhsCopPfNWrXjUtHXnb/Lmxqv5HXUEfT09PT7a/UbRMBOwTaZRNmzZV7acx1Fj8Fpcgn4L387rXvS5Lr5GFRwnkh98qA7/6q79alRdUo9YiNvghH71Z9oIXvCBpJ9o7uPwMFUviUbyApR6psCwK64cyWx82L9lRBhFIBNiTnjTLly+v8uOJvWJmqTIqf62rvkTulFs/pNVR0MbkIf/i61//+iq/dHA9MoJPyG+W4VsDF0t9XNmyGcyaCPglRyoOWhtAAbTu4f285jWvyfXDbXTtE5WmHgXywU/qAbpafml07Ve8aiAaUHZiPSi996M8RDqDt4XyASQCpWHd+6lFm04kLeVhqXoSEYG1JT7FLiouC/KxTIkAX8oX8vEtawPs33Z7o2hIBICCpURgQTCIgIJoP5UkKNgiQfNyua1oqM4PWPIciY2lCK0fsdnfLPPxaBSz9FCeKWgfjW998LeFTa91LwLo/Xhik1q3ZLsHIvB2tWBj9fH83u/93sSeCuhjil3xpL5A1yo0fSSwQUL2iRTCf4aRpSAbjRS1yH4mVqo0+bI2gCOB4hCxq0dsgHyw5H0C7yeP+PLxIH5vZ+Ht7d+WilP0RwLqRyOvYOcEovWRIvWL73piwc6jURFAQD42f0Tgy2X343feiACo43r4yiD4WkcCNVreHWPScHVII60anKWgSvNI+bNU5eq3h2GRO8YWxAHt1aBa8XiobnzH429t88CvtYWqC7WJFYHKmGovD8WjNJ5s92j2SODj4fchvB+odmF93oiARqhVob4Aoq1cC3wxAnh7S9LY+wQ+79Q2IeXLrot2VCoiAptfKp4iAgDklxp9FQv0SImAbbZd7MRYNkUg8ZGv0lmm4kmJoFZ7CKn6SYnAxzFvRGBHHU81nCXBp0SAPUgdCWx6GuVrX/taZquGttS2VMV6v/Kthvb5wKJHApt3MyQt9VIrHm33IJ0vk4edE+CDfFIxWODX5y/io9bEmGe2bCzYyLe1y2OtI4GIX0RA/oLStgINicD+3pdHqvJY6rIi64KCzxMBRAS6NObBdjWMh/epeNT5LNXI/GZZPZCP8kvFUxSkJw7Rx6PtPg/ytuWCHlYEtfx4sF/148l2iE/vxx8JyIsYxaIoKgLqTXUPG8mjHhoSASCIm2++ObuSwkRSZBQV6Uz83pYtCBUq4AOkRGD9QGxsPp7EsXnz5syfhfVJJX7rW9/K/PELlT4Pbe/v759InQYVzw0c5etjaYT14mBJHer+hdCICCB1ztLH+rKXvWzCego+f0u2QV4/tX4uvvjiybyUn/Z523rkU43WT4pr1qzJyiG/rJ8WEajz5l0iBXlXh0BKBB5cHVJ6b8s2mHqU2ttyRxEo72bhH6Vuls2gURHUYpFHqVNI+TpdtP1ppihF0CBKEcwP2v40U5QiaBClCOYHbX+aKUoR5ADrOB2O5F9FBAvJe0GMZ2F1HmJlf4W19k04rtDD7jP7MxGQp8l3yqxyflyKoHE0JIJ68EHOxfsE9UTQCOSbCZfNe8ECLu+uCAsWxfXIhW0rwuKlS8KiuK9t4aK4jasmi6IDnFQWsavGFToky4kdWQeFGE0YZpxciazYjI2NhjGuwsRNVkwwi6ktMoqAv9valmQpRwM364az9Md6j1TbZ6y+FzGbIigCn8Y/NgG8zby6Y1wLPuj/FCJgxI2df2VcXxE70qKFy8PCRW2RMd9FUQyLF4W2uH9spHJHW12RC4nq9o1yNIYyGn2xXLosCnBhFKJh24KlkTGWeCSi7CPDMdeRmDLGACpHgulHTctSBNUoRRAh37VEgAAWL1gSR2EEsCAsYSReuCR0dK4Pf/LB94WxIS6txhE8/otyyDpz5fSpuX+jYyMZb73tlnD7HbdN8fbbwx23fSLcEZe33/Hn4c9v/bMwMj4ShmL/HyLTiKO9x2LsjPy1hVCKoBqzLgIhJYJG3ywDKRHwZbg8kA6mri3XFEHsSIuWrIx5LA8LeDJ0CadBC8J7bvyjMByTcBWfTp8N25lf/ETiT9S21L7UfmszNrG02+OxhjyHI0fi32PjQxlH4z/QeyyKYPLIUTkNWrokrptyNSIC1RtQu9VjCkqvm5u6+SZ6EWDPjTdr97QQAYdhS154UeEBhec7mezjFUXW3/KWt2QTTUvv5+qrr85+GAOyX78PAGkUKmr16tXT/Hg++uijk3F4KM7pIlgQT3liY/ACTez8zAV27diVjfQDpBk8FleOhHCyJ4S+7shdFZ7Scndcwom/WWfbqT0T1P4iNhP7B3aE0M/2mN/R7XG5N+riVBiOghkbHghHjxwKixfHo1YUwUKEEGPujfMEW6fbtm1L1lEerQ/4zW9+c1p9efzbv/1b1mZQfryYeKrA5gNpV4Qgm6eFCOhIljxiQYdTB7PQNkYACmtpfZD+ta99bVYJGvW1riUVtWzZsml+LLHjVTygt9EsFI8XgSaYzAGWRB8fuOk9mQDC0Kmw/4d3h6/9/iXhga5nhcc3PiPsvPay8OTGi8MTmy4O2+OS9Sc3XjJB//elE9TfRWzYd2l4YuNlYfuGy8KergvDjnXnhIc2PT98sfOqMLjtO/GI1B/Gh/vD+//4PbHMjKSVl3uGBuN2U6/cBU7VUy2qrq0PyGmorS9owcjPjwuqvUTbuSH7U/lC2T4tRQC1XUtR4uASKRVg6e30Ug0VYpeqPJbaVo+8t4vPUff8C2A7SImgjQlo29LoY0l23t0/PhZ6ogB+svZnwr6uc8LB9hXheGTv+iXhSMeycKhjRTjcsTIcjtuOZFyZ8Wi21LZ6rNgdbl8+ua7tx9YvCyfXLo15rAo9XavCkQ3Lot8loafjrPDT9ZeFk7vuj0eFk2E8zieYF6jsXK2y9YoIbN3UI3Vb9AE6aIENp7P40X67bmnz9GT/00IE9aBK8+tF7hPYN8u8bSO09wmUvz1SseR5lOp0cRRcFI8y8ZTo2ms3hewYMnQyfO1Nl4Z9nefGjmo7KZ1W6yvCvthBD0dBHIod9GD7OeHE2lXhQOfy+Pfy0GvsPHvXrYn7l4f9GxZH/3F9/fJwMKY72LEmE9LRiXwQWUUoFe7vXB2+2vH8KIKj4VQU63Wbro8dtzKKjo9WnwJ2d3dXldPWra1rX++qK8E/QIdQVL+ytT8zW5Q+HpYSgfzaPGaKWT0SWMrGLlMisGnopP7NsqL0fmvdLLN/J+cE8ZRiUZwP3PyhD8RToWgb5wBbNj0769y+A1v2v+Ws2IGXhYNdbeFY+7JwfN3yrAMfbo8jeHv9tMfXL46j/tJwZP05WTqOAEfx0b4waQ+J5+GNz43nez3ZhPm/f/CDMfZYDzH2ypx6ql79kYBTDo32vv60jXVfd4hA9hA/ADvaDiAC0lq7PJInvlhXHP5IoDxUJrEZtEwECjZFvXMLOB1RsCkRWFIJHE5tmqLwvlJHArYTmyrfp4F0oOHhOMkf6a9crTm5JzzadUk4Hk99/OhviQAY/Q+1nx1Pk5aEo5EH42lM7/rV4ej62iJghO9tjwKIo/6B9gvD8WtWZ+kPdC0Np9aSZzrd0fUrw+6Oy0I4ESfLUa7D/UyWh2L4Y9lpnS1T6uqQzr1VD/rhPnVmu54HW8d+WRT+6JESgW+zOfvhvlqwwXgSLIUicCpSlVlUBKDRSvS+UiLAv69IT0QwGk8nxseGSRxC396wc9Ol8bQlzgESnVHct6ktngbFSewHXhu2ve8Xw1Pt58WOek442mnnC9N5MM4nYHfnReGR9/1K2PXffiXsjef/+zfGI8m6c5Np4NHI7s5Loki3xzCjCIYHQt/gQBiN69zjyB7zmChTSgS0jx31+daP6qqRure2Wm8kvaBYJAaJwIpS5RHnvQigwMgOiohAb5YpjYUEpYqx8H6YGANs1Si20WuRwZ8J8cDQlAi2b7osdrzaRwG4v2tJ2PH2F4ZwcHMIx7eG7R95c9jfcV7ojRPbw/GIkEoDmVTv3Xh+2Pe/fjeEU4+EcPgnYccfPD8cWL8oOz1KpRG3b7w0ztx3ZHcMBgYGowiGw/DIaBRBPNrVEQF1q3qQGCSCVgFfsFZ7WbCfeKDiQQTyIT++7ea1CCABC1Q6fOMb35i0FUmDCHS51QMftSrV++Grd/Ij+vPOFDkSDMVKH5x4NIJr9U9uuiTZCS0PxknxYzddmV3Pz97IO7I1/PTdPx+OrVsdz/Nri4DTpwf+6BfC+NEtoX9sMIyc2hMeufGqcKRzcTgeBZRKIz4ZxRn6d2aXcfv7+sOpgf4wNDJUJQCYEoEGBBERtBLUnd4QTLWXBTa0jY3JTozZLxtbrnkvAk28RArw+c9/vqpTpqiJcS3ihwmah/fDG2E+rbeZzpGwfPGisGT5yvCxW2+pHAlO7Qg7Nl6U7ISWXAV65B2/EIfkQzGakTix6A/HfvB34cmNF8QRvfZRZEfnxaHv+3fGAoyGAe5Jn3g87PqD/xIOd54V9ne2JdOIOzfE06G+OCeIYX781ttDW4x90ZJFYdlZla/lianTIZWZjqrOmocf/ehH0+q0FtWp6QfkY/GlL32pypabZ9jT+RWztqkfad2Wa96LwFKFSz075NHso9QejGzWD8siqNi2hdtuvy32rcqRYFfsbPXO6zPGjr7zhpeGcSaqHIFG4+lU/77wxP98XXbJlHsKx6LNoThRPty1LPR2nh2FszQ8+qdXR7vu2CsHK49kHNkWuq+7IhzsWhlOdixO5zXBHRsrcwKS8ZwRV4aySTFXiVhOMCWCZpD62kQeU/We945xUZYiyEHTIsg6UkUE2SXSeHqyq+uyXBFw2rMz2g33fDce3+OpAIPfwMnQ+52/ikeDZ8QJcrRbvzQc7VgTR/ll4dA6RvJzQt/34lFgsD925DgixyPP8L7vhyc2PCPs5x4BN+QSeUHuSVREsCOL+zZEEE+D2rKyVp82lCKoRimCHDQtgrUrwu6u88OxzXfGU4uKCIb4X9+e8PCNPx8Ox3nBwTh5xlY3wB6+8Wej/wNhLNqNcnoyPhaO/PgzYc/Gc8LheMQ40Fn7rnMpglIEE9a1MdciONK+OOztPCfs/4u3x94/EKcFp6K3E2F08HB4/P+8IRxYf37o2cjNr2VxhI+CiEeGR25bH+1OxCPHkSiAU2F8sC/0fOLaKBiOLCvjEaNREfDYB2UtRVAPLRNBI8iuskQUeWzCg7SyrScC6zOP8sOdVA/eEBgd4YFAHlduQATcLY6T48fe/cvxHP9IGD7yWPjqh98Uxnp+Gk599aNRIJeGgzwawZ3heFTo7loTTt73F3H/A+GfPvj7YeToE/H0aX/Y9q6XhUPRH88knYz+knlF1hOBh39sopUsglQ6z7lEKYLI2RABo/ux9iXhsU3PCCPdP4rn9pvDT9/24rD7r+Jotfdfw+NdcV4QJ8eVRylWhyc3XRDC/vvC/o9fHx5621Vh+MCDYWTnt8Ijb70sHOhaFfbFyfOxtc3NCTxKEVSjFEHkbIjgWBy1eTyip/PcsP+T14VwfEv4j+uvCA9sem7shV8Oj1z3nGze0LueO8irw7brnxnG93w1bNv0oiiCK+OZ07aw82OdYX8XD9WtjPOH6LfO80qlCJrHrORGR/XXmdXxgdb9V+qKFD4lgu9+97sTe6dgfaZIOrsOt2/nuZtqIIIxK4I4sS02J4DxaLB2TXjohngOfmxz2HHbhrCz65Iw9B+fDFuvfVac6K4Ox3iWqGNJeOKtzwlDP/hUeKLj4rD7jo4Qen8Ytl53efYU6cm1K7PTIU2gU/QiuDXOYXgfemmkRxER2PopStLQ7vY+gG137fPX91MkHZQv66fVmDXJ6ZMr3NRQwSgQVOFSBZNtLfrOy40Tu18sAt3AEVN+mp4TZA/YcWd4dejecG448HfvDie+/5fhkY6fCYNf+ZOwfdMl8RTnrHB83erQ27ksPLrxuWHgyx+K258VTv7gL8OT/3dj6O5ckz0ifTIeMY62nxWFUPsBOi+C/oGBcOLEyTA+PBI7Xf7NMg9eQqJOmhEDVDp+vVJtXfQmHCC9zVuPTcwGZk0E7e3tWfD8XpYKRCEkAMi3NrVNlG0tqoIhjURH5vfDrA30flOUrfzwhpr1AZueE8TRvafz7DiSTzwKccPPhPDEl8LWD74u9P39e8JjG58ZumPHPrp2VfaIxUPXvTAc/n//NWz541eG8SfvDdveenk4HkXw1IY1USgrskcterqKXx061d8X+vr6GX5jOSp3X0UeGU/Vh0jb8MBhrYGhFvXxZag6lQgkBESgDzvXIrYaPOUHERQVUKOYNRHoN8soAEsKI1BQQGE9bGOliB+WVJDfZlkPqmw1mNKk/DR/JOANsDXZuwAHO1eGvRtWhac+ek3o/ZePhd57/mfY1vXMcDju61vHneMF4Ykbnh16vvA/wvFv3BK6b7km7I+d/ug1cb7QsToc6lwRTqxdnc0PknlFehH0DfTHowEiqH7LDCKCeqBuEIHqpyjxTR3adS5xC2p3LWtBIoD4gJxZ5KVrFrN6OmQrHoK8gviKtZQfuw5V8ZZ5IA4JtJ6fpkUQz98ZwfdupJMvDSeiEHZueHY4+fWPhNEH7grb4vqBeLp0sPP8cCSO8I9ee2EY/uk/RBF8LGzfcEHojadAh96yJruCtD+mRQSHOms/QJc6Herr64sF5WnL/PsE1IdtG4mAerFpG6V+zFu+WaYGPw/vx54O6ajSKrRMBAQlEiQiUKdSJ1Pw9SjbFOXL+qzFlG9R8PGl2KwITsVOfDCe6+/dcFb2XvDRN7eFno5V4f63vzSMb/ls2HX9s2LnX529pslp09YNF4axB+8MW65/QTi8gTfLVoXea86No/+ymBdzB+4VFJ8TVE6HBmLDcHSdfjqUgq0f5gQ2TS1Sf/Xof9HetoOlh/fjnyKtla4ZtEwENmAqh+8OWcUTsLWpxXrQOSH+6cBqhEYvkeoIoKsU8tPSS6Rx9D/QeVboXRfnBe1LI5fFzr487GHk/9t3hJ+87YrQs351ON7RFo8Ia8KD77wy9P7t28JTnRfESfDicCCmPx4Fwp3kQ+0rs1cu673S6UWgS6TL2haHUV6KqAPaRvWpuijyKHWRO8YpEfgjbt7HtxSXjY/laRGBMk1lboOG+viWhMDSFsAuLetB+ZLO+qAxPLxfS9JYEWlbK0XAu8W8S8zVH9766okd/UBc7tlwURja8k9hvOeB8Nht14ctN70iPPrRdWF853fCwCNfDVs3Pj8ciZPpw/H8f/81S7J7Dbxoc7QjCqOz3ss4TgR31L5PkIKtE9hqEdi+422KikDr2t4qNOSJS1wUoogIPvOZz2Tb7aFL++y5uE0D60H52sZivdEjgdL6OUFrRRDnAvEIcDSe9x/uWJ49Pr2v/YLw6P++OoSBXXF0Hg5hMJ6zn9wVwvDhMDoe/+7bHx75s7Whu+vsmI6jx+rMV+Wd47OiCNJ5wZQI+NoE9wkSzVUF6pV6FKkLvWMsMojZIztoVASQ/oB/a1PkM4ye+GgVGhKBfj5IBbLwQXIksNeFqUDts79jpm1iPagh1HnVaM3cMbYNLrZSBFzfH4gj+aH158UJbRzRoyg2v/3lYWzvj8LI+FDoj/1paIRB4lQYGRsNfXGddw7GDj0QHnr3L4bemP7oupiWRys6FsbTq7PCsXXF5wScDvHV6qWxrsZcW6VAXdgXVjgSaABTO85UBPjAF3lYm6eVCACF0Y9526A8mMjYgO1S60U+yJuiBfH43/bKgwRs44KtFAHfDDqxbmmc+J6fPUO0k6s/W78WBof7w/B47EzRFY9YD4z3xU4aB4oogsFYjtGRY2H8ka+EHW97YTjReV7s3FxqXRZ6owiO87BdIi/oRXDLrbdmZUo9RZqi6kRgYsx21REddyYiAOQBvZ8UUr4siatVaEgEqqhmfqTDUtuaEUGrCk9ZrE9YSwTNPDbBJ1B4U6wnnsdnL89/fEMc6QfCEFU4EkXLJ9VHR2LfHwjjYwPxFCl2kHiKNJi9ink8PB7tD3etyXwdbD83u1rEaZXPR0xPjNOPUqfo4e8TpOq9URE0gpQvy1b1A1CKYMInbOWRgNGb94z5aNbujefGXvXVmGfMl1O6OPKPx6MABwS+DJT55XRoLB7VYp682B8e+5fQzQQ5du4DcS7B6VAjd4ztA3SlCOqjFMGET9hKETCRRQCVznlRCN3fiXMArtuPZqdDY/iKImDGNBLXxzkliiJg3+j4YAi77wt7Y6fmXsOheCQ5FgXBJdd0XqUIZoKWiUCTVlE3y5hksbSTIQrAkt8n8OlkY22VXv58mhTzkBIBvx1c7WdkQgRxdI4iiF01drLKi/apjmh5fO2a2DEr3x7t6bgo9N17a/R0PAzGiWH0HAMYZlKQdfyxuD5Gx4/58V7x6MihMPSVj4XuKDbuPDMvQFA8SZrKS6yIoPKi/a133BEWtcX6ot6yn52qrldbp7C63GPZd5qsfarTFfnaBN+S9fB5pZjyZUk/aBVaJgLPer9U0wjr/VJNPeahqJ+xMBxGuJrJ/8ajGqII+O4Qn1lMdUSRdwQOxFH8WPui0Lv27LD1j345hCMPxH4fz/pjZx+n42fL2OiM/jGngThX6Gd+0PtwuP+dLwknogBOXRPnFu3nZc8fHe1YlMwrYxTbjo0XVo4EUWPHhwbCyYGTWR5Lcj6+BWyZU0yJoFmk/HvOJUoR5DCeoMS+X3nyURPjHRueEUfl2jeu4P4NbdkTpMfWnR0OdpwV9nWdG7pvfnUY2f3tMD50MObfH0f9keidE6PYa3m3eDhu3/G98MSfvinsvvbSKKDFmdgOdJwdjwarsnsHqbwgp0OPXXtZjG93JoK+gcEwdLIvjI4NZu9J2zKVIqhGKYJ6jJ2HETqMDIaxwaFs0hoGdofd8TSF8/R68wLO5SuPQK8M+7uWht6NPE16fth6w4vC4x99Q9j/Dx8IA9/9XAgP/Wvo//7fh6fu+mDY8ZHfDY9e97womgvjqL86HOuic1fmBNkcY32diXHk9o18gW5XLFwMs38wjB7nytPw5C9eqlylCKrxtBGB0IwIOMdkJBd03knDwlT6CheFgXjaPh5PYUaH4mkRghiIp0PrLwq92alJ7UuWR9bz2wIrol1b7PxLQ0/XWbFz827Aqjiyr47n++eG3RsuyB6j2Nt1UfYg3YG4n7fHetuXZB2fIwh5cOe58pJOdR5HM3FEAaznKtSKsLuTb5Fuz+4+nxjoCwMn+rNyLllW/SZXoyLQzUludDUKtT8gPfEUebNsLjFnIqDwtkKKgufRNbnGb/1OO0UL8tUnV/AjH3kg2gULF4fF0f5DH7o5m8CGwX3hJx3PDYfX8bmU2iLQ16Urv1BDZ14dz+1XxxG78qpkdgOsY3FlzhBPeypp1sR5xMrsM+zcX0AUvIPMTbKjEzfNfD6HEUDMh989uP+a2LkH9kSpDoXewZPhZF885WLyTUFyqt7WnSf1D1P78sjVIbU9d4yhR+qTK3OJORGB7/zalkcq7zWveU3mz3Zeu16LFvjiWRi28xYaS3ywXfuTjP8WLV4QFscjwoa3vi2OsFwm6gt3t/9ieCpnTnAkOwJUOvbReFQ4nr08syweEaIQogi42nMw+77o6jhfoPOzvSIQnhFiIkzH5hSI94yx90eDQ9Fnb/RxOO7ncey71/1sjO9kFnvvqWOhPx69hvmQ1yA3IarL5mHrzlJ1jQh43IX1oiSNRCAhsPRvlp1xIrDrecC23m+W1aMHH+RluxqI9fxYxrJfrMx+w3jx8vhXLMvIeBjcdl/4cfszY8dbEztt5Vyd0xHbQU+u45SGn1HiKMCVHTr90uxIwFGh8v5x7MDsmyD3Ahj5oX6dBsFUTosm8og+2UYe/M27BgfiqdUD6y4IA09+Ozvl4CbcwYP7Qz/zmPhH9nNNOUW1deepOitS75bY+zfLRIunlQgASs4TAYVHBPbQp4KTvhFYEaTyqkUL8r7iiiuqDun4LHKOy081cdOJn0S96ab3xAIwqvaFE0/8R/jXrueH+9ufHXa1PyOSX5e8MDyx8dKwI06cd2y4NGzfUPkly2xZtX7JBM2+WiTNRLodkTu7LgiPxzy2R/+71l8ctrY/J9zT+Quhf9s3YmiD2Sh76NCh7CdW9Q53HmgT6rdWHdfb54mdFYtulhEH+aTaPyUC7GrFXstPs2hKcu9973urfpcW2gJQEZ/61KfCsWPHqlgE9ndy+a3j3/7t387yOvvss6vyy6MFFfayl71s0gdLWKQiF2ZlolHpBAvD7t07Y4sOxVneqcgjcSK6P4ST/O7wjjhf2J5NnLmMmv2W8alomzHuy6i/2Wf3F7HR/sh43s9VKibBYaC7cgoUY6XTUG+7d+/OljrtyAODgerE1yPU70gXEQL26hv4+63f+q3J9tTvV/uY/vmf/7kqP9IrDf1G6yJ+WBYpWxE0LAIyTmVuK8KOHIwKGoFJl9fxrB/ScnVopsq36RUD5EiVV5GTR4JMBJSrLbzvj98bTzGGw0k+tEv6+N/o6Eh2HyHLBZeih92X2g9q2cT1LNxI8hnlRl6cBPOo9Eg86N50001ZBzpw4EAYGBgoVD6gqzZ5yBMB7eX96If76tl4EDN25FfrShL7i5StCBoSQb1MU4GKBKyg8wL3aREBaepVXKsqI4WFk7FMCYF1Gui6a68Lf/LBm0P3zl1h164dcQTeFfbEUfgTt388+30AXmwRd8Z9k9y1K9z+8Tsy8pEs9vPoM/t2xfTsT3F75ON7dmbru3btCdvj+vtv/kC49vprY/1W6pmR9OTJk9mpECKg3op0Otn4urR/49+3jyd+SKN0/NIQ25VW/SAPsvV5Wj+tQlOnQynYQFMsGrRPo/sENKiHGji1rxHIT2qOYOOZEkGFixbGZex8W7ZuDfc/9FD48eafhs0PPhDaspeG2DfFzZvvn+SPf/yTWLa27Atx2cNtcX/b4iXhgQceCpvvf6DK1vIn92+O+38aHv7x5vDYjx8MW3/yUBQpgmwLi9sqV244BdFpEGUCRTodsJ1X0DbqWB2wFjniyx6Sv37RXpRNHlL+IYNPI36KYF6LACICjWoeEoAau1nU8+PjsVy4KLJtQeg5vD/s298T9u57KnQ/tSf7iST2c2UJcjTZ2707PNW9Jzy1Z0/ojiM5T3eyry2KyNvs6+4OPd17M7K+b293eGpvTBu5Fz61K+yL+Rzcf6ByqhlFtDCeNlDHnA6pc6g8RToL5Yfelr/ZzgCBf18Hlpy6YEu+8mOPBOznMmuR9vK+RfmBRfwUwbwTgQdXF1L+RPzO9IO8ED9MKD0qo/6EjSPzBb5ax1OaSxYuCUsX8qDagnDk+JFwqq8vsn9i2RfT04Eg84rFYelSvsyHb21fkJ3GTKWzrPjoO9UfBk4MhBN9J0Lv4PHQPzIQRoZGw1B/HCSGK+f16nwsIdsom8oA/R1j28G9LX+Ltc7PRY3SkHVR++0+m67R1yvlR3NNcd7/SAdBN4Nmf6TD29aj/KTeJ0jZT2dMn7HiKzVCpdNNkXSFMDFQs5gcsydX0vB5NfPs0GyymXeMUyxF4OBt61F+mhfBFPEzqyJoAj6vUgTVKEUQKT+lCE4Pn5Yi4EYF37i3pGLrMe8jsIL3yw95KL18qdDqvLMpAuVZj94XcwtfDmuTIuk8vA/YDHxel1566TS/3qZVZM5Ur75gERGsXLky18+ciECTrtRjE62C96tLpHbCp33qvLMpgjzYeGbClAi8DRPKZuD9zCVT7xh7myIi0LdILbxNKQIH6yOPpQhmj6UImoD3W4pgiqUIquFt5nROcOONN04LwIKJob/7qk6cB+9XIgD40HVvEZvvf//7ExZT8H48lVbrcK5FQJ66Zq4Ojj/Vlb8O7kVAHXN3ODURB+zHl/0FmXq08dhtWte7GLVIvNxLUNz44sKG2k1x+jy8CLDDhy2/FQHlko31MyciIGM1UB703SEVmMpsJL1AJVJYW3HyIX+veMUrJveJeSAdPiGxwdkUgQVp1LmUv2LRNpYqZy1YP1qK/G1p9zGptCjqx8N/d0g2+BP12IT2s2S7hX+UGjtbH9CKYNTdlZ4pGhKBMtcIY2nB3x0dHVnw9vfEUrYesoHkZd8s01I+ZPfyl798Mg+fVz36NLMpAp+3ttu7sD4enwZaUD9KS73YtHab7UwQEXi/No21VXro253TUGuLjcB+wJHcxsTS+oCIQDYQP3addBKBOj9L+qP31QwaEoEyIYA88JtlqhgVptEgsedIQHqOBizxKT+qBETAdst6IA1pZasKn6sjAVDnV96yY111pnLWg04JrI/U35b+SACK+PHxpL5AR70CbOkn9gG6WuVKvVSjNPrbHglIL7YCDYmgEfjPMLIUFHyemNjPm2X23A8/tqJBERH4vEjrR+HUs0Me1o/yV3r5StFDovbp7N959UM94EejpSe+bN2JKRF4G098eaRE4GNGBD4+b+NFYO1VHxKB7fh59VMUp0UEBA8ZefnmpaUFNtdee232krylCl9UBNg9+eST2efGLX3jfPvb364bD34effTRaX74kkUerU8+cUg52K4ysU4M1JPqDN82HbRABDZ9irxb7YXQKhE8+OCD0/LydfM3f/M3k2VSuXyZ+EEX70eDhPK3RwJAW3g/PT09E3sbw2kTAYXgbrAKKVrIDrDkb5G/ta+ICHjHWA1B54d2NIapUdMCP+eff/6kPfvxo331YH2SFntbFqC4ZOfjUV4CIiB9HqxP2CoReFAO7MjP1i1/s5QvH4+/OoQfb5MSgfUJ5+zqEFCj1YPmBCIBW+CDwlsbaIGNbWT+Fi2KnA4hAl+xohortc+DN7fwI180dhGk/KosKqONIxUPedaDryvB+8oTQa16KgLS2nJ4pran7hPIh+xTp0Pez5yIQFcH8oANRwJbCJaCGj7vSACUH0tRI6D85IkAGw6zbFc8RWlBfry0gg81dl7HFKxP0uELqBzAdiDW/fP7RfPCn0hd4c/6KXokUDot86C8YOqoWot5N8soNyJQPWnpyzUnIrA/i6RAUqBhN27cmAWvAAlYUOPkHQkAdrbwUB1Hfq666qq6frDnSOBtitCDry5w80mN3OyRgJh0o4syAJ1CsIS2/mCeCOQHqG4YuHxnyROBygZth7b+U2C/bpb5POsxTwSQS+4C+VA+Xz9zdseYzHlsol4hVXEsFSjrgjpxXqVix9Uh71tgv13Wgs2L9UZg84Z8MkRo1JcF5fAE+ISUqVERkIZPlGBr/fo7xkVEwJETKB5oxZEi+xsVACwiAvmF1APLvHYvioZEQEWAvI9vpUjQzcC/T9Csn2ZhywB5jByoLpqF/NUrl2zEPBEA4vPpPIucDkkEFt6mVSwiAs9W9oNSBDmwZYClCFrPUgQ5KEUwxVIEU2xlP2hKBLfccks2GW2EXMFpBghO6Wv54eYTdy9nytTvIfvK/+Y3v5nZ8tyMT1+PHvJXTwS2/lT2PL8pEXg/V1999YT1FHyaIiJYtWrVNN9F6P382q/92rRy+TTPe97zqtKcNhHMN0iUqUukjZAKhalnh1L2zdBD2+uJwIOJoNKJHl4ERTuLTQOLiIDO2Qy8nxQ9Pve5z1XtL1quIihFEEmFwlIEUyxF8DRBKYJSBK1AQyLQTQpuwJwuqOODoiKgwphUiqn9ME8EpNWvtdi0fp0vLGib6IEv7BUT18EBZap1T2O+i4C4ob1+78sAvB9P6kO+AP4QAdvZzw052bQCDYmAYCgUd+Z84HNFGlVxqIJTIrDATr9Uo4q0xCfMEwE2ulmmhsY3PuWDddsJBOsHks6Xg/TKB3pg7/14nE4RUA7FDrHhHWOVT/B+UrR+oB6bgKq3VqEhEehrx+9617umBTmXVAVoWUQEPG7Mdv88DpTfIiKgkwFGIfxCpWc0RwSpq0yyEe0ohw+WEhNL6I+4810ExEd+7FMZEAHbLbwfT+qRpeoKWhGIp+VIQMbgD//wD6cFPhekMnTaABRPngjAlVdeOenD26qii8wJ+CkkYBvC26Qax+4nL6WXCLwN1HZhvosA0PG1n7x57MXD+kiRdPKjdSsCYNdniqZE0MzNsmZIBUDWbaUIiqeICGhUpfe22p7+KvWUDTHwU0F+ZPNvqKXmTNYP9KAs3sbnkxKBBKe6sM8Oycb7SUG2YrNzAurI5t3MkUBtDfEF7VOkrUbLREBhW03uFl944YVVFctSaJUItO2uu+7KXge0tHbE8aUvfalqPzfPbGwsebnc2kDrB3pYEciP94FfXz/aLpt777032w6xedWrXlWo8yhvsVkR2NhY8vt2Pn/v56KLLppMp7Rqc9UFRxSVsRZ5668ZtEwEswHy42sTVIRGB9YFxdMKEUCdi9YiMdjzVf7WNus3zw/0oCzexvshLwvS2Diw4X0Hgf1iHmw+sFkRMOorv1r5ez/+sQnsVR5RbWTr2XNOHqVWYYqIIHVe3AwYFWzhWQqKp5E5QYp5ldsIi/oB6iAqh92f8uNFALRP9qdTBPWgGFj6sqWeHZIIWKbqIrVt3omgyHloESAC/KvQLAXFkycCYql3JGgV8U2jFfnim2BHTjV4LT9s87D7Ia9/Co20gfczGyKAxEQ5rB8vAtlQD/WOqr4t56UIVPCZoFUisC/ae9tWkQaj8Xwjp0hMTKBZQmAbPuWHvz3sfmhFwNG4aP17P7MhAuKBvg1SIlAdpNpL7ej3zSsRYKevTTRKj2ZFYEkaruCkKi6PRUEskAZM3YvwUCyWwPqZiQisHz+ano5HqSmfOnW90R1iV0sA2gdbdco9KyIA/pMrRenRChHMhM2ABsrzo+2pcgmyEfHr4W3skUDwNvPtfYJmmKqvZlGKIIfNoBTB7DNVX82iFEEOm0Epgtlnqr6axX8KEbzvfe/LJleW1mctyvb1r399tlyxYsU0myLgW5oiN9P4npJ8ix7yb8tl/UDZiCkR+Hze/OY3V/kgHm+zfv36Khvo8+I34uz+lJ8UvZ8UU+maYavwtBZBPVifKVo/KhcN7+3yQFprj19d7akHa2/T12NKBB5Fnh1q5of6ZqPe5wtKEUSUIsjnbNT7fEEpgohSBPmcjXqfLyhFEEG54HOe85xpdhZ0br1Tob8hviCdlOXg4GC2vxZIb+9b2LTkqevobLOxNCIC69M/1VpEBIqFJfGk/KTg/XjipxloYKHuiINleZ9ghqAsKg+VWWT0xp5nc4jDdlr5kSj0twV2IulE29G9H5sGNiICqLuu1gdMXR3y4Hv/Kh8+Un5Sd4y9jSc+m8Gdd945mV7xpOq5GZyRIqAckM7vl/VAx+QSJHFodFRjQAkg5QfbFNVRoSAR6IggWptaSB0JFKvIaV89kDc/sKH0ov+bS9MeNt4USdcoqE/eMVa+8pPXXkVxRooAqOMD24nzcMEFF0zGQadIxZwCdimqXDwsBxQT8HXXiAgg6W2cYpEjwZYtW6rSyJfdNpdHgnnztYmiIsCOH+nwI1kRerRCBKkOzjZtV7mKjCw6EtgOYQVVC7KtRx9j3pHA2it/PzFO0YvA1wOwRwKl8/F4EVAPPg3kb7vNl9MjFY+OBNZnqzBrIvj0pz+dvRLXKD1aJYJ77rknq0hLlYclvPvuu6fZeHgRsPRpUkyV1dPGA/x+jq7erwSoNM2KwPv9yEc+kpVN5YQ+ng9/+MMTHiogFrbzWwLEyjrtJz/y5fO67777JjxUoHg++9nPTtrccMMNk3FAfLUKsyYC2c4UrRKBfq5JjQE12oiXX355VZmghxUB9Ou1WA/K349+/sjEfuuT8vg0zYgAH3YEV3nYZtNhVw/st/Gw5LVHXz/er7/7Wyse64P1VmFWRNBK6Me8xWYLz5tltSpR5SpynyB1OiSyDfpGhrVA3sofaN1uE+gcKb/WBx8C8DaeqTmB7XSWdlsqJgv2S7isE69EkPInph6B8Dai0rNsFea1CKhEXrxWobVsFPjhgTDSq4NaPyrXTEWgc+bUPgviAeo0yl9QB+KehAXbavllH+TjYKn8Lb0IuO6uND6t/qZsPk4P9nsigtSgYNmICPAFuc+iepwp5r0I+MoADWEbqVHgx79ZZv2oXK0QQWo7tCAe5YkI7N8s2abtFvzt/WKvN9RAMyIgr1pHAki5iogAEIeEzbLVIiBGxePrp1m0TASzQRWYSmSpbUVQy48axPpRuVpxOoT/vN85wEYdBbCE1g/EJg/4kr1o80oxNSeAisOCv22nrgd8+HiY0zWDVNxQ5WOpPiGe9tcr54oUvghSaS2tH5VrpiLQ9tQI5e08iMHub1U5U0zNCVoFnxens83A+ynCUgQOqbSWpQhmBz6vUgSzwFIE1bBpirIUQTWaEgE3lcjwdLEIUuk8BZXr5ptvrmkj8FlBb+MpfxbexoM0eTYp+DRF+KEPfWgidevh8/rEJz4xsacxeD9F+PnPf34idWNoSAQlSvxnRCmCEmc8ShGUOONRiqDEGY9SBCXOeJQiKHHGoxRBiTMepQhKnPEoRVDijEcpghJnPEoRlDjjUYqgxBmPUgQlznCE8P8BQIKH641SnwcAAAAASUVORK5CYII=" />
							<span>长按识别二维码</span>
						</div>
					</div>`
            });
            countAction("xb_2008");
            recordEventLog("T2020071312073552669632");
        });

        //-- 分享产品
        $("#shareProduct").unbind("click").click(function () {
            //$$.showShareView("点击右上角，发送产品给好友");
            shareHandler();
        });

        //-- 分享二维码
        $(".shareOfQrCode").unbind("click").click(function(){
            if(!PAGE_STATE.shareQrCodeImage){
                const base64 = $(`#shareQrCode`).find("canvas")[0].toDataURL('image/jpeg');
                PAGE_STATE.shareQrCodeImage = base64;
            }
            layer.open({
                area:"200px",
                content:
                    `<div class="popupContent">
						<div class="question">
							<img src="${PAGE_STATE.shareQrCodeImage}" style="height:200px;width:200px;margin:0 auto;" />
							<span style="display: inline-block;padding-top: 15px">长按识别二维码保存</span>
						</div>
					</div>`
            });
            recordEventLog("T2020071315070307569632");
        });

        //-- 投保须知
        $('.notice').on("click", function () {
            $('.special').click();
        })
    }

    function timeoutVerification() {
        //平安燃气险的超时验证
        const { beShareToken } = PAGE_STATE;
        if (productId_PG != "100357") return false;
        $$.request({
            url: UrlConfig.insuranceInfo_loadThirdPartyParam,
            pars: {
                'shareToken':beShareToken
            },
            loading: true,
            sfn: (data) => {
                $$.closeLoading();
                if(data.success){
                    return;
                }else{
                    setTimeout(function () {
                        //授权失败跳出页面
                        $$.alert("授权超时,请重新打开页面", function () {
                            window.history.go(-1);
                        });
                    }, 300);

                }
            }
        });
    };

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){

        //--平安燃气意外险的特殊数据不需要登录


        //-- 协议条款 -> 职业分类
        if(productId_PG == 100370){
            $("#termsOfAgreement_occupation").show();
        }
        if(productId_PG == 100379){
            $("#yianInsuranceDeclaration").show();
            $("#yianInsuranceSample").show();

            $(".special").text("特别约定");
        }
        //-- 永安产品的特殊显示
        if(productId_PG == 100398){
            $("#yongYanInformed").show();
        }
        if(productId_PG == 100396){
            $("#yongYanDeclaration").show();
        }
        //-- 推广费显示隐藏
        const promotionFeeDisplay = localStorage.getItem($Constant.promotionFeeDisplayKey);
        PAGE_STATE.promotionFeeDisplay = promotionFeeDisplay;
        if(!$$.isValidObj(promotionFeeDisplay)){
            $(".promotionFee").remove();
        }

        //-- 绑定自动跳转
        $$.staticPushAutoBind();

        //-- 家庭财产保险隐藏保费单位
        if(productId_PG == "100388"){
            $("#moneyCompany").html("元");
        }

        //-- 加载二维码
        (function(){
            const shareQrCodeId = "shareQrCode";
            if(!PAGE_STATE.shareQrCodeImage){
                const ele = $(`#${shareQrCodeId}`);
                ele.qrcode({
                    text: getShareLink(),
                    render : "canvas",                                  // 设置渲染方式，有table和canvas
                    background : "#ffffff",                             // 二维码的后景色
                    foreground : "#000000",                             // 二维码的前景色
                    width: 200,
                    height: 200,
                    src: "../../images/product/detail/03.png"
                });
            }
        })();
    }

    /**
     * 获取产品库详情
     * @Author 肖家添
     * @Date 2019/9/4 15:02
     */
    function findInsuranceInfoDetail(isFirstHandler = true) {
        const { beShareToken } = PAGE_STATE;
        $$.request({
            url: UrlConfig.insuranceInfo_detail,
            loading: true,
            pars: {
                insuranceInfoId: productId_PG,
                sellProductInfoId: sellProductInfoId_PG,
                shareToken: beShareToken
            },
            sfn: function (data) {
                if (data.success) {
                    const { datas, tips_promotionFeeDisplay } = data;
					shareImg = $$.imageUrlCompatible(data.datas.insuranceLogo);
					shareContent = data.datas.insuranceName;
                    responseHandler(datas, tips_promotionFeeDisplay);
                    $("img").attr("crossOrigin", "Anonymous");
                } else {
                    $$.errorHandler(data.msg);
                }
            }
        });

        /**
         * 产品详情 -> 响应处理
         * @Author 肖家添
         * @Date 2019/9/4 17:02
         */
        function responseHandler(data, tips_promotionFeeDisplay) {
            try{
                const {
                    //-- 产品LOGO
                    insuranceLogo,
                    //-- 产品详情
                    unscramble,
                    //-- 投保须知
                    ensureExplainContent,
                    //-- 产品计划
                    insurancePlanData,
                    //-- 投保期限
                    insuranceDueTime,
                    //-- 产品名称
                    insuranceName,
                    //-- 年龄分类
                    insuranceAgeData,
                    //-- 订单token
                    orderToken,
                    //-- 产品险种
                    insuranceType,
                    //-- 微信昵称
                    weChatNickName,
                    //-- 分享Token
                    shareToken,
                    //-- 理赔服务
                    claimsServices,
                    //-- 常见问题
                    commonProblem,
                    //-- 事件日志Token
                    eventLogToken,
                    //-- 责任免除条款
                    exemptionListMap,
                } = data;
                PAGE_STATE.orderToken = orderToken;
                PAGE_STATE.insuranceType = insuranceType;
                PAGE_STATE.weChatNickName = weChatNickName;
                PAGE_STATE.shareToken = shareToken;
                PAGE_STATE.eventLogToken = eventLogToken;
                PAGE_STATE.ensureExplainContent = ensureExplainContent;

                if(!$$.isValidObj(PAGE_STATE.beShareToken)){
                    PAGE_STATE.beShareToken = shareToken;
                }

                if($$.isValidObj(tips_promotionFeeDisplay)){
                    PAGE_STATE.promotionFeeDisplay = null;
                }else{
                    PAGE_STATE.promotionFeeDisplay = true;
                }

                $(".head-img").attr("src", $$.imageUrlCompatible(insuranceLogo));
                $(".detail-content1").append($$.changeIsNilVal(unscramble, "<br/>-"));
                $(".detail-content2").html($$.changeIsNilVal(ensureExplainContent, "-"));
                $(".detail-content3").html($$.changeIsNilVal(claimsServices, "-"));
                $(".detail-content4").html($$.changeIsNilVal(commonProblem, "-"));
                $("#timeLimit").html($$.changeIsNilVal(insuranceDueTime, "-"));
                $("#infoName").html(insuranceName);

                //-- 产品计划处理
                (function () {
                    if(!isFirstHandler)
                        return;

                    let html = "";
                    if ($$.isValidObj(insurancePlanData)) {
                        insurancePlanData.forEach((item) => {

                            const { id, planId, tiMoney, insureEnsureData } = item;
                            if(  insurancePlanData.length == 1){
                                $(".main-plan-icon").hide();
                                html += `
                                <li
                                    class="planItem" 
                                    data-sellId="${id}"
                                    data-planId="${planId}"
                                    data-tiMoney="${tiMoney}"
                                    data-ensure='${JSON.stringify(insureEnsureData)}'
                                >
                                     ${item.name}
                                </li>
                                `;
                            }else{
                                html += `
                                <li
                                    class="planItem" 
                                    data-sellId="${id}"
                                    data-planId="${planId}"
                                    data-tiMoney="${tiMoney}"
                                    data-ensure='${JSON.stringify(insureEnsureData)}'
                                >
                                     ${item.name}
                                </li>
                                `;
                            }
                        });
                    }else{
                        $$.alert("无相关销售产品！", function(){
                            $$.pop();
                        });
                        return;
                    }
                    $("#planList, .insuran-val.plan-list>ul").html(html);

                    //-- 选择产品计划
                    $(".planItem").off().click(function () {
                        const id = $(this).attr("data-sellId");
                        //检查改成品是否存在收藏记录
                        checkWasCollection(false,id);
                        insurancePlanChange(id);
                        sellProductInfoId_PG = id;
                        //-- 加载立即投保所需数据
                        findInsuranceNeedData();


                    });

                    //-- 选中
                    if ($$.isValidObj(html)) {
                        insurancePlanChange(sellProductInfoId_PG);
                    }
                })();

                //-- 年龄分类处理
                (function(){
                    if($$.isValidObj(insuranceAgeData)){
                        const { minAgeType, maxAgeType, minAge, maxAge } = insuranceAgeData;
                        if(productId_PG == "100388"){
                            $("#ageName").html(`投保人年龄`);
                            $("#ageInfo").html(`${minAge}${ageTypeChange(minAgeType)}以上`);
                        }else{
                            $("#ageInfo").html(`${minAge}${ageTypeChange(minAgeType)} - ${maxAge}${ageTypeChange(maxAgeType)}`);
                        }

                        function ageTypeChange(type){
                            switch (type) {
                                case 0:{
                                    return "周岁";
                                }
                                case 1:{
                                    return "月";
                                }
                                case 2:{
                                    return "天";
                                }
                            }
                        }
                    }
                })();

                //-- 产品分类
                (function(){
                    if(insuranceType == OrderHelper.insuranceType.INSURANCE_TYPE_19 || insuranceType == OrderHelper.insuranceType.INSURANCE_TYPE_20 || insuranceType == OrderHelper.insuranceType.INSURANCE_TYPE_24){
                        //-- 团险处理
                        businessInsuranceHandler();
                    }else{
                        //-- 检查是否收藏
                        checkWasCollection();
                    }
                })();

                //-- 图片加载事件
                (function(){
                    $("img").load(function(){
                        //-- 重置Tabs高度
                        tabsHeightChange(0);
                    });
                })();

                //-- 是否显示 责任免除条款
                (function(){
                    if (exemptionListMap == "") return;
                    let {tikuanUrl} = exemptionListMap;
                    if (!$$.isValidObj(tikuanUrl)) return;
                    $('#exemption').css('display', 'inline').attr('href', `javascript:pdfPreview('${tikuanUrl}');`);
                })();

                //-- 重置Tabs高度
                tabsHeightChange(0);

                //-- 加载立即投保所需数据
                findInsuranceNeedData(true);

                //-- 产品分享
                shareProduct();

            }finally {
                $$.closeLoading();
            }
            $$.screenRecording(PAGE_STATE.eventLogToken);
        }
    }

    /**
     * 获取投保所需数据
     * @Author 肖家添
     * @Date 2019/9/10 19:49
     */
    function findInsuranceNeedData(pageLoad = false){
        if(pageLoad){
            //-- 读取页面状态
            pageStatusHandler(2);
            return;
        }

        const { insuranceNeedData } = PAGE_STATE;
        if(insuranceNeedData.hasOwnProperty(sellProductInfoId_PG)){
            responseHandler(insuranceNeedData[sellProductInfoId_PG]);

            return;
        }else PAGE_STATE.insuranceNeedData[sellProductInfoId_PG] = null;

        $$.request({
            url: UrlConfig.insuranceInfo_detail_immediatelyData,
            pars: {
                productId: productId_PG,
                sellProductId: sellProductInfoId_PG,
            },
            loading: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){
                    responseHandler(data);
                }else{
                    $$.errorHandler(data.msg);
                }
            }
        });

        //-- 投保数据 -> 响应处理
        function responseHandler(data){
            const {
                //-- 销售产品
                sellProductInfo,
                //-- 销售产品数据源
                sellProductData,
                //-- 保障期限数据源
                guaranteePeriodData,
                //-- 起始时间，默认为当前时间第二天，不能为空
                startingTimeOfInsurance,
                //-- 保障期限 -> 固定一年
                fixedOptionOfOneYear,
                //-- 不重复销售产品内容
                noRepeatSellProductsData
            } = data;

            PAGE_STATE.insuranceNeedData[sellProductInfoId_PG] = data;
            PAGE_STATE.fixedOptionOfOneYear = fixedOptionOfOneYear;
            PAGE_STATE.sellProductData = sellProductData;

            const firstDateArr = startingTimeOfInsurance.split("-");

            //-- 可选择最大的年份
            let maxSelectDate = new Date();
            maxSelectDate.setFullYear(maxSelectDate.getFullYear() + 1);
            maxSelectDate = $$.dateUtils.dateFormat(maxSelectDate, ["y", "M", "d"]);

            //-- 职业选择[意外险、健康险]
            (function(){
                const { occupationIds } = sellProductInfo;
                const occupationDisplay = $$.isValidObj(occupationIds);

                PAGE_STATE.occupationDisplay = occupationDisplay;

                if(occupationDisplay){
                    $(".occSelectContainer").show();

                    clearOccupation();

                    //-- 选择职业
                    $("#occSelect").off().click(function(){
                        selectedOccupation();
                    });
                }
            })();

            //-- 保障期限
            (function(){
                if(fixedOptionOfOneYear){
                    return;
                }

                const guaranteePeriodDataSource = guaranteePeriodData.map((item, index) => {
                    return {
                        value: item.id,
                        label: item.title
                    };
                });

                let defaultSelectItem = {value: null, label: ""};
                if($$.isValidObj(guaranteePeriodDataSource) && guaranteePeriodDataSource.length > 0){
                    defaultSelectItem = guaranteePeriodDataSource[0];

                    //-- 易安产品
                    if (productId_PG == "100338" || productId_PG == "100394" || productId_PG == "100393" || productId_PG == "100392" || productId_PG == "100391" || productId_PG == "100390"){
                        setLimitType(defaultSelectItem, function sfn(limitType){});

                        if (productId_PG == "100391") $('.businessArea').text('营业面积');

                        /*if (productId_PG == "100394") {
                            $('.policyTemplate').attr('href', `javascript:pdfPreview(${policyTemplate[productId_PG.toString()]['3个月']});`).show();
                        } else {
                            $('.policyTemplate').attr('href', `javascript:pdfPreview(${policyTemplate[productId_PG.toString()]});`).show();
                        }*/
                    }
                    setLimitPageData(defaultSelectItem);
                }

                $("#limitSelect").off().on("click", function(){
                    weui.picker(guaranteePeriodDataSource, {
                        id: 1,
                        defaultValue: [defaultSelectItem.value],
                        onConfirm: function (result) {
                            //-- 易安产品
                            if (productId_PG == "100338" || productId_PG == "100394" || productId_PG == "100393" || productId_PG == "100392" || productId_PG == "100391" || productId_PG == "100390"){
                                let limitTypes;
                                setLimitType(result[0], function sfn(limitType){
                                    limitTypes = limitType;
                                });
                                if (limitTypes) return;
                            }

                            setLimitPageData(result[0], );

                            premiumCalculation(true);
                        }
                    });
                    countAction("xb_2009");
                });

                //-- 设置页面参数
                function setLimitPageData(data){
                    const {label, value} = data;
                    $("#limitSelect").val(label).attr("data-sellId", value);

                    /*if (productId_PG == "100394"){
                        let ensureExplainContent = PAGE_STATE.ensureExplainContent;
                        if (label == '6个月') {
                            ensureExplainContent = PAGE_STATE.ensureExplainContent.replace('3个月', '6个月');
                        }
                        $(".detail-content2").html($$.changeIsNilVal(ensureExplainContent, "-"));

                        $('.policyTemplate').attr('href', `javascript:pdfPreview(${policyTemplate[productId_PG.toString()][label]});`).show();
                    }*/
                }

                //-- 设置保障期限状态
                function setLimitType(result, sfn){
                    const occSelect = $("#occSelect").attr("data-azcncode");
                    const sellProductData = PAGE_STATE.sellProductData;
                    for (const index in sellProductData){
                        const {id, occupationIds} = sellProductData[index];
                        if (result.value == id.toString()){
                            if ($$.isValidObj(occSelect)){
                                const exists = occupationIds.includes(occSelect);
                                if (!exists) {
                                    $$.layerToast("当前保障期限不适用于您选择的职业，请选择其他保障期限~");
                                    sfn(true);
                                    break;
                                }
                            }
                            $("#limitSelect").attr("data-occupationIds", occupationIds);
                            sfn(false);
                            break;
                        }
                    }
                }
            })();

            //-- 产品条件[意外险、健康险]
            (function(){
                $(".conditionSelectContainer").hide();
                let defaultSelectItem = {value: null, label: ""};
                setLimitPageData(defaultSelectItem);

                //-- 设置页面参数
                function setLimitPageData(data){
                    const sellId = data.value;
                    $("#conditionSelect").val(data.label).attr("data-sellId", sellId);
                    recordEventLog("T2020071315073239469632", sellId);
                }
                PAGE_STATE.productConditionSelect = !(PAGE_STATE.insuranceType != 4 && ["1014424", "1014426", "1014428"].indexOf(sellProductInfoId_PG) == -1);
                if(PAGE_STATE.productConditionSelect == false){
                    return;
                }
                const noRepeatSellProductDataSource = noRepeatSellProductsData.map((item, index) => {
                    return {
                        value: item.id,
                        label: item.title
                    };
                });
                if($$.isValidObj(noRepeatSellProductDataSource) && noRepeatSellProductDataSource.length > 0){
                    defaultSelectItem = noRepeatSellProductDataSource[0];

                    setLimitPageData(defaultSelectItem);
                }
                $(".conditionSelectContainer").show().off().click(function(){
                    weui.picker(noRepeatSellProductDataSource, {
                        defaultValue: [defaultSelectItem.value],
                        onConfirm: function (result) {

                            setLimitPageData(result[0]);

                            premiumCalculation(true);
                        }
                    });
                });
            })();

            //-- 起保时间
            (function(){
                $("#startDate").off().on("click", function(){
                    if($(this).hasClass("disabled")){
                        return;
                    }

                    weui.datePicker({
                        title: "起保时间",
                        start: startingTimeOfInsurance,
                        end: maxSelectDate,
                        defaultValue: firstDateArr,
                        onConfirm: function (result) {
                            let dateStr = transferDateByWeChatSelect(result);

                            $("#startDate").val(dateStr);

                            premiumCalculation();
                            countAction("xb_2010");
                            recordEventLog("T2020071315070966769632", dateStr);
                        }
                    });
                }).val(startingTimeOfInsurance);
                recordEventLog("T2020071315070966769632", startingTimeOfInsurance);
            })();

            //-- 终保时间
            (function(){
                $("#endDate").off().on("click", function(){
                    const isEnable = $(this).hasClass("disabled");
                    if(isEnable){
                        return;
                    }

                    weui.datePicker({
                        title: "终保时间",
                        start: startingTimeOfInsurance,
                        defaultValue: firstDateArr,
                        end: maxSelectDate,
                        onConfirm: function (result) {
                            let dateStr = transferDateByWeChatSelect(result);

                            $("#endDate").val(dateStr);

                            premiumCalculation();
                        },
                    });
                    countAction("xb_2011");
                }).val(startingTimeOfInsurance);
            })();

            //-- 转换WeChat日期选择结果
            function transferDateByWeChatSelect(result){
                let dateStr = "";
                for (let item in result) {
                    let { value } = result[item];
                    if(value < 10){
                        value = "0" + value;
                    }
                    dateStr += ($$.isValidObj(dateStr) ? "-" : "") + value;
                }

                return dateStr;
            }

            //-- 保费计算
            premiumCalculation(true);

            //-- 特殊处理
            specialHandling();

            //-- 设置页面状态
            pageStatusHandler(1);
        }
    }

    /**
     * 标签页高度改变
     * @Author 肖家添
     * @Date 2019/9/4 16:04
     */
    function tabsHeightChange(tips) {
        const transform = ["0", "-25%", "-50%", "-75%"];
        const showViewCls = ["detail-content1", "detail-content2", "detail-content3", , "detail-content4"];
        const height = $(`.${showViewCls[tips]}`).height();

        $("#slideWrap").css({
            '-webkit-transform': `translate(${transform[tips]}, 0)`,
            'transform': `translate(${transform[tips]}, 0)`
        });
        const footerHeight = $("footer").height();
        $("#infoCon").css({height: (height + footerHeight) + "px"});
    }

    /**
     * 产品计划改变事件
     * @Author 肖家添
     * @Date 2019/9/4 18:37
     */
    function insurancePlanChange(id) {

        const { promotionFeeDisplay } = PAGE_STATE;

        //-- 选中计划
        $(`.planItem`).removeClass("choose");
        const selectedPlanEle = $(`.planItem[data-sellId=${id}]`);
        selectedPlanEle.addClass("choose");

        //-- 标题切换
        $("#planName").html($(selectedPlanEle[0]).text().trim());

        //-- 保障项目
        let ensureData = selectedPlanEle.attr("data-ensure");
        if($$.isValidObj(ensureData)){
            let htmlForLimit3 = "";
            ensureData = JSON.parse(ensureData);
            if(ensureData.length <= 0) return;

            ensureData.forEach((item, index) => {
                if(["0", 0].indexOf(item.money) == -1){
                    htmlForLimit3 += `
                        <li class="proItem">
                            <span class="proItem-detail">${item.name}</span>
                            <span class="proItem-money">${item.money}</span>
                        </li>
                    `;
                }
            });

            $(".main-plan .plan-list>ul").html(htmlForLimit3);
        }

        if(promotionFeeDisplay == null){
            //-- 推广费用
            const tiMoney = selectedPlanEle.attr("data-tiMoney");
            $(".promotionFee").show().text(`立赚${tiMoney}%`);
        }else{
            $(".promotionFee").remove();
        }
        recordEventLog("T2020071315074532069632", id);
    }

    /**
     * 保费计算
     * @Author 肖家添
     * @Date 2019/9/11 15:28
     */
    function premiumCalculation(resetTime = false){
        const {
            //-- 立即投保所需数据
            insuranceNeedData,
            //-- 销售产品数据源
            sellProductData,
            //-- 保障期限固定一年 -> [true: 固定, false: 按销售产品]
            fixedOptionOfOneYear,
            //-- 职业选择 -> [true: 显示, false: 隐藏]
            occupationDisplay,
            //-- 企业险参数
            enterpriseInsuranceInsurance: {
                //-- 是否是企业险,
                isEnterprise
            }
        } = PAGE_STATE;
        const {
            //-- 天数相关 -> Id标识
            day_tips,
            //-- 天数相关 -> 最低天数
            day_minDate,
            //-- 天数相关 -> 最大天数
            day_maxDate,
        } = insuranceNeedData[sellProductInfoId_PG];

        const sellId = $("#limitSelect").attr("data-sellId");
        let startDate = $("#startDate").val();
        let endDate = $("#endDate").val();
        let money = 0;

        if(isEnterprise && productId_PG != "100393" && productId_PG != "100394" && productId_PG != "100338" && productId_PG != "100390" && productId_PG != "100391"){
            //-- 企业险
            const azcnCode = $("#groupInsurance-occupation-val").attr("data-azcnCode");
            if($$.isValidObj(azcnCode)){
                for(const index in sellProductData){
                    const { id, occupationIds, sellMoney } = sellProductData[index];
                    if(!$$.isValidObj(occupationIds)) continue;
                    if(occupationIds.indexOf(azcnCode) > -1){
                        money = sellMoney;
                        $("#limitSelect").attr("data-reallySellId", id);
                        recordEventLog("T2020071315070335969632", id);
                        break;
                    }
                }
            }
        }else{
            //-- 终保日期
            let newestEndDate = new Date();
            newestEndDate.setDate(newestEndDate.getDate() + 1);
            newestEndDate = $$.dateUtils.dateFormat(newestEndDate);

            //-- 按天数计算的标识
            $("#limitSelect").removeAttr("data-reallySellId");

            if(sellId && day_tips && sellId == day_tips){
                //-- 按天数计算
                byDay();
            }else{
                //-- 按单位计算
                byCompany();
            }

            //-- 按天数计算
            function byDay(){
                $("#endDate").removeClass("disabled");
                if(resetTime){
                    //-- 重置日期
                    $("#startDate, #endDate").val(startDate);
                    endDateReset(day_minDate);
                }
                let selectedDays = checkMinAndMaxDay(day_minDate, day_maxDate);
                for(const index in sellProductData){
                    const {
                        id,
                        moneyType,
                        minDate,
                        maxDate,
                        sellMoney
                    } = sellProductData[index];
                    if(moneyType == 0){
                        if(minDate <= selectedDays && selectedDays <= maxDate){
                            money = sellMoney;
                            $("#limitSelect").attr("data-reallySellId", id);
                            recordEventLog("T2020071315070335969632", id);
                            break;
                        }
                    }
                }
            }

            //-- 按单位计算
            function byCompany(){
                if(fixedOptionOfOneYear || occupationDisplay){
                    //-- [健康险、意外险] -> 职业、产品条件 选择

                    if(fixedOptionOfOneYear){
                        $("#limitSelect").val("一年");

                        //-- 固定期限为一年
                        handler_MonthOrYear(3, 1);
                    }

                    const occupationAZCNCode = $("#occSelect").attr("data-azcncode");
                    const productCondition = $("#conditionSelect").val();

                    for(const index in sellProductData){
                        const sellProductDatum = sellProductData[index];
                        let { id, occupationIds, conditionContent, sellMoney } = sellProductDatum;

                        if(PAGE_STATE.insuranceType == 4){
                            if(productCondition != conditionContent){
                                continue;
                            }
                        }

                        if(occupationDisplay){
                            if($$.isValidObj(occupationIds) && $$.isValidObj(occupationAZCNCode)){
                                occupationIds = occupationIds.split("-");

                                const hasOcc = occupationIds.includes(occupationAZCNCode.toString());
                                const insuranceType = "4-19-20-24";
                                if(!hasOcc){
                                    continue;
                                }else if(!insuranceType.includes(PAGE_STATE.insuranceType.toString())) {
                                    $("#limitSelect").attr("data-sellId", id);
                                    recordEventLog("T2020071315070335969632", id);
                                }
                            }
                        }
                        money = sellMoney;
                        break;
                    }
                }

                if(!fixedOptionOfOneYear){
                    for(const index in sellProductData){
                        const sellProductDatum = sellProductData[index];
                        if(sellProductDatum.id == sellId){
                            handler(sellProductDatum);
                            break;
                        }
                    }
                }

                //-- 处理
                function handler(sellProductDatum){
                    const { id, moneyUnit, maxDate, sellMoney } = sellProductDatum;

                    money = parseFloat(sellMoney).toFixed(2);

                    switch (moneyUnit) {
                        case 1:{
                            handler_Day(sellProductDatum);
                            break;
                        }
                        case 2:
                        case 3:{
                            handler_MonthOrYear(moneyUnit, maxDate);
                            break;
                        }
                    }
                    recordEventLog("T2020071315070335969632", id);
                }

                //-- 按单位 -> 天
                function handler_Day(sellProductDatum){
                    const {
                        id,
                        moneyType,
                        minDate,
                        maxDate,
                        sellMoney,
                        beginMoney,
                        moneyNum
                    } = sellProductDatum;
                    $("#endDate").removeClass("disabled");
                    endDateReset(minDate);
                    let selectedDays = checkMinAndMaxDay(minDate, maxDate);
                    if(moneyType == 6){
                        money = beginMoney;
                        if(selectedDays > minDate){
                            selectedDays--;
                            const sell = (selectedDays - minDate) / moneyNum + 1;
                            money = sellMoney * sell + beginMoney;
                        }
                    }else{
                        $("#limitSelect").attr("data-reallySellId", id);
                    }
                }

                //-- 按单位 -> 月或年
                function handler_MonthOrYear(moneyUnit, maxDate){
                    const startDate_obj = new Date(startDate);

                    switch (moneyUnit) {
                        case 2:{
                            startDate_obj.setMonth(startDate_obj.getMonth() + maxDate)
                            break;
                        }
                        case 3:{
                            startDate_obj.setFullYear(startDate_obj.getFullYear() + maxDate);
                            startDate_obj.setDate(startDate_obj.getDate() - 1);
                            break;
                        }
                    }

                    newestEndDate = $Date.dateFormat(startDate_obj);
                    $("#endDate").addClass("disabled").val(newestEndDate);
                }
            }

            function endDateReset(minDate){
                try{
                    if(!resetTime) return;
                    const startDate_obj = new Date(startDate);
                    startDate_obj.setDate(startDate_obj.getDate() + (minDate - 1));
                    endDate = $Date.dateFormat(startDate_obj);
                    $("#endDate").val(endDate);
                }catch (e) {
                    console.error(e);
                }
            }
        }

        //-- 检查最低、最高的天数
        function checkMinAndMaxDay(minDay, maxDay){
            let selectedDays = $Date.dateMinus(`${startDate} 00:00:00`,  `${endDate} 23:59:59`);

            //-- 易安产品 按天数计算
            if (productId_PG == "100393" || productId_PG == "100394" || productId_PG == "100338" || productId_PG == "100390" || productId_PG == "100391"){
                if (selectedDays < minDay || selectedDays > maxDay){
                    const startDate_obj = new Date(startDate);
                    startDate_obj.setDate(startDate_obj.getDate() + (minDay-1));
                    endDate = $Date.dateFormat(startDate_obj);
                    selectedDays = minDay;
                }
                $("#endDate").addClass("disabled").val(endDate);
            }

            try{
                if(selectedDays < minDay){
                    if(!resetTime){
                        $$.alert(`日期不能小于最低保障天数:${minDay}`);
                    }
                    throw "日期不能小于最低保障天数";
                }
                if(selectedDays > maxDay){
                    if(!resetTime){
                        $$.alert(`日期不能大于最高保障天数:${maxDay}`);
                    }
                    throw "日期不能大于最高保障天数";
                }
            }catch (e) {
                console.error(e);
                money = 0;
            }
            return selectedDays;
        }

        $("#money").html(money);
        $("#groupInsurance-money").html(money);
    }

    /**
     * 职业选择
     * @Author 肖家添
     * @Date 2019/9/17 9:56
     */
    function selectedOccupation(){
        const { vocationInfoData } = PAGE_STATE;
        const vocationInfoData_SL = vocationInfoData[sellProductInfoId_PG];

        if(!$$.isValidObj(vocationInfoData_SL) || vocationInfoData_SL.length <= 0){
            $$.request({
                url: UrlConfig.vocationInfo_data,
                loading: true,
                pars: {
                    productId: productId_PG,
                    sellId: sellProductInfoId_PG
                },
                sfn: function(data){
                    $$.closeLoading();

                    if(data.success){
                        data = data.datas;

                        PAGE_STATE.vocationInfoData[sellProductInfoId_PG] = data;

                        responseHandler(data);
                    }else{
                        $$.alert(data.msg);
                    }
                }
            });
        }else responseHandler(vocationInfoData_SL);

        /**
         * 职业 -> 响应处理
         * @Author 肖家添
         * @Date 2019/9/17 11:43
         */
        function responseHandler(data){
            let pickerDefaultValues = new Array();
            let j = 0;
            const loopChild = function(dataSource){
                return dataSource.map((item, index) => {
                    const { id, name, children } = item;
                    let dataJSON = {
                        label: name,
                        value: id
                    };

                    if(j == 0 && index == 0){
                        pickerDefaultValues[pickerDefaultValues.length] = id;
                    }

                    if($$.isValidObj(children) && children.length > 0){
                        dataJSON["children"] = loopChild(children);
                    }
                    j++;
                    return dataJSON;
                });
            }

            const pickerDataSource = loopChild(data);

            weui.picker(pickerDataSource, {
                defaultValue: pickerDefaultValues,
                onConfirm: function (result) {
                    if(result.length == 3){
                        const occIds = new Array();
                        for (let i = 0; i < result.length; i++) {
                            occIds.push(result[i].value);
                        }

                        const { value, label } = result[2];

                        $("#occSelect, #groupInsurance-occupation-val").val(label).attr("data-occupationId", value).attr("data-occIds", occIds.join("-"));
                        $("#groupInsurance-occupation-val").html(label);

                        //-- 职业编号
                        setAZCNCode(result);

                        //-- 易安产品
                        if (productId_PG == "100393" || productId_PG == "100394" || productId_PG == "100338" || productId_PG == "100390" || productId_PG == "100391"){
                            const azcnCode = $("#occSelect, #groupInsurance-occupation-val").attr("data-azcnCode");
                            const occupationids = $("#limitSelect").attr("data-occupationids");
                            if (!occupationids.includes(azcnCode)){
                                $$.layerToast("当前职业不适用于您选择的保障期限，请选择其他职业~");
                                $("#occSelect, #groupInsurance-occupation-val").val("").attr("data-occupationId", "").attr("data-occIds", "").attr("data-azcnCode", "");
                                $("#groupInsurance-occupation-val").html("");
                                return;
                            }
                        }

                        //-- 保费计算
                        premiumCalculation(true);

                        //-- 设置页面缓存
                        pageStatusHandler(1);

                        //-- 事件日志
                        recordEventLog("T2020071315074813969632", occIds.join(","));
                    }
                }
            });
        }

        /**
         * 设置选择的职业编码
         * @Author 肖家添
         * @Date 2019/9/17 11:39
         */
        function setAZCNCode(selectedResults){
            let occupationData = PAGE_STATE.vocationInfoData[sellProductInfoId_PG];
            const selectedIds = [selectedResults[0].value, selectedResults[1].value, selectedResults[2].value];

            let loopIndex = 0;
            function loop(dataSource){
                if(!$$.isValidObj(dataSource) || dataSource.length <= 0){
                    return;
                }

                for(const index in dataSource){
                    const datum = dataSource[index];

                    if(datum.id == selectedIds[loopIndex]){
                        loopIndex++;

                        if(loopIndex == selectedIds.length){
                            then(datum);
                            break;
                        }

                        loop(datum.children);
                    }
                }
            }

            function then(result){
                if(!$$.isValidObj(result)){
                    return;
                }
                const { azcnCode } = result;

                $("#occSelect, #groupInsurance-occupation-val").attr("data-azcnCode", azcnCode);
            }

            loop(occupationData);
        }
    }

    /**
     * 清空职业
     * @Author 肖家添
     * @Date 2019/9/17 11:41
     */
    function clearOccupation(){
        $("#occSelect")
            .val("")
            .removeAttr("data-occupationId")
            .removeAttr("data-azcnCode");
    }

    /**
     * 检查是否存在收藏记录
     * @Author 肖家添
     * @Date 2019/9/17 20:25
     */
    function checkWasCollection(isPageLoad = false,checkStatusId){
        if(!$$.checkLogin()){
            return;
        }

        if (checkStatusId!=null){
            sellProductInfoId_PG=checkStatusId;
        }

        $$.request({
            url: UrlConfig.userFavInfo_checkHasRecord,
            pars: {
                favId: sellProductInfoId_PG,
                type: 0
            },
            sfn: function(data){
                const ele = $("#collectionBtn");
                if(data.success){
                    ele.addClass("active");
                    if(isPageLoad) $$.layerToast("收藏成功");
                }else{
                    ele.removeClass("active");
                    if(isPageLoad) $$.layerToast("已取消收藏");
                }
            }
        })
    }

    /**
     * 收藏产品
     * @Author 肖家添
     * @Date 2019/9/17 20:32
     */
    function collectionProduct(e){
        if(!ShawHandler.checkLogin()){
            ShawHandler.confirmLogin();
            return;
        }

        const params = {
            //-- 操作类型 -> [1: 新增, 2:删除]
            handlerType: 1,
            //-- 对象Id
            favId: sellProductInfoId_PG,
            //-- 记录类型 -> [0: 产品收藏]
            type: 0
        };
        if(e.hasClass("active")){
            params.handlerType = 2;
        }
        $$.request({
            url: UrlConfig.userFavInfo_handler,
            loading: true,
            checkLogin: true,
            pars: params,
            sfn: function(data){
                if(data.success){
                    $$.closeLoading();

                    checkWasCollection(true);
                    countAction("xb_2007");
                }else{
                    $$.errorHandler();
                }
            }
        });
    }

    /**
     * 特殊处理
     * @Author 肖家添
     * @Date 2019/9/18 14:51
     */
    function specialHandling(){
        const startDate = $("#startDate");
        const endDate = $("#endDate");
        //-- 太平百万健康险限制
        if (productId_PG == "100325" || productId_PG == "100326" || productId_PG == "100328" || productId_PG == "100383") {
            startDate.addClass("disabled");
            endDate.addClass("disabled");
            return;
        }

       /* const yongYanInformed = $("#yonYanInformed");
        if (productId_PG == "100398" ) {
            yongYanInformed.show();
            return;
        }

        const yongYanDeclaration = $("#yongYanDeclaration");
        if (productId_PG == "100396" ) {
            yongYanDeclaration.show();
            return;
        }*/
    }

    /**
     * 立即投保
     * @Author 肖家添
     * @Date 2019/9/18 15:47
     */
    function immediateInsurance(){
        //-- 保费计算
        premiumCalculation();

        if($("#money").html() <= 0){
            return;
        }

        //-- CONSTANT START
        const guaranteePeriod = $("#limitSelect").attr("data-sellId");
        const reallySellId = $("#limitSelect").attr("data-reallySellId");
        const startDate = $("#startDate").val();
        const endDate = $("#endDate").val();
        const productCondition = $("#conditionSelect").attr("data-sellId");
        const occSelect = $("#occSelect").attr("data-occupationid");
        const occIds = $("#occSelect").attr("data-occIds");
        const occTitle = $("#occSelect").val();
        const azcnCode = $("#occSelect").attr("data-azcncode");
        const productConditionTitle = $("#conditionSelect").val();
        const {
            insuranceNeedData,
            //-- 保障期限固定一年 -> [true: 固定, false: 按销售产品]
            fixedOptionOfOneYear,
            //-- 职业选择 -> [true: 显示, false: 隐藏]
            occupationDisplay,
            //-- 订单token
            orderToken,
            //-- 投保标识
            terminal,
            //-- 分享Token
            beShareToken,
            //-- 事件日志Token
            eventLogToken
        } = PAGE_STATE;

        const {
            //-- 天数相关 -> Id标识
            day_tips
        } = insuranceNeedData[sellProductInfoId_PG];
        //-- CONSTANT END

        //-- 数据校验
        (function(){
            !fixedOptionOfOneYear && $$.isValidObj(guaranteePeriod, "请选择保障期限", true);
            if(occupationDisplay)
                $$.isValidObj(occSelect, "请选择职业", true);
            if(PAGE_STATE.productConditionSelect)
                $$.isValidObj(productCondition, "请选择产品条件", true);
            $$.isValidObj(startDate, "请选择起保时间", true);
            $$.isValidObj(endDate, "请选择终保时间", true);
        })();

        //-- 立即投保
        (function(){
            const params = {
                //-- 产品库Id
                productId: productId_PG,
                //-- 产品组销售展示产品Id
                groupSellId: sellProductInfoId_PG,
                //-- 如果固定一年则是产品条件，否则是产品期限
                sellProductId: PAGE_STATE.productConditionSelect ? productCondition : guaranteePeriod,
                //-- 产品条件标题
                productConditionTitle,
                //-- 职业Id
                occupationId: occSelect,
                //-- 职业Id，三个，"-"隔开
                occupationIds: occIds,
                //-- 职业选中显示的内容
                occupationTitle: occTitle,
                //-- 职业类型
                azcnCode,
                //-- 开始时间
                startDate,
                //-- 结束时间
                endDate,
                //-- 保障期限固定一年 -> [true: 固定, false: 按销售产品]
                fixedOptionOfOneYear,
                //-- 职业选择 -> [true: 显示, false: 隐藏]
                occupationDisplay,
                //-- 订单token
                orderToken,
                //-- 天数相关 -> Id标识
                day_tips,
                //-- 投保标识
                terminal,
                //-- 分享Token
                beShareToken,
                //-- 事件日志Token
                eventLogToken
            };

            //-- 按天数的销售产品
            if($$.isValidObj(reallySellId)){
                params.sellProductId = reallySellId;
            }

            $$.request({
                url: UrlConfig.insuranceInfo_detail_immediateInsurance,
                pars: params,
                loading: true,
                requestBody: true,
                sfn: (data) => {
                    if(data.success){
                        responseHandler(data);
                    }else{
                        $$.alert(data.msg);
                    }
                }
            });

            //-- 立即投保 -> 响应处理
            function responseHandler(data){
                const { hasHealthToldRecord, _orderSignKey } = data;

                params["_orderSignKey"] = _orderSignKey;
                sessionStorage.setItem(`PRODUCT_DETAIL_TO_HEALTH_${orderToken}`, JSON.stringify(params));

                if($$.isValidObj(hasHealthToldRecord) && true == hasHealthToldRecord){
                    $$.push("product/health", {
                        orderToken,
                        beShareToken,
                        eventLogToken
                    });
                    return;
                }
                OrderHelper.orderHandler(params);
            }
        })();
    }

    /**
     * 检测是否勾选协议条款
     * @Author 肖家添
     * @Date 2019/10/17 11:08
     */
    function checkTermsOfAgreement(){
        const termsOfAgreement = $(".whetherAgree>.checkbox.isCheck").css("display");

        if(termsOfAgreement == "none"){
            $$.throwTips("请阅读并同意保险条款和协议告知书");
        }
    }

    /**
     * 企业险处理
     * @Author 肖家添
     * @Date 2019/10/17 11:08
     */
    function businessInsuranceHandler(){
        const {
            //-- 起保人数
            numberOfInsuredPersons
        } = PAGE_STATE.enterpriseInsuranceInsurance;
        PAGE_STATE.enterpriseInsuranceInsurance.isEnterprise = true;

        (function(){
            $(".planItem").css({width: "calc(50% - 15px)"});
            $("#groupInsurance-body").show();
            $("#groupInsurance-footer").css({"display": "flex"});
            $("#ordinary-footer").hide();
            $("#groupInsurance-numberOfInsuredPersons").html(`${numberOfInsuredPersons}人`);
            $("#termsOfAgreement_enterpriseInsurance_delegation").show();

            //-- 易安产品 - [企业险、雇主责任险、短期雇主责任险、食品安全险、商户综合险] 隐藏职业类别
            if (productId_PG == "100393" || productId_PG == "100394" || productId_PG == "100338" || productId_PG == "100390" || productId_PG == "100391"){
                $(".groupInsurance-occupation").hide();
            }

            //-- 易安产品 - [食品安全险、商户综合险] 起保人数为1
            if (productId_PG == "100390" || productId_PG == "100391"){
                $("#groupInsurance-numberOfInsuredPersons").html(`1人`);
            }
        })();

        (function(){
            //-- 职业选择
            $(".groupInsurance-occupation").unbind("click").click(function(){
                selectedOccupation();
            });

            //-- 发送客户
            $('.groupInsurance-footer-buttons-custom').unbind("click").click(function(){
				//$$.showShareView("点击右上角发送给客户");
                shareHandler();
			});

            //-- 立即投保
            $(".groupInsurance-footer-buttons-insure").unbind("click").click(function(){
                //-- 易安产品 - [企业险、雇主责任险、短期雇主责任险、食品安全险、商户综合险] 底部弹窗选择
                if (productId_PG == "100393" || productId_PG == "100394" || productId_PG == "100338" || productId_PG == "100390" || productId_PG == "100391"){
                    //-- 协议条款
                    checkTermsOfAgreement();
                    countAction("xb_2006");

                    const insuranWrapEle = $("#insuranWrap");

                    if(insuranWrapEle.hasClass("show")){
                        new enterprise().yiAnImmediateInsurance();
                    }else{

                        function open(){
                            //-- 投保窗口底部边距
                            const paddingBottom = $("footer").height();
                            $(".insuran-con").css("padding-bottom", paddingBottom);

                            insuranWrapEle.addClass('show');
                        }

                        open();
                    }
                } else{
                    new enterprise().immediateInsurance();
                }
            });
        })();

        /**
         * 企业险
         * @Author 肖家添
         * @Date 2019/11/6 18:19
         */
        function enterprise(){
            //-- 立即投保
            this.immediateInsurance = function(){
                const occupationVal = $("#groupInsurance-occupation-val"),
                    occupationId = occupationVal.attr("data-occupationId");

                $$.isValidObjThrow(occupationId, "请选择职业~");
                checkTermsOfAgreement();
                premiumCalculation(true);

                const { orderToken } = PAGE_STATE,
                    sellProductId = $("#limitSelect").attr("data-reallySellId"),
                    insuranceMoney = $("#groupInsurance-money").html();
                if($$.isValidObj(insuranceMoney) && parseFloat(insuranceMoney) <= 0){
                    $$.throwTips("请正确选择职业~");
                }

                OrderHelper.enterprise_createOrder({
                    sellProductId: sellProductId,
                    occupationId,
                    requestToken: orderToken
                });
            }

            //-- 易安产品 - 立即投保
            this.yiAnImmediateInsurance = function () {
                let occupationId = "";
                if (PAGE_STATE.occupationDisplay){
                    occupationId = $("#occSelect").attr("data-occupationid");
                    $$.isValidObjThrow(occupationId, "请选择职业~");
                }

                premiumCalculation(true);

                const { orderToken } = PAGE_STATE,
                    sellProductId = $("#limitSelect").attr("data-sellId"),
                    insuranceMoney = $("#groupInsurance-money").html();
                if($$.isValidObj(insuranceMoney) && parseFloat(insuranceMoney) <= 0){
                    $$.throwTips("请正确选择职业~");
                }

                const startDate = $("#startDate").val();
                const endDate = $("#endDate").val();
                OrderHelper.enterprise_createOrder({
                    sellProductId,
                    occupationId,
                    startDate,
                    endDate,
                    requestToken: orderToken,
                });

            }
        }
    }

    function share() {
		//分享
		if ($$.checkLogin()){
			let shareUrl = window.location.href;

            let shareDatums = {
                url: shareUrl,
                image: shareImg,
                title: "来自好友的推荐分享",
                content: shareContent
            };
            PAGE_STATE.shareDatums = {...shareDatums};

			weChatJSTool.share({
				_imgUrl: shareImg,
				_lineLink: shareUrl,
				_shareTitle: "来自好友的推荐分享",
				_descContent: shareContent,
				_sfn: function () {
					console.log("成功注册分享链接："+shareUrl);
					$$.layerToast("分享成功");
					$$.share(productId_PG,4)
				}
			});
		}
	}

    /**
     * 产品分享
     * @Author 肖家添
     * @Date 2019/11/12 10:00
     */
    function shareProduct(){
        if (!$WeChat.isWx() && !PAGE_APP) return;

        const imgUrl = $Constant.shareLogo,
            infoName = $("#infoName").html(),
            planName = $("#planName").html(),
            { weChatNickName, shareToken, beShareToken } = PAGE_STATE,
            shareProduct = $("#shareProduct");
        let linkUrl = getShareLink();

        if(!$$.isValidObj(weChatNickName) || !$$.isValidObj(beShareToken)){
            shareProduct.hide();
            return;
        }
        shareProduct.stop().fadeIn();

        let shareDatums = {
            url: linkUrl,
            image: imgUrl,
            title: infoName + planName,
            content: `我是${weChatNickName}，快来查看这款超适合您的产品。`
        };
        PAGE_STATE.shareDatums = {...shareDatums};

        weChatJSTool.share({
            _imgUrl: imgUrl,
            _lineLink: linkUrl,
            _shareTitle: infoName + planName,
            _descContent: `我是${weChatNickName}，快来查看这款超适合您的产品。`
        });
    }

    function getShareLink(){
        const { beShareToken } = PAGE_STATE;
        let linkUrl = window.location.href.split("?")[0];
        linkUrl += $$.jsonToUrlParams({
            productId: productId_PG,
            sellId: sellProductInfoId_PG,
            uuid: $$.getTimeStampNow(),
            beShareToken
        });
        return linkUrl;
    }

    /**
     * 浏览历史
     * @Author 吴嘉洪
     * @Date 2019/11/12 15:55
     */
    function browsingHistory(productId) {
        let memberId = $$.getUrlParam("memberId");
        $$.request({
            url: UrlConfig.viewStatistic_insertViewStatistic,
            loading: true,
            pars: {
                shareUserId:memberId,
                objectId: productId,
                type: 5,
                judge:1,
            },
            method: "POST"
        });
    }

    /**
     * 页面状态处理
     * @Author 肖家添
     * @Date 2019/11/18 20:21
     */
    function pageStatusHandler(handlerType = 1){
        const { pageUUID } = PAGE_STATE,
            cacheKey = `PRODUCT_DETAIL_CACHE_FOR_UUID_TOKEN_${pageUUID}`,
            occupation = $("#groupInsurance-occupation-val"),
            whetherAgree = $(".whetherAgree .isCheck");
        try{
            switch (handlerType) {
                case 1:{
                    switch_01();
                    break;
                }
                case 2:{
                    switch_02();
                    break;
                }
            }

            /**
             * 设置状态
             * @Author 肖家添
             * @Date 2019/11/18 20:23
             */
            function switch_01(){
                if(!$$.isValidObj(pageUUID) || pageUUID.length != 13){
                    return;
                }
                const occupationId = occupation.attr("data-occupationId"),
                    occupationIds = occupation.attr("data-occIds"),
                    occAZCNCode = occupation.attr("data-azcnCode"),
                    occupationName = occupation.html(),
                    termsOfAgreement = whetherAgree.css("display");
                const cache = {
                    sellProductInfoId: sellProductInfoId_PG,
                    occupation: {
                        occupationId,
                        occupationIds,
                        occAZCNCode,
                        occupationName
                    },
                    termsOfAgreement
                };
                localStorage.setItem(cacheKey, JSON.stringify(cache));
            }

            /**
             * 读取页面状态
             * @Author 肖家添
             * @Date 2019/11/18 20:26
             */
            function switch_02(){
                if(!$$.isValidObj(pageUUID) || pageUUID.length != 13){
                    findInsuranceNeedData(false);
                    return;
                }

                let cache = localStorage.getItem(cacheKey);
                if(!$$.isValidObj(cache)){
                    findInsuranceNeedData(false);
                    return;
                }
                cache = JSON.parse(cache);
                const {
                    sellProductInfoId,
                    occupation: {
                        occupationId,
                        occupationIds,
                        occAZCNCode,
                        occupationName
                    },
                    termsOfAgreement,
                } = cache;

                //-- 产品计划
                $(`#planList .planItem[data-sellId=${sellProductInfoId}]`).click();
                //-- 职业类别
                if($$.isValidObj(occupationId)){
                    occupation
                        .attr("data-occupationId", occupationId)
                        .attr("data-occIds", occupationIds)
                        .attr("data-azcnCode", occAZCNCode)
                        .html(occupationName);
                }
                //-- 保险条款
                $(`.whetherAgree>.checkbox[data-check=${!$$.isValidObj(termsOfAgreement) || termsOfAgreement == "none" ? 1 : 0}]`).click();
            }
        }catch (e) {
            console.log("页面缓存失效！");
            clearCache();
        }

        function clearCache(){
            localStorage.removeItem(cacheKey);
        }
    }

    /**
     * 保存事件日志
     * @Author 肖家添
     * @Date 2020/7/13 17:30
     */
    function recordEventLog(eventId, evenResult){
        $$.recordEventLog({
            requestToken: PAGE_STATE.eventLogToken,
            evenId: eventId,
            productId: productId_PG,
            evenResult
        });
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-5-15 11:31:25
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;

            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            console.log(PAGE_STATE.shareDatums);
            //-- 分享
            $$.showShareView('点击右上角，发送产品给好友~');
        }
    }
}

//-- pdf预览
function pdfPreview(pdfPath){
    countAction("xb_2005");
    let prefix = pdfPath.substring(0, $$.findStringPosition(pdfPath,'/', 3));
    location.href = `${prefix}/pdfnew/pdf.html?path=` + $$.pdfUrlCompatible(pdfPath);
}
