$(function(){
	$(".dailyActivities").on("click", function(){
		$$.push("my/newGiftBag");
	})
	$(".newbieGift").on("click", function(){
        $$.request({
            url: UrlConfig.checkIn_mailejifen_login,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });
});