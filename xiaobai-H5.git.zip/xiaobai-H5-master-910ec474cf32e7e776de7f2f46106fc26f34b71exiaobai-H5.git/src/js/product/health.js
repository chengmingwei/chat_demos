

/**
 * 健康告知 JS
 * @Author 肖家添
 * @Date 2019/9/19 15:22
 */


(function(){
    $$.loaderRes({
        css: [
            //-- Health CSS
            `css/product/health.css`,
            "js/tool/rrweb/rrweb.min.css",
            "js/tool/rrweb/style.css"
        ],
        scripts: [
            "js/product/productVersionControl.js",
            "js/product/orderHelper.js",
            "js/tool/rrweb/rrweb.min.js",
            "js/tool/rrweb/index.js",
            "js/tool/loki-db.js"
        ]
    });
})();

window.onload = function(){

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/19 14:45
     */
    const PAGE_STATE = {
        //-- 订单Token
        orderToken: null,
        //-- 投保数据
        insuranceData: {},
        //-- 健康告知数据源
        insuranceInfoHealthToldData: [],
        //-- 健康告知类型: [1: 单选问题, 4: 公告详情]
        healthToldType: 1,
        //-- 事件日志Token
        eventLogToken: null,
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader() {
        const orderToken = $$.getUrlParam("orderToken");
        $$.validPageParams(orderToken, "product/productList");

        const insuranceData = sessionStorage.getItem(`PRODUCT_DETAIL_TO_HEALTH_${orderToken}`);
        $$.validPageParams(insuranceData, "product/productList");

        PAGE_STATE.orderToken = orderToken;
        PAGE_STATE.insuranceData = JSON.parse(insuranceData);
        PAGE_STATE.eventLogToken = $$.getUrlParam("eventLogToken");

        //-- 页面初始化
        pageInit();
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 初始化页面
        initPageState();

        //-- 加载健康告知
        findHealth();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 回答 [是 or 否]
        $(".questions").on("click", ".questions-item-btn>div", function(){
            const activeThis = $(this).hasClass("active");
            const tips = $(this).attr("data-tips");
            const id = $(this).parent().attr("data-id");

            if(!activeThis){
                $(this).addClass("active");
                const isTrue = tips == 1;
                if(isTrue){
                    $(this).next().removeClass("active");
                }else{
                    $(this).prev().removeClass("active")
                }
                recordEventLog("T2020071315074986669632", `${id}-${isTrue}`);
            }
        });

        //-- 保存信息
        $(".submitBtn").on("click", function() {
            submit(this);
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){

        $$.clearHTMLNotes();

    }

    /**
     * 获取健康告知
     * @Author 肖家添
     * @Date 2019/9/19 15:07
     */
    function findHealth(){
        const {
            insuranceData: {
                productId
            }
        } = PAGE_STATE;

        const params = {
            insureId: productId
        };

        $$.request({
            url: UrlConfig.insuranceInfoHealthTold_data,
            pars: params,
            loading: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){

                    responseHandler(data.datas);

                }else{
                    $$.errorHandler(data.msg);
                }
            }
        });

        //-- 健康告知 -> 响应处理
        function responseHandler(data){
            if(!$$.isValidObj(data) || data.length <= 0){
                $$.throwTips();
            }

            PAGE_STATE.insuranceInfoHealthToldData = data;

            let html = "";
            data.forEach((item, index) => {
                const { id, question, type } = item;

                if(index == 0 && type == 4){
                    //-- 产品详情
                    html += `
                        <div class="questions-detail">
                            <div class="title">被保险人健康告知确认：</div>
                            <p class="detailContent">${question}</p>
                            <p class="tips">声明：本告知书以上各项回答均属实，并以此作为此保险合同之依据。如上述资料不属实。任何据此告知书而缮发的保险合同将视作无效。</p>
                            <i class="weui-icon-checked"></i>
                            <div class="weui-cells weui-cells_checkbox">
                                <label class="weui-cell weui-check__label" for="c1">
                                    <div class="weui-cell__hd">
                                        <input required="" pattern="{1,}" type="checkbox" tips="健康告知栏未勾选，无法保存投保信息哦~" class="weui-check" name="assistance" id="c1">
                                        <i class="weui-icon-checked"></i>
                                    </div>
                                    <div class="weui-cell__bd">我接受以上健康告知</div>
                                </label>
                            </div>
                        </div>
                    `;

                    PAGE_STATE.healthToldType = type;
                    $("#container>.bottomTips").hide();
                }else{
                    //-- 单选问题
                    html += `
                        <div class="questions-item">
                            <p class="content">${question}</p>
                            <div class="questions-item-btn" data-index="${index}" data-id="${id}">
                                <div data-tips="1">是</div>
                                <div data-tips="0">否</div>
                            </div>
                        </div>
                    `;

                    if($(".bottomTips").size() <= 0){
                        $("#container>.bottomTips").show();
                    }
                }
            });

            $("#container>.questions").html(html);

            //-- 绑定事件
            bindEvent();

            //-- 屏幕录制
            $$.screenRecording(PAGE_STATE.eventLogToken);

        }
    }

    /**
     * 保存信息
     * @Author 肖家添
     * @Date 2019/9/19 16:51
     */
    function submit(e){
        const {
            insuranceInfoHealthToldData,
            healthToldType
        } = PAGE_STATE;

        new Promise((resolve) => {
            switch (healthToldType) {
                case 1:{
                    //-- 单选问题
                    const selectedSize = $(".questions-item-btn>div.active").size();

                    //-- 检查选项是否填完整
                    if(selectedSize != insuranceInfoHealthToldData.length){
                        $$.throwTopTips("保存失败，非常抱歉，还有题目没完成，请全部填写！");
                    }

                    const answers = $(".questions-item-btn>div.active");

                    //-- 检查答案是否正确
                    for (let i = 0; i < answers.length; i++) {
                        const tips = $(answers[i]).attr("data-tips");
                        const index = $(answers[i]).parent().attr("data-index");

                        if(insuranceInfoHealthToldData[index].answer != tips){
                            $$.throwTopTips("保存失败，非常抱歉，被保险人的健康告知条件不符合本产品要求请重新选择产品");
                        }
                    }

                    resolve();

                    break;
                }
                case 4:{
                    //-- 公告详情
                    weui.form.validate("#pageForm", function(error){
                        if(!error){
                            resolve();
                        }
                    });
                    break;
                }
            }
        }).then(() => {
            orderHandler();
        });
    }

    /**
     * 订单处理
     * @Author 肖家添
     * @Date 2019/9/20 12:15
     */
    function orderHandler(){
        const {
            //-- 投保数据
            insuranceData
        } = PAGE_STATE;

        OrderHelper.orderHandler(insuranceData);
    }

    /**
     * 保存事件日志
     * @Author 肖家添
     * @Date 2020/7/15 14:56
     */
    function recordEventLog(eventId, evenResult){
        const { eventLogToken, orderToken } = PAGE_STATE;
        $$.recordEventLog({
            requestToken: eventLogToken,
            evenId: eventId,
            evenResult
        });
    }
}