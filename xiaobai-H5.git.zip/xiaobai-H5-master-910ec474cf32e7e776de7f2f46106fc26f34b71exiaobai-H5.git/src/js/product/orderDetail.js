

/**
 * 订单详情 JS
 * @Author 肖家添
 * @Date 2019/10/6 16:13
 */

ShawHandler.loaderRes({
    css: [
        "js/tool/rrweb/rrweb.min.css",
        "js/tool/rrweb/style.css"
    ],
    scripts: [
        //-- Order helper
        "js/product/productVersionControl.js",
        `js/product/orderHelper.js`,
        "js/tool/rrweb/rrweb.min.js",
        "js/tool/rrweb/index.js",
        "js/tool/loki-db.js"
    ]
});

window.onload = function(){

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 订单Token
        orderToken: null,
        //-- 订单分享Token
        beShareToken: null,
        //-- 投保人
        policyHolder: null,
        //-- 支付回调
        paymentCbk: false,
        //-- 产品库Id
        productId: null,
        //-- 销售展示产品名称
        sellProductName: null,
        //-- 出单类型
        issueType: null,
        //-- 事件日志Token
        eventLogToken: null,
    };

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader() {

        const orderToken = $$.getUrlParam("orderToken"),
            beShareToken = $$.getUrlParam("beShareToken"),
            paymentCbk = $$.getUrlParam("paymentCbk");
        $$.validPageParams(orderToken, "product/productList");

        PAGE_STATE.orderToken = orderToken;
        PAGE_STATE.beShareToken = beShareToken;
        PAGE_STATE.paymentCbk = paymentCbk;
        PAGE_STATE.eventLogToken = $$.getUrlParam("eventLogToken");

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

        //-- 验证订单是否支付成功
        verifyOrderPaymentSuccess();
    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 隐藏/显示 子级
        $(".orderDetails-item .orderDetails-item-toggle").off().on("click", function(){
            $(this).parent().toggleClass("on");
        });

        //-- 复选框选中事件
        $(".checkbox").off().click(function(e){
            const readStatus = $(this).find(".read-status"),
                hasActive = readStatus.hasClass("readed"),
                tips = $(this).attr("data-tips");

            readStatus.toggleClass("readed");

            switch(tips){
                //-- 投保声明
                case "insuranceDeclaration":{
                    const ele = $(".payContainer .payContainer-goPay");

                    if(hasActive){
                        ele.removeClass("active");
                    }else{
                        ele.addClass("active");
                    }
                    recordEventLog("T2020071315075568269632", !hasActive);
                    break;
                }
            }
        }).click();

        //-- 保障项目展开/收起
        $(".insureEnsure-container").off().on("click", ".insureEnsure-title", function(){
            $(this).parent().toggleClass("on");
        });

        //-- 去支付
        $(".payContainer-goPay").off().click(function(){
            orderPaymentBefore(this);
        });

        //-- 易安产品 - 投保声明
        $(".yianInsurance").off().click(function(){
            $('.orderContainer').css({'height':'100%', 'overflow':'hidden'});
            $('#previewDeclaration').show();
        });

        //-- 易安产品 - 投保声明 - 点击阴影层关闭
        $(".closePreviewDeclaration").off().click(function(){
            $('.orderContainer').css({'height':'auto', 'overflow':'auto'});
            $('#previewDeclaration').hide();
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){
        //-- 展开所有信息
        $(".orderDetails>.orderDetails-item").addClass("on");

        //-- 自动跳转
        $$.staticPushAutoBind();
    }

    /**
     * 加载订单详情
     * @Author 肖家添
     * @Date 2019/10/5 12:02
     */
    function loadOrderDetail(){
        const { orderToken, beShareToken } = PAGE_STATE;

        $$.request({
            url: UrlConfig.insuranceInfo_loadOrderDetail,
            pars: { orderToken, beShareToken },
            loading: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){
                    responseHandler(data.datas);
                }else{
                    $$.unBindAll();
                    $$.errorHandler(data.msg);
                }
            }
        });

        //-- 订单详情 -> 响应处理
        function responseHandler(data){
            const {
                //-- 销售展示产品名称
                sellProductName,
                //-- 销售产品条件名称
                conditionContent,
                //-- 投保日期
                issueDate,
                //-- 起保日期
                effectiveDate,
                //-- 终保日期
                expireDate,
                //-- 投保人, JSONObject
                policyHolder,
                //-- 被保人, JSONArray
                insuredUserInfo,
                //-- 订单需支付金额
                orderPayMoney,
                //- 被保人数量
                beInsureSize,
                //-- 保障项目
                insureEnsure,
                //-- 是否显示健康告知 [true: 显示, false: 隐藏]
                isShowHealthy,
                //-- 订单发票
                orderMailInvoiceInfo,
                //-- 订单Id
                orderId,
                //-- 订单状态
                orderStatus,
                //-- 中文订单状态
                orderStatusChinese,
                //-- 是否是企业险 [true: 是, false: 不是]
                isEnterpriseInsurance,
                //-- 分享Token
                beShareToken,
                //-- 订单扩展信息
                orderExtendAddress,
                //-- 产品id
                productId,
                //-- 出单类型
                issueType,
                //-- 投保须知
                ensureExplainContent
            } = data;

            PAGE_STATE.beShareToken = beShareToken;
            PAGE_STATE.policyHolder = policyHolder;
            PAGE_STATE.productId = productId;
            PAGE_STATE.sellProductName = sellProductName;
            PAGE_STATE.issueType = issueType;
            const calcMoney = transferMoney(orderPayMoney);

            $("#data-sellProductName").html(sellProductName);
            $("#data-conditionContent").html(conditionContent);
            $("#data-issueDate").html(issueDate);
            $("#data-effectiveDate, #business-data-effectiveDate").html(`${effectiveDate} 00时`);
            $("#data-expireDate, #business-data-expireDate").html(`${expireDate} 24时`);
            $("#data-payMoney").html(`￥${calcMoney}（${beInsureSize}人）`);
            $("#data-totalMoney").html(`￥${calcMoney}`);
            $("#data-orderStatus").html(orderStatusChinese);
            $("#data-orderId").html(orderId);
            $("#data-orderPayMoney").html(`${calcMoney}元`);

            //-- 企业险
            (function(){
                if(isEnterpriseInsurance){
                    $(".business-item").show();
                    $(".personal-item").hide();
                }else{
                    $(".business-item").hide();
                    $(".personal-item").show();
                }
            })();

            //-- 投保人
            (function(){
                const { name, mobile, cardType, cardNum, birthday, sex, companyName, email, credentialsFile, companyAddress,address ,postcode ,companyTel} = policyHolder;

                $("#data-policyHolder-name, #business-data-policyHolder-name").html(name);
                $("#data-policyHolder-mobile").html(mobile);
                $("#business-data-policyHolder-companyTel").html(companyTel);
                $("#data-policyHolder-email").html(email);
                $("#data-policyHolder-cardType").html(cardType);
                $("#data-policyHolder-cardNum, #business-data-policyHolder-idNumber").html(cardNum);
                $("#business-data-policyHolder-idNumber").html(cardNum);
                $("#data-policyHolder-birthday").html(birthday);
                $("#data-policyHolder-sex").html(sex);

                //--康健保and海外重疾提交页面多增加显示邮政编码以及地址
                if(productId.toString() == "100396" || productId.toString() == "100398"){
                    if($$.isValidObj(address)){
                        $("#insuredAddress").show();
                        $("#data-policyHolder-address").html(address);
                    }
                    if($$.isValidObj(postcode)){
                        $("#postcode").show();
                        $("#data-policyHolder-postcode").html(postcode);
                    }
                    if($$.isValidObj(companyTel)){
                        $("#companyTel").show();
                        $("#data-policyHolder-companyTel").html(companyTel);
                    }
                }

                //-- 都会天使百万医疗
                if (productId.toString() == "100383"){
                    $("#insuredAddress").show();
                    if (Object.keys(orderExtendAddress).length > 0){
                        $("#data-policyHolder-address").text(orderExtendAddress["policyAddress"]);
                    }

                    $(".metlife").show();
                    $(".common").hide();
                }

                if (productId.toString() == "100375" || productId.toString() == "100376" || productId.toString() == "100377" || productId.toString() == "100378"){
                    $(".axa").show();
                    $(".common").hide();
                }

                if (productId.toString() == "100379"){
                    $(".yian").show();
                    $(".common").hide();
                }

                //-- 易安产品 显示手机号
                if (productId == 100338 || productId == 100390|| productId == 100391 || productId == 100392 || productId == 100393 || productId == 100394){
                    if($$.isValidObj(companyTel)){
                        $(".business-data-policyHolder-mobile").show();
                        $("#business-data-policyHolder-mobile").html(mobile);
                    }
                }

                //-- 易安产品
                if (productId == 100390 || productId == 100391 || productId == 100392 || productId == 100393 || productId == 100394){
                    $(".yianInsurance").show();
                    $(".common").hide();

                    $('.previewDeclarationContainers').html(insuranceDeclaration[productId.toString()]);
                    if ($$.isValidObj(ensureExplainContent)) $('.previewInformationContainers').html(ensureExplainContent);

                    //-- 易安产品 - 投保须知
                    $(".insuranceInformation").off().click(function(){
                        $('#previewInformation').show();
                    });

                    //-- 易安产品 - 投保须知 - 点击阴影层关闭
                    $(".closePreviewInformation").off().click(function(){
                        $('#previewInformation').hide();
                    });
                }

                /**----- 协议 事件绑定 ----**/
                $(".metlife span").on("click", function() {
                    //-- 固定路径跳转
                    const url = $(this).attr("data-url");
                    location.href = url;
                });
                $(".yian span").on("click", function() {
                    //-- 固定路径跳转
                    const url = $(this).attr("data-url");
                    location.href = url;
                });

                if(isEnterpriseInsurance){
                    //-- 企业险
                    $("#business-data-policyHolder-companyName").html(companyName);
                    $("#business-data-policyHolder-address").html(companyAddress);

                    $("#business-data-policyHolder-email").html(email);

                    if($$.isValidObj(credentialsFile)){
                        $("#business-data-credentialsFile").attr("src", credentialsFile).fadeIn();
                    }

                    //-- 易安 - [食品安全险]
                    if (productId.toString() === "100391"){
                        //-- 营业地址
                        $('.businessArea').show();
                        $("#business-data-policyHolder-businessArea").html( `${orderExtendAddress["area"]}平方米`);
                    }

                    //-- 易安 - [商户综合险]
                    if (productId.toString() === "100390"){
                        //-- 营业地址
                        $('.businessAddress').show();
                        $("#business-data-policyHolder-businessAddress").html( `${orderExtendAddress["policyAddress"]} ${orderExtendAddress["policyAreaValue"]}`);
                    }
                }
            })();

            //-- 被保人
            (function(){
                if(!$$.isValidObj(insuredUserInfo))
                    return;

                let html = "";

                for(const index in insuredUserInfo){
                    const item = insuredUserInfo[index];
                    const { mobile } = policyHolder;
                    const { name, cardType, cardNum, birthday, sex, relationship, occName } = item;
                    let { insuredAddress, insuredAreaValue, insuredCityValue, insuredProvinceValue, petAge, petId, petName, petSex, petSterilisation, petType ,bulidingAddress ,steelNo ,labelNo ,facNo ,sellOrderIdNum} = orderExtendAddress;

                    let address = '';
                    //-- 易安 宠物产品
                    if (productId.toString() == "100392"){
                        if (Object.keys(orderExtendAddress).length > 0){
                            address = insuredProvinceValue + " " + insuredCityValue + " " + insuredAreaValue;  // 地址（省+市+区）
                            petType = petType == "01"?'猫':"犬";
                            petSex = petSex == '01'?'公':(petSex == '02'?'母':'其他');
                            let petAgeList = petAge.toString().split('-');
                            petAge = petAgeList[0] + '年-' + petAgeList[1] + '个月';
                            petSterilisation = petSterilisation == "01"?'是':"否";
                        }
                    }

                    if(isEnterpriseInsurance){
                        html += `
                            <li>
                                <span>${name}</span>
                                <span>${cardNum}</span>
                            </li>
                        `;
                    }else{
                        html += `
                            <li>
                                <span>您为谁投保(关系)</span>
                                <span>${relationship}</span>
                            </li>
                            <li>
                                <span>姓名</span>
                                <span>${name}</span>
                            </li>
                            <li>
                                <span>手机</span>
                                <span>${mobile}</span>
                            </li>
                            <li>
                                <span>证件类型</span>
                                <span>${cardType}</span>
                            </li>
                            <li>
                                <span>证件号码</span>
                                <span>${cardNum}</span>
                            </li>
                            <li>
                                <span>出生日期</span>
                                <span>${birthday}</span>
                            </li>
                            <li>
                                <span>性别</span>
                                <span>${sex}</span>
                            </li>
                            ${(productId.toString() == "100388" || productId.toString() == "100316" || productId.toString() == "100317" || productId.toString() == "100329") ? `
                            <li>
                                <span>地址</span>
                                <span>${Object.keys(orderExtendAddress).length > 0?orderExtendAddress["bulidingAddress"]:""}</span>
                            </li>
                            ` : "" }
                            ${productId.toString() == "100383" ? `
                            <li>
                                <span>地址</span>
                                <span>${Object.keys(orderExtendAddress).length > 0?orderExtendAddress["insuredProvinceValue"]+orderExtendAddress["insuredCityValue"]:""}</span>
                            </li>
                            ` : "" }
                            ${ $$.isValidObj(occName) ? `
                            <li>
                                <span>职业</span>
                                <span>${occName}</span>
                            </li>
                            ` : "" }
                            ${productId.toString() == "100392" ? `
                            <li>
                                <span>地址</span>
                                <span>${address}</span>
                            </li>
                            <li>
                                <span style="width: 25%">详细地址</span>
                                <span style="width: 70%; max-height: 40px;overflow-y: scroll;">${insuredAddress}</span>
                            </li>
                            <li class="petProduct">
                                <span>宠物类型</span>
                                <span>${petType}</span>
                            </li>
                            <li class="petProduct">
                                <span>宠物品种</span>
                                <span>${petName}</span>
                            </li>
                            <li class="petProduct">
                                <span>电子识别码</span>
                                <span>${petId}</span>
                            </li>
                            <li class="petProduct">
                                <span>宠物性别</span>
                                <span>${petSex}</span>
                            </li>
                            <li class="petProduct">
                                <span>宠物年龄</span>
                                <span>${petAge}</span>
                            </li>
                            <li class="petProduct">
                                <span>是否绝育</span>
                                <span>${petSterilisation}</span>
                            </li>
                            ` : "" }
                             ${productId.toString() == "100357" ? `
                            <li>
                                <span>燃气运送地址</span>
                                <span>${bulidingAddress}</span>
                            </li>
                            <li class="petProduct">
                                <span>标签</span>
                                <span>${steelNo}</span>
                            </li>
                            <li class="petProduct">
                                <span>钢码</span>
                                <span>${labelNo}</span>
                            </li>
                            <li class="petProduct">
                                <span>出厂编码</span>
                                <span>${facNo}</span>
                            </li>
                            <li class="petProduct">
                                <span>渠道订单号</span>
                                <span>${sellOrderIdNum}</span>
                            </li>
                            ` : "" }
                        `;
                    }
                    if((parseInt(index) + 1) < insuredUserInfo.length){
                        html += `
                            <div class="beInsureInfoLine"></div>
                        `;
                    }
                }

                $("#data-beInsure-info").html(html);
            })();

            //-- 保障项目
            (function(){
                if(!$$.isValidObj(insureEnsure)){
                    return;
                }

                let html = "";
                for(const item of insureEnsure){
                    const { name, money, detail } = item;

                    html += `
                        <div>
                            <div class="insureEnsure-title">
                                <div class="insureEnsure-name">${name}</div>
                                <div class="insureEnsure-money">${money}</div>
                                ${ $$.isValidObj(detail) ? `
                                    <div class="insureEnsure-toggle"></div>
                                ` : "" }
                            </div>
                            ${ $$.isValidObj(detail) ? `
                                <div class="insureEnsure-detail">
                                    ${detail}
                                </div>
                            ` : "" }
                        </div>
                    `;
                }

                $("#data-insureEnsure").html(html);
            })();

            //-- 订单发票
            (function(){
                if(!$$.isValidObj(orderMailInvoiceInfo)){
                    $("#invoice-container").hide();
                    return;
                }

                const { invoiceName, invoicePhone, invoiceMoney, invoiceType, invoiceAddress, invoiceMail, logisticsRange } = orderMailInvoiceInfo;
                let goodsName = "电子发票";

                if(invoiceType == 1){
                    //-- 纸质发票
                    goodsName = "发票、保单";
                    $("#data-invoice-address").html(invoiceAddress).parent().show();

                    $("#data-invoice-logisticsRange").html(`${logisticsRange}：${transferMoney(invoiceMoney)}元`).parent().show();
                }else{
                    //-- 电子发票
                    $("#data-invoice-mail").html(invoiceMail).parent().show();
                }

                $("#data-invoice-goodsName").html(goodsName);
                $("#data-invoice-name").html(invoiceName);
                $("#data-invoice-phone").html(invoicePhone);
                $("#data-totalMoney").html(`￥${transferMoney(orderPayMoney + invoiceMoney)}`);
            })();

            //-- 订单状态
            (function(){
                //-- 见费出单 + 支付回调 = 隐藏支付按钮
                if(issueType == 2 && $$.getUrlParam("paymentCbk") == "true"){
                    $("#payContainer").hide();
                    return;
                }
                if($$.isValidObj(orderStatus)){
                    switch (orderStatus) {
                        case 0:
                        case 1:
                        case 8:{
                            //-- 支付组件高度兼容
                            const payContainerHeight = $(".payContainer").outerHeight();

                            $(".orderContainer").css({"padding-bottom": `${payContainerHeight}px`});
                            $(".payContainer").css({opacity: 1});
                            $(".pageTitle").css('display','flex');
                            $(".progress").show();

                            break;
                        }
                        default:{
                            $(".payContainer").remove();
                            $(".paymentOrderDetail").show();
                            break;
                        }
                    }
                }
            })();

            function transferMoney(money){
                if($$.isValidObj(money) && money > 0){
                    return parseFloat(money.toString()).toFixed(2);
                }else{
                    return 0.00;
                }
            }

            //-- 订单分享
            shareOrder();

            //-- 屏幕录制
            $$.screenRecording(PAGE_STATE.eventLogToken);
        }
    }

    /**
     * 订单支付前的数据校验
     * @Author 肖家添
     * @Date 2019/10/9 21:03
     */
    function orderPaymentBefore(e){
        if(!$$.checkHasCls({ele: e, throws: false})){
            $$.alert("请先勾选相关协议条款和声明！");
            return;
        }

        const { orderToken, beShareToken, issueType, eventLogToken, productId } = PAGE_STATE;

        //-- 易安产品
        if (productId == 100390 || productId == 100391 || productId == 100392 || productId == 100393 || productId == 100394){
            $('.closePreviewDeclaration>span').hide();
            $('.goPay').css('display', 'flex');
            $('.orderContainer').css({'height':'100%', 'overflow':'hidden'});
            $('#previewDeclaration').show();

            //-- 取消/确认
            $(".goPay>.cancel, .goPay>.determine").off().click(function(){
                $('.orderContainer').css({'height':'auto', 'overflow':'auto'});
                $('#previewDeclaration').hide();
                $('.goPay').hide();
                $('.closePreviewDeclaration>span').show();

                if ($(this).attr('data-value') == '1') goPay();     // 确认 => 去支付
            });

            return;
        }

        goPay();

        //-- 去支付
        function goPay() {
            const isBillAtCost = issueType == 2;
            OrderHelper.orderPaymentBefore(orderToken, beShareToken, function(){
                recordEventLog("T2020071315071303069632");
                if(isBillAtCost){
                    $$.request({
                        url: UrlConfig.management_mobileInsuranceInfo_bindSellBillAtCostHandler,
                        pars: {orderToken: orderToken},
                        loading: true,
                        sfn: function(data){
                            const { success, msg, datas } = data;
                            if(success && $$.isValidObj(datas)){
                                const { payUrl } = datas;
                                location.href = payUrl;
                            }else{
                                $$.closeLoading();
                                if("I0004" == msg){
                                    $$.alert("订单已经支付成功！", function(){
                                        window.location.reload();
                                    });
                                    return;
                                }
                                $$.alert(msg);
                            }
                        }
                    });
                    return;
                }
                $$.push("product/paymentDetail", {
                    orderToken,
                    beShareToken,
                    eventLogToken
                });
            }, !isBillAtCost);
        }
    }

    /**
     * 订单分享
     * @Author 肖家添
     * @Date 2019/11/21 15:11
     */
    function shareOrder(){
        const imgUrl = $Constant.shareLogo,
            { orderToken, beShareToken, policyHolder, sellProductName } = PAGE_STATE,
            policyHolderName = policyHolder.name;
        let isShare = $$.getUrlParam("isShare");
        if(!$WeChat.isWx() || !$$.isValidObj(policyHolderName) || !$$.isValidObj(beShareToken) || ($$.isValidObj(isShare) && isShare === 'true')){
            WE_CHAT_MENU_FLAG = false;
            weChatMenuHandler();
            $('.gotoShare').hide();
            return;
        }

        isShare = 'true';
        let linkUrl = window.location.href.split("?")[0];
        linkUrl += $$.jsonToUrlParams({
            orderToken,
            beShareToken,
            isShare
        });

        weChatJSTool.share({
            _imgUrl: imgUrl,
            _lineLink: linkUrl,
            _shareTitle: `${sellProductName}保单详情`,
            _descContent: `亲，您的保障已出订单，点击可了解更多。`
        });
    }

    /**
     * 验证订单是否支付成功
     * @Author 肖家添
     * @Date 2019/12/5 10:19
     */
    function verifyOrderPaymentSuccess(){
        const { orderToken, beShareToken, paymentCbk } = PAGE_STATE;
        if(paymentCbk){
            //-- 支付完成
            $$.pushHistory();
            window.addEventListener("popstate", function() {
                $$.push("product/productList");
            }, false);
            OrderHelper.orderPaymentOverHandler(orderToken, beShareToken, function(){
                //-- 加载订单详情
                loadOrderDetail();
            });
        }else{
            //-- 加载订单详情
            loadOrderDetail();
        }
    }
    $('.gotoShare, .weChatShare').on('click',function () {
        let state = $(this).attr('data-state');
        let text = '点击右上角，发给客户支付~';
        if ($$.isValidObj(state) && state == '1') text = '点击右上角，分享订单给好友~';
        $$.showShareView(text);
        return false;
    });
    /* 取消 分享 */
    $('#popup .bg,.showFrame').on('click',function () {
        $('#popup').hide();
        return false;
    });

    /**
     * 保存事件日志
     * @Author 肖家添
     * @Date 2020/7/13 17:30
     */
    function recordEventLog(eventId, evenResult){
        const { eventLogToken, orderToken } = PAGE_STATE;
        $$.recordEventLog({
            requestToken: eventLogToken,
            evenId: eventId,
            orderId: orderToken,
            evenResult
        });
    }

};
