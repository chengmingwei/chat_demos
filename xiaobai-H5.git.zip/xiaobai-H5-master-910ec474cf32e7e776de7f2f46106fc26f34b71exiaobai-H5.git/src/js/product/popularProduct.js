$(function(){
	/* 加载保险热门产品列表  */
	$$.request({
        url: UrlConfig.getHotProductsList_data,
        sfn: function(data){
            if(data.success){
                console.log(data);
                const { datas, tips_promotionFeeDisplay } = data;
				
                bindInsuranceInfoElement(datas, tips_promotionFeeDisplay);
            }else{
                $$.errorHandler(`获取产品失败！[${data.msg}]`);
            }
        }
    });
    
    /* 绑定保险产品元素 */    
    function bindInsuranceInfoElement(list, tips_promotionFeeDisplay){
        let html = "";

        if($$.isValidObj(list)){
            $$.hideNoResultView();

            list.forEach((item) => {
                const { listShowCover, labelList } = item;

                //-- product labels handler start
                let labelsHtml = "";
                if($$.isValidObj(labelList)){
                    labelList.forEach((item) => {
                        const { labelName } = item;
                        labelsHtml += `<span>${labelName}</span>`;
                    });
                }
                //-- product labels handler end

                html += `
                    <li data-id="${item.insuranceInfoId}" data-sellId="${item.id}">
                        <span class="left productImage" style="background-image: url(${$$.isValidObj(listShowCover) ? listShowCover : $$.imageUrlCompatible(item.plogo)});"></span>
                        <div class="right">
                            <div class="top">
                                <h3>${item.name}${item.ageType == 1 ? "（成年版）" : "（未成年版）"}</h3>
                                <p class="icon" style="${$$.isValidObj(labelsHtml) ? `` : `padding-top: 0px;`}">
                                    ${labelsHtml}
                                </p>
                                <p class="desc">${item.productIntroduce}</p>
                            </div>
                            <div class="bottom">
                                <p class="price">${parseFloat($$.changeIsNilVal(item.sellMoney, 0)).toFixed(2)}元起</p>
                                <div class="promotionFee"></div>
                            </div>
                        </div>
                    </li>
                `;
                
                if($$.isValidObj(tips_promotionFeeDisplay)){
		        	$(".promotionFee").text(`立赚${item.tiMoney}%`);
		        }
            });
        }else if(list.length <= 0){
            $$.showNoResultView({
                msg: "搜索不到该产品"
            });
        }
		$(".content>.list").html(html);
        let channel;
        try{
            const that = $("#popularProductScript");
            channel = that.attr("data-channel");
        }catch (e) {

        }finally {
            channel = $$.changeIsNilVal(channel, "none");
        }
        //-- 跳转 产品详情
        $(".content .list li").off().click(function () {
            const productId = $(this).attr("data-id");
            const sellId = $(this).attr("data-sellId");
            if(PAGE_APP){
                $$.pushAPP("/product/detail", {
                    insuranceInfoId: productId,
                    sellId: sellId
                });
            }else{
                $$.push("product/productDetail", {productId, sellId, channel});
            }
        });
        
        //-- 推广费显示隐藏
        if(!$$.isValidObj(tips_promotionFeeDisplay)){
        	$(".promotionFee").remove();
        }
        //-- 根据缓存判断 推广费显示隐藏
        const promotionFeeDisplay = localStorage.getItem($Constant.promotionFeeDisplayKey);
        if(!$$.isValidObj(promotionFeeDisplay)){
            $(".promotionFee").remove();
        }
    }
});