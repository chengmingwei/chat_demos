/**
 *  我的评价（经纪人）JS
 * @Author 吴成林
 * @Date 2020-1-16 16:25:12
 */
window.onload = function(){

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
        checkShare();
    }

    /**
     * 页面加载对必要的参数作处理
     */
    function pageInit(){
        //-- 跳转自动绑定
        $$.staticPushAutoBind();

        dataLoading();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        /* 最低选择1星==1分 */
        let score = 1;

        /* 选择星星事件 */
        $('.star>div').on('click', function () {
            score = $(this).attr("data-id");
            /* 选中的 */
            for (let i=0; i<score; i++) {
                $(".star>div:eq("+i+")").addClass("selected").removeClass("unselected");
            }
            /* 未选中的 */
            if (score < 5) {
                for (let i=score; i<=5; i++) {
                    $(".star>div:eq("+i+")").addClass("unselected").removeClass("selected");
                }
            }
        });

        /* 对经纪人的印象 事件 */
        $(".impression>span").on("click",function(){
            if ($(this).hasClass("impression-click")) {
                $(this).removeClass("impression-click");
            } else {
                $(this).addClass("impression-click");
            }
        });

        $("textarea").bind('input propertychange', function () {
            $(".count").html($(this).val().length)
        });
        /* 提交 事件 */
        $('.submit').on('click', function () {
            let share = $$.getUrlParam("share");
            let memberId = $$.getUrlParam("memberId");
            let id = $$.getUrlParam("id");//订单号
            let wxOpenId = $$.getUrlParam("weChatOpenId");
            let count = $("textarea").val();
            let impression =  new Array();
            $(".impression .impression-click").each(function(i,e){
                impression[i] =  $(this).html();
            });
            console.log(impression);
            console.log(count);
            let pingfen = 0;
            $(".selected").each(function(i,e){
              pingfen = i+1;
            });
            console.log(pingfen);
            if (impression.length === 0){
                $$.alert("请选择经纪人印象！");
                return;
            }
            if (pingfen === 0){
                $$.alert("请选择综合评价！");
                return;
            }
            if (count.length === 0){
                $$.alert("请输入评价内容！");
                return;
            }
            $$.request({
                url: UrlConfig.orderevaluation_insertOrderEvaluation,
                loading: true,
                pars: {
                    openid:wxOpenId,
                    score:pingfen,
                    evaluation:count,
                    memberId:memberId,
                    orderId:id,
                    impression:impression.join(","),
                    isShow:1
                },
                requestBody: true,
                sfn: function(data) {
                    $$.closeLoading();
                    if(data.success) {
                        let index = layer.open({
                            content:
                                `<div class="popupContent">
                                    <b>感谢您的认真评价！</b>
                                    <div class="answer">
                                        <span class="affirm">好的</span>
                                    </div>
                                </div>`
                        });

                        /* 完成 事件 */
                        $(".answer").on("click", function(){
                            layer.close(index);

                            /* 页面跳转 */
                            $$.gotoLogin();
                        });
                    } else {
                        $$.layerToast(data.msg);
                        return null;
                    }
                },
                ffn: function(data) {
                    $$.errorHandler();
                }
            });
        })
    }
};

//微信授权登录
function checkShare() {
    console.log();
    let share = $$.getUrlParam("share");
    let memberId = $$.getUrlParam("memberId");
    let id = $$.getUrlParam("id");//订单号
    if (share === 'true'){
        let url = window.location.search;
        url = url.replace("true",'false');
        url = "product/myEstimate/myEstimateBroker.html"+url;
        console.log('----url',url);
        ShawHandler.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: url,
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_7,
                otherParams: JSON.stringify({"objectId": id,"type":1,"memberId":memberId})
            },
            loading: true,
            sfn: function(data){
                $$.closeLoading();
                location.href = data.datas;
            }
        });
    }
}
