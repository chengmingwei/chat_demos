

/**
 * 保障详情 JS
 * @Author 肖家添
 * @Date 2019/9/5 16:24
 */


let planId_PG = null;

window.onload = function(){

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/9/5 16:25
     */
    function pageLoader() {

        planId_PG = $$.getUrlParam("planId");

        $$.validPageParams(planId_PG, "product/productList");

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/9/5 16:25
     */
    function pageInit() {

        //-- 加载保障项目
        findInsureEnsure();

        $$.changeVersion();
        countAction("xb_2003");

    }

    /**
     * 获取保障项目
     * @Author 肖家添
     * @Date 2019/9/5 16:31
     */
    function findInsureEnsure(){
        $$.request({
            url: UrlConfig.insuranceEnsure_data,
            loading: true,
            requestBody: true,
            pars: {
                planId: planId_PG
            },
            sfn: function(data){
                if(data.success){
                    responseHandler(data.datas);
                }else{
                    $$.errorHandler(data.msg);
                }
            }
        });

        /**
         * 获取保障项目 -> 响应处理
         * @Author 肖家添
         * @Date 2019/9/5 16:34
         */
        function responseHandler(data){
            try{
                let html = "";

                if($$.isValidObj(data)){
                    data.forEach((item, index) => {
                        html += `
                            <li>
                                <p class="title">
                                    <span style="padding-right: 10px">${item.name}</span>
                                    <span >${item.money}</span>
                                </p>
                                ${$$.isValidObj(item.detail) ? `
                                    <p class="content">
                                        ${item.detail}
                                    </p>                                    
                                ` : ""}
                            </li>
                        `;
                    });
                }

                if(!$$.isValidObj(html)){
                    $$.layerToast("无保障项目~");
                }

                $(".list").html(html);
            }finally {
                $$.closeLoading();
            }
        }
    }

}