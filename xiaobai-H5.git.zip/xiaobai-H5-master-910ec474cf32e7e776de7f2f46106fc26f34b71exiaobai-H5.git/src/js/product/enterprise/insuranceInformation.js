

/**
 * 企业险投保资料 JS
 * @Author 肖家添
 * @Date 2019/11/6 14:55
 */


(function(){
    $$.loaderRes({
        scripts: [
            "js/product/orderHelper.js",
            "js/tool/lrz/lrz.bundle.js"
        ]
    });
})();

window.onload = function(){

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2019/9/16 14:56
     */
    const PAGE_STATE = {
        //-- 订单Token
        orderToken: null,
        //-- 保障期限单位
        sellMinDate: null,
        //-- 金额单位
        sellMoneyUnit: null,
        //-- 表单数据
        formData: {
            //-- 营业执照OSS数据
            businessLicense: null,
            //-- 被保人数据  ``JSONObject, key = cardNumber, value = data
            beInsureData: {},
            //-- 智能识别数据  ``JSONObject, key = cardNumber, value = data
            scanData: {}
        },
        //-- 产品Id
        productId: null,
        //-- 起保人数
        numberOfInsuredPersons: 5,
        //-- 投保人省份代码
        policyProvinceCode: null,
        //-- 投保人省份
        policyProvinceValue: null,
        //-- 投保人城市代码
        policyCityCode: null,
        //-- 投保人城市
        policyCityValue: null,
        //-- 投保人市区代码
        policyAreaCode: null,
        //-- 投保人市区
        policyAreaValue: null,
        //-- 产品条件
        conditionContent: null,
    }

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){

        const orderToken = $$.getUrlParam("orderToken");
        $$.validPageParams(orderToken, "product/productList", {insuranceType: 2});

        PAGE_STATE.orderToken = orderToken;

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

        //-- 加载页面
        loadPage();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        //-- 营业执照
        $(".uploadBusinessLicense-file").change(function(){
            fileUploadHandler(this, "30001");
        });

        //-- 打开被保人列表窗口
        $Listener.onTap("#openBeInsureModel", function(e){
            popupViewHandler("#beInsureSection", "add");
        });

        //-- 关闭被保人列表窗口
        $Listener.onTap(".popupView-bg", function(e){
            if(!$(e).hasClass("popupView-notClose")){
                //-- 智能识别流程
                if(isScanAction()){
                    $(".fixedBottomMenu-submit").html("提交订单");
                }
                popupViewHandler($(e).parent(), "remove");
            }
        });

        //-- 返回
        $Listener.onTap(".fixedBottomMenu-back", function(){
            const beInsureSection = $("#beInsureSection"),
                beInsureInputWayAiSection = $("#beInsureInputWay-ai-section");

            //-- 智能识别流程
            if(isScanAction()){
                if(Object.keys(PAGE_STATE.formData.scanData).length > 0){
                    $$.confirm({
                        title: "确定要返回吗？扫描的结果不会保存哦~~！",
                        onOkLabel: "确定",
                        onCancelLabel: "取消",
                        onOk: function(){
                            handler();
                        }
                    });
                }else{
                    handler();
                }

                function handler(){
                    $(".fixedBottomMenu-submit").html("提交订单");
                    popupViewHandler(beInsureInputWayAiSection, "remove");
                }
                return;
            }

            //-- 被保人列表流程
            if(beInsureSection.hasClass("show")){
                popupViewHandler(beInsureSection, "remove");
                return;
            }

            //-- 页面离开流程
            $$.confirm({
                title: "订单还未提交，确认离开吗？",
                onOkLabel: "继续填写",
                onCancelLabel: "残忍离开",
                onCancel: function(){
                    history.go(-1);
                }
            });
        });

        //-- 打开被保人录入方式
        $Listener.onTap(".addInsured, .section-body-append", function(){
            verifyEnterpriseInformation();
            popupViewHandler("#beInsureInputWay", "add");
        });

        //-- 被保人录入方式 -> 手动输入
        (function(){
            //-- OPEN
            $Listener.onTap("#beInsureInputWay-manual", function(){
                popupViewHandler("#beInsureInputWay", "remove");
                popupViewHandler("#beInsureInputWay-manual-section", "add");

                $("#beInsureInputWay-manual-section").addClass("default").removeClass("update").removeAttr("data-idCard");
            });

            //-- CLOSE
            $Listener.onTap("#beInsureInputWay-manual-section-close", function(){
                popupViewHandler("#beInsureInputWay-manual-section", "remove");
            });

            //-- OK
            $Listener.onTap("#beInsureInputWay-manual-section-ok", function(e){
                const body = $(e).parent().parent(),
                    section = body.parent(),
                    isEdit = section.hasClass("update"),
                    editIdCard = section.attr("data-idCard"),
                    beInsureName = body.find("input[name=beInsureName]").val(),
                    beInsureIdCard = body.find("input[name=beInsureIdCard]").val();

                //-- ADD BE_INSURE DATA
                addBeInsureData(beInsureName, beInsureIdCard, isEdit, editIdCard);

                body.find("input").val("");
                popupViewHandler("#beInsureInputWay-manual-section", "remove");
                if(!isScanAction()) popupViewHandler("#beInsureSection", "add");
            });

            //-- DELETE
            $Listener.onTap("#beInsureInputWay-manual-section-delete", function(e){
                $$.confirm({
                    title: "确定删除吗？",
                    onOk: function(){
                        const section = $(e).parent().parent().parent(),
                            isUpdate = section.hasClass("update"),
                            idCard = section.attr("data-idCard");
                        if(!isUpdate || !idCard) return;

                        if(!isScanAction())
                            delete PAGE_STATE.formData.beInsureData[idCard];
                        else
                            delete PAGE_STATE.formData.scanData[idCard];

                        section.find("input").val("");
                        popupViewHandler("#beInsureInputWay-manual-section", "remove");

                        //-- GENERATE VIEW
                        generateBeInsureList(!isScanAction() ? 1 : 2);
                    }
                });
            });
        })();

        //-- 智能识别
        (function(){
            //-- 身份证识别
            $Listener.onTap("#beInsureInputWay-idCard", function(){
                $("#beInsureInputWay-ai-section .popupView-body-title span").html("身份证");
                $("#beInsureInputWay-ai-section .popupView-body-scan-type img").attr("src", "../../../images/product/enterprise/04.png");

                open(30002);
            });

            //-- 表格识别
            $Listener.onTap("#beInsureInputWay-table", function(e){
                $("#beInsureInputWay-ai-section .popupView-body-title span").html("表格");
                $("#beInsureInputWay-ai-section .popupView-body-scan-type img").attr("src", "../../../images/product/enterprise/06.png");

                open(30003);
            });

            //-- SCAN FOR ID CARD
            $Listener.bindEvent("change", ".uploadAI-file", function(e){
                const formType = $(e).attr("data-formType");
                fileUploadHandler(e, formType);
            });

            function open(formType = 30001){
                $(".uploadAI-file").val("").attr("data-formType", formType);
                $(".fixedBottomMenu-submit").html("确定");
                PAGE_STATE.formData.scanData = {};
                generateBeInsureList(2);
                popupViewHandler("#beInsureInputWay", "remove");
                popupViewHandler("#beInsureInputWay-ai-section", "add");
            }
        })();

        //-- 确定点击
        $Listener.onTap(".fixedBottomMenu-submit", function(e){
            if(!isScanAction()){
                //-- 提交订单
                submitOrder(e);
            }else{
                //-- 智能识别流程
                scanResultMergeToBeInsureData();
            }
        });

        //-- 打开被保人录入方式
        $Listener.onTap(".petInsuredProvinces", function(){
            weui.picker(chinaAreas_pet, {
                id: "addressPicker",
                container: "body",
                defaultValue: [110000, 110100, 110101],
                onConfirm: function (result) {
                    let names = "";
                    let ids = "";

                    for(const item of result){
                        names += `${item.label} `;
                        ids += `${item.value}-`;
                    }
                    if($$.isValidObj(names)){
                        names = names.substring(0, names.length - 1);
                        ids = ids.substring(0, ids.length - 1);
                    }

                    $("#petInsuredProvinces").val(names);
                    let idsList = ids.split("-");
                    let namesList = names.split(" ");
                    PAGE_STATE.policyProvinceCode = $$.isValidObj(idsList[0]) ? idsList[0]:"";
                    PAGE_STATE.policyProvinceValue = $$.isValidObj(namesList[0]) ? namesList[0]:"";
                    PAGE_STATE.policyCityCode = $$.isValidObj(idsList[1]) ? idsList[1]:"";
                    PAGE_STATE.policyCityValue = $$.isValidObj(namesList[1]) ? namesList[1]: "";
                    PAGE_STATE.policyAreaCode = $$.isValidObj(idsList[2]) ? idsList[2]:"";
                    PAGE_STATE.policyAreaValue = $$.isValidObj(namesList[2]) ? namesList[2]:"";
                }
            });
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){

        //-- 清理注释
        $$.clearHTMLNotes();

        //-- 自动跳转
        $$.staticPushAutoBind();

    }

    /**
     * 加载页面
     * @Author 肖家添
     * @Date 2019/11/6 20:31
     */
    function loadPage(){
        const { orderToken } = PAGE_STATE;

        $$.request({
            url: UrlConfig.businessInsurance_loadFillInInsuranceInformation,
            pars: { orderToken },
            loading: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){
                    responseHandler(data.datas);
                }else{
                    failHandler(data.msg);
                }
            }
        });

        //-- 加载页面 -> 响应处理
        function responseHandler(data){
            const {
                //-- 产品名称
                sellProductName,
                //-- 保险公司Id
                insureCompanyId,
                //-- 职业名称
                occupationName,
                //-- 保费金额
                payMoney,
                //-- 起保时间
                effectiveDate,
                //-- 终保时间
                expireDate,
                //-- 日历结束时间
                pickerEndDate,
                //-- 保障期限单位
                sellMinDate,
                //-- 金额单位
                sellMoneyUnit,
                //-- 投保人
                policyHolderInfo,
                //-- 被保人
                insuredUserInfoEntities,
                //-- 订单状态
                orderStatus,
                //-- 产品Id
                productId,
                //-- 产品条件描述
                conditionContent,
            } = data;

            //-- 页面初始化
            (function(){
                PAGE_STATE.sellMoneyUnit = sellMoneyUnit;
                PAGE_STATE.sellMinDate = sellMinDate;
                PAGE_STATE.productId = productId;

                $("#sellProductName").html(sellProductName);
                $("#beInsured_occupation").val(occupationName);
                $("#beInsured_effectiveDate").val(effectiveDate);
                $("#beInsured_expireDate").val(expireDate);

                //-- 职业为空隐藏
                if (!$$.isValidObj(occupationName)){
                    $(".occupation").hide();
                }

                //-- 产品ID
                if (productId == 100390 || productId == 100391){
                    $("#openBeInsureModel").hide();
                    $(".addInsured").hide();
                    $("#beInsured_payMoney").val(`${payMoney}元`);
                } else{
                    $("#beInsured_payMoney").val(`${payMoney}元/人`);
                }
            })();

            //-- 起保时间
            (function(){
                $("#beInsured_effectiveDate").unbind("click").click(function(){
                    const that = $(this);
                    weui.datePicker({
                        title: "起保时间",
                        start: effectiveDate,
                        end: pickerEndDate,
                        defaultValue: effectiveDate.split("-"),
                        onConfirm: function (result) {
                            let dateStr = $WeChat.transferDateByWeChatSelect(result);
                            that.val(dateStr);

                            expireDateHandler();
                        },
                        id: "beInsured_effectiveDate_picker"
                    });
                });
            })();

            //-- 投保人
            (function(){
                if(!$$.isValidObj(policyHolderInfo))
                    return;
                const {
                    credentialsFile,
                    companyName,
                    idnumber,
                    companyaddress,
                    name,
                    companyTel,
                    email
                } = policyHolderInfo;

                $("#enterpriseName").val(companyName);
                $("#socialCreditCode").val(idnumber);
                $("#address").val(companyaddress);
                $("#legalPerson").val(name);
                $("#workTelephone").val(companyTel);
                $("#workEmail").val(email);

                businessLicenseHandler_setImage(credentialsFile);
                PAGE_STATE.formData.businessLicense = {
                    filePath: credentialsFile
                };
            })();

            //-- 被保人
            (function(){
                if(!$$.isValidObj(insuredUserInfoEntities))
                    return;
                const beInsuredUsers = {};
                for(const item of insuredUserInfoEntities){
                    const { name, idNumber } = item;

                    beInsuredUsers[idNumber] = { beInsureName: name, beInsureIdCard: idNumber };
                }
                PAGE_STATE.formData.beInsureData = beInsuredUsers;
            })();

            //-- Other
            (function(){

                //-- 生成被保人组件
                generateBeInsureList();

                //-- 易安险
                if(insureCompanyId == 388){
                    $("#beInsured_limit_container").css({"display": "flex"});
                }

                //-- 订单状态处理
                if(orderStatus != OrderHelper.orderStatus.ORDER_STATUS_0 && orderStatus != OrderHelper.orderStatus.ORDER_STATUS_8){
                    return;
                    $$.confirm({
                        title: "订单已经不可修改！",
                        onOkLabel: "查看订单",
                        onCancelLabel: "返回",
                        onOk: function(){
                            $$.push("product/orderDetail", { orderToken });
                        },
                        onCancel: function(){
                            $$.pop();
                        }
                    });
                    return;
                }
            })();

            //-- 保障期限
            (function () {
                let sellMinDates = "";
                switch (sellMoneyUnit) {
                    case OrderHelper.sellProductMoneyUnit.MONEY_UNIT_1: {
                        sellMinDates = sellMinDate + "天";
                        break;
                    }
                    case OrderHelper.sellProductMoneyUnit.MONEY_UNIT_2: {
                        sellMinDates = sellMinDate + "个月";
                        break;
                    }
                    case OrderHelper.sellProductMoneyUnit.MONEY_UNIT_3: {
                        sellMinDates = sellMinDate + "年";
                        break;
                    }
                }

                $("#beInsured_limit").val(sellMinDates);
            })();

            //-- 易安产品
            (function () {
                //-- 产品条件描述[易安食品安全险]
                if (productId == 100391){
                    $(".productConditions").show();
                    $(".actualArea").show();
                    $("#beInsured_conditionContent").val(conditionContent);
                    let truncateLocation = conditionContent.indexOf("平方米");
                    truncateLocation = conditionContent.substring(0, truncateLocation).split("-");
                    if (truncateLocation[0] == "50") truncateLocation = ['0', '50'];
                    if (truncateLocation[0] == "2001") truncateLocation = ['2001', '∞'];
                    PAGE_STATE.conditionContent = truncateLocation;
                }

                //-- 省市地址[易安商户综合险]
                if (productId == 100390){
                    $(".petInsuredProvinces").show();
                }

                //-- 易安产品 显示手机号
                if (productId == 100338 || productId == 100390|| productId == 100391 || productId == 100392 || productId == 100393 || productId == 100394){
                    $('.mobile').css('display', 'flex');
                }

                //-- 易安 [雇主责任险、团体意外险] 起保人数为3人
                if (productId == 100393 || productId == 100394){
                    PAGE_STATE.numberOfInsuredPersons = 3;
                }
            })();

        }

        //-- 加载页面 -> 错误处理
        function failHandler(error){
            const errorMsg = {
                "E0001": "订单不存在！",
                "E0002": "职业已下架，请重新投保！",
                "E0003": "参数异常，请重新投保！"
            };
            let errorMsgForCode = $$.changeIsNilVal(errorMsg[error], error);

            $$.alert(errorMsgForCode + `[${error}]`, function(){
                if(error == "E0001" || error == "E0002" || error == "E0003"){
                    $$.push("product/productList", {insuranceType: 2});
                }
            });
        }
    }

    /**
     * 终保时间处理
     * @Author 肖家添
     * @Date 2019/11/12 11:41
     */
    function expireDateHandler(){
        let { sellMoneyUnit, sellMinDate } = PAGE_STATE,
            effectiveDate = $("#beInsured_effectiveDate").val(),
            expireDate = new Date(effectiveDate),
            year = expireDate.getFullYear(),
            month = expireDate.getMonth(),
            day = expireDate.getDate();

        switch (sellMoneyUnit) {
            case OrderHelper.sellProductMoneyUnit.MONEY_UNIT_1: {
                expireDate.setDate(day + sellMinDate);
                day = expireDate.getDate();
                break;
            }
            case OrderHelper.sellProductMoneyUnit.MONEY_UNIT_2: {
                expireDate.setMonth(month + sellMinDate);
                month = expireDate.getMonth();
                break;
            }
            case OrderHelper.sellProductMoneyUnit.MONEY_UNIT_3: {
                expireDate.setFullYear(year + sellMinDate);
                year = expireDate.getFullYear();
                break;
            }
        }
        expireDate.setDate(day - 1);
        $("#beInsured_expireDate").val($Date.dateFormat(expireDate));
    }

    /**
     * 文件上传处理  ``因考虑到【营业执照识别】和【OSS文件上传】分开请求存在网络损耗，证件识别时OSS文件也会一起上传上去
     * @Author 肖家添
     * @Date 2019/11/12 11:41
     */
    function fileUploadHandler(e, formType = "30001"){
        const files = e.files,
            businessLicenseImage = files[0];

        lrz(businessLicenseImage).then(function(resultObj){
            const { file, base64 } = resultObj,
                formData = new window.FormData();
            formData.append("file", file);
            formData.append("formType", formType);

            $$.request({
                url: UrlConfig.upload_attachment_uploadFileByComplex,
                pars: formData,
                requestBody: true,
                loading: true,
                sfn: function(data){
                    $$.closeLoading();

                    if(data.success){
                        data = data.datas;
                        switch (formType) {
                            case "30001":{
                                responseHandler_30001(data);
                                break;
                            }
                            case "30002":{
                                responseHandler_30002(data);
                                break;
                            }
                            case "30003":{
                                responseHandler_30003(data);
                                break;
                            }
                        }
                    }else{
                        $$.alert(data.msg);
                    }
                }
            });

            //-- 营业执照识别 -> 响应处理
            function responseHandler_30001(data){
                const { enterpriseName, legalPerson, address, socialCreditCode, oss } = data;
                PAGE_STATE.formData.businessLicense = oss;
                $$.confirm({
                    title: `证件识别成功，单位名称：${enterpriseName}、法人：${legalPerson}、地址：${address}、社会信用代码：${socialCreditCode}；是否设置数据到表单？`.replace(/undefined/g, ""),
                    onOkLabel: "设置",
                    onCancelLabel: "不要",
                    onOk: function(){
                        for(const key in data){
                            if(key == "oss"){
                                continue;
                            }
                            $(`#${key}`).val($$.changeIsNilVal(data[key], ""));
                        }
                    }
                });

                businessLicenseHandler_setImage(base64);
                $(".uploadBusinessLicense-file").val("");
            }

            //-- 身份证识别 -> 响应处理
            function responseHandler_30002(data){
                const { name, idCardNumber } = data;
                if(!$$.isValidObj(idCardNumber)){
                    $$.throwTips("未识别到证件号，请重试！");
                }

                $$.layerToast("识别成功！");
                setScanImage(base64);
                PAGE_STATE.formData.scanData[idCardNumber] = {
                    beInsureName: name,
                    beInsureIdCard: idCardNumber
                };

                generateBeInsureList(2);
            }

            //-- 表格识别 -> 响应处理
            function responseHandler_30003(data){
                const { responseList } = data;
                const { scanData } = PAGE_STATE.formData;

                responseList.map((item) => {
                    const { name, idCard } = item;
                    if(!$$.isValidObj(idCard)){
                        return;
                    }
                    scanData[idCard] = {
                        beInsureName: name,
                        beInsureIdCard: idCard
                    };
                });

                setScanImage(base64);
                generateBeInsureList(2);
            }

            function setScanImage(image){
                $("#beInsureInputWay-ai-section .popupView-body-scan-type img").attr("src", image);
            }
        });
    }

    /**
     * 营业执照设置图片
     * @Author 肖家添
     * @Date 2019/11/14 0:12
     */
    function businessLicenseHandler_setImage(image){
        $(".uploadBusinessLicense>div").css({
            "background-image": `url(${image})`,
            "border": "0"
        }).children("span").remove();
    }

    /**
     * 弹出层显示、隐藏处理
     *
     * selector -> 选择器
     * action -> [add: 显示, remove: 隐藏]
     *
     * @Author 肖家添
     * @Date 2019/11/13 9:50
     */
    function popupViewHandler(selector, action){
        const view = $(selector);
        switch (action) {
            case "add":{
                $$.forbidPageRolling();
                view.addClass("show");
                break;
            }
            case "remove":{
                view.removeClass("show");
                if($(".popupView.show").size() <= 0){
                    $$.recoveryPageRolling();
                }
                break;
            }
        }
    }

    /**
     * 添加被保人数据 [beInsureName: 被保人姓名, beInsureIdCard: 被保人身份证]
     * @Author 肖家添
     * @Date 2019/11/13 12:02
     */
    function addBeInsureData(beInsureName, beInsureIdCard, isEdit = false, editIdCard, isScanSubmit = false){
        const verify = new $Valid.validComment({}),
            { beInsureData, scanData } = PAGE_STATE.formData,
            generateBeInsureListBizType = !isScanAction() ? 1 : 2,
            tempBeInsureData = { beInsureName, beInsureIdCard };

        $$.isValidObjThrow(beInsureName, "请输入被保人姓名");
        if(!verify.checkNameForRegex(beInsureName)) $$.throwTips("请输入有效的姓名！");
        $$.isValidObjThrow(beInsureIdCard, "请输入被保人身份证");
        if(!verify.checkCardIdForRegex(beInsureIdCard)) $$.throwTips(`请输入有效的身份证[${beInsureIdCard}]！`);

        if(!isScanAction() || isScanSubmit){
            if(isEdit){
                if($$.isValidObj(beInsureIdCard) && editIdCard != beInsureIdCard){
                    const { beInsureData } = PAGE_STATE.formData;
                    if($$.isValidObj(beInsureData[beInsureIdCard])){
                        $$.throwTips(`被保人[${beInsureIdCard}]已经存在！`);
                    }
                }

                delete beInsureData[editIdCard];
            }

            //-- PASS
            const oldBeInsureData = beInsureData[beInsureIdCard];
            if($$.isValidObj(oldBeInsureData)) $$.throwTips(`被保人[${beInsureIdCard}]已经存在！`);

            beInsureData[beInsureIdCard] = tempBeInsureData;
            PAGE_STATE.formData.beInsureData = beInsureData;
        }else{
            //-- 智能识别编辑确定
            delete scanData[editIdCard];

            scanData[beInsureIdCard] = tempBeInsureData;
            PAGE_STATE.formData.scanData = scanData;
        }

        //-- GENERATE VIEW
        generateBeInsureList(generateBeInsureListBizType);
    }

    /**
     * 生成被保人列表
     *
     * bizType -> [1: 营业执照, 2: 智能识别]
     *
     * @Author 肖家添
     * @Date 2019/11/13 12:05
     */
    function generateBeInsureList(bizType = 1){
        const { beInsureData, scanData } = PAGE_STATE.formData,
            loopDatum = bizType == 1 ? beInsureData : scanData;
        let html = new Array();
        const verify = new $Valid.validComment({});
        for(const key in loopDatum){
            const { beInsureName, beInsureIdCard } = loopDatum[key],
                index = html.length + 1;
            let style = "";
            try{
                if(!verify.checkCardIdForRegex(beInsureIdCard) || !verify.checkNameForRegex(beInsureName)){
                    style += "color: red;";
                }
            }catch (e) {
                console.log(e);
            }
            html.push(`
                <tr style="${style}">
                    <td>${index}</td>
                    <td>${beInsureName}</td>
                    <td>${beInsureIdCard}</td>
                    <td class="section-body-list-update systemColor" data-idCard="${beInsureIdCard}">修改</td>
                </tr>
            `);
        }

        switch (bizType) {
            case 1:{
                //-- 营业执照
                const sectionBody = $("#beInsureSection>.popupView-body"),
                    sectionBodyList = $("#beInsureSection>.popupView-body>.section-body-list"),
                    beInsureSize = html.length;

                sectionBodyList.find("tr:gt(0)").remove();
                sectionBodyList.append(html.join(""));
                sectionBody.find(".section-body-beInsureCount span").html(beInsureSize);
                $("#openBeInsureModel input").val(`共${beInsureSize }人`);
                $("#beInsureSection>.popupView-body>.section-body-append").html(beInsureSize > 0 ? "+ 继续添加" : "+ 立即添加");
                break;
            }
            case 2:{
                //-- 智能识别
                const sectionBody = $("#beInsureInputWay-ai-section>.popupView-body"),
                    sectionBodyList = $("#beInsureInputWay-ai-section>.popupView-body .section-body-list"),
                    beInsureSize = html.length;

                sectionBodyList.find("tr:gt(0)").remove();
                sectionBodyList.append(html.join(""));
                sectionBody.find(".scan-result-count").html(beInsureSize);
                break;
            }
        }

        //-- 修改被保人信息
        $Listener.onTap(".section-body-list .section-body-list-update", function(e){
            const { beInsureData, scanData } = PAGE_STATE.formData,
                handlerDatum = !isScanAction() ? beInsureData : scanData,
                idCard = $(e).attr("data-idCard"),
                beInsureInputWayManualSection = $("#beInsureInputWay-manual-section"),
                { beInsureName, beInsureIdCard } = handlerDatum[idCard];

            beInsureInputWayManualSection.find("input[name=beInsureName]").val(beInsureName);
            beInsureInputWayManualSection.find("input[name=beInsureIdCard]").val(beInsureIdCard);
            beInsureInputWayManualSection.removeClass("default").addClass("update").attr("data-idCard", idCard);
            popupViewHandler(beInsureInputWayManualSection, "add");
        });
        $(".uploadAI-file").val("");
    }

    /**
     * 提交订单
     * @Author 肖家添
     * @Date 2019/11/13 9:56
     */
    function submitOrder(){

        const enterpriseInformation = verifyEnterpriseInformation(),
            {
                //-- 订单Token
                orderToken,
                //-- 表单数据
                formData: {
                    //-- 被保人数据  ``JSONObject, key = cardNumber, value = data
                    beInsureData,
                    //-- 营业执照OSS数据
                    businessLicense
                },
                //-- 起保人数
                numberOfInsuredPersons,
                //-- 产品Id
                productId,
                //-- 产品条件
                conditionContent,
            } = PAGE_STATE,
            //-- 被保人数
            beInsureDataKeys = Object.keys(beInsureData),
            //-- 起保时间
            beInsuredEffectiveDate = $("#beInsured_effectiveDate").val();

        //-- 营业面积
        let area = '';

        //-- 扩展信息
        const extendLists = [];

        //-- VERIFY
        (function(){
            //-- 易安产品[商户综合险、食品安全险] - 被投保人为本人
            if (!(productId == 100390 || productId == 100391)) {
                if(beInsureDataKeys.length < numberOfInsuredPersons){
                    $$.throwTips(`被保人数量不能小于${numberOfInsuredPersons}人！`);
                }
            } else {
                //-- 企业名称
                const name = $('#enterpriseName').val(),
                    //-- 社会信用代码
                    idCard = $('#socialCreditCode').val();

                beInsureData[idCard] = {
                    beInsureName: name,
                    beInsureIdCard: idCard
                };
            }

            //-- 易安产品[食品安全] - 营业面积
            if (productId == 100391){
                area = $('#beInsured_actualArea').val(),
                    minimum = parseInt(conditionContent[0]),
                    maximum = parseInt(conditionContent[1]);

                if (!$$.isValidObj(area)) $$.throwTips('请输入真实营业面积~');
                area = parseInt(area);
                console.log(area);
                if (area < minimum) $$.throwTips('你的营业面积小于当前产品范围，请选择其他适合的产品款式~');
                if (minimum !== 2001){
                    if (area > maximum) $$.throwTips('你的营业面积大于当前产品范围，请选择其他适合的产品款式~');
                }

                extendLists.push({area});
            }

            //-- 易安产品[商户综合] - 省市区地址
            if (productId == 100390){
                const petInsuredProvinces = $("#petInsuredProvinces").val();
                if (petInsuredProvinces){
                    const {
                        policyProvinceCode,
                        policyProvinceValue,
                        policyCityCode,
                        policyCityValue,
                        policyAreaCode,
                        policyAreaValue,
                    } = PAGE_STATE;

                    extendLists.push({
                        policyProvinceCode,
                        policyProvinceValue,
                        policyCityCode,
                        policyCityValue,
                        policyAreaCode,
                        policyAreaValue,
                    });
                } else{
                    $$.throwTips('请选择省市地址~');
                }
            }
        })();

        const params = {
            orderToken,
            productId,
            ...enterpriseInformation,
            beInsureData: JSON.stringify(beInsureData),
            beInsuredEffectiveDate,
            credentialsFile: businessLicense.filePath,
            extendLists: JSON.stringify(extendLists),
        };

        $$.request({
            url: UrlConfig.businessInsurance_submitFillInsuranceInfo,
            pars: params,
            loading: true,
            requestBody: true,
            sfn: function(data){
                $$.closeLoading();

                if(data.success){
                    $$.push("product/orderDetail", {orderToken});
                }else{
                    let msg = data.msg;
                    switch (msg) {
                        case "E0001":{
                            msg = "订单状态已不可修改！";
                            break;
                        }
                        case "E0002":{
                            msg = "参数异常，请重新投保！";
                            break;
                        }
                    }

                    $$.alert(msg);
                }
            }
        });
    }

    /**
     * 验证企业信息
     * @Author 肖家添
     * @Date 2019/11/13 9:55
     */
    function verifyEnterpriseInformation(){
        const {
            formData: {
                businessLicense
            }
        } = PAGE_STATE;

        const companyName = $("#enterpriseName").val(),         // 投保单位
            socialCreditCode = $("#socialCreditCode").val(),    // 社会信用代码
            address = $("#address").val(),                      // 注册地址
            legalPerson = $("#legalPerson").val(),              // 联系人
            workTelephone = $("#workTelephone").val(),          // 联系电话（固话）
            mobile = $("#mobile").val(),                        // 手机号
            workEmail = $("#workEmail").val();                  // 联系邮箱

        const chineseReg = /^[\u2E80-\u9FFFa-zA-Z0-9\(\)\（\）]+$/;

        $$.isValidObjThrow(businessLicense, "请上传营业执照~")
        $$.isValidObjThrow(companyName, "请输入真实有效的投保单位~");
        $$.checkRegThrow(companyName, chineseReg, "投保单位格式不正确！");
        $$.isValidObjThrow(socialCreditCode, "请输入真实有效的社会信用代码~");
        $$.checkReg(socialCreditCode, $Reg.numAndLetterReg, "社会信用代码格式有误！")
        $$.isValidObjThrow(address, "请输入单位地址~");
        $$.checkRegThrow(address, chineseReg, "单位地址格式不正确！");
        $$.isValidObjThrow(legalPerson, "请输入联系人~");
        $$.isValidObjThrow(workTelephone, "请输入联系电话（区号-固话）~");
        $$.checkRegThrow(workTelephone, $Reg.fixedTelephoneReg, "请输入有效的联系电话！（区号-固话）！");
        $$.isValidObjThrow(mobile, "请输入手机号~");
        $$.checkRegThrow(mobile, $Reg.phoneReg, "请输入有效的手机号！");
        $$.isValidObjThrow(workEmail, "请输入联系邮箱~");
        $$.checkRegThrow(workEmail, $Reg.emailReg, "请输入有效的联系邮箱！");

        return {companyName, socialCreditCode, address, legalPerson, workTelephone, workEmail, mobile};
    }

    /**
     * 是否在智能识别流程中
     * @Author 肖家添
     * @Date 2019/11/14 17:26
     */
    function isScanAction(){
        return $("#beInsureInputWay-ai-section").hasClass("show");
    }
    
    /**
     * 智能识别结果合并到被保人数据
     * @Author 肖家添
     * @Date 2019/11/14 18:08
     */
    function scanResultMergeToBeInsureData(){
        const {
            formData: { scanData }
        } = PAGE_STATE,
        scanResultKeys = Object.keys(scanData),
        scanResultSize = scanResultKeys.length;

        //-- VERIFY
        (function(){
            if(scanResultSize <= 0)
                $$.throwTips("被保员工不能为空！");
            const tempBeInsureData = JSON.stringify(PAGE_STATE.formData.beInsureData);
            for(const key in scanData){
                try{
                    const { beInsureName, beInsureIdCard } = scanData[key];
                    addBeInsureData(beInsureName, beInsureIdCard, false, null, true);
                }catch (e) {
                    PAGE_STATE.formData.beInsureData = JSON.parse(tempBeInsureData);
                    $$.throwTips(e);
                }
            }
            generateBeInsureList(1);
            $("#beInsureInputWay-ai-section .popupView-bg").click();
            popupViewHandler("#beInsureSection", "add");
        })();
    }
}