let yintegral_PG = null;

window.onload = function () {
    $$.changeVersion();
    integralRule();
	IntegralLevel();

    /**
     * 签到规则说明
     */
    EvtMgr.bindClick('view-integrals');

    //-- 产品介绍产品详情切换
    const infoTit = $(".tit");
    infoTit.on("click", function () {
        const _that = $(this),
            tips = _that.attr("data-tips");

        infoTit.removeClass("active");
        _that.addClass("active");
        tabsHeightChange(tips);
        switch (tips) {
            case "0":{
                countAction("xb_3013");
                break;
            }
            case "1":{
                countAction("xb_3014");
                break;
            }
        }
    });

    /**
     *
     *积分规则说明
     * */

    function integralRule() {
        $("#integral").on("click", function () {
            $$.push('signin/integralRule');
        })
    }

    /**
     * 标签页高度改变
     * @Author 肖家添
     * @Date 2019/9/4 16:04
     */
    function tabsHeightChange(tips) {
        const transform = ["0", "-50%"];
        const showViewCls = ["detail-content1", "detail-content2"];
        const height = $(`.${showViewCls[tips]}`).height();

        $("#slideWrap").css({
            '-webkit-transform': `translate(${transform[tips]}, 0)`,
            'transform': `translate(${transform[tips]}, 0)`
        });
        $("#infoCon").css({height: height + 50});
    };

    /**
     * 分页参数
     * @Author 肖家添
     * @Date 2019/8/22 15:09
     */
    let pagingData = {
        _pageSize: 10,
        _current: 1,
        _total: 0
    };

    let OrderPagingData = {
        _pageSize: 10,
        _current: 1,
        _total: 0
    };

    findIntegralRecords();
    findIntegralOrderRecords();
    $Listener.pageScrollToBottomListener(function () {

    });

    //-- 页面滑动到底部监听
    $Listener.pageScrollToBottomListener(function () {
        if ($(".header_progress_box .tit-item>.tit.active").attr("data-tips") === "1") {
            OrderPagingData = $$.pagingHelper.before(OrderPagingData);
            $$.pagingHelper.loading(".detail-content2>ul");
            findIntegralOrderRecords(false,false,function () {
                $$.pagingHelper.closeLoading();
            });
        } else {
            pagingData = $$.pagingHelper.before(pagingData);
            $$.pagingHelper.loading(".detail-content1>ul");
            findIntegralRecords(false,false,function () {
                $$.pagingHelper.closeLoading();
            });
        }
    });

    function findIntegralRecords(loading = true, clearList = false, overCallback) {
        let params = JSON.parse(JSON.stringify(pagingData));

        //-- params handler
        (function () {
            if (clearList) {
                pagingData._current = 0;
                params._current = 0;
            }
        })();

        $$.request({
            url: UrlConfig.checkIn_integralRecords_listPage,
            loading: loading,
            pars: params,
            sfn: function (data) {
                if (data.success) {
                    const {list, pagination} = data.datas;
                    bindIntegralRecordsElement(list, pagination);
                } else {
                    $$.errorHandler(`获取积分明细失败！[${data.msg}]`);
                }
            }
        });

        /**
         * 绑定积分明细元素
         */
        function bindIntegralRecordsElement(list, pagination) {
            try {
                //-- paging handler
                (function () {
                    pagingData._current = pagination.current;
                    pagingData._pageSize = pagination.pageSize;
                    pagingData._total = pagination.total;
                })();

                //-- html handler
                (function () {
                    let html = "";

                    if ($$.isValidObj(list)) {
                        list.forEach((item, index) => {
                            html += `
                                <li>
                                    <div class="row-one"><strong>|</strong><label>${item.createTime}</label></div>
                                    <div class="row-two"><span class="cmn-one">${$$.isValidObj(item.rname) ? item.rname : ''}</span><span class="cmn-three">${item.itype === 1 ? '+' : '-'}${item.tintegral}积分</span>
                                    </div>
                                </li>
                            `;
                        });
                    }

                    if (clearList) {
                        $(".detail-content1>.list").html(html);
                    } else {
                        $(".detail-content1>.list").append(html);
                    }

                })();
            } catch (e) {
                console.error(e);
            } finally {
                $$.closeLoading();

                if (overCallback) overCallback();
            }
        }
    }

    function findIntegralOrderRecords(loading = true, clearList = false, overCallback) {
        let params = {...OrderPagingData};

        //-- params handler
        (function () {
            if (clearList) {
                OrderPagingData._current = 0;
                params._current = 0;
            }
        })();

        $$.request({
            url: UrlConfig.checkIn_order_listPage,
            loading: loading,
            pars: params,
            sfn: function (data) {
                if (data.success) {
                    const {list, pagination} = data.datas;
                    bindIntegralOrderRecordsElement(list, pagination);
                } else {
                    $$.errorHandler(`获取积分兑换明细失败！[${data.msg}]`);
                }
            }
        });

        /**
         * 绑定积分明细元素
         */
        function bindIntegralOrderRecordsElement(list, pagination) {
            try {
                //-- paging handler
                (function () {
                    OrderPagingData._current = pagination.current;
                    OrderPagingData._pageSize = pagination.pageSize;
                    OrderPagingData._total = pagination.total;
                })();

                //-- html handler
                (function () {
                    let html = "";
                    if ($$.isValidObj(list)) {
                        list.forEach((item, index) => {
                            html += `
                                <li>
                                    <div class="row-one"><strong>|</strong><label>${item.createTime}</label></div>
                                    <div class="row-two"><span class="cmn-one">${$$.isValidObj(item.remark) ? item.remark : ''}</span><span class="cmn-three">${-item.integrals}积分</span>
                                    </div>
                                </li>
                            `;
                        });
                    }
                    if (clearList) {
                        $(".detail-content2>.list").html(html);
                    } else {
                        $(".detail-content2>.list").append(html);
                    }
                })();
            } catch (e) {
                console.error(e);
            } finally {
                $$.closeLoading();
                if (overCallback) overCallback();
            }
        }
    }

    $(".maile").click(() => {
        countAction("xb_3011");
        $$.request({
            url: UrlConfig.checkIn_mailejifen_login,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });
    countAction("xb_2027");
    countAction("xb_3013");
}


function IntegralLevel() {
	$$.request({
		url: UrlConfig.management_integral_getMemberIntegralInfo,
		loading: true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
                let {tintegral, yintegral} = data.datas;
                //let html = `<div>可用积分/总积分：</div><div>${yintegral} / ${tintegral}</div>`
				$('#view-integrals>span').html($$.isValidObj(yintegral) ? yintegral : 0);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}

