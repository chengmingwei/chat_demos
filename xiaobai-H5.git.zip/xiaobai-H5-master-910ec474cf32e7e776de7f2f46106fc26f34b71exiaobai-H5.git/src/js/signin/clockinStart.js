let lineLink = $$.getFullHost() + "/src/pages/signin/clockinStart.html";

window.onload = function () {

    initPageData();

    shareClockinStart();
    if(!PAGE_APP){
        countAction("xb_2032");
    }
    /**
     * 加载页面数据
     */
    function initPageData() {
        $$.changeVersion();
        $$.request({
            url: UrlConfig.checkIn_morning,
            loading: true,
            checkLogin: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (data.morningTask.button) {
                        $("#btn-income").click(() => {
                            countAction("xb_3009");
                            if (data.morningTask.warn) {
                                $$.alert('请在活动时间内（5:00-8:00）参加')
                            } else {
                                $$.push('signin/signin');
                            }
                        });
                    } else if (data.morningTask.button == false && data.morningTask.warn == false) {
                        $("#btn-income").hide();
                        $("#consecutiveDays").html(data.morningTask.consecutiveMorningDays);
                        $("#clockin-finish").show();
                    }
                    checkEarlyReminder();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    };

    function checkEarlyReminder(){
        $$.request({
            url: UrlConfig.member_check_early_reminder,
            checkLogin: true,
            sfn: function (data) {
                if (data.success) {
                    $("#ele-switch").removeClass("switch-no");
                    $("#ele-switch").addClass("switch-on");
                } else {
                    $("#ele-switch").removeClass("switch-on");
                    $("#ele-switch").addClass("switch-no");
                }
            }
        });
    }

    function updateEarlyReminder(param){
        $$.request({
            url: UrlConfig.member_update_early_reminder,
            checkLogin: true,
            pars: {'reminderStatus':param},
            sfn: function (data) {
                if (data.success) {
                    if($("#ele-switch").hasClass("switch-on")){
                        $$.alert('早起提醒已开启');
                    }else{
                        $$.alert('早起提醒已关闭');
                    }
                } else {
                    $$.alert('早起提醒设置失败');
                }
            }
        });
    }

    function shareClockinStart(){
        weChatJSTool.share({
            _imgUrl: $Constant.shareLogo,
            _lineLink: lineLink,
            _shareTitle: '又是元气满满的一天,快来早起打卡!',
            _descContent: '黄金时间5:00-8:00打卡，可尽享积分翻倍，兑换更多福利！',
            _sfn: function () {
                $$.layerToast("分享成功");
            }
        });
    }

    /**
     * 提醒开关
     */
    EvtMgr.bindClick('ele-switch', function (ele) {
        var currCls = ele.hasClass("switch-on");
        var addCls = "switch-no";
        if (currCls) {
            addCls = "switch-no";
            ele.removeClass("switch-on");
            updateEarlyReminder(0);
        }
        currCls = ele.hasClass("switch-no");
        if (currCls) {
            addCls = "switch-on";
            ele.removeClass("switch-no");
            updateEarlyReminder(1);
        }
        ele.toggleClass(addCls);
        $$.postAPP(10005, {
            eventId: "xb_2011",
            arguments: {
                position: "早起打卡-每日签到提醒"
            }
        });
        countAction("xb_3010");
    });

}
