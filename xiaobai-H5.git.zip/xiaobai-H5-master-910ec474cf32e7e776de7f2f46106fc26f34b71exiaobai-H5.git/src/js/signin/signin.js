let weekDayArray_PG = null;
let today_PG = null;

let lineLink = $$.getFullHost() + "/src/pages/signin/signin.html";

window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_12', null);
    } catch (error) {
        console.log(error);
    }

    /**
     * 签到规则说明
     */
    EvtMgr.bindClick('rules-remark', function (ele) {
        openRulesDialog();
        countAction("xb_2028");
    });

    /**
     * 未签到按钮
     */
    EvtMgr.bindClick('btn-sigin', function (ele) {
        $$.request({
            url: UrlConfig.checkIn_submit,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    openSigninOkDialog();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

    });

    /**
     * 补签
     */
    $(".week-icons").on('click', '.sigin-append', function () {
        openSiginAppendDialog();
    });

    /**
     * 签到规则说明
     */
    function openRulesDialog() {
        /*var htmlArr = [
            '<div class="rulesDialog">',
            '<h2>签到规则</h2>',
            '<h5>1. 用户签到打卡时间为每日0:00至次日0:00；</h5>',
            '<h5>2. 用户连续打卡一周后，额外奖励30积分，连续签到一个月，额外奖励100积分；</h5>',
            '<h5>3. 每个用户每天只能打卡一次，中途遗漏打卡一次，则重新开始计算打卡天数；</h5>',
            '<h5>4. 若忘记或遗漏打卡，可通过分享QQ、微博或微信，获得补卡机会1次（只可补前一天，不可越天补卡）；</h5>',
            '</div>',
            '<div class="know">我知道了</div>'
        ];*/

        let htmlArr = `<div class="pop-up">
                            <div class="title">签到规则</div>
                            <div class="text">
                                
                                1:用户签到打卡时间为每日0:00至次日0:00；
                            </div>
                            <div class="text">
                                 
                                2:用户连续打卡一周后，额外奖励30积分，连续签到一个月，额外奖励100积分；
                            </div>
                            <div class="text">
                                 
                                3:每个用户每天只能打卡一次，中途遗漏打卡一次，则重新开始计算打卡天数；
                            </div>
                            <div class="text">
                                 
                                4:若忘记或遗漏打卡，可通过微信，获得补卡机会1次（只可补当月前一天，不可越天,跨月补卡）；
                            </div>                     
                            以上解释权归小白保险所有。
                            <div class="know">我知道了</div>
                        </div>`;
        layer.open({
            content: htmlArr,
            type: 1
        });
        $('.know').click(() => {
            layer.closeAll();
        });
    }


    /**
     * ad-clockin
     */
    function openSiginAppendDialog() {

        var htmlArr = [
            '<div class="layer-dialog dialog-append">',
            '<h3>分享补签</h3>',
            '<span>分享成功将获得1次补签</span>',
            '</div>'
        ];
        var html = htmlArr.join(" ");

        layer.open({
            content: html
            , btn: ['马上分享', '取消']
            , yes: function () {
                $$.showShareView('点击右上角,分享签到好礼给好友！');
            }
        });
    }

    shareReplenishSign();
    getBanner();

    function shareReplenishSign() {
        weChatJSTool.share({
            _imgUrl: $Constant.shareLogo,
            _lineLink: lineLink,
            _shareTitle: '签到有礼',
            _descContent: '快来签到领积分，兑换更多福利，我在这里等你哦！',
            _sfn: function () {
                countAction("xb_2031");
                if ($(".week-icons>li>div.sigin-append").size() > 0) {
                    $$.request({
                        url: UrlConfig.checkIn_resign,
                        pars: {day: weekDayArray_PG[today_PG - 2]},
                        loading: true,
                        sfn: function (data) {
                            $$.closeLoading();
                            if (data.success) {
                                $$.layerToast("补签成功");
                                countAction("xb_2030");
                                setTimeout(() => location.reload(), 700)
                            } else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });
                }
            }
        });
    }

    function openShareSucessDialog() {
        var htmlArr = [
            '<div class="layer-dialog dialog-share-success">',
            '<h3>补签成功</h3>',
            '</div>'
        ];
        var html = htmlArr.join(" ");

        layer.open({
            content: html
            , btn: ['好的']
        });
    }


    function openSigninOkDialog() {
        var html = getSigninOkHtml();
        layer.open({
            content: html,
            btn: '关闭',
            shadeClose: false,
            end: function (index, layero) {
                location.reload();
            }
        });

        //点击分享新人礼包
        $('ul > li').on('click', () => {
            $('#popup').show();
            return false;
        });

        $('#popup .bg,.showFrame').click(function () {
            $('#popup').hide();
            return false;
        });
        countAction("xb_2029");

    }


    function getSigninOkHtml() {
        var htmlArr = [
//		'<DIV class="layer-dialog-close">关闭</DIV>',
            '<div class="layer-dialog">',
            '<h3>签到成功</h3>',
            '<p><span>分享至</span></p>',
            '<ul class="flex-center">',
            /*'<li class="share-qq"><span>QQ好友</span></li>',*/
            '<li class="share-wx"><span>微信好友</span></li>',
            '<li class="share-frend"><span>朋友圈</span></li>',
            /*'<li class="share-sina"><span>新浪微博</span></li>',*/
            '</ul>',
            '<div style="clear:both;"></div>',
            '</div>'
        ];
        return htmlArr.join(" ");
    }

    findDailyTaskData();

    function findDailyTaskData() {
        $$.request({
            url: UrlConfig.checkIn_dailyTask_data,
            loading: true,
            checkLogin: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {

                    weekDayArray_PG = data.dailyTask.weekDay;
                    today_PG = data.dailyTask.today;
                    let yintegral = data.dailyTask.yintegral;

                    // 初始化页面数据
                    $("#yintegral").html(yintegral);
                    /*  $("#totalDays").html(data.dailyTask.totalDays);*/
                    $("#maxDays").html(data.dailyTask.maxDays);
                    $("#consecutiveDays").html(data.dailyTask.consecutiveDays);
                    let str = '今日已签到';
                    if (data.dailyTask.toDaySign == 0 && (data.dailyTask.weekStatus[data.dailyTask.today - 1] == 0 || data.dailyTask.weekStatus[data.dailyTask.today - 1] == 4)) {
                        str = '今日未签到';
                        $("#btn-sigin").html("未签到");
                        $("#btn-sigin").removeAttr("disabled");
                        $("#btn-sigin").attr("class", "signin-un");
                    }

                    /*动态设置本月累计签到天数*/
                    $(".row_two").html("本月累计签到&nbsp;<span>" + data.dailyTask.totalDays + "</span>&nbsp;天 <span>&sdot;</span>&nbsp;" + str);

                    /*动态设置连续签到进度条*/
                    $(".progress_bg_sp_current").css("width", toPercent((data.dailyTask.consecutiveDays / data.dailyTask.maxDays).toFixed(2)));

                    /*设置weekStatus*/
                    let weekStatusArray = data.dailyTask.weekStatus;
                    console.log(weekStatusArray);
                    $(".week-icons").empty();
                    for (let index in weekStatusArray) {
                        if (weekStatusArray[index] == 4) {
                            $(".week-icons").append('<li><div class="sigin-unstart">+40</div></li>');
                            /*day-gift 礼包图标*/
                            $(".week-tips li:eq(" + index + ")").attr("class", "day-gift");
                        } else if (weekStatusArray[index] == 3) {
                            $(".week-icons").append('<li><div class="sigin-forget">漏签</div></li>');
                        } else if (weekStatusArray[index] == 2) {
                            console.log(2);
                            $(".week-icons").append('<li><div class="sigin-append">补签</div></li>');
                            /*day-tip 补签图标*/
                            $(".week-tips li:eq(" + index + ")").attr("class", "day-tip");
                        } else if (weekStatusArray[index] == 1) {
                            $(".week-icons").append('<li><div class="sigin-ok"></div></li>');
                        } else if (weekStatusArray[index] == 0) {
                            $(".week-icons").append('<li><div class="sigin-unstart">+10</div></li>');
                        }
                    }

                    // 加载每日任务按钮
                    if (data.dailyTask.toDayShareArticle == 0) {
                        $("#toDayShareArticle").removeAttr("disabled");
                        $("#toDayShareArticle").attr("class", "btn-undo");
                        $("#toDayShareArticle").html("未完成");
                    }
                    if (data.dailyTask.toDayRead == 0) {
                        $("#toDayRead").removeAttr("disabled");
                        $("#toDayRead").attr("class", "btn-undo");
                        $("#toDayRead").html("未完成");
                    }
                    if (data.dailyTask.toDayTopic == 0) {
                        $("#toDayTopic").removeAttr("disabled");
                        $("#toDayTopic").attr("class", "btn-undo");
                        $("#toDayTopic").html("未完成");
                    }
                    if (data.dailyTask.toDayWatchAndLearn == 0) {
                        $("#toDayWatchAndLearn").removeAttr("disabled");
                        $("#toDayWatchAndLearn").attr("class", "btn-undo");
                        $("#toDayWatchAndLearn").html("未完成");
                    }

                    /**
                     * 签到->积分明细
                     */
                    $("#view-integrals").click(() => {
                        $$.push("signin/integralList", {yintegral});
                    });

                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

        function toPercent(point) {
            var str = Number(point * 100).toFixed(2);
            str += "%";
            return str;
        }
    }

    $(".btn-integral-buy").click(() => {
        countAction("xb_2037");
        $$.request({
            url: UrlConfig.checkIn_mailejifen_login,
            loading: true,
            checkLogin: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });

    $("#toDayShareArticle").click(() => {
        $$.push("know/information");
    });
    $("#toDayRead").click(() => {
        $$.push("know/information");
    });
    $("#toDayTopic").click(() => {
        $$.push("topicPK/topicPKList");
    });
    $("#toDayWatchAndLearn").click(() => {
        $$.push("know/information");
    });

    function getBanner() {
        $$.request({
            url: UrlConfig.AppHomePic_getPicList,
            pars: {
                //-- 类型 0-app 1-微信公众号H5首页 2-课堂首页 3-积分活动图 4-我的页面
                type: 3,
                isenabled: 1
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    bindBannerView(data.datas);
                } else {
                    $$.layerToast(`获取失败！[${data.msg}]`);
                }
            }
        });
    }

    function bindBannerView(data) {
        let html = "";
        data.forEach((item) => {
            const url = item.picUrl;
            if (!$$.isValidObj(url)) {
                console.error(`发现错误！id=${item.id}的轮播图地址为空！`);
                return;
            }
            html += `
                <div class="swiper-slide" data-action=${item.adUrl}>
                    <img src=${$$.imageUrlCompatible(url)} />
                </div>
            `;
        });
        //-- 轮播图点击事件
        $(".banner-container>.banner-wrapper").html(html).find(".swiper-slide").click(function () {
            const action = $(this).attr("data-action");
            if ($$.isValidObj(action)) {
                location.href = action;
            }
        });

        if(data.length > 1){
            //-- 初始化轮播组件
            new Swiper(".swiper-container", {
                spaceBetween: 15,
                centeredSlides: true,
                loop: true,
                autoplay: {
                    delay: 1000 * 3,
                    disableOnInteraction: false,
                },
                pagination: {
                    el: '.swiper-pagination',
                    clickable: true,
                },
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev',
                },
            });
        }
    }
}
