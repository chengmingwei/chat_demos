$(function () {

    const swiper1 = new Swiper('.swiper1', {
//					设置slider容器能够同时显示的slides数量(carousel模式)。
//					可以设置为number或者 'auto'则自动根据slides的宽度来设定数量。
//					loop模式下如果设置为'auto'还需要设置另外一个参数loopedSlides。
		observer: true,//修改swiper自己或子元素时，自动初始化swiper
     	observeParents: true,//修改swiper的父元素时，自动初始化swiper
        slidesPerView: 5.5,
        paginationClickable: true,//此参数设置为true时，点击分页器的指示点分页器会控制Swiper切换。
        spaceBetween: 12,//slide之间的距离（单位px）。
        freeMode: true,//默认为false，普通模式：slide滑动时只滑动一格，并自动贴合wrapper，设置为true则变为free模式，slide会根据惯性滑动且不会贴合。
        loop: false,//是否可循环
        onTab: function(swiper) {
            var n = swiper1.clickedIndex;
        }
    });

    //非空判断
    if(swiper1.slides){
        swiper1.slides.each(function(index, val) {
            var ele = $(this);
            ele.unbind('click').on("click", function() {
                //数据统计
                console.log(ele.html());
               try {
                    if(index == 0){
                        countAction('xb_35', null);
                    }else if(index == 1){
                        countAction('xb_36', null);
                    }else if(index == 2){
                        countAction('xb_37', null);
                    }else if(index == 3){
                        countAction('xb_38', null);
                    }else if(index == 4){
                        countAction('xb_39', null);
                    }else if(index == 5){
                        countAction('xb_40', null);
                    }else if(index == 6){
                        countAction('xb_41', null);
                    }
                } catch (error) {
                    console.log(error);
                }
                setCurrentSlide(ele, index);
                if(swiper2){
                    swiper2.slideTo(index, 800, false);
                }
                //mySwiper.initialSlide=index;
            });
        });
    }

    const swiper2 = new Swiper('.swiper2', {
    	observer: true,//修改swiper自己或子元素时，自动初始化swiper
     	observeParents: true,//修改swiper的父元素时，自动初始化swiper
        //freeModeSticky  设置为true 滑动会自动贴合
        direction: 'horizontal',//Slides的滑动方向，可设置水平(horizontal)或垂直(vertical)。
        loop: false,
		effect: 'fade',//淡入
        //effect : 'cube',//方块
        //effect : 'coverflow',//3D流
        //effect : 'flip',//3D翻转
        autoHeight: true,//自动高度。设置为true时，wrapper和container会随着当前slide的高度而发生变化。
        onSlideChangeEnd: function(swiper) {  //回调函数，swiper从一个slide过渡到另一个slide结束时执行。
            var n = swiper.activeIndex;
            setCurrentSlide($(".swiper1 .swiper-slide").eq(n), n);
            swiper1.slideTo(n, 800, false);
        }
    });

    const swiper3 = new Swiper('.swiper3', {
    	observer: true,//修改swiper自己或子元素时，自动初始化swiper
     	observeParents: true,//修改swiper的父元素时，自动初始化swiper
        slidesPerView: 5.5,
        paginationClickable: true,//此参数设置为true时，点击分页器的指示点分页器会控制Swiper切换。
        spaceBetween: 12,//slide之间的距离（单位px）。
        freeMode: true,//默认为false，普通模式：slide滑动时只滑动一格，并自动贴合wrapper，设置为true则变为free模式，slide会根据惯性滑动且不会贴合。
        loop: false,//是否可循环
        onTab: function(swiper) {
            var n = swiper3.clickedIndex;
        }
    });
    //非空判断
    if(swiper3.slides){
        swiper3.slides.each(function(index, val) {
            var ele = $(this);
            ele.unbind('click').on("click", function() {
                //数据统计
                console.log(ele.html());
                try {
                    if(index == 0){
                        countAction('xb_44', null);
                    }else if(index == 1){
                        countAction('xb_45', null);
                    }else if(index == 2){
                        countAction('xb_46', null);
                    }else if(index == 3){
                        countAction('xb_47', null);
                    }else if(index == 4){
                        countAction('xb_48', null);
                    }else if(index == 5){
                        countAction('xb_49', null);
                    }else if(index == 6){
                        countAction('xb_50', null);
                    }
                } catch (error) {
                    console.log(error);
                }
                setCurrentSlideTwo(ele, index);
                swiper4.slideTo(index, 800, false);
            });
        });
    }

    const swiper4 = new Swiper('.swiper4', {
    	observer: true,//修改swiper自己或子元素时，自动初始化swiper
     	observeParents: true,//修改swiper的父元素时，自动初始化swiper
        direction: 'horizontal',//Slides的滑动方向，可设置水平(horizontal)或垂直(vertical)。
        loop: false,
        effect : 'fade',//淡入
        autoHeight: true,//自动高度。设置为true时，wrapper和container会随着当前slide的高度而发生变化。
        onSlideChangeEnd: function(swiper) {  //回调函数，swiper从一个slide过渡到另一个slide结束时执行。
            var n = swiper.activeIndex;
            setCurrentSlideTwo($(".swiper3 .swiper-slide").eq(n), n);
            swiper3.slideTo(n, 800, false);
        }
    });

    //课堂页面Banner图
    // const swiperClassroom = new Swiper('.swiperClassroom',{
    // 	observer: true,//修改swiper自己或子元素时，自动初始化swiper
    //  	observeParents: true,//修改swiper的父元素时，自动初始化swiper
    //     autoplay: {
    //         delay: 2500,
    //         disableOnInteraction: false,
    //     },
    //     loop: true,
	// });
});

//资讯
function setCurrentSlide(ele, index) {
    $(".swiper1 .swiper-slide").removeClass("selected");
    ele.addClass("selected");
    //swiper1.initialSlide=index;
    var id = ele.attr('data-val');
    $$.request({
        url: UrlConfig.getByClassifyIdList,
        pars: {
            _classifyId: id
        },
        method: "POST",
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                //console.log("实现getByClassifyIdList函数");
                let resultHtml = ``;
                resultHtml += `<div class="swiper-slide swiper-no-swiping">
                               <div style="width: 100%;height: 100%;background-color: #f2f4f7;">
                               <div class="part1">
                               <div class="part1-top">
                               <ul id="subjectList">`;
                for (let i = 0; i < data.datas.length; i++) {
                    if (1 == 0) {
                        resultHtml += ` <li class="left" onclick='jumpSubject(${data.datas[i].id})'>
                                        <a href="javascript:;" style=background-image:url(${data.datas[i].coverImgUrl})>
                                        <span class="title">${data.datas[i].coverTitle}</span>
                                        <span class="specialIcon">专题</span>
                                        </a>
                                        </li>`;
                    } else {
                        resultHtml += ` <li class="right" onclick='jumpSubject(${data.datas[i].id})'>
                                        <a href="javascript:;" style=background-image:url(${data.datas[i].coverImgUrl})>
                                        <span class="title">${data.datas[i].coverTitle}</span>
                                        <span class="specialIcon">专题</span>
                                        </a>
                                        </li>`;
                    }
                }
                resultHtml += `		</ul>
                                    </div>
                                    </div>
                                    </div>
                                    </div>`;
                $("#classifyMenu").html(resultHtml);

                setTimeout(loadGetWebInformaList(),500);
                return resultHtml;
            } else {
                $$.layerToast(`获取专题失败！[${data.msg}]`);
            }
        }
    });

    function loadGetWebInformaList(){
        $$.request({
            url: UrlConfig.getWebInformaList,
            pars: {
                classifyId: id
            },
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    //console.log("实现getWebInformaList函数");
                    let z = data.articleList.length + data.videoList.length;
                    let articleIndex = 0,articleLen = 0, videoIndex = 0,videoLen = 0;
                    let resultHtml = ``;
                    let s = 0;
                    if(data.articleList.length > 0){
                        articleLen = data.articleList.length;
                    }
                    if(data.videoList.length > 0){
                        videoLen = data.videoList.length;
                    }
                    //文章长度比视频长度
                    if (data.articleList.length > data.videoList.length){
                        for (let i = 0; i < data.articleList.length; i++) {
                            resultHtml += ` <div class="part3" onclick='jumpArticleDetails(${data.articleList[i].id})'>
                                            <div class="item">
                                            <div class="left">
                                            <p class="overflow">${data.articleList[i].title}</p>
                                            <div class="label">
                                            <span class="icon">${data.articleList[i].classifyname}</span>
                                            <div class="commentWrap">
                                            <span class="comment"></span><span class="commentNum">${data.articleList[i].ecount < 999 ? data.articleList[i].ecount : "999+"}</span>
                                            </div>
                                            <div class="eyesWrap">
                                            <span class="eyes"></span><span class="eyesNum">${data.articleList[i].vscount < 999 ? data.articleList[i].vscount : "999+"}</span>
                                            </div>
                                            </div>
                                            </div>
                                            <div class="right">
                                            <a href="javascript:;" style=background-image:url(${data.articleList[i].coverimgurl})></a>
                                            </div>
                                            </div>
                                            </div>`;
                            if (i > 0 && (i+1) % 2 == 0){
                                if (videoIndex<videoLen){
                                    resultHtml += ` <div class="part2" onclick='jumpVideoDetails(${data.videoList[videoIndex].id})'>
                                                    <h3>${data.videoList[videoIndex].title}</h3>
                                                    <div class="img img1" style='position: relative;'>
                                                    <img id='coverImgUrl' style='height: 200px' src=${data.videoList[videoIndex].coverImgUrl} />
                                                    <img style='height: 40px; width: 40px; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);' src='../../images/know/information/ico_play.png' />
                                                    </div>
                                                    <div class="label">
                                                    <span class="icon">${data.videoList[videoIndex].classifyname}</span>
                                                    <div class="commentWrap">
                                                    <span class="comment"></span><span class="commentNum">${data.articleList[videoIndex].ecount < 999 ? data.articleList[videoIndex].ecount : "999+"}</span>
                                                    </div>
                                                    <div class="eyesWrap">
                                                    <span class="eyes"></span><span class="eyesNum">${data.articleList[videoIndex].vscount < 999 ? data.articleList[videoIndex].vscount : "999+"}</span>
                                                    </div>
                                                    </div>
                                                    </div>`;
                                }
                                videoIndex++;
                            }
                        }
                    }else if (data.videoList.length > data.articleList.length){
                        for (let i = 0; i < data.videoList.length; i++) {
                            resultHtml += ` <div class="part2" onclick='jumpVideoDetails(${data.videoList[i].id})'>
                                            <h3>${data.videoList[i].title}</h3>
                                            <div class="img img1" style='position: relative;'>
                                            <img id='coverImgUrl' style='height: 200px' src=${data.videoList[i].coverImgUrl}' />
                                            <img style='height: 40px; width: 40px; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);' src='../../images/know/information/ico_play.png' />
                                            </div>
                                            <div class="label">
                                            <span class="icon">${data.videoList[i].classifyname}</span>
                                            <div class="commentWrap">
                                            <span class="comment"></span><span class="commentNum">${data.articleList[i].ecount < 999 ? data.articleList[i].ecount : "999+"}</span>
                                            </div>
                                            <div class="eyesWrap">
                                            <span class="eyes"></span><span class="eyesNum">${data.articleList[i].vscount < 999 ? data.articleList[i].vscount : "999+"}</span>
                                            </div>
                                            </div>
                                            </div>`;
                            if (i > 0 && (i+1) % 2 == 0){
                                if (articleIndex<articleLen){
                                    resultHtml += ` <div class="part3" onclick='jumpArticleDetails(${data.articleList[articleIndex].id})'>
                                                    <div class="item">
                                                    <div class="left">
                                                    <p class="overflow">${data.articleList[articleIndex].title}</p>
                                                    <div class="label">
                                                    <span class="icon">${data.articleList[articleIndex].classifyname}</span>
                                                    <div class="commentWrap">
                                                    <span class="comment"></span><span class="commentNum">${data.articleList[articleIndex].ecount < 999 ? data.articleList[articleIndex].ecount : "999+"}</span>
                                                    </div>
                                                    <div class="eyesWrap">
                                                    <span class="eyes"></span><span class="eyesNum">${data.articleList[articleIndex].vscount < 999 ? data.articleList[articleIndex].vscount : "999+"}</span>
                                                    </div>
                                                    </div>
                                                    </div>
                                                    <div class="right">
                                                    <a href="javascript:;" style=background-image:url(${data.articleList[articleIndex].coverimgurl})></a>
                                                    </div>
                                                    </div>
                                                    </div>`;
                                }
                                articleIndex++;
                            }
                        }
                    }
                    $("#classifyMenu>div>div").append(resultHtml);
                    // loadRes();
                    // return resultHtml;
                } else {
                    $$.layerToast(`获取资讯列表失败！[${data.msg}]`);
                }
            }
        });
    }
}



/** --------问答
 * 描述信息：选中样式
 * @author 覃创斌
 * @date 2019/10/31
 */
function setCurrentSlideTwo(ele, index) {
    $(".swiper3 .swiper-slide").removeClass("selected");
    ele.addClass("selected");
    const id = ele.attr('data-val');
    $$.request({
        url: UrlConfig.getWebWenDaList,
        pars: {
            id: id
        },
        method: "POST",
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                let resultHtml = ``;
                resultHtml += `<div class="swiper-slide swiper-no-swiping">
                               <ul class="content_ul" id="LabelList">`;
                for (var i = 0; i < data.datas.length; i++) {
                    resultHtml += ` <li>
                                    <div data-val=${data.datas[i].qid}>
                                    <h3>${data.datas[i].questionContent}</h3>
                                    <div class="message">`;

                    //判断是否为匿名发表
                    if(data.datas[i].isAnonymous == 1){
                        resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                       <span class="name">匿名</span>`;
                    }else{
                        //判断是否设置过昵称
                        if("" == data.datas[i].rname || null == data.datas[i].rname){
                            //判断是否设置过头像
                            if("" == data.datas[i].imgPath || null == data.datas[i].imgPath){
                                if("" == data.datas[i].account || null == data.datas[i].account){
                                    resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                                   <span class="name" style="color: #ff7052;">侵入者</span>`;
                                }else{
                                    resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                                   <span class="name">${data.datas[i].account}</span>`;
                                }
                            }else{
                                if("" == data.datas[i].account || null == data.datas[i].account){
                                    resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                                   <span class="name" style="color: #ff7052;">侵入者</span>`;
                                }else{
                                    resultHtml += `<div class="headImg"><img src=${data.datas[i].imgPath}></div>
                                               <span class="name">${data.datas[i].account}</span>`;
                                }
                            }
                        }else{
                            if("" == data.datas[i].imgPath || null == data.datas[i].imgPath){
                                resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                                   <span class="name">${data.datas[i].rname}</span>`;
                            }else{
                                resultHtml +=
                                    `<div class="headImg"><img src=${data.datas[i].imgPath}></div>
                                     <span class="name">${data.datas[i].rname}</span>`;
                            }
                        }
                    }
                    resultHtml += `		<span class="date">${data.datas[i].answerDate}</span>
                                        </div>
                                        <p class="content">${cutString(data.datas[i].answerContent,100)}</p>
                                        <div class="label">
                                        <span class="icon icon2">${data.datas[i].labelName}</span>
                                        <div class="commentWrap">
                                        <span class="comment"></span><span class="commentNum">${data.datas[i].answer < 999 ? data.datas[i].answer : "999+"}</span>
                                        </div>
                                        <div class="eyesWrap">
                                        <span class="eyes"></span><span class="eyesNum">${data.datas[i].browse < 999 ? data.datas[i].browse : "999+"}</span>
                                        </div>
                                        </div>
                                        </div>`;
                    if (data.datas[i].count == 0){
                        resultHtml += `	<button class="follow" data-val=${data.datas[i].qid}>关注</button>`;
                    }else {
                        resultHtml += `	<button class="follow" >已关注</button>`;
                    }
                    resultHtml += `</li>`;
                }
                resultHtml += `</ul>
                               </div>`;


                $("#labelMenu").html(resultHtml);
                $(".follow").on("click",function(){
                    const id = $(this).attr("data-val");
                    if (id != null){
                        //数据统计
                        try {
                            countAction('xb_53', null);
                        } catch (error) {
                            console.log(error);
                        }
                        $(this).html("已关注");
                        $$.request({
                            url: UrlConfig.focusquestion_insertData,
                            loading: true,
                            pars:{
                                questionId:id,
                                qid:id
                            },
                            requestBody:true,
                            sfn: function (data) {
                                $$.closeLoading();
                                if (data.success) {
                                    $$.layerToast("关注成功");
                                } else {
                                    $$.layerToast(data.msg);
                                }
                            },
                            ffn: function (data) {
                                $$.errorHandler();
                            }
                        });
                    }
                });

                $("#LabelList > li > div").on("click",function(){
                    const id = $(this).attr("data-val");
                    $$.push("know/questionDetail",{
                        questionId:id
                    })
                });
                //loadRes();
                return resultHtml;
            } else {
                $$.layerToast(`获取问答分类失败！[${data.msg}]`);
            }
        }
    });
}
