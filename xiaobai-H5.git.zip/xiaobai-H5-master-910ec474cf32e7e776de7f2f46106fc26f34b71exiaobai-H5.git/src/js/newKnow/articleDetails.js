/**
 * 新版咨询 - 文章详情 JS
 * @Author 吴成林
 * @Date 2020-8-14 16:45:25
 */
window.onload = function() {
    $$.changeVersion();

    let id, memberId, share, weChatOpenId, params, orderToken, isPay, paymentCbk;
    const PAGE_STATE = {
        shareDatums: {
            url: "",
            image: $Constant.shareLogo,
            title: "",
            content: 'hi，这篇文章很有意思哦，快来一起学习吧'
        }
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        id = $$.getUrlParam("id");
        if ($$.isValidObj(id)) id = id.toString();
        share = $$.getUrlParam("share");
        memberId = $$.getUrlParam("memberId");                  // 分享用户id
        weChatOpenId = $$.getUrlParam("shareWeChatOpenId");     // 分享用户weChatOpenId
        orderToken = $$.getUrlParam("orderToken");              // 订单
        isPay = $$.getUrlParam("isPay");
        paymentCbk = $$.getUrlParam("paymentCbk");

        if (paymentCbk){
            $$.request({
                url: UrlConfig.member_getByPayID,
                pars: {
                    payRecordId: orderToken
                },
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        $$.push("newKnow/articleDetails",{
                            id: data.videoId
                        })
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        }else {
            pageInit();
            /*if ($$.isValidObj(share) && share === 'true' ){                 // 点击分享地址后先获取weChatOpenId
                getWeChatOpenId();
            } else {
                pageInit();
            }*/
        }

        verifyPaymentSuccess();     // 验证支付成功状态
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        //-- 登录状态
        loadArticle();              // 加载文章详情
        loadCollect();              // 加载收藏
        loadEvaluation();           // 加载评论
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 点击收藏和取消收藏
        $(".topUserInfo .collect").on("click",function () {
            if ($$.checkLogin()){
                collectOperation();
            } else{
                $$.confirmLogin();
            }
        });

        //-- 点击分享给客户填写
        $('.topUserInfo .share').on('click', function () {
            shareHandler();
        });

        //-- 点击发布评论
        $('.menu-evaluate').on('click', function () {
            if ($$.checkLogin()){
                submitBtn();
            } else{
                $$.confirmLogin();
            }
        });

        //-- 点赞文章
        $('.likeArticle').on('click', function () {
            if ($$.checkLogin()){
                getGiveLike();
            } else{
                $$.confirmLogin();
            }
        });

        //-- 评论列表 显示更多
        $(".showMoreComment").on("click", function(){
            $('.commentList>div').css("display", "flex");
            $(this).hide();
        });

        //-- 评论文章
        $(".commentArticle").on("click", function(){
            params = null;
            $(this).siblings('.title').css({"font-size":"16px", "color":"black",}).html('评论');
        });

        //-- 支付 - 购买文章
        $(".readMore").on('click', function () {
            createOrder();      // 创建订单
        });

        $$.setReadLongTimes();  // 阅读时长
    }

    /**
     * 描述信息：加载文章详情
     * @author 吴成林
     * @date 2020-8-14 16:45:16
     */
    function loadArticle() {
        $$.request({
            url: UrlConfig.member_article_getByArticleIdNew,
            pars: {
                articleId: id
            },
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    loadContent(data);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

        function loadContent(data) {
            const {article, buyStatus, memberHeadList, articlePcount, memberIsVip, praiseCount, memberIsPraise} = data,
                {title, issuer, issueDate, memberPrice, unmemberPrice ,articleContent ,articlePreviewContent} = article;
            if ($$.isValidObj(articlePcount)) $('.previewCount span').html(articlePcount);
            if ($$.isValidObj(praiseCount)) $('.likeArticleSum span').html(praiseCount);
            if ($$.isValidObj(issuer)) $('.articlePublisher').html(issuer);
            if ($$.isValidObj(issueDate)) $('.articleDate').html(issueDate);
            if ($$.isValidObj(memberIsVip)) $('.price>span').html(memberIsVip == 1 ? memberPrice : unmemberPrice);          //-- 用戶是否是vip   1：vip、2、未开通
            if ($$.isValidObj(memberIsPraise) && memberIsPraise == 1) $('.likeArticle img').attr('src', '../../images/know/likeArticle.png');

            if ($$.isValidObj(title)) {
                $('.articleContent .title').html(title);
                $('title').html(title);
            }

            if ($$.isValidObj(memberHeadList) && memberHeadList.length != 0){
                let html = ``;
                for (let i in memberHeadList){
                    const {imgPath} = memberHeadList[i];
                    html += $$.isValidObj(imgPath) ? `<img src="${imgPath}">` : `<img src="../../images/my/defaultImg.png">`;
                }
                $('.previewUser').html(html);
            } else{
                $('.previewUser').hide()
            }

            if (buyStatus == 1 || buyStatus == 2){      //-- 购买状态   1： 免费、2：用户已购买/vip免费、3：未购买、4：未登录（可忽略）
                $('.payment').hide();
                $('.hiddenPart').hide();
                $('.gradients').hide();
                $('.wrapper').css('padding-bottom', '0px');
                $('.articleContent').append(articleContent);
            } else{
                $('.articleContent').append(articlePreviewContent);
            }

            //-- 分享参数
            PAGE_STATE.shareDatums.title = $$.isValidObj(title) ? title : '热门资讯';

            weChatShare();              // 分享配置
        }
    }

    /**
     * 描述信息：加载收藏
     * @author 吴成林
     * @date 2020-8-14 16:45:16
     */
    function loadCollect() {
        if ($$.checkLogin()){
            $$.request({
                url: UrlConfig.getCountCollectstatistic,
                pars: {
                    type: 1,
                    objectId: id
                },
                requestBody: true,
                method: "POST",
                sfn: function (data) {
                    if (data.success) {
                        let background = `#FF8009`, text = "收藏";
                        if (data.count > 0){
                            background = "#CCCCCC";
                            text = "已收藏";
                        }
                        $(".collect").css("background", background).text(text);
                    } else {
                        $$.layerToast(`失败！[${data.msg}]`);
                    }
                }
            });
        }
    }

    /**
     * 描述信息：收藏操作
     * @author 吴成林
     * @date 2020-8-14 16:45:16
     */
    function collectOperation() {
        $$.request({
            url: UrlConfig.insertCollectstatistic,
            pars: {
                type: 1,
                objectId: id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    let background = `#FF8009`, text = "收藏", layerToast = "取消收藏！";
                    if (data.count === 0){
                        background = "#CCCCCC";
                        text = "已收藏";
                        layerToast = "收藏成功！";
                        countAction("xb_2012");
                    }
                    $$.layerToast(layerToast);
                    $(".collect").css("background", background).text(text);
                } else {
                    $$.layerToast(`失败！[${data.msg}]`);
                }
            }
        });
    }

    /**
     * 描述信息：点赞文章
     * @author 吴成林
     * @date 2020-8-14 16:45:16
     */
    function getGiveLike(){
        $$.request({
            url: UrlConfig.praisestatistic_save,
            pars: {
                type: 14,
                objectId: id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    let n =  $('.likeArticleSum span').text().trim();
                    let giveLike;
                    if (data.delete){
                        $$.layerToast('取消点赞！');
                        giveLike = parseInt(n)-1;
                        $('.likeArticle img').attr('src', '../../images/know/notLikeArticle.png');
                    }else {
                        $$.layerToast('点赞成功！');
                        giveLike = parseInt(n)+1;
                        $('.likeArticle img').attr('src', '../../images/know/likeArticle.png');
                        checkToDayRead();
                    }
                    $('.likeArticleSum span').html(giveLike);
                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    }

    /**
     * 描述信息：检查当日是否阅读文章并点赞 (点赞文章后调用)
     * @author 吴成林
     * @date 2020-8-14 16:45:16
     */
    function checkToDayRead() {
        $$.request({
            url: UrlConfig.integral_checkToDayRead,
            pars: {},
            method: "POST",
            sfn: function (data) {
                if (!data) {
                    $$.request({
                        url: UrlConfig.integral_handSendIntegral,
                        pars: {
                            code:"I0006"
                        },
                        method: "POST",
                        sfn: function (info) {
                            if (info.success){
                                $$.alert("积分赠送成功！");
                                countAction("xb_2034");
                            }
                        }
                    });
                }
            }
        });
    }

    /**
     * 描述信息：加载评论
     * @author 吴成林
     * @date 2020-8-18 09:52:49
     */
    function loadEvaluation() {
        $$.request({
            url: UrlConfig.member_evaluation_getEvaluationListByObjectId,
            requestBody: true,
            pars: {
                objectId: id,
                type: 1
            },
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    if ($$.isValidObj(data.datas)){
                        loadContent(data.datas);
                    }
                } else {
                    $$.layerToast("获取评论失败！");
                }
            }
        });

        //-- 加载评论列表
        function loadContent(data) {
            let html = ``;
            for (let i in data){
                const item = data[i];
                let {allEvaluationChildList, rname, id, imgPath, createTime, evaluationContent, giveLike, isAnonymous, isMyPraise} = item;
                rname = isAnonymous == 0 ? ($$.isValidObj(rname) ? rname : `小白`) : "匿名";
                html += `<div class="flex-start commentUnit topComment" data-id="${id}" data-state="1">
                            <img src='${$$.isValidObj(imgPath) && isAnonymous == 0 ? imgPath : `../../images/my/defaultImg.png`}'>
                            <div>
                                <div><span class="commentRname" data-rname="${rname}">${rname}</span></div>
                                <div class="replyTime" style="color: #CCCCCC">
                                    <span>回复于 </span>
                                    <span>${getDate(createTime)}</span>
                                </div>
                                <div class="space-between">
                                    <div class="commentContent">${evaluationContent}</div>
                                    <div class="commentPraise" data-id="${id}">
                                        <img src="${localCache(labelKey = 'comment'+ id, imgState = true) || isMyPraise == 1 ? `../../images/my/newMyVisitingCard/like.png` : `../../images/my/newMyVisitingCard/dislike.png`}">
                                        <div style="color: #999999">${giveLike}</div>
                                    </div>
                                </div>
                                ${$$.isValidObj(allEvaluationChildList) ? replyComment(allEvaluationChildList) : ``}
                            </div>
                        </div>`;
            }
            $('.commentList').html(html);
            if (data.length > 2) $('.showMoreComment').show().text(`—— 展开${data.length-2}条评论 ——`);

            //-- 回复评论
            $(".commentList .commentUnit").on("click", function(e){
                e.stopPropagation();
                let id = $(this).attr("data-id");
                let state = $(this).attr("data-state");
                let topCommentId = $(this).parents('.topComment').attr("data-id");
                let name = $(this).find(".commentRname").eq(0).text();
                let content = $(this).find(".commentContent").eq(0).text();

                if (state == "1") topCommentId = id;
                params = {"id": id, "topCommentId": topCommentId};
                $('.commentTitle .title').css({"font-size":"12px", "color":"#CCCCCC",}).text(`回复 ${name}: ${content}`);
                $("#evaluation").focus();
            });

            //-- 显示更多回复
            $('.expandAll').on("click", function (e) {
                e.stopPropagation();
                $(this).siblings('.replyCommentList').children().css("display", "flex");
                $(this).hide();
            });

            //-- 点赞
            $('.commentPraise').on("click", function (e) {
                e.stopPropagation();
                let doc = $(this);
                let id = $(this).attr("data-id");
                let giveLike = parseInt($(this).children("div").text().trim());
                getGiveLike(doc, id, giveLike);
            });
        }

        //-- 二级回复评论
        function replyComment(data) {
            let html = `<div class="replyCommentList">`;
            for (let i in data){
                const item = data[i];
                let {rname, id, imgPath, createTime, evaluationContent, giveLike, isAnonymous, toRname, toIsAnonymous, isMyPraise} = item;
                rname = isAnonymous == 0 ? ($$.isValidObj(rname) ? rname : `小白`) : "匿名";
                toRname = toIsAnonymous == 0 ? ($$.isValidObj(toRname) ? toRname : `小白`) : "匿名";
                html += `<div class="flex-start commentUnit" data-id="${id}">
                            <img src='${$$.isValidObj(imgPath) && isAnonymous == 0 ? imgPath : `../../images/my/defaultImg.png`}' style="width: 22px; height: 22px;">
                            <div>
                                <div>
                                    <span class="commentRname" data-rname="${rname}">${rname}</span>
                                    <span style="color: #CCCCCC; font-size: 12px">回复</span>
                                    <span>${$$.isValidObj(toRname) ? toRname : `小白`}</span>
                                </div>
                                <div class="replyTime" style="color: #CCCCCC">
                                    <span>回复于 </span>
                                    <span>${getDate(createTime)}</span>
                                </div>
                                <div class="space-between">
                                    <div class="commentContent">${evaluationContent}</div>
                                    <div class="commentPraise" data-id="${id}">
                                        <img src="${localCache(labelKey = 'comment'+ id, imgState = true) || isMyPraise ? `../../images/my/newMyVisitingCard/like.png` : `../../images/my/newMyVisitingCard/dislike.png`}">
                                        <div style="color: #999999">${giveLike}</div>
                                    </div>
                                </div>
                            </div>
                        </div>`;
            }
            html += `</div>`;
            if (data.length > 2)  html += `<div class="expandAll">—— 展开${data.length - 2}条回复 ——</div>`;
            return html;
        }

        //-- 更新评论点赞数
        function getGiveLike(doc, id, giveLike){
            $$.request({
                url: UrlConfig.praisestatistic_save,
                pars: {
                    type:1,
                    objectId:id
                },
                requestBody: true,
                method: "POST",
                sfn: function (data) {
                    if (data.success) {
                        checkToDayRead();
                        if (data.delete){
                            giveLike -= 1;
                            $$.layerToast('取消点赞！');
                            $(doc).children("div").html(giveLike);
                            $(doc).children("img").attr('src', '../../images/my/newMyVisitingCard/dislike.png');

                        }else {
                            giveLike += 1;
                            $(doc).children("div").html(giveLike);
                            $(doc).children("img").attr('src', '../../images/my/newMyVisitingCard/like.png');
                            $$.layerToast('点赞成功！');
                        }
                        $$.request({
                            url: UrlConfig.evaluation_updateGiveLike,
                            pars: {
                                "id": id,
                                "giveLike": giveLike,
                            },
                            sfn: function (data) {

                            }
                        });
                    } else {
                        $$.layerToast(`${data.msg}`);
                    }
                }
            });
        }
    }

    /**
     * 描述信息：提交评论
     * @author 吴成林
     * @date 2020-8-14 16:45:16
     */
    function submitBtn() {
        //数据统计
        try {
            countAction('xb_43', null);
            countAction("xb_2014");
        } catch (error) {
            console.log(error);
        }
        let anonymity = $("#anonymity").prop("checked");
        let isAnonymous = anonymity ? 1 : 0;
        let param = $$.isValidObj(params) ? params : {"evaluationType": 0} ;
        let evaluation = $("#evaluation").val().trim();
        if (evaluation !==""){
            $$.request({
                url: UrlConfig.member_evaluation_evaluationInsert,
                pars: {
                    evaluationContent: evaluation,
                    isAnonymous: isAnonymous,
                    objectID: id,
                    type: 1,
                    ...param
                },
                requestBody: true,
                method: "POST",
                sfn: function (data) {
                    if (data.success) {
                        loadEvaluation(id);
                    } else {
                        $$.layerToast(`${data.msg}`);
                    }
                    $("#evaluation").val("");
                }
            });
        }else{
            $$.layerToast("评论内容不能为空~");
        }
    }


    //-- 验证支付成功
    function verifyPaymentSuccess() {
        if (isPay) {
            $$.loading("支付处理中");
            $$.pushHistory();
            window.addEventListener("popstate", function() {
                const backUrl = localStorage.getItem('backUrl');
                if(!$$.isValidObj(backUrl) || backUrl.indexOf(".html") === -1){
                    return;
                }
                window.location.href = backUrl;
            }, false);
            loop(orderToken);
        } else {
            localStorage.setItem('backUrl',document.referrer);
        }
    }

    function loop(orderToken, loopIndex = 0) {
        loopIndex++;
        $$.request({
            url: UrlConfig.member_pay_getSubjectPayById,
            pars: {id: orderToken},
            requestBody: true,
            sfn: function (data) {
                if (data.success) {
                    const payStatus = data.payStatus;
                    if (payStatus === 1) {
                        $$.closeLoading();
                        $$.alert("支付成功！");
                    } else if (payStatus === 0) {
                        //-- 待支付状态
                        if (loopIndex >= 10) {
                            $$.closeLoading();
                            $$.alert("似乎没支付成功！");
                        } else {
                            setTimeout(function () {
                                loop(orderToken, loopIndex);
                            }, 1000);
                        }
                    } else {
                        $$.closeLoading();
                        $$.alert("支付失败！");
                    }
                } else {
                    $$.closeLoading();
                }
            }
        });
    }

    //-- 发起订单
    function createOrder() {
        $$.request({
            url: UrlConfig.member_pay_insertSubjectPay,
            pars: {
                courseId: id,           // 文章资讯id
                productType: 1          // 1：文章资讯的类型
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    const {payId} = data;     //返回插入成功后的购买记录订单id
                    paymentHandler(payId, id);
                } else {
                    $$.layerToast(data.msg);
                }
            },
        });
    }

    //-- 支付处理
    function paymentHandler(orderId, courseId) {
        const returnUrl = encodeURIComponent('newKnow/articleDetails');
        $$.push("product/payment", {
            paymentType: 'weChatPay',
            doComplexFormType: OrderHelper.payDoComplexFormType.FORM_TYPE_10009,  // 资讯购买业务类型
            otherParams: JSON.stringify({
                orderToken: orderId,
                courseId: courseId,
                returnUrl: returnUrl,
                successPayUrl: returnUrl
            })
        });
    }

    //微信授权登录
    function getWeChatOpenId() {
        let url = window.location.search;
        url = url.replace("true",'false');
        url = "newKnow/articleDetails.html"+url;

        $$.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: url,
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_6,
                otherParams: JSON.stringify({
                    "objectId": id,
                    "type": 1,
                    "memberId": memberId,
                    'shareWeChatOpenId': weChatOpenId
                })
            },
            loading: true,
            sfn: function(data){
                $$.closeLoading();
                location.href = data.datas;
            }
        });
    }

    /**
     * 分享
     * @Author 吴成林
     * @Date 2020-5-15 11:36:31
     */
    function weChatShare(){
        if (!$WeChat.isWx() && !PAGE_APP) {
            return;
        }

        let _lineLink = $$.getFullHost() + '/src/pages/newKnow/articleDetails.html';
        /* 是否带参 */
        _lineLink += $$.jsonToUrlParams({
            id: id,
        });

        PAGE_STATE.shareDatums.url = _lineLink;      //-- 保存分享参数
        const { url, image, title, content } = PAGE_STATE.shareDatums;

        weChatJSTool.share({
            _imgUrl: image,
            _lineLink: url,
            _shareTitle: title,
            _descContent: content,
            _sfn: function () {
                check();
                countAction("xb_2013");
            }
        });
    }

    /**
     * 检查今日是否分享文章/话题
     * @Author 吴成林
     * @Date 2020-8-14 20:58:30
     */
    function check() {
        if ($$.isValidObj(memberId)) {
            $$.request({
                url: UrlConfig.integral_checkToDayShareArticle,
                pars: {
                    memberId: memberId
                },
                method: "POST",
                sfn: function (data) {
                    if (!data) {
                        //-- 根据code和memberId送积分
                        $$.request({
                            url: UrlConfig.integral_handSendIntegral,
                            pars: {
                                code:"I0005"
                            },
                            method: "POST",
                            sfn: function (info) {
                                if (info.success){
                                    $$.alert("积分赠送成功！");
                                    countAction("xb_2033");
                                }
                            }
                        });
                    }
                }
            });
        }
    }

    /**
     * 判断缓存是否是当天
     * @Params (String) labelKey = keyName+id, imgState
     * @Author 吴成林
     * @Date 2020-7-16 17:40:16
     */
    let localCache = (labelKey, imgState) => {
        //-- 本地缓存
        let returnValue = false;
        const cacheKey = "WX_VISITING_CARD_TIME_" + labelKey;
        const defaultValue = $Date.dateFormat(new Date());

        let cacheTime = localStorage.getItem(cacheKey);
        const hasCache = $$.isValidObj(cacheTime);
        if (hasCache){
            if (cacheTime === defaultValue){
                returnValue = true;
            } else {
                if (!imgState) localStorage.setItem(cacheKey, defaultValue);
            }
        } else{
            if (!imgState) localStorage.setItem(cacheKey, defaultValue);
        }
        return returnValue;
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-5-15 11:31:25
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;

            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            console.log(PAGE_STATE.shareDatums);
            //-- 分享
            $$.showShareView('点击右上角，分享文章~');
        }
    }

    function getDate(old) {
        let returnText = "";
        const nowDate = new Date().getTime();   //当前时间
        const setDate = new Date(old).getTime();
        const times = Math.floor((nowDate - setDate) / 1000);
        if (times > 60*60*24*30){
            returnText= old.substring(0,10);
        } else if(times > 60*60*24){
            returnText=Math.floor(times / (60*60*24))+"天前";
        }else if(times > 60*60){
            returnText=Math.floor(times / (60*60))+"小时前";
        }else if(times > 60){
            returnText=Math.floor(times / (60))+"分钟前";
        }else if(times > 0){
            returnText=Math.floor(times / 1)+"秒前";
        }else{
            returnText="刚刚";
        }
        return returnText;
    }
}