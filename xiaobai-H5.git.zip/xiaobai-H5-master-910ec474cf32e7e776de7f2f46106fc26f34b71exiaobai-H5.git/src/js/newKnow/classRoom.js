window.onload = function () {
    $$.changeVersion();
    /**
     * 一级菜单切换
     */
    //点击资讯
    $('#xl-tab-head-title-1').click(function () {
        $$.push('know/information');
    });

    //点击问答
    $('#xl-tab-head-title-2').click(function () {
        $$.push('know/answers');
    });

    // 我的学习
    $(".headLogo").click(function () {
        window.location.href = '../../pages/know/myLearn.html'
    });

    // 更多精品


    //音频
    /*$(".moreAudio").click(function () {
        $$.push("know/courseList",{
            type:"Audio"
        });
    });*/

    //获取Banner图并加载
    getBanner();
    getIndexLabelTop();
    //加载课堂视频
   // getCourseList();
    //加载课堂音频
    //getCourseAudioList();



    // 底部菜单
    let oBtn = document.getElementById("menu");
    let uLi = oBtn.getElementsByTagName("a");
    let n = uLi.length;
    for (let i = 0; i < n; i++) {
        uLi[i].index = i;
        uLi[i].addEventListener("touchend", function () {
            for (let j = 0; j < n; j++) {
                uLi[j].className = "";
            }
            this.className = "active";
        }, false)
    }

    //-- 跳转自动绑定
    $$.staticPushAutoBind();
    if (!$$.checkLogin()){
        $$.gotoLogin();
    }
    //加载分类
    loadClassify();

};
