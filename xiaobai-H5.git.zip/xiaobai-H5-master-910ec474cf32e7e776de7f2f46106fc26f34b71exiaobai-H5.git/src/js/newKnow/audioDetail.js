let videoId;
let audioId;
let courseItemId;
let type;
let shareImg;//分享图片
let shareMemberId;
let shareStatus;
let videoType = 1;          // 视频类型（1：单独，2：整套）
let whetherFree = false;     // 是否免费（true：免费，false：付费）
let unmemberPrice = 0;//会员价格
let payStatus = -2; //-1 免费 -2 未支付 0:支付中,1:成功,2:失败

const PAGE_STATE = {
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "",
        content: '小白保险小课堂，我在这里等你一起来学习哦'
    }
};

ShawHandler.loaderRes({
    scripts: [
        //-- Order helper
        `js/product/orderHelper.js`,
    ]
});
/*
*   1.5新版 更新功能
*   页面默认显示免费视频，付费视频隐藏 share 分享图标和禁用微信分享功能
*   底部 '免费学习' 替换为 价格 '购买学习￥99'
*   用户付费后隐藏 bottomBtn 底部
* */
window.onload = function () {
    $$.changeVersion();
    courseItemId = $$.getUrlParam("courseItemId");
    videoId = $$.getUrlParam("videoId");
    audioId = $$.getUrlParam("audioId");
    //分享参数
    shareMemberId = $$.getUrlParam("shareMemberId");
    shareStatus = $$.getUrlParam("share");
    let paymentCbk = $$.getUrlParam("paymentCbk");
    shareDetailPage(shareMemberId, shareStatus);
    let isPay = $$.getUrlParam("isPay");
    if (videoId != null) {
       // $(".playBar").append("<video controls preload='none' poster='../.././images/postersTest/person-icon.jpg'  width=\"100%\" height=\"100%\" controls id=\"video\"></video>");
        type = 1;
    }

    $(".single-slider").jRange({
        from: 0,
        to: 100,
        step: 1,
        // scale: [0, 25, 50, 75, 100],
        format: '%s',
        width: '60%',
        showLabels: false,
        showScale: false
    });
    if (paymentCbk){
        $$.request({
            url: UrlConfig.member_getByPayID,
            pars: {
                payRecordId:$$.getUrlParam("orderToken")
            },
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $$.push("newKnow/audioDetail",{
                        videoId:data.videoId
                    })
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }else {
        CourseDetailsList();
        loadEvaluation();
        insertBrowse();
        checkShare();
    }
    if (isPay) {
        $$.loading("支付处理中");
        const orderToken = $$.getUrlParam("orderToken");//訂單ID
        loop(orderToken);
    }
    /**
     * 描述信息：上一页
     * @author 覃创斌
     * @date 2019/10/10
     */
    $("#prev").on("click", function () {
        prevCourseItem(1);
    });
    /**
     * 描述信息：下一页
     * @author 覃创斌
     * @date 2019/10/10
     */
    $("#next").on("click", function () {
        prevCourseItem(2);
    });
    //点赞
    $(".like").on("click", function () {
        let id;
        if (type === 1) {
            id = videoId;
        } else if (type === 2) {
            id = audioId;
        }
        $$.request({
            url: UrlConfig.praisestatistic_save,
            pars: {
                type: 4,
                objectId: id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {

                    if (data.delete) {
                        $$.layerToast('点赞成功！');
                        $(".like").html("已点赞");
                        $(".like").css("background", "#C0C0C0");
                    } else {
                        $$.layerToast('取消点赞！');
                        $(".like").html("点赞");
                        $(".like").css("background", "#ff7052");
                    }

                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    });
    //评论
    $(".send").on("click", function () {
        if (!$$.checkLogin()){
            $$.confirmLogin();
            return;
        }

        //数据统计
        try {
            countAction('xb_58', null);
        } catch (error) {
            console.log(error);
        }

        let speech = $("#speech").val().trim();
        if (!$$.isValidObj(speech)) {
            $$.layerToast('评论内容不能为空~');
            return false;
        }

        let id;
        id = type === 1 ? videoId : audioId;

        if (speech !== "") {
            $$.request({
                url: UrlConfig.insertEvaluation,
                pars: {
                    evaluationContent: speech,
                    isAnonymous: 0,
                    state: 1,
                    objectID: id,
                    type: 4,
                    isTop: 0,
                    giveLike: 0
                },
                requestBody: true,
                method: "POST",
                sfn: function (data) {
                    if (data.success) {
                        checkToDayWatchAndLearn();
                        $$.layerToast('评论成功！');
                        loadEvaluation();
                    } else {
                        $$.layerToast(`${data.msg}`);
                    }
                    $("#speech").val('');
                }
            });
        }
    });
    /**
     * 描述信息：收藏
     * @author 覃创斌
     * @date 2019-09-19
     */
    $(".collect").on("click", function () {
        if (!$$.checkLogin()){
            $$.confirmLogin();
            return;
        }

        let id;
        if (type === 1) {
            id = videoId;
        } else if (type === 2) {
            id = audioId;
        }
        $$.request({
            url: UrlConfig.insertCollectstatistic,
            pars: {
                type: 6,
                objectId: id
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    if (data.count === 0) {
                        $(".collect").html("已收藏");
                        $(".collect").css("background", "#C0C0C0");
                        $$.layerToast(`收藏成功！`);
                    } else {
                        $(".collect").html("收藏");
                        $(".collect").css("background", "#5677fc");
                        $$.layerToast(`取消收藏！`);
                    }
                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    });
    //购买
    $(".freeStudy").on("click", function () {
        if (!$$.checkLogin()){
            $$.confirmLogin();
            return;
        }
        payment();
    });

    //-- 找客服  加群学习 二维码 绑定事件
    $(".ask").on("click", function () {
        layer.open({
            content:
                `<div class="popupContent">
					<div class="question">
						<b>扫描下方二维码，加群学习</b>
						<img src="../../images/my/serviceQrCode.png"" />
						<span>长按识别二维码</span>
					</div>
				</div>`
        });
    });

    /* 点击分享给客户填写  */
    $('.share').click(function () {
        shareHandler();
    });
    /* 取消 分享 */
    $('#popup .bg,.showFrame').click(function () {
        $('#popup').hide();
        return false;
    });

    /* 课程详情标题切换 */
    $('.courseIntroTitle>div').click(function () {
        $(this).addClass("titleSelect").siblings().removeClass("titleSelect");
        let href = $(this).attr("href").toString();
        $(href).show().siblings().hide();
    });


    //播放和暂停
   $("#payVideo").click(function () {
       if (!$$.checkLogin()){
           $$.confirmLogin();
           return;
       }
       let myVideo = document.getElementById("video");
       console.log(myVideo.paused);
       if(myVideo.paused){
           if (payStatus == -1 || payStatus == 1){
               myVideo.play();
           }else {
               $$.confirm({
                   title: "您还没购买本套课程，请购买后播放！",
                   onOkLabel: "去购买",
                   onCancelLabel: "取消",
                   onOk: function(){
                       //-- 去购买
                       payment();
                   }
               });
           }

       }else{
           myVideo.pause();
       }
   });

    //-- 去支付
    function payment() {
        let id;
        if (type === 1) {
            id = videoId;
        } else if (type === 2) {
            id = audioId;
        }
        if ($('.freeStudy').html() != "免费学习"){
            gotoBuyVip(id);//开始支付
        }else {
            $$.request({
                url: UrlConfig.member_insertFreeSubject,
                pars: {
                    courseId: videoId
                },
                requestBody: true,
                method: "POST",
                sfn: function (data) {
                    if (data.success) {
                        $(".bottomBtn").hide()
                    } else {
                        $$.layerToast(`获取失败！[${data.msg}]`);
                    }
                }
            });
        }
    }


};

function checkToDayWatchAndLearn() {
    $$.request({
        url: UrlConfig.integral_checkToDayWatchAndLearn,
        pars: {},
        method: "POST",
        sfn: function (data) {
            if (!data) {
                $$.request({
                    url: UrlConfig.integral_handSendIntegral,
                    pars: {
                        code: "I0008"
                    },
                    method: "POST",
                    sfn: function (info) {
                        if (info.success) {
                            $$.alert("积分赠送成功！")
                        }
                    }
                });
            }
        }
    });
}

/**
 * 描述信息：加载Banner
 * @author 覃创斌
 * @date 2019/10/9
 */
function loadBanner() {
    let id;
    if (type === 1) {
        id = videoId;
    } else if (type === 2) {
        id = audioId;
    }
    $$.request({
        url: UrlConfig.course_getCourseBannerList,
        pars: {
            id: id
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                let resultHtml = "";
                const bannerLength = data.datas.length;
                for (let i = 0; i < bannerLength; i++) {
                    resultHtml += "  <div class=\"swiper-slide\"><img src=\"" + data.datas[i].url + "\"></div>";
                    shareImg = data.datas[i].url;
                }

                $("#banner").append(resultHtml);
                if (bannerLength > 1) {
                    //动态加载后需要重新渲染
                    const swiper = new Swiper('.swiper-container', {
                        observer: true,//修改swiper自己或子元素时，自动初始化swiper
                        observeParents: true,//修改swiper的父元素时，自动初始化swiper
                        autoplay: 2000,
                        loop: true,
                        prevButton: '.swiper-button-prev',
                        nextButton: '.swiper-button-next',
                    });
                } else {
                    $('.swiper-button-prev').hide();
                    $('.swiper-button-next').hide();
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}

function videoOrAudio() {
    let id;
    if (type === 1) {
        id = videoId;
    } else if (type === 2) {
        id = audioId;
    }
    let memberId = $$.getUrlParam("memberId");
    $$.request({
        url: UrlConfig.courseItem_getByCourseId,
        pars: {
            courseId: id,
            memberId:memberId
        },
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                console.log(data);
                payStatus = data.payStatus;
                if (data.payStatus === -1 || data.payStatus === 1){
                    const courseItemLength = data.courseItem.length;
                    if (courseItemLength > 0) {
                        let url = data.courseItem[0].avattachId;
                        const data_val = data.courseItem[0].id;
                        if (type === 1) {
                            url = url !== undefined ? url : data.courseItem[0].linkUrl;
                            $("#video").attr("src", url);
                            $("#video").attr("data-val", data_val);
                        } else if (type === 2) {
                            $("#audio").attr("src", url);
                            $("#audio").attr("data-val", data_val);
                        }
                        if (data.payStatus === 1){
                            $(".bottomBtn").hide()
                        }
                        if (data.payXstatus === 1){
                            $(".bottomBtn").hide()
                        }
                        if (data.isVip){
                            $(".bottomBtn").hide()
                        }
                        $("#prev").hide();
                        $("title").html(data.courseItem[0].cname);
                        if (courseItemLength === 1) {
                            $("#next").hide();
                        }
                    } else {
                        $("#prev").hide();
                        $("#next").hide();
                        $$.layerToast("暂无数据");
                    }
                }else {
                    $("#video").attr("poster",data.coverImg);
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}

/*function loadInfo() {
    let id;
    if (type === 1) {
        id = videoId;
    } else if (type === 2) {
        id = audioId;
    }
    $$.request({
        url: UrlConfig.course_getCourseList,
        pars: {
            id: id
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                for (let i = 0; i < data.datas.length; i++) {
                    $("#title").html(data.datas[i].title);
                    $("#lecturer").html(data.datas[i].speaker);
                    $("#Play").html(data.datas[i].pcount + '次');
                    $("#time").html(data.datas[i].createTime.substring(0, 10));
                    $("#content").html(data.datas[i].txtattachPath);
                    videoOrAudio();
                    updatePlay(data.datas[i].id, data.datas[i].pcount);
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}*/

function updatePlay(id, pcount) {
    pcount = pcount + 1;
    $$.request({
        url: UrlConfig.course_updateCourse,
        pars: {
            id: id,
            pcount: pcount
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {

            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}

/**
 * 描述信息：加载评论
 * @author 覃创斌
 * @date 2019/10/10
 */
function loadEvaluation() {
    let id;
    if (type === 1) {
        id = videoId;
    } else if (type === 2) {
        id = audioId;
    }
    $$.request({
        url: UrlConfig.getListByEvaluation,
        requestBody: true,
        pars: {
            objectid: id,
            type: 4
        },
        method: "POST",
        sfn: function (data) {
            let resultHtml = "";
            if (data.success) {

                for (let i = 0; i < data.datas.length; i++) {
                    let account = data.datas[i].account.replace(/^(\d{3})\d{4}(\d+)/, "$1****$2"); //手机号159****1111
                    resultHtml += "<li>";
                    resultHtml += "	<p class=\"top\">";
                    if (data.datas[i].isanonymous === 1) {
                        resultHtml += "<span class=\"avatar\">  <img src=" + ($$.isValidObj(data.datas[i].imgpath) ? data.datas[i].imgpath : "../../images/my/mituLogo.png") + " style=\"background-size: contain;display: inline;\"/> &nbsp;匿名</span>";
                    } else {
                        let name = data.datas[i].rname ? data.datas[i].rname : account;
                        resultHtml += "<span class=\"avatar\">  <img src=" + ($$.isValidObj(data.datas[i].imgpath) ? data.datas[i].imgpath : "../../images/my/mituLogo.png") + " style=\"background-size: contain;display: inline;\"/> &nbsp;" + name + "</span>";
                    }
                    resultHtml += "	</p>";
                    resultHtml += "	<p class=\"content\">" + data.datas[i].evaluationcontent + "</p>";
                    resultHtml += "<div class='space-between'>";
                    resultHtml += "	<p class='commentTime'>" + getDate(data.datas[i].createtime) + "</p>";
                    resultHtml += "	<div class='like' hidden><img src='../../images/know/like.png'>"+data.datas[i].givelike+"</div>";
                    resultHtml += "</div>";
                    resultHtml += "</li>";
                }
                $(".comments-li").html(resultHtml);
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}

/**
 * 描述信息：添加浏览记录
 * @author 覃创斌
 * @date 2019/10/12
 */
function insertBrowse() {
    let id;
    let viewStatisticType;
    if (type === 1) {
        id = videoId;
        viewStatisticType = 2;
    } else if (type === 2) {
        id = audioId;
        viewStatisticType = 6;
    }
    let memberId = $$.getUrlParam("memberId");
    $$.request({
        url: UrlConfig.viewStatistic_insertViewStatistic,
        pars: {
            shareUserId: memberId,
            type: viewStatisticType,
            objectId: id,
            judge: 1,
        },
        method: "POST",
        sfn: function (data) {

        }
    });
}


function getDate(dateTimeStamp) {
    let minute = 1000 * 60;
    let hour = minute * 60;
    let day = hour * 24;
    let halfamonth = day * 15;
    let month = day * 30;


    if (dateTimeStamp === undefined) {

        return false;
    } else {
        dateTimeStamp = dateTimeStamp.replace(/\-/g, "/");

        let sTime = new Date(dateTimeStamp).getTime();//把时间pretime的值转为时间戳

        let now = new Date().getTime();//获取当前时间的时间戳

        let diffValue = now - sTime;

        if (diffValue < 0) {
            console.log("结束日期不能小于开始日期！");
        }

        let monthC = diffValue / month;
        let weekC = diffValue / (7 * day);
        let dayC = diffValue / day;
        let hourC = diffValue / hour;
        let minC = diffValue / minute;

        if (monthC >= 1) {
            return dateTimeStamp.substr(5, 5).replace(/\//g, '月') + "日";
        } else if (weekC >= 1) {
            return dateTimeStamp.substr(5, 5).replace(/\//g, '月') + "日";
        } else if (dayC >= 1) {
            return dateTimeStamp.substr(5, 5).replace(/\//g, '月') + "日";
        } else if (hourC >= 1) {
            return parseInt(hourC) + "小时前";
        } else if (minC >= 1) {
            return parseInt(minC) + "分钟前";
        } else {
            return "刚刚";
        }
    }
}

//微信授权登录
function checkShare() {
    let share = $$.getUrlParam("share");
    let memberId = $$.getUrlParam("memberId");
    let videoId = $$.getUrlParam("videoId");
    let audioId = $$.getUrlParam("audioId");
    let id;
    let type;
    if (videoId !== undefined) {
        id = videoId;
        type = 3;
    } else {
        id = audioId;
        type = 4;
    }

    if (share === 'true') {
        let url = window.location.search;
        url = url.replace("true", 'false');
        url = "newKnow/audioDetail.html" + url;
        ShawHandler.request({
            url: UrlConfig.weChat_authorize,
            pars: {
                authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                returnUrl: url,
                businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_6,
                otherParams: JSON.stringify({"objectId": id, "type": type, "memberId": memberId})
            },
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                location.href = data.datas;
            }
        });
    }
}


function shareDetailPage(shareMemberId, shareStatus) {
    if (shareMemberId != null && shareStatus === 'true') {
        //alert("获取分享页");
        $$.request({
            url: UrlConfig.member_getShareMemberInfo,
            pars: {
                memberId: shareMemberId
            },
            loading: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    $$.closeLoading();
                    if (data.datas.rname != null && data.datas.rname !== "") {
                        $(".name p").text(data.datas.rname);
                    } else {
                        $(".name p").text(data.datas.account);
                    }
                    if ((data.datas.imgPath != null) && (data.datas.imgPath !== "")) {
                        $(".head").attr("src", data.datas.imgPath);
                    } else {
                        $(".head").attr("src", "../../images/my/defaultImg.png");
                    }
                    $(".evaluate").hide();
                    $(".menu").hide();
                    $(".info").show();
                    $('.iphone').on('click', function () {
                        window.location.href = "tel:" + data.datas.phone;
                    });
                    if ($$.checkLogin()) {
                        $(".textarea").show();
                        $(".loginApp").hide();
                        $(".bottomBtn").show();
                    } else {
                        $(".textarea").hide();
                        $(".loginApp").show();
                        $(".bottomBtn").hide();
                    }
                    $('.loginApp').on('click', function () {
                        $$.push("login/login");
                    })
                } else {
                    $$.layerToast("系统出错");
                }
            }
        });
    }
}

function prevCourseItem(page) {
    let id;
    if (type === 1) {
        id = videoId;
    } else if (type === 2) {
        id = audioId;
    }
    let video = $("#video").attr("data-val");
    let audio = $("#audio").attr("data-val");
    let objId = video != null ? video : audio;
    if ($$.isValidObj(objId)) {
        $$.request({
            url: UrlConfig.courseItem_prevCourseItem,
            pars: {
                courseId: id,
                id: objId,
                page: page,//上一页 为1 下一页为2
            },
            requestBody: true,
            method: "POST",
            sfn: function (data) {
                if (data.success) {
                    if (type === 1) {
                        let Media = document.getElementById("video");
                        Media.src = data.mapList.avattachId != null ? data.mapList.avattachId : data.mapList.linkUrl; //返回或设置当前资源的URL
                        Media.load();
                        $("#video").attr("data-val", data.mapList.id)
                    } else if (type === 2) {
                        let Media = document.getElementById("audio");
                        Media.src = data.mapList.avattachId != null ? data.mapList.avattachId : data.mapList.linkUrl; //返回或设置当前资源的URL
                        Media.load();
                        $("#audio").attr("data-val", data.mapList.id)
                    }
                    $("#prev").show();
                    $("#next").show();
                    if (data.msg === 'noPrev') {
                        $("#prev").hide();
                    } else if (data.msg === 'noNext') {
                        $("#next").hide();
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            }
        });
    } else {
        $$.layerToast("暂无资源~~~")
    }
}

/*------------------------1.5版----------------------------------------*/
/**
 * 支付处理 微信支付
 */
function paymentHandler(orderId, courseId) {
    const returnUrl = encodeURIComponent('newKnow/audioDetail');
    $$.push("product/payment", {
        paymentType: 'weChatPay',
        doComplexFormType: OrderHelper.payDoComplexFormType.FORM_TYPE_10006,
        otherParams: JSON.stringify({
            orderToken: orderId,
            courseId: courseId,
            returnUrl: returnUrl,
            successPayUrl: returnUrl
        })
    });
}

/**
 * 描述信息：发起支付
 * @author 覃创斌
 * @date 2020/4/10
 */
function gotoBuyVip(courseId) {
    $$.request({
        url: UrlConfig.member_pay_insertSubjectPay,
        pars: {
            courseId: courseId,
            productType:0
        },
        loading: true,
        requestBody: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                const orderId = data.payId;
                paymentHandler(orderId, courseId);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

//递归请求查询支付状态
function loop(orderToken, loopIndex = 0) {
    loopIndex++;
    $$.request({
        url: UrlConfig.member_pay_getSubjectPayById,
        pars: {id: orderToken},
        sfn: function (data) {
            if (data.success) {
                const payStatus = data.payStatus;
                if (payStatus === 1) {
                    $$.closeLoading();
                    $$.alert("支付成功！");
                } else if (payStatus === 0) {
                    //-- 待支付状态
                    if (loopIndex >= 10) {
                        $$.closeLoading();
                        $$.alert("似乎没支付成功！");
                    } else {
                        setTimeout(function () {
                            loop(orderToken, loopIndex);
                        }, 1000);
                    }
                } else {
                    $$.closeLoading();
                    $$.alert("支付失败！");
                }
            } else {
                $$.closeLoading();
            }
        }
    });
}

// 课堂详情
function CourseDetailsList() {
    $$.request({
        url: UrlConfig.course_getCourseDetailsList,
        pars: {
          id:videoId
        },
        requestBody: true,
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                if (data.courseItem.length > 1){
                    $(".space-around").removeClass("courseIntroTitle");
                    let videoHtml = "";
                    for (let i = 0; i < data.courseItem.length; i++) {
                        videoHtml +=`<li class="flex-start"  data-id="`+data.courseItem[i].id+`">
                                        <img src="../../images/know/videoDirectory.png">
                                        <span>0`+(i+1)+`</span>
                                        <span class="overflow">`+data.courseItem[i].cname+`</span>
                                    </li>`
                    }
                    $("#videoList").html(videoHtml);
                    $(".flex-start").click(function () {
                        courseItemId = $(this).attr("data-id");
                       if (payStatus == -1 || payStatus == 1 ){
                           $$.request({
                               url: UrlConfig.courseItem_getByCourseItemId,
                               pars: {
                                   id: courseItemId
                               },
                               method: "POST",
                               sfn: function (courseItemData) {
                                   $("#video").attr("src", courseItemData.courseItem.linkUrl);
                                   $("#video").attr("data-val", courseItemData.courseItem.linkUrl);
                                   $("title").html(courseItemData.courseItem.cname);
                                   $("#title").html(courseItemData.courseItem.cname);
                                   //回到顶部
                                   let scrollToTop = window.setInterval(function() {
                                       let pos = window.pageYOffset;
                                       if ( pos > 0 ) {
                                           window.scrollTo( 0, pos - 20 ); // how far to scroll on each step
                                       } else {
                                           window.clearInterval( scrollToTop );
                                       }
                                   }, 16); // how fast to scroll (this equals roughly 60 fps)
                               }
                           })
                       }else {
                           $$.alert("您还没购买本套课程，请购买后播放！")
                       }
                    })
                }else {
                    $(".space-around").addClass("courseIntroTitle");
                }
                $("#title").html(data.course.title);
                $("title").html(data.course.title);
                $("#lecturer").html(data.course.speaker);
                $("#Play").html(data.course.pcount + '次');
                $("#time").html(data.course.createTime);
                $("#content").html(data.txtattachPath);
                updatePlay(data.course.id, data.course.pcount);
                unmemberPrice = data.course.unmemberPrice;
                if (unmemberPrice != 0){
                    $(".freeStudy").html("购买学习￥"+unmemberPrice);
                }else {
                    $(".freeStudy").html("免费学习");
                }

                $("#video").attr("poster",data.listImg);

                if ($$.checkLogin()){
                    videoOrAudio();
                }

                let topHtml = "";
                if (data.top3 != undefined){
                    for (let i = 0; i < data.top3.length; i++) {
                        if (data.top3[i].unmemberPrice > 0){
                            topHtml +=` <li class="topVideo" data-id="`+data.top3[i].id+`">
                                    <div class='left'>
                                        <img class="img img1" src="`+data.top3[i].listImgPath+`">
                                        <div class='label'>`+(data.top3[i].label == undefined ? "" : data.top3[i].label)+`</div>
                                    </div>
                                    <div class="right">
                                        <h3 class='overflow'>`+data.top3[i].title+`</h3>
                                        <div class="content overflow"></div>
                                        <div class='bottomLabel space-between'>
                                            <div><span class='fontThemeColor'>￥`+data.top3[i].unmemberPrice+`</span><span class='strikethrough originalPrice'>￥`+(data.top3[i].originalPrice == undefined ? 0 : data.top3[i].originalPrice)+`</span></div>
                                            <div class='videoStatistics'><span>`+data.top3[i].count+`</span>人购买</div>
                                        </div>
                                    </div>
                                </li>`
                        }else {
                            topHtml +=` <li  class="topVideo" data-id="`+data.top3[i].id+`">
                                    <div class='left'>
                                        <img class="img img1" src="`+data.top3[i].listImgPath+`">
                                        <div class='label'>`+(data.top3[i].label == undefined ? "" : data.top3[i].label)+`</div>
                                    </div>
                                    <div class="right">
                                        <h3 class='overflow'>`+data.top3[i].title+`</h3>
                                        <div class="content overflow"></div>
                                        <div class='bottomLabel space-between'>
                                            <div><span class='fontThemeColor'>免费</span></div>
                                            <div class='videoStatistics'><span>`+data.top3[i].count+`</span>人学习</div>
                                        </div>
                                    </div>
                                </li>`
                        }
                        $(".item").html(topHtml);
                        $(".topVideo").click(function () {
                            let id = $(this).attr("data-id");
                            $$.push('../pages/newKnow/audioDetail',{
                                videoId:id
                            });
                        })
                    }
                }else {
                    $(".courseTop").hide()
                }

                weChatShare();              // 分享配置
            } else {
                $$.layerToast(`${data.msg}`);
            }
        }
    });
}

/**
 * 分享处理(APP和H5)
 * @Author 吴成林
 * @Date 2020-5-15 11:31:25
 */
function shareHandler(){
    if(PAGE_APP){
        //-- APP
        const { shareDatums } = PAGE_STATE;

        const params = {bussType: 10001, ...shareDatums};
        $$.postAPP(10002, params);
    }else{
        //-- 分享
        $$.showShareView('点击右上角，分享课堂视频~');
    }
}

/**
 * 分享
 * @Author 吴成林
 * @Date 2020-5-15 11:36:31
 */
function weChatShare(){
    if (!$WeChat.isWx() && !PAGE_APP) {
        return;
    }

    let _imgUrl = $("#video").attr("poster");
    let _title = $("#title").html();
    //let shareUrl = window.location.href + "&share=true&memberId=" + data.memberId;

    let _lineLink = $$.getFullHost() + '/src/pages/newKnow/audioDetail.html';
    /* 是否带参 */
    _lineLink += $$.jsonToUrlParams({
        share: true,
    });

    PAGE_STATE.shareDatums.url = _lineLink;      //-- 保存分享参数 - 路径
    PAGE_STATE.shareDatums.image = _imgUrl;      //-- 保存分享参数 - 图片
    PAGE_STATE.shareDatums.title = _title;       //-- 保存分享参数 - 标题
    const { content } = PAGE_STATE.shareDatums;

    weChatJSTool.share({
        _imgUrl: _imgUrl,
        _lineLink: _lineLink,
        _shareTitle: _title,
        _descContent: content,
        _sfn: function () {
            check();
            countAction("xb_2013");
            if (videoId !== undefined) $$.share(videoId, 5);
        }
    });
}