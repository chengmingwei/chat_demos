let classifyList;                   // 课堂分类缓存列表
let classifyId;                     // 课堂分类ID
let timeType = 1;                   // 上传时间（1：最新，2：最早）
let offset = 1;                     // 分页页数
let pageSize = 10;                  // 分页每页加载数量
let loadedState = true;             // 分页加载状态（数据长度小于pageSize => false）
window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_19', null);
    } catch (error) {
        console.log(error);
    }
    if (!$$.checkLogin()) {
        ShawHandler.gotoLogin();
    }

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        classifyId = $$.getUrlParam("classified") ;
        //-- 默认加载最新全部
        getCourseList(timeType, classifyId);
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 标题切换
        $(".tab>li").on("click",function(){
            $(this).siblings().children('div').removeClass('fontThemeColor');
            $(this).children('div').addClass('fontThemeColor');

            $(this).siblings().find("span.down").removeClass('themeDownward').addClass('downward');
            $(this).find("span.down").removeClass('downward').addClass('themeDownward');
            let value = $(this).attr('data-value');
            if (value == '1'){
                $$.isValidObj(classifyList)?picker(1, classifyList):getLabelList();
            } else {
                let uploadTimeList = [{label:'最新', value: 1},{label:'最早', value: 2}]
                picker(2, uploadTimeList);
            }
        });

        //-- 加载课程分类列表
        function getLabelList() {
            $$.request({
                url: UrlConfig.course_getClassClassification,
                pars: {
                    classifyId:2
                },
                loading:true,
                method: "POST",
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        data.datas = data.datas.map((item, index) => {
                            const {id, labelName} = item;
                            return {label: labelName, value: id};
                        });
                        classifyList = data.datas;
                        picker(1, classifyList);
                    } else {
                        $$.layerToast("暂无分类");
                    }
                }
            });
        }

        //-- 页面滚动事件监听
        $(window).scroll(function () {
            if (loadedState){
                if ($(window).scrollTop() == $(document).height() - $(window).height()) {
                    if($(".pageLoading").size() > 0){
                        return;
                    }

                    $(".section>.item").append(`<p class="pageLoading" style="text-align: center;font-size: 14px;margin: 15px 0px;">加载中...</p>`);
                    offset = offset + 1;
                    let value = $$.isValidObj(classifyId)?classifyId:null;
                    getCourseList(timeType, value, function(){
                        $(".pageLoading").remove();
                    });
                }
            }
        });

    }

    //-- 选择器
    function picker(id, data) {
        weui.picker(data, {
            id: id,
            defaultValue: [data[0].value],
            onConfirm: function(result) {
                if (id == 1){
                    offset = 1;
                    pageSize = 10;
                    $(window).scrollTop(0);
                    $('.classify').text(result[0].label);
                    classifyId = result[0].value;
                    getCourseList(timeType, result[0].value);
                } else{
                    offset = 1;
                    pageSize = 10;
                    $(window).scrollTop(0);
                    $('.uploadTime').text(result[0].label);
                    timeType = result[0].value;
                    let value = $$.isValidObj(classifyId)?classifyId:null;
                    getCourseList(timeType, value);
                }
                return result;
            }
        });
    }

    //-- 加载视频
    function getCourseList(latest, classified, overCallback) {
        $$.request({
            url: UrlConfig.course_getCourseList,
            pars: {
                ctype:1,
                obCt:latest,
                isenabled:1,
                classified:classified,
                _current:offset,
                _pageSize:pageSize
            },
            requestBody: true,
            method: "POST",
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (data.datas.list.length === 0){
                        $(".item").html("");
                        $$.showNoResultView(".section");
                    } else{
                        $$.hideNoResultView();
                        loadContent(data, overCallback);
                    }
                } else {
                    $$.layerToast(`获取失败！[${data.msg}]`);
                }
            }
        });
    }

    //-- 内容加载
    function loadContent(data, overCallback) {
        try {
            const list = data.datas.list;
            let resultHtml = "";
            console.log(data);
            for (let i = 0; i < list.length; i++) {
                if ($$.isValidObj(list[i])){
                    let freeHtml = "";
                    if(list[i].unmemberPrice > 0){
                        <!-- 收费版 -->
                        freeHtml = `<div><span class='fontThemeColor'>￥`+list[i].unmemberPrice+`</span><span class='strikethrough originalPrice'>￥`+(list[i].originalPrice == undefined ? 0 : list[i].originalPrice)+`</span></div>
                                    <div class='videoStatistics'><span>`+list[i].payCount+`</span>人购买</div>`;
                    }else{
                        <!-- 免费版 -->
                        freeHtml = `<div><span class='fontThemeColor'>免费</span></div>
                                    <div class='videoStatistics'><span>`+list[i].payCount+`</span>人学习</div>`;
                    }
                    resultHtml += `
                        <li onclick='jumpCourseVideo(${list[i].id})'>
                            <div class='left'>
                                <img class="img img1" src="${list[i].filePath}">
                                <div class='label'>`+(list[i].label === undefined ? "" : list[i].label)+`</div>
                            </div>
                            <div class="right">
                                <h3 class='overflow'>${list[i].title}</h3>
                                <div class="content overflow">${list[i].intro === undefined ? "" : list[i].intro}</div>
                                <div class='bottomLabel space-between'>
                                    ${freeHtml}
                                </div>
                            </div>
                        </li>
                    `;
                }
            }
            if (offset === 1){
                $(".item").html(resultHtml);
            } else {
                $(".item").append(resultHtml);
            }
            const pagination = data.datas.pagination;
            const total = pagination.total;
            const current = pagination.current;
            const totalPage = parseInt(total / pageSize) + (total % pageSize > 0 ? 1 : 0);
            loadedState = current < totalPage;
        } catch (e) {
            console.error(e);
        } finally {
            if (overCallback) overCallback();
        }
    }
};

//-- 跳转课程详情
function jumpCourseVideo(id) {
    $$.push('newKnow/audioDetail',{
        videoId:id
    })
}

