let labelIds = new Array();
window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('51', null);
    } catch (error) {
        console.log(error);
    }
    $$.changeVersion();
    /**
     * 一级菜单切换
     */

    //点击问答
    $('#xl-tab-head-title-2').off().click(function () {
        $$.push('know/answers');
    });

    //点击课堂
    $('#xl-tab-head-title-3').off().click(function () {
        /*$$.push('know/classRoom');*/
        $$.push('newKnow/classRoom');
    });

    // 我的学习
    $(".headLogo").off().click(function () {
        //数据统计
        try {
            countAction('xb_59', null);
        } catch (error) {
            console.log(error);
        }
        window.location.href = '../../pages/know/myLearn.html'
    });

    // 更多精品
    $(".moreVideo").off().click(function () {

        //数据统计
        try {
            //countAction('xb_56', null);
        } catch (error) {
            console.log(error);
        }
        $$.push("newKnow/courseList");
    });

    //点击更多音频
    $(".moreAudio").off().click(function () {
        $$.push("know/courseList",{
            type:"Audio"
        });
    });


    // 底部菜单
    let oBtn = document.getElementById("menu");
    let uLi = oBtn.getElementsByTagName("a");
    let n = uLi.length;
    for (let i = 0; i < n; i++) {
        uLi[i].index = i;
        uLi[i].addEventListener("touchend", function () {
            for (let j = 0; j < n; j++) {
                uLi[j].className = "";
            }
            this.className = "active";
        }, false)
    }

    //-- 跳转自动绑定
    $$.staticPushAutoBind();
    if (!$$.checkLogin()){
        $$.gotoLogin();
    }
    //加载课堂
    loadClassify();

};

/**
 * 描述信息：加载分类
 * @author 覃创斌
 * @date 2019-09-10
 */
function loadClassify() {
    $$.request({
        url: UrlConfig.classify_list,
        pars:{
            state:1
        },
        method: "POST",
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                let resultHtml = ``;
                let infoHtml = ``;
                for (let i = 0; i < data.datas.length; i++) {
                    if (i == 0) {
                        resultHtml += `<div class="swiper-slide selected" data-val=${data.datas[i].id} style='width: auto; min-width: 50px;'>${data.datas[i].classifyName}</div>`;
                        loadSubject(data.datas[i].id);
                        //informationList(data.datas[i].id);
                        // swiper2 swiper-container swiperContent swiper-container-fade swiper-container-horizontal swiper-container-autoheight swiper-container-ios
                    } else {
                        resultHtml += `<div class="swiper-slide" data-val=${data.datas[i].id}>${data.datas[i].classifyName}</div>`;
                        infoHtml += `<div class="swiper-slide swiper-no-swiping">${data.datas[i].classifyName+"内容"}</div>`;
                    }
                }
                //console.log(infoHtml);
                $("#ClassifyList").append(resultHtml);
                //$("#classifyMenu").append(infoHtml);
            } else {
                $$.layerToast(`获取分类失败！[${data.msg}]`);
            }
        }
    });
}


/**
 * 描述信息：加载js
 * @author 覃创斌
 * @date 2019-09-10
 */
function loadScript(src, callback) {
    let script = document.createElement('script'),
        head = document.getElementsByTagName('head')[0];
    script.type = 'text/javascript';
    script.charset = 'UTF-8';
    script.src = src;
    if (script.addEventListener) {
        script.addEventListener('load', function () {
            callback();
        }, false);
    } else if (script.attachEvent) {
        script.attachEvent('onreadystatechange', function () {
            let target = window.event.srcElement;
            if (target.readyState == 'loaded') {
                callback();
            }
        });
    }
    head.appendChild(script);
}


/**
 *加载tabSwiper文件
 */
function loadRes(){
    loadScript("../../js/newKnow/tabSwiper.js", function () {})
}

/**
 * 描述信息：资讯--默认加载专题 -- CSS已被隐藏
 * @author 覃创斌
 * @date 2019-09-10
 */
function loadSubject(id) {
    let resultHtml = ``;
    resultHtml += `<div class="swiper-slide swiper-no-swiping">
                   <div style="width: 100%;height: 100%;background-color: #f2f4f7;">
                   <div class="part1">
                   <div class="part1-top">
                   <ul id="subjectList">`;
    resultHtml += `</ul>
                   </div>
                   </div>
                   </div>
                   </div>`;
    loadRes();
    $("#classifyMenu").html(resultHtml);
    setTimeout(informationList(id),1000);
    return;
    //暂时不使用
    // $$.request({
    //     url: UrlConfig.getByClassifyIdList,
    //     pars: {
    //         _classifyId: id
    //     },
    //     method: "POST",
    //     loading: true,
    //     sfn: function (data) {
    //         if (data.success) {
    //             $$.closeLoading();
    //             let resultHtml = ``;
    //             resultHtml += `<div class="swiper-slide swiper-no-swiping">
    //                            <div style="width: 100%;height: 100%;background-color: #f2f4f7;">
    //                            <div class="part1">
    //                            <div class="part1-top">
    //                            <ul id="subjectList">`;
    //              for (let i = 0; i < data.datas.length; i++) {
    //                  if (i == 0) {
    //                      resultHtml += `<li class="left" onclick='jumpSubject(${data.datas[i].id})'>
    //                                     <a href="javascript:;" style=background-image:url(${data.datas[i].coverImgUrl})>
    //                                     <span class="title">${data.datas[i].coverTitle}</span>
    //                                    <span class="specialIcon">专题</span>
    //                                    </a>
    //                                     </li>`;
    //                  } else {
    //                     resultHtml += `<li class="right" onclick='jumpSubject(${data.datas[i].id})'>
    //                                     <a href="javascript:;" style=background-image:url(${data.datas[i].coverImgUrl})>
    //                                     <span class="title\">${data.datas[i].coverTitle}</span>
    //                                     <span class="specialIcon\">专题</span>
    //                                     </a>
    //                                     </li>`;
    //                  }
    //              }
    //             resultHtml += `</ul>
    //                            </div>
    //                            </div>
    //                            </div>
    //                            </div>`;
    //             loadRes();
    //             $("#classifyMenu").html(resultHtml);
    //             return resultHtml;
    //         } else {
    //             $$.layerToast(`获取资讯专题失败！[${data.msg}]`);
    //         }
    //     }
    // });
}

//截取字符串的长度
function cutString(str, len) {
    //length属性读出来的汉字长度为1
    if (str != undefined){
        if(str.length*2 <= len) {
            return str;
        }
        let strlen = 0;
        let s = "";
        for(let i = 0;i < str.length; i++) {
            s = s + str.charAt(i);
            if (str.charCodeAt(i) > 128) {
                strlen = strlen + 2;
                if(strlen >= len){
                    return s.substring(0,s.length-1) + "...";
                }
            } else {
                strlen = strlen + 1;
                if(strlen >= len){
                    return s.substring(0,s.length-2) + "...";
                }
            }
        }
        return s;
    }else {
        return  "";
    }
}

/**
 * 描述信息：加载资讯列表 --- (label)
 * @author 覃创斌
 * @date 2019-09-11
 */
function informationList(id) {
    $$.request({
        url: UrlConfig.getWebInformaList,
        pars: {
            classifyId: id
        },
        method: "POST",
        sfn: function (data) {
            if (data.success) {
                //console.log("实现getWebInformaList函数");
                let z = data.articleList.length + data.videoList.length;
                let articleIndex = 0, articleLen = 0, videoIndex = 0, videoLen = 0;
                let resultHtml = ``;
                let s = 0;
                if (data.articleList.length > 0) {
                    articleLen = data.articleList.length;
                }
                if (data.videoList.length > 0) {
                    videoLen = data.videoList.length;
                }
                //文章长度比视频长度
                if (data.articleList.length > data.videoList.length) {
                    for (let i = 0; i < data.articleList.length; i++) {
                        resultHtml += ` <div class="part3" onclick='jumpArticleDetails(${data.articleList[i].id})'>
                                            <div class="item">
                                            <div class="left">
                                            <p class="overflow">${data.articleList[i].title}</p>
                                            <div class="label">
                                            <span class="icon">${data.articleList[i].classifyname}</span>
                                            <div class="commentWrap">
                                            <span class="comment"></span><span class="commentNum">${data.articleList[i].ecount < 999 ? data.articleList[i].ecount : "999+"}</span>
                                            </div>
                                            <div class="eyesWrap">
                                            <span class="eyes"></span><span class="eyesNum">${data.articleList[i].vscount < 999 ? data.articleList[i].vscount : "999+"}</span>
                                            </div>
                                            </div>
                                            </div>
                                            <div class="right">
                                            <a href="javascript:;" style=background-image:url(${data.articleList[i].coverimgurl})></a>
                                            </div>
                                            </div>
                                            </div>`;
                        if (i > 0 && (i + 1) % 2 == 0) {
                            if (videoIndex < videoLen) {
                                resultHtml += ` <div class="part2" onclick='jumpVideoDetails(${data.videoList[videoIndex].id})'>
                                                    <h3>${data.videoList[videoIndex].title}</h3>
                                                    <div class="img img1" style='position: relative;'>
                                                    <img id='coverImgUrl' style='height: 200px' src=${data.videoList[videoIndex].coverImgUrl} />
                                                    <img style='height: 40px; width: 40px; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);' src='../../images/know/information/ico_play.png' />
                                                    </div>
                                                    <div class="label">
                                                    <span class="icon">${data.videoList[videoIndex].classifyname}</span>
                                                    <div class="commentWrap">
                                                    <span class="comment"></span><span class="commentNum">${data.articleList[videoIndex].ecount < 999 ? data.articleList[videoIndex].ecount : "999+"}</span>
                                                    </div>
                                                    <div class="eyesWrap">
                                                    <span class="eyes"></span><span class="eyesNum">${data.articleList[videoIndex].vscount < 999 ? data.articleList[videoIndex].vscount : "999+"}</span>
                                                    </div>
                                                    </div>
                                                    </div>`;
                            }
                            videoIndex++;
                        }
                    }
                } else if (data.videoList.length > data.articleList.length) {
                    for (let i = 0; i < data.videoList.length; i++) {
                        resultHtml += ` <div class="part2" onclick='jumpVideoDetails(${data.videoList[i].id})'>
                                            <h3>${data.videoList[i].title}</h3>
                                            <div class="img img1" style='position: relative;'>
                                            <img id='coverImgUrl' style='height: 200px' src=${data.videoList[i].coverImgUrl}' />
                                            <img style='height: 40px; width: 40px; position: absolute; left: 50%; top: 50%; transform: translate(-50%, -50%);' src='../../images/know/information/ico_play.png' />
                                            </div>
                                            <div class="label">
                                            <span class="icon">${data.videoList[i].classifyname}</span>
                                            <div class="commentWrap">
                                            <span class="comment"></span><span class="commentNum">${data.articleList[i].ecount < 999 ? data.articleList[i].ecount : "999+"}</span>
                                            </div>
                                            <div class="eyesWrap">
                                            <span class="eyes"></span><span class="eyesNum">${data.articleList[i].vscount < 999 ? data.articleList[i].vscount : "999+"}</span>
                                            </div>
                                            </div>
                                            </div>`;
                        if (i > 0 && (i + 1) % 2 == 0) {
                            if (articleIndex < articleLen) {
                                resultHtml += ` <div class="part3" onclick='jumpArticleDetails(${data.articleList[articleIndex].id})'>
                                                    <div class="item">
                                                    <div class="left">
                                                    <p class="overflow">${data.articleList[articleIndex].title}</p>
                                                    <div class="label">
                                                    <span class="icon">${data.articleList[articleIndex].classifyname}</span>
                                                    <div class="commentWrap">
                                                    <span class="comment"></span><span class="commentNum">${data.articleList[articleIndex].ecount < 999 ? data.articleList[articleIndex].ecount : "999+"}</span>
                                                    </div>
                                                    <div class="eyesWrap">
                                                    <span class="eyes"></span><span class="eyesNum">${data.articleList[articleIndex].vscount < 999 ? data.articleList[articleIndex].vscount : "999+"}</span>
                                                    </div>
                                                    </div>
                                                    </div>
                                                    <div class="right">
                                                    <a href="javascript:;" style=background-image:url(${data.articleList[articleIndex].coverimgurl})></a>
                                                    </div>
                                                    </div>
                                                    </div>`;
                            }
                            articleIndex++;
                        }
                    }
                }
                $("#classifyMenu>div>div").append(resultHtml);
                // loadRes();
                // return resultHtml;
            } else {
                $$.layerToast(`获取资讯列表失败！[${data.msg}]`);
            }
        }
    });
}


//跳转专题
function  jumpSubject(id) {
    $$.push("know/specialTopicDetail",{
        id:id
    });
}

//跳转文章详情
function  jumpArticleDetails(id) {
    $$.push("newKnow/articleDetails",{
        id:id
    });
}

//跳转视频详情
function  jumpVideoDetails(id) {
    $$.push("know/MsgvideoDetail",{
        id:id
    });
}

//跳转远程课程视频
function jumpCourseVideo(id) {
    $$.push('../pages/newKnow/audioDetail',{
        videoId:id
    })
}

//跳转音频详情
function jumpCourseAudio(id) {
    $$.push('../pages/newKnow/audioDetail',{
        audioId:id
    })
}


/**
 * 描述信息：问答 --- 加载问答分类标签
 * @author 覃创斌
 * @date 2019-09-17
 */
function loadLabel() {
    $$.request({
        url: UrlConfig.getLabelList,
        method: "POST",
        pars: {
            classifyId:1,
        },
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                var resultHtml = "";
                let infoHtml = "";
                for (let i = 0; i < data.datas.length; i++) {
                    if (i == 0) {
                        resultHtml += `<div class="swiper-slide selected" data-val=${data.datas[i].id}>${data.datas[i].labelName}</div>`;
                        loadLabelById(data.datas[i].id);
                        informationList(data.datas[i].id);
                    } else {
                        resultHtml += `<div class="swiper-slide" data-val=${data.datas[i].id}>${data.datas[i].labelName}</div>`;
                        infoHtml += `<div class="swiper-slide swiper-no-swiping">${data.datas[i].labelName + "内容"}</div>`;
                    }
                }
                //  $("#classifyMenu").append(infoHtml);
                //loadRes();
                $("#label").append(resultHtml);

            } else {
                $$.layerToast(`获取问答分类失败！[${data.msg}]`);
            }
        }
    });
}


/**
 * 描述信息：问答---默认加载分类
 * @author 覃创斌
 * @date 2019-09-10
 */
function loadLabelById(id) {
    $$.request({
        url: UrlConfig.getWebWenDaList,
        pars: {
            id: id
        },
        method: "POST",
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                let resultHtml = ``;
                resultHtml += `<div class="swiper-slide swiper-no-swiping">
                               <ul class="content_ul" id="LabelList">`;
                for (let i = 0; i < data.datas.length; i++) {
                    resultHtml += `<li>
                                   <div  key=${data.datas[i].creatorId}  data-val=${data.datas[i].qid}>
                                   <h3>${data.datas[i].questionContent}</h3>`;
                    //判断是否为匿名发表
                    if (data.datas[i].isAnonymous == 1){
                        resultHtml += `<div class="message">
                                       <div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                       <span class="name">匿名</span>
                                       <span class="date">${data.datas[i].answerDate}</span>
                                       </div>`;
                    }else {
                        resultHtml += `	<div class="message">`;
                        //判断是否设置过昵称
                        if("" == data.datas[i].rname || null == data.datas[i].rname){

                            //判断是否设置过头像
                            if("" == data.datas[i].imgPath || null == data.datas[i].imgPath){

                                //判断account字段是否为空
                                if("" == data.datas[i].account || null == data.datas[i].account){
                                    resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                                   <span class="name" style="color: #ff7052;">侵入者</span>`;
                                }else{
                                    resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                           <span class="name">${data.datas[i].account}</span>`;
                                }

                            }else{
                                resultHtml += `<div class="headImg"><img src=${data.datas[i].imgPath}></div>
                                               <span class="name">${data.datas[i].account}</span>`;
                            }
                        }else{

                            if("" == data.datas[i].imgPath || null == data.datas[i].imgPath){
                                resultHtml += `<div class="headImg"><img src="../../images/my/mituLogo.png"></div>
                                                   <span class="name">${data.datas[i].rname}</span>`;
                            }else{
                                resultHtml +=
                                    `<div class="headImg"><img src=${data.datas[i].imgPath}></div>
                                     <span class="name">${data.datas[i].rname}</span>`;
                            }
                        }
                        resultHtml += `		<span class="date">${data.datas[i].answerDate}</span>
                                    	</div>`;
                    }

                    resultHtml += `	<p class="content">${cutString(data.datas[i].answerContent,100)}</p>
                                    <div class="label">
                                    <span class="icon icon2">${data.datas[i].labelName}</span>
                                    <div class="commentWrap">
                                    <span class="comment"></span><span class="commentNum">${data.datas[i].answer < 999 ? data.datas[i].answer : "999+"}</span>
                                    </div>
                                    <div class="eyesWrap">
                                    <span class="eyes"></span><span class="eyesNum">${data.datas[i].browse < 999 ? data.datas[i].browse : "999+"}</span>
                                    </div>
                                    </div>
                                    </div>`;

                    if (data.datas[i].count == 0){
                        resultHtml +=  `<button class="follow" data-val=${data.datas[i].qid} style="background: #5677fc">关注</button>`;
                    }else {
                        resultHtml += `<button class="follow" data-val=${data.datas[i].qid} style="background: #C0C0C0">已关注</button>`;
                    }
                    resultHtml += `</li>`;
                }
                resultHtml += `</ul>
                               </div>`;


                $("#labelMenu").html(resultHtml);

                //loadScript("../../js/know/tabSwiper.js", function () {});

                $(".follow").off().on("click",function(){
                    let id = $(this).attr("data-val");
                    let content = $(this).text();
                    if (content === "关注"){
                        $(this).text("已关注");
                        $(this).css("background", "#C0C0C0");
                        $$.request({
                            url: UrlConfig.focusquestion_insertData,
                            loading: true,
                            pars:{
                                questionId:id
                            },
                            requestBody:true,
                            sfn: function (data) {
                                $$.closeLoading();
                                if (data.success) {
                                    $$.layerToast("关注成功")
                                } else {
                                    $$.layerToast(data.msg);
                                }
                            },
                            ffn: function (data) {
                                $$.errorHandler();
                            }
                        });
                    } else {
                        $(this).text("关注");
                        $(this).css("background", "#5677fc");
                        $$.request({
                            url: UrlConfig.focusquestion_cancelFocus,
                            pars: {
                                questionId:id
                            },
                            requestBody:true,
                            sfn: function(data){
                                if (data.success) {
                                    $$.layerToast("取消关注")
                                } else {
                                    $$.layerToast(data.msg);
                                }
                            },
                            ffn: function (data) {
                                $$.errorHandler();
                            }
                        });
                    }
                });
                $("#LabelList > li > div").on("click",function(){
                    let id = $(this).attr("data-val");
                    $$.push("know/questionDetail",{
                        questionId:id
                    })
                });

                //loadRes();

                return resultHtml;
            } else {
                $$.layerToast(`获取问答分类失败！[${data.msg}]`);
            }
        }
    });
}


/**
 * 轮播图加载
 */
function  getBanner() {
    $$.request({
        url: UrlConfig.AppHomePic_getPicList,
        pars: {
            //-- 类型 0-app 1-微信公众号H5首页 2-课堂首页 3-积分活动图
            type: 2,
            isenabled: 1
        },
        requestBody: true,
        method: "POST",
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                let html = ``;
                for(let x in data.datas){
                    let url = $$.imageUrlCompatible(data.datas[x].picUrl);
                    let adUrl = data.datas[x].adUrl;
                    if ($$.isValidObj(adUrl)) {
                        adUrl = ' htmlUrl="' + adUrl + '"';
                    } else {
                        adUrl = '';
                    }
                    html += `<div class="swiper-slide"${adUrl}><img src='${url}'/></div>`;
                }
                $("#swiperClassroom").html(html);

                //-- 初始化轮播组件
                new Swiper('.swiperClassroom',{
                    observer: true,//修改swiper自己或子元素时，自动初始化swiper
                    observeParents: true,//修改swiper的父元素时，自动初始化swiper
                    autoplay: {
                        delay: 2500,
                        disableOnInteraction: false,
                    },
                    loop: true,
                    on:{
                        tap: function(){
                            const htmlUrl = $("#swiperClassroom .swiper-slide[data-swiper-slide-index=" + this.realIndex + "]").attr('htmlUrl');
                            if ($$.isValidObj(htmlUrl)) {
                                //数据统计
                                try {
                                    countAction('xb_55', null);
                                } catch (error) {
                                    console.log(error);
                                }
                                window.location.href = htmlUrl;
                            }
                        },
                    },
                });
                //$(".classRoomBg").css("background-image","url("+data.datas[0].picUrl+")");
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}


/**
 * 描述信息：加载课堂视频
 * @author 覃创斌
 * @date 2019/10/9
 */
function  getCourseList() {
    $$.request({
        url: UrlConfig.course_getCourseByLabelIdTop3,
        pars: {
            jingpin:"精品视频",
            baoxian:"保险小知识",
            shenghuo:"生活小常识",
        },
        requestBody: true,
        method: "POST",
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                const datasLength = data.jingpinList.length + data.shenghuoList.length + data.baoxianList.length;
                if (datasLength > 0) {
                    let resultHtml = ""; //精品视频
                    let insuranceHtml = "";         // 保险小知识
                    let liveHtml = "";              // 生活小知识
                    for (let i = 0; i < data.jingpinList.length; i++) {
                        resultHtml += "<li onclick='jumpCourseVideo("+ data.jingpinList[i].id +")'>";
                        resultHtml += "	<div class='left'>";
                        resultHtml += "	    <img class=\"img img1\" src="+ data.jingpinList[i].filePath +">";
                        resultHtml += "	    <div class='label'>"+(data.jingpinList[i].label == undefined ? "" : data.jingpinList[i].label)+"</div>";
                        resultHtml += "	</div>";
                        resultHtml += "	<div class=\"right\">";
                        resultHtml += "     <h3 class='overflow'>" + data.jingpinList[i].title + "</h3>";
                        resultHtml += "		<div class=\"content overflow\">"+data.jingpinList[i].txtAttachPath+ "</div>";
                        resultHtml += "     <div class='bottomLabel space-between'>";
                        if (data.jingpinList[i].unmemberPrice > 0){
                            resultHtml += "         <div><span class='fontThemeColor'>￥"+data.jingpinList[i].unmemberPrice+ "</span><span class='strikethrough originalPrice'>￥"+(data.jingpinList[i].originalPrice == undefined ? 0 : data.jingpinList[i].originalPrice)+ "</span></div>";
                            resultHtml += "         <div class='videoStatistics'><span>"+data.jingpinList[i].count+ "</span>人购买</div>";
                        }else {
                            resultHtml += "         <div><span class='fontThemeColor'>免费</span></div>";
                            resultHtml += "         <div class='videoStatistics'><span>"+data.jingpinList[i].count+ "</span>人学习</div>";
                        }
                        resultHtml += "     </div>";
                        resultHtml += "	</div>";
                        resultHtml += "</li>";
                        $(".competitiveProducts").next().attr("data-id",data.jingpinList[i].classified)
                    }
                    //生活
                    for (let i = 0; i < data.shenghuoList.length; i++) {
                        liveHtml += "<li onclick='jumpCourseVideo("+ data.shenghuoList[i].id +")'>";
                        liveHtml += "	<div class='left'>";
                        liveHtml += "	    <img class=\"img img1\" src="+ data.shenghuoList[i].filePath +">";
                        liveHtml += "	    <div class='label'>"+(data.shenghuoList[i].label == undefined ? "" : data.shenghuoList[i].label)+"</div>";
                        liveHtml += "	</div>";
                        liveHtml += "	<div class=\"right\">";
                        liveHtml += "     <h3 class='overflow'>" + data.shenghuoList[i].title + "</h3>";
                        liveHtml += "		<div class=\"content overflow\">"+data.shenghuoList[i].txtAttachPath+ "</div>";
                        liveHtml += "     <div class='bottomLabel space-between'>";
                        if (data.shenghuoList[i].unmemberPrice > 0){
                            liveHtml += "         <div><span class='fontThemeColor'>￥"+data.shenghuoList[i].unmemberPrice+ "</span><span class='strikethrough originalPrice'>￥"+(data.shenghuoList[i].originalPrice == undefined ? 0 : data.shenghuoList[i].originalPrice)+ "</span></div>";
                            liveHtml += "         <div class='videoStatistics'><span>"+data.shenghuoList[i].count+ "</span>人购买</div>";
                        }else {
                            liveHtml += "         <div><span class='fontThemeColor'>免费</span></div>";
                            liveHtml += "         <div class='videoStatistics'><span>"+data.shenghuoList[i].count+ "</span>人学习</div>";
                        }
                        liveHtml += "     </div>";
                        liveHtml += "	</div>";
                        liveHtml += "</li>";
                        $(".liveKnowledge").next().attr("data-id",data.shenghuoList[i].classified)
                    }

                    //保险
                    for (let i = 0; i < data.baoxianList.length; i++) {
                        insuranceHtml += "<li onclick='jumpCourseVideo("+ data.baoxianList[i].id +")'>";
                        insuranceHtml += "	<div class='left'>";
                        insuranceHtml += "	    <img class=\"img img1\" src="+ data.baoxianList[i].filePath +">";
                        insuranceHtml += "	    <div class='label'>"+(data.baoxianList[i].label == undefined ? "" :  data.baoxianList[i].label )+"</div>";
                        insuranceHtml += "	</div>";
                        insuranceHtml += "	<div class=\"right\">";
                        insuranceHtml += "     <h3 class='overflow'>" + data.baoxianList[i].title + "</h3>";
                        insuranceHtml += "		<div class=\"content overflow\">"+data.baoxianList[i].txtAttachPath+ "</div>";
                        insuranceHtml += "     <div class='bottomLabel space-between'>";
                        if (data.baoxianList[i].unmemberPrice > 0){
                            insuranceHtml += "         <div><span class='fontThemeColor'>￥"+data.baoxianList[i].unmemberPrice+ "</span><span class='strikethrough originalPrice'>￥"+(data.baoxianList[i].originalPrice == undefined ? 0 : data.baoxianList[i].originalPrice)+ "</span></div>";
                            insuranceHtml += "         <div class='videoStatistics'><span>"+data.baoxianList[i].count+ "</span>人购买</div>";
                        }else {
                            insuranceHtml += "         <div><span class='fontThemeColor'>免费</span></div>";
                            insuranceHtml += "         <div class='videoStatistics'><span>"+data.baoxianList[i].count+ "</span>人学习</div>";
                        }
                        insuranceHtml += "     </div>";
                        insuranceHtml += "	</div>";
                        insuranceHtml += "</li>";
                        console.log(data.baoxianList[i].classified)
                        $(".insuranceKnowledge").next().attr("data-id",data.baoxianList[i].classified)
                    }
                    $("#courseList").html(resultHtml);
                    $("#insuranceList").html(insuranceHtml);
                    $("#liveList").html(liveHtml);
                    $('.videoSection').show();
                } else {
                    $('.videoSection').hide();
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}

function getIndexLabelTop() {
    $$.request({
        url: UrlConfig.label_webSearchLabelList,
        pars: {
            state:1,
            classifyId:2,
            isIndexShow:1
        },
        sfn: function(data){
            let html = "";
            for (let i = 0; i < data.datas.length ; i++) {
                html += "<div class=\"section videoSection\">";
                html += "	<p class=\"top\">";
                html += "		<span class=\"icon competitiveProducts\">"+data.datas[i].labelName+"</span>";
                html += "		<span class=\"more moreVideo\" data-id='"+data.datas[i].id+"'>...</span>";
                html += "	</p>";
                html += "	<ul class=\"item\" id=\"courseList\">";
                for (let j = 0; j < data.datas[i].courseList.length; j++) {
                    html += "<li onclick='jumpCourseVideo("+ data.datas[i].courseList[j].id +")'>";
                    html += "	<div class='left'>";
                    html += "	    <img class=\"img img1\" src="+ data.datas[i].courseList[j].filePath +">";
                    html += "	    <div class='label'>"+(data.datas[i].courseList[j].label == undefined ? "" :  data.datas[i].courseList[j].label )+"</div>";
                    html += "	</div>";
                    html += "	<div class=\"right\">";
                    html += "     <h3 class='overflow'>" + data.datas[i].courseList[j].title + "</h3>";
                    html += "		<div class=\"content overflow\">"+data.datas[i].courseList[j].txtAttachPath+ "</div>";
                    html += "     <div class='bottomLabel space-between'>";
                    if (data.datas[i].courseList[j].unmemberPrice > 0){
                        html += "         <div><span class='fontThemeColor'>￥"+ data.datas[i].courseList[j].unmemberPrice+ "</span><span class='strikethrough originalPrice'>￥"+(data.datas[i].courseList[j].originalPrice == undefined ? 0 : data.datas[i].courseList[j].originalPrice)+ "</span></div>";
                        html += "         <div class='videoStatistics'><span>"+ data.datas[i].courseList[j].count+ "</span>人购买</div>";
                    }else {
                        html += "         <div><span class='fontThemeColor'>免费</span></div>";
                        html += "         <div class='videoStatistics'><span>"+data.datas[i].courseList[j].count+ "</span>人学习</div>";
                    }
                    html += "     </div>";
                    html += "	</div>";
                    html += "</li>";
                }
                html +=  "</ul>";
                html += "</div>";
            }
            $("#courseTop").append(html);
            $("#courseTop").append("<div class=\"bottomPrompt\">哎呀呀，我是有底线滴！</div>");
            //视频
            $(".moreVideo").click(function () {
                $$.push("newKnow/courseList",{
                    classified:$(this).attr("data-id")
                });
            });
        }
    });
}
/**
 * 描述信息：加载课堂音频
 * @author 覃创斌
 * @date 2019/10/9
 */
function  getCourseAudioList() {
    $$.request({
        url: UrlConfig.course_getKnowClassList,
        pars: {
            ctype:2,
            isenabled:1,
            offset:0,
            pageSize:3
        },
        requestBody: true,
        method: "POST",
        loading: true,
        sfn: function (data) {
            if (data.success) {
                $$.closeLoading();
                const datasLength = data.datas.length;
                if (datasLength > 0) {
                    let resultHtml = "";
                    for (let i = 0; i < datasLength ; i++) {
                        if (i <= 2){
                            let content;
                            resultHtml += "<li onclick='jumpCourseAudio("+ data.datas[i].id +")'>";
                            resultHtml += "	<span class=\"img img1\" style=background-image:url(" + data.datas[i].filePath + " no-repeat)>";
                            //   resultHtml += "		<span class=\"audioPlay\">30:00</span>";
                            resultHtml += "	</span>";
                            resultHtml += "	<div class=\"right\">";
                            resultHtml += "		<h3>" + data.datas[i].title + "</h3>";
                            resultHtml += "		<p class=\"content\">"+data.datas[i].txtattachPath.substring(0,8)+"...</p>";
                            resultHtml += "		<div class=\"label\">";
                            // resultHtml += "			<span class=\"icon icon2\">保险</span>";
                            resultHtml += "			<div class=\"commentWrap\">";
                            resultHtml += `				<span class="comment"></span><span class="commentNum">${data.datas[i].count <= 999 ? data.datas[i].count : "999+"}</span>`;
                            resultHtml += "			</div>";
                            resultHtml += "			<div class=\"eyesWrap\">";
                            resultHtml += `				<span class="eyes"></span><span class="eyesNum">${data.datas[i].pcount <= 999 ? data.datas[i].pcount : "999+"}</span>`;
                            resultHtml += "			</div>";
                            resultHtml += "		</div>";
                            resultHtml += "	</div>";
                            resultHtml += "</li>";
                        }else{
                            window.reload;
                        }
                    }
                    $("#audioList").html(resultHtml);
                    $('.audioSection').show();
                } else {
                    $('.audioSection').hide();
                }
            } else {
                $$.layerToast(`获取失败！[${data.msg}]`);
            }
        }
    });
}
