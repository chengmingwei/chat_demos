let fundCodeArr = [];
let fundsFixedData = {};
window.onload = function () {
	$$.changeVersion();
	thisDay();

	//搜索事件
	$(".search-main input").on('input propertychange', function() {
		let searchVal = $(".search-main input[name=search]").val();
		if (searchVal == "" || searchVal == null || searchVal == undefined ) {
			console.log("输入为空");
		} else{
			$(".search-list").html("");
			search(searchVal);
		}
	});


	//唤起搜索
	$(".fund-name-items").on('click', function() {
		$(".search").fadeIn();
		$(".search-list").html("");
		let inputEle = $(this).find('input[type=text]');
		let inputId = inputEle.attr('id');
		let inputVal = inputEle.val();
		$('#searchId').val(inputId);
		$(".search-main input[name=search]").val(inputVal);
	});
	//取消搜索
	$(".cancel-btn").on('click', function() {
		$(".search").fadeOut();
	});

	//按钮动画
	$("#fund-btn1").on('click', function() {
		fundCodeArr = [];
		let funds = $(".fund-name-items").find('input[type=hidden]');
		for (let i = 0;i < funds.size();i++) {
			let fundCode = funds.eq(i).val();
			if (fundCode != "" && fundCode != null && fundCode != undefined ) {
				fundCodeArr.push(fundCode);
			}
		}
		if (fundCodeArr.length == 0) {
			mui.alert("请选择基金");
		} else {
			fixed();
			summaryList();
			$("#window1").animate({top:'0px'},300);
		}
	});
	$("#fund-btn2").on('click', function() {
		$("#window1").animate({top:'100%'},300);
	});
	$("#fund-btn3").on('click', function() {
		$("#window2").animate({top:'100%'},300);
	});

	//贷款类型选择
	$(".choose-list li").on('click', function() {
		$(".choose-list li").removeClass("on");
		$(this).addClass("on");
		fixed();
	});


};

//日期事件
function thisDay(){
	//日期4数据
	let day4Html;
	for (let i = 1; i <= 30; i++) {
		day4Html += "<option value='"+ i +"' >每月"+ i +"日</option>";
		$("#day4").html(day4Html);
	}
	let myDate = new Date();
	let dataYear = parseInt(myDate.getFullYear());
	let dataMon = parseInt(myDate.getMonth())+ 1;
	let dataDay = parseInt(myDate.getDate())-1;
	if(dataMon < 10){
		dataMon = "0"+dataMon;
	}
	if(dataDay < 10){
		dataDay = "0"+dataDay;
	}
	if(dataMon == 0 && dataDay == 1){
		dataYear = dataYear-1;
		dataMon = 12;
		dataDay = 31;
	}
	let thisDate = dataYear+"-"+ dataMon +"-"+ dataDay;//最新可选日期
	let day1Default = dataYear-1 +"-"+ dataMon +"-"+ dataDay;
	$("#day1").text(day1Default);
	$("#day2").text(thisDate);
	$("#day3").text(thisDate);
	let day1 = $("#day1").text();
	let day2 = $("#day2").text();
	let day3 = $("#day3").text();
	laydate.render({
	  elem: '#day1',
	  type: 'date',
	  btns: ['confirm'],
	  max: thisDate,
	  done: function(value, date, endDate){
	  	 $('#day2').remove();
	  	 $('.fund-time-items').eq(1).append('<div class="fund-time-items-day" id="day2"></div>');
	  	 $("#day2").text(value);
	    laydate.render({
		  elem: '#day2',
		  type: 'date',
		  btns: ['confirm'],
		  min: value,
		  max: thisDate,
		  value: thisDate,
		  done: function(value, date, endDate){
		  	 $('#day3').remove();
		  	 $('.fund-time-items').eq(2).append('<div class="fund-time-items-day" id="day3"></div>');
		  	 $("#day3").text(value);
		  	 console.log("日历1的回调的回调");
		    laydate.render({
			  elem: '#day3',
			  type: 'date',
			  btns: ['confirm'],
			  min: value,
			  max: thisDate,
			  value: thisDate
			});
		  }
		});
	  }
	});
	laydate.render({
	  elem: '#day2',
	  type: 'date',
	  btns: ['confirm'],
	  min: day1,
	  max: thisDate,
	  value: thisDate,
	  done: function(value, date, endDate){
	  	 $('#day3').remove();
	  	 $('.fund-time-items').eq(2).append('<div class="fund-time-items-day" id="day3"></div>');
	  	 $("#day3").text(value);
	    laydate.render({
		  elem: '#day3',
		  type: 'date',
		  btns: ['confirm'],
		  min: value,
		  max: thisDate,
		  value: thisDate
		});
	  }
	});
	laydate.render({
	  elem: '#day3',
	  type: 'date',
	  btns: ['confirm'],
	  min: day2,
	  max: thisDate,
	  value: thisDate
	});
}
function search(searchVal) {
	searchVal = encodeURI(searchVal);
	$$.request({
		url: UrlConfig.market_calculator_fundSearch,
		method : 'GET',
		pars: {
			searchVal:searchVal
		},
		sfn: function(data) {
			if(data.success) {
				let list = data.list;
				createSearchList(list);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createSearchList(list) {
	if(!list || typeof(list) == 'undefined' || list.length == 0) {
		$(".search-list").html("<li>没有相关基金，请试试其他关键词</li>");
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$(".search-list").html(htmlCodes);
	$(".search-list li").on('click', function() {
		let inputId = $('#searchId').val();
		let search = $(this).html();
		let id = $(this).attr('id');
		let code = id.replace('code', '');
		$('#' + inputId).val(search);
		$('#' + inputId + 'Code').val(code);
		$(".search").fadeOut();
	});
}
function getHtmlByList(xpro) {
	let name = xpro.name;
	let id = xpro.id;
	let code = xpro.code;
	let htmlArr = [
	'<li id="code' + code + '_' + id + '">' + name + '</li>'
	];
	return htmlArr.join("");
}
function summaryList() {
	let day1 = $('#day1').html();
	let day2 = $('#day2').html();
	$$.request({
		url: UrlConfig.market_calculator_fundSummaryList,
		method : 'GET',
		pars: {
			start_date:day1,
			end_date:day2
		},
		sfn: function(data) {
			if(data.success) {
				let list = data.list;
				//行情数据
				createSummaryList(list);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createSummaryList(list) {
	if(!list || typeof(list) == 'undefined' || list.length == 0) {
		$("#hangqing").html("");
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList2(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$("#hangqing").html(htmlCodes);
}
function getHtmlByList2(xpro) {
	let name = xpro.name;
	let start_price = xpro.start_price;
	let end_price = xpro.end_price;
	let p_change = xpro.p_change;
	let htmlArr = [
	'<li>',
		'<span>' + name + '</span>',
		'<span>' + start_price + '</span>',
		'<span>' + end_price + '</span>',
		'<span>' + p_change + '</span>',
	'</li>'
	];
	return htmlArr.join("");
}
function fixed() {
	let amount = $('#amount').val();
	let term = $('#term').val();
	let rate = $('#rate').val();
	if (amount == "" || amount <= 0) {
		amount = 1;
		$('#amount').val(amount);
	}
	if (term == "" || term <= 0) {
		term = 1;
		$('#term').val(term);
	}
	if (rate == "" || rate <= 0) {
		rate = 1;
		$('#rate').val(rate);
	}
	let termType = $('#termType').val();
	let start = $('#day1').html();
	let end = $('#day2').html();
	let redemption = $('#day3').html();
	let invest = $('#day4').val();
	let typeChoose = $(".choose-list li.on").index();
	let prm = {
		amount:amount,
		term:term,
		rate:rate,
		termType:termType,
		start:start,
		end:end,
		redemption:redemption,
		invest:invest,
		typeChoose:typeChoose,
		fundCodes:fundCodeArr.join(",")
	};
	calcFundFixed(prm);
}
function calcFundFixed(prm) {
	$$.request({
		url: UrlConfig.market_calculator_fundFixed,
		method : 'GET',
		pars: prm,
		sfn: function(data) {
			if(data.success) {
				let fundCodes = data.fundCode;
				let fundDatas = data.fundData;
				fundsFixedData = fundDatas;
				createFundAboutDataList(fundCodes, fundDatas);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createFundAboutDataList(fundCodes, fundDatas) {
	if(!fundCodes || typeof(fundCodes) == 'undefined' || fundCodes.length == 0) {
		$("#window1 .window-top-data").html("");
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < fundCodes.length;i++){
		let fundCode = fundCodes[i];
		for(let j = 0;j < fundDatas.length;j++){
			let fundData = fundDatas[j];
			let summary = fundData.summary;
			let fund_code = summary.fund_code;
			if (fundCode == fund_code) {
				htmlArr[i] = getHtmlByList3(summary);
			}
		}
	}
	let htmlCodes = htmlArr.join("");
	$("#window1 .window-top-data").html(htmlCodes);

	//详情页唤起
	$(".window-top").on('click', function() {
		let id = $(this).attr('id');
		let fundCode = id.replace('fund_code', '');
		setWindow2Data(fundCode);
		$("#window2").animate({top:'0px'},300);
	});
}
function getHtmlByList3(xpro) {
	let fund_code = xpro.fund_code;
	let fund_info = xpro.fund_info;
	let total_invest = xpro.total_invest;
	let total_profit = xpro.total_profit;
	let rate_of_return = xpro.rate_of_return;
	let htmlArr = [
	'<div class="window-top" id="fund_code' + fund_code + '">',
		'<ul class="window-top-list">',
			'<li>',
				'<div>' + fund_info + '</div>',
				'<div class="click-text">点击浏览详情</div>',
			'</li>',
			'<li>',
				'<div>投入总额/元</div>',
				'<div><b>' + total_invest + '</b></div>',
			'</li>',
			'<li>',
				'<div>赎回总额/元</div>',
				'<div><b>' + total_profit + '</b></div>',
			'</li>',
			'<li>',
				'<div>总收益率：</div>',
				'<div><b>' + rate_of_return + '%</b></div>',
			'</li>',
		'</ul>',
	'</div>'
	];
	return htmlArr.join("");
}
function setWindow2Data(fundCode) {
	for (let i = 0;i < fundsFixedData.length;i++) {
		let fundData = fundsFixedData[i];
		let summary = fundData.summary;
		let fund_code = summary.fund_code;
		if (fundCode == fund_code) {
			let fund_info = summary.fund_info;
			let total_invest = summary.total_invest;
			let total_profit = summary.total_profit;
			let rate_of_return = summary.rate_of_return;
			let accumulated = summary.accumulated;
			let accumulated_profit = summary.accumulated_profit;
			let unit_netvalue = summary.unit_netvalue;
			let detailAbout = $('#window2 .window-top-list li');
			detailAbout.eq(0).find('div').eq(0).html(fund_info);
			detailAbout.eq(0).find('div').eq(1).html('代码：' + fund_code);
			detailAbout.eq(1).find('b').html(total_invest);
			detailAbout.eq(2).find('b').html(total_profit);
			detailAbout.eq(3).find('b').html(rate_of_return + '%');
			detailAbout.eq(4).find('b').html(accumulated);
			detailAbout.eq(5).find('b').html(accumulated_profit);
			detailAbout.eq(6).find('b').html(unit_netvalue);
			//定投详情数据
			let buy = fundData.buy;
			createBuyList(buy);
		}
	}
}
function createBuyList(list) {
	if(!list || typeof(list) == 'undefined' || list.length == 0) {
		$("#dingtou").html("");
		return;
	}
	$('#window2 .window-main-tips').html('期数：共' + list.length + '期');
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList4(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$("#dingtou").html(htmlCodes);
}
function getHtmlByList4(xpro) {
	let date = xpro.date;
	let unit_netvalue = xpro.unit_netvalue;
	let amount = xpro.amount;
	let value = xpro.value;
	let htmlArr = [
	'<li>',
		'<span>' + date + '</span>',
		'<span>' + unit_netvalue + '</span>',
		'<span>' + amount + '</span>',
		'<span>' + value + '</span>',
	'</li>'
	];
	return htmlArr.join("");
}
