window.onload = function () {
	$$.changeVersion();
	//贷款类型选择
	$(".choose-list li").on('click', function() {
		$(".choose-list li").removeClass("on");
		$(this).addClass("on");
		calcInvestment();
	});

	//按钮动画
	$("#investment-btn1").on('click', function() {
		calcInvestment();
		$(".pop-window").animate({top:'0px'},300);
	});
	$("#investment-btn2").on('click', function() {
		$(".pop-window").animate({top:'100%'},300);
	});
};
function calcInvestment() {
	let amount = $('#amount').val();
	let rate = $('#rate').val();
	let term = $('#term').val();
	let term_unit = $('#term-unit').val();
	let mode = $(".choose-list li.on").index();
	if(amount == null || amount == '' || amount <= 0) {
		amount = 100;
		$('#amount').val(amount);
	}
	if(rate == null || rate == '' || rate <= 0) {
		rate = 1;
		$('#rate').val(rate);
	}
	if(term == null || term == '' || term <= 0) {
		term = 1;
		$('#term').val(term);
	}

	$$.request({
		url: UrlConfig.market_calculator_investment,
		method : 'GET',
		pars: {
			amount:amount,
			rate:rate,
			term:term,
			term_unit:term_unit,
			mode:mode
		},
		sfn: function(data) {
			if(data.success) {
				let amountStr = data.amountStr;
				let rateStr = data.rateStr;
				let totalStr = data.totalStr;
				let term_unit_str = '个月';
				if (term_unit == '0') {
					term_unit_str = '年';
				} else if (term_unit == '2') {
					term_unit_str = '天';
				}
				let summary_info = '投资' + amount + '元，' +
					'年化收益' + rate + '%，' +
					term + term_unit_str + '后';
				$('.window-top-text').html(summary_info);
				$('#amountStr').html(amountStr);
				$('#rateStr').html(rateStr);
				$('#totalStr').html(totalStr);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
