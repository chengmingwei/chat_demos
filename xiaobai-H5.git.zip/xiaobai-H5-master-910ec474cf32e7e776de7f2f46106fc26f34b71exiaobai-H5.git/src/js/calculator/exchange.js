window.onload = function () {
	$$.changeVersion();
//	calcExchangeList();
	calcExchange();
	//第一币种选择事件
	 $("#first-currency").change(function(){
	 	calcExchange();
	 });

	 //第二币种选择事件
	 $("#last-currency").change(function(){
	 	calcExchange();
	 });

	//切换币种事件
	$(".exchange-switch-btn").on('click', function() {
		let firstCurrency = $("#first-currency").val();
		let lastCurrency = $("#last-currency").val();
		$("#first-currency").val(lastCurrency);
		$("#last-currency").val(firstCurrency);
		let lastValue = $("#last-value").val();
		$("#first-value").val(lastValue);
		calcExchange();
	});

	//监听币种一的金额改变事件
	$("#first-value").on("input propertychange",function() {
	 	calcExchange();
	});

};
function calcExchangeList() {
	$$.request({
		url: UrlConfig.market_calculator_exchangeList,
		method : 'GET',
		pars: {},
		sfn: function(data) {
			if(data.success) {
				let error_code = data.error_code;
				if (error_code == 0) {
					let exchangeList = data.exchangeList;
					createList(exchangeList);
					let firstCurrency = $('#first-currency');
					let lastCurrency = $('#last-currency');
					firstCurrency.val('CNY');
					lastCurrency.val('USD');
					calcExchange();
				} else{
					let reason = data.reason;
					$$.alert(reason);
				}
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createList(list) {
	if(!list || typeof(list) == 'undefined') {
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$('#first-currency').html(htmlCodes);
	$('#last-currency').html(htmlCodes);
}
function getHtmlByList(xpro) {
	let name = xpro.name;//货币名称
	let code = xpro.code;//货币代码
	let htmlArr=[
	'<option value="' + code + '">' + name + ' ' + code + '</option>'
	];
	return htmlArr.join("");
}
function calcExchange() {
	let base_unit = $("#first-currency").val();
	let targ_unit = $("#last-currency").val();
	let base_value = $('#first-value').val();
	if (base_value == null || base_value == '' || base_value <= 0) {
		base_value = 1;
		$('#first-value').val(base_value)
	}
	$$.request({
		url: UrlConfig.market_calculator_exchange,
		method : 'GET',
		pars: {
			base_unit:base_unit,
			targ_unit:targ_unit,
			base_value:base_value
		},
		sfn: function(data) {
			if(data.success) {
				let error_code = data.error_code;
				if (error_code == 0) {
					let targ_valueStr = data.targ_valueStr;
					$('#last-value').val(targ_valueStr);
				} else{
					let reason = data.reason;
					$$.alert(reason);
				}
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
