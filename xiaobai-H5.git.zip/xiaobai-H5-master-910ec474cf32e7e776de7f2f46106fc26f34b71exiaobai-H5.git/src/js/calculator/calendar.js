window.onload = function() {
	$$.loading();
	wechatShare();
	calendar();
	$$.closeLoading();
};
let dataList = null;
function calendar() {
	$$.request({
		url: UrlConfig.market_calculator_getCalendarData,
		method : 'GET',
		pars: {},
		sfn: function(data) {
			if(data.success) {
				let firstDay = data.firstDay;
				let lastDay = data.lastDay;
				let mark = data.mark;
				dataList = data.dataList;
				laydateOn(firstDay, lastDay, mark);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function laydateOn(firstDay, lastDay, mark) {
	//日期控件初始化
	laydate.render({
		elem: '.calendar',
		position: 'static',
		type: 'date',
		showBottom: false,
		min: firstDay,
  		max: lastDay,
		mark: mark,
		change: function(value){
			//value 当前日期如：2018-08-18
			$("#dataList").html('');
			for (let i = 0;i < dataList.length;i++) {
				let data = dataList[i];
				let time = data.time;
				if(value == time) {
					let list = data.list;
					createList(list);
				}
			}
		}
	});
}
function createList(list) {
	if(!list || typeof(list) == 'undefined') {
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$("#dataList").html(htmlCodes);
}
function getHtmlByList(xpro) {
	let typeName = xpro.typeNameCN;
	let dataByType = xpro.dataByType;
	let htmlArr = [];
	for(let i = 0;i < dataByType.length;i++){
		let xpro2 = dataByType[i];
		htmlArr[i] = getHtmlByList2(xpro2);
	}
	let htmlArr2 = [
	'<div class="calendar-data">',
		'<div class="calendar-data-type">' + typeName + '</div>',
		htmlArr.join(""),
	'</div>'];
	return htmlArr2.join("");
}
function getHtmlByList2(xpro2) {
	let titleType = xpro2.titleType;
	let title = xpro2.title;
	let code = xpro2.code;
	let issuePrice = '';
	if (code != null && code != '') {
		code = '代码：' + code;
	} else {
		code = '';
	}
	let description = xpro2.description;
	for (let i = 0;i < description.length;i++) {
		if (description[i].indexOf('发行价') > -1) {
			issuePrice = description[i];
			issuePrice = issuePrice.replace('发行价:','发行价格：');
			if (isNaN(parseFloat(issuePrice.substring(issuePrice.indexOf('发行价格：') + 5,issuePrice.length - 1)))) {
				issuePrice = '发行价格：0元';
			}
		}
	}
	let htmlArr = [
	'<div class="calendar-items">',
		'<div class="calendar-items-icon">' + titleType + '</div>',
		'<div class="calendar-items-bank">' + title + '</div>',
		'<div class="calendar-items-code">' + code + '</div>',
		'<div class="calendar-items-money">' + issuePrice + '</div>',
	'</div>'
	];
	return htmlArr.join("");
}

function wechatShare() {
	let lineLink;
	let from = $$.getUrlParam("from");
	if(from == null) {
		lineLink = location.href.split('#')[0];
	} else {
		lineLink = location.href.split('?')[0];
		window.location.href = lineLink;
	}
	weChatJSTool.share({
		_imgUrl: $Constant.shareLogo,
		_lineLink: lineLink,
		_shareTitle: '每日投资日历',
		_descContent: '福利多多，快来一起领钱吧~',
		_sfn: function () {
			console.log("成功注册分享链接：" + lineLink);
		},
		_cfn: function () {
		},
		_ffn: function () {
			console.log("失败注册分享链接：" + lineLink);
		}
	});
}
