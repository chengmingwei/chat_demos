window.onload = function () {
	$$.changeVersion();
	$$.loading();
	//二级页面跳转
	$(".calculator li").on('click', function() {
		let thisID = $(this).attr("id");
		$$.push("calculator/" + thisID);
	});
	wechatShare();
	$$.closeLoading();
};
function wechatShare() {
	let lineLink;
	let from = $$.getUrlParam("from");
	if(from == null) {
		lineLink = location.href.split('#')[0];
	} else {
		lineLink = location.href.split('?')[0];
		window.location.href = lineLink;
	}
	weChatJSTool.share({
		_imgUrl: $Constant.shareLogo,
		_lineLink: lineLink,
		_shareTitle: '史上强大的理财计算器！！！',
		_descContent: '福利多多，快来一起领钱吧~',
		_sfn: function () {
			console.log("成功注册分享链接：" + lineLink);
		},
		_cfn: function () {
		},
		_ffn: function () {
			console.log("失败注册分享链接：" + lineLink);
		}
	});
}
