window.onload = function () {
	$$.changeVersion();
	//贷款类型选择
	$(".choose-list li").on('click', function() {
		let thisIndex = $(this).index();
		$(".window-top-list").hide();
		$(".window-top-list").eq(0).show();
		$(".window-top-list").eq(thisIndex + 1).show();
		$(".choose-list li").removeClass("on");
		$(this).addClass("on");
		calcLoan();
	});

	//按钮动画
	$("#loan-btn1").on('click', function() {
		calcLoan();
		$(".pop-window").animate({top:'0px'},300);
	});
	$("#loan-btn2").on('click', function() {
		$(".pop-window").animate({top:'100%'},300);
	});
};
function calcLoan() {
	let amount = $('#amount').val();
	let rate = $('#rate').val();
	let term = $('#term').val();
	let mode = $(".choose-list li.on").index();
	if(amount == null || amount == '' || amount <= 0) {
		amount = 100;
		$('#amount').val(amount);
	}
	if(rate == null || rate == '' || rate <= 0) {
		rate = 1;
		$('#rate').val(rate);
	}
	if(term == null || term == '' || term <= 0) {
		term = 1;
		$('#term').val(term);
	}

	$$.request({
		url: UrlConfig.market_calculator_loan,
		method : 'GET',
		pars: {
			amount:amount,
			rate:rate,
			term:term,
			mode:mode
		},
		sfn: function(data) {
			if(data.success) {
				let term = data.term;
				let rateMoneyTotal = data.rateMoneyTotal;
				let total = data.total;
				let list = data.list;
				$('#termStr').html(term);
				$('#termStr2').html(term);
				$('#rateMoneyTotal').html(rateMoneyTotal);
				$('#total').html(total);
				$('#totalByPeriod').html(0);
				$('#total1st').html(0);
				$('#decrease').html(0);
				if (mode == '0') {
					let totalByPeriod = data.totalByPeriod;
					$('#totalByPeriod').html(totalByPeriod);
				} else{
					let total1st = data.total1st;
					let decrease = data.decrease;
					$('#total1st').html(total1st);
					$('#decrease').html(decrease);
				}
				//分期数据
				createList(list);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createList(list) {
	if(!list || typeof(list) == 'undefined') {
		$(".window-main-list").html("");
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$(".window-main-list").html(htmlCodes);
}
function getHtmlByList(xpro) {
	let term = xpro.term;
	let amount = xpro.amount;
	let rate = xpro.rate;
	let total = xpro.total;
	let htmlArr=[
	'<li>',
		'<span>' + term + '</span>',
		'<span>' + amount + '</span>',
		'<span>' + rate + '</span>',
		'<span>' + total + '</span>',
	'</li>'
	];
	return htmlArr.join("");
}
