window.onload = function () {
	$$.changeVersion();
	calcInstallment();
	$("#money").on("input propertychange",function() {
	 	calcInstallment();
	});
	//按钮动画
	$(".installment-list li").on('click', function() {
		$(".pop-window").animate({top:'0px'},300);
		let id = $(this).attr('id');
		let term = id.replace('term', '');
		let money = $('#money').val();
		calcInstallmentList(term, money);
	});
	$("#installment-btn").on('click', function() {
		$(".pop-window").animate({top:'100%'},300);
	});
};
function calcInstallment() {
	let money = $('#money').val();
	if (money == null || money == '') {
		money = 100;
		$('#money').val(money);
	}
	$$.request({
		url: UrlConfig.market_calculator_installment,
		method : 'GET',
		pars: {
			money:money
		},
		sfn: function(data) {
			if(data.success) {
				let banks = data.banks;
				for (let i = 0;i < banks.length;i++) {
					let bank = banks[i];
					setBank(bank, i);
				}
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function setBank(bank, i) {
	let bankName = bank.bankName;
	let rate = bank.rate;
	let term = bank.term;
	let totalByPeriod = bank.totalByPeriod;
	let total = bank.total;
	let installment_list = $('.installment-list li').eq(i);
	let tip = '分' + term + '期，当前 [ ' + bankName + ' ] 最划算</br>点击浏览更多';
	installment_list.attr('id', 'term' + term);
	installment_list.find('.installment-list-items-tips').html(tip);
	let items_date = installment_list.find('.installment-list-items-date');
	items_date.eq(0).find('.data-number b').html(rate + '%');
	items_date.eq(1).find('.data-number').html(totalByPeriod);
	items_date.eq(2).find('.data-number').html(total);
}
function calcInstallmentList(term, money) {
	$$.request({
		url: UrlConfig.market_calculator_installmentList,
		method : 'GET',
		pars: {
			money:money,
			term:term
		},
		sfn: function(data) {
			if(data.success) {
				let banks = data.banks;
				let bank0 = banks[0];
				let bankName = bank0.bankName;
				let rate = bank0.rate;
				let totalByPeriod = bank0.totalByPeriod;
				let total = bank0.total;
				let top_text = '总额' + money + '元，分' + term + '期，当前 [ ' + bankName + ' ] 实际年利率最低';
				$('.window-top-text').html(top_text);
				let top_list = $('.window-top-list li');
				top_list.eq(0).find('div b').html(rate + '%');
				top_list.eq(1).find('div b').html(totalByPeriod);
				top_list.eq(2).find('div b').html(total);
				//分期数据
				createList(banks);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createList(list) {
	if(!list || typeof(list) == 'undefined') {
		$(".window-main-list").html("");
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$(".window-main-list").html(htmlCodes);
}
function getHtmlByList(xpro) {
	let bankName = xpro.bankName;
	let totalByPeriod = xpro.totalByPeriod;
	let total = xpro.total;
	let rate = xpro.rate;
	let htmlArr=[
	'<li>',
		'<span>' + bankName + '</span>',
		'<span>' + totalByPeriod + '</span>',
		'<span>' + total + '</span>',
		'<span>' + rate + '%</span>',
	'</li>'
	];
	return htmlArr.join("");
}
