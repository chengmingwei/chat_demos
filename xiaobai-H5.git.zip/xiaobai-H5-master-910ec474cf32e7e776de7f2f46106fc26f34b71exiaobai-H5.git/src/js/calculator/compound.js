window.onload = function () {
	$$.changeVersion();
	//按钮动画
	$("#compound-btn1").on('click', function() {
		calcCompound();
		$(".pop-window").animate({top:'0px'},300);
	});
	$("#compound-btn2").on('click', function() {
		$(".pop-window").animate({top:'100%'},300);
	});
};
function calcCompound() {
	let amount = $('#amount').val();
	let rate_unit = $('#rate-unit').val();
	let rate = $('#rate').val();
	let term_unit = $('#term-unit').val();
	let term = $('#term').val();
	if (amount == null || amount == '' || amount <= 0) {
		amount = 100;
		$('#amount').val(amount);
	}
	if (rate == null || rate == '' || rate <= 0) {
		rate = 1;
		$('#rate').val(rate);
	}
	if (term == null || term == '' || term <= 0) {
		term = 1;
		$('#term').val(term);
	}
	$$.request({
		url: UrlConfig.market_calculator_compound,
		method : 'GET',
		pars: {
			amount:amount,
			rate_unit:rate_unit,
			rate:rate,
			term_unit:term_unit,
			term:term
		},
		sfn: function(data) {
			if(data.success) {
				let amountTotal = data.amountTotal;
				let rateMoneyTotal = data.rateMoneyTotal;
				let total = data.total;
				let list = data.list;
				let term_unit_str = '月';
				let term_unit_str2 = '个月';
				if (term_unit == '0') {
					term_unit_str = '年';
					term_unit_str2 = '年';
				} else if (term_unit == '2') {
					term_unit_str = '天';
					term_unit_str2 = '天';
				}
				let rate_unit_str = '年';
				if (rate_unit == '1') {
					rate_unit_str = '月';
				} else if (rate_unit == '2') {
					rate_unit_str = '日';
				}
				let summary_info = '每' + term_unit_str + '投入' + amount + '元，' +
					rate_unit_str + '利率' + rate + '%复利，' +
					term + term_unit_str2 + '后';
				$('.window-top-text').html(summary_info);
				$('#amountTotal').html(amountTotal);
				$('#rateMoneyTotal').html(rateMoneyTotal);
				$('#total').html(total);
				$('#termStr').html(term);
				//分期数据
				createList(list);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createList(list) {
	if(!list || typeof(list) == 'undefined') {
		$("#loanList").html("");
		return;
	}
	let htmlArr = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		htmlArr[i] = getHtmlByList(xpro);
	}
	let htmlCodes = htmlArr.join("");
	$(".window-main-list").html(htmlCodes);
}
function getHtmlByList(xpro) {
	let term = xpro.term;
	let amount = xpro.amount;
	let rate = xpro.rate;
	let total = xpro.total;
	let htmlArr=[
	'<li>',
		'<span>' + term + '</span>',
		'<span>' + amount + '</span>',
		'<span>' + rate + '</span>',
		'<span>' + total + '</span>',
	'</li>'
	];
	return htmlArr.join("");
}
