let myDate = new Date(); //时间对象
let dataYear = myDate.getFullYear(); //年
let dataMon = parseInt(myDate.getMonth()) + 1; //月
let dataDay = myDate.getDate(); //日
window.onload = function() {
	$$.loading();
	wechatShare();
	//更新时间
	$(".valuation-time span").text(dataYear + " 年 " + dataMon + " 月 " + dataDay + " 日更新");
	fundsList();
	$$.closeLoading();
};
function fundsList() {
	$$.request({
		url: UrlConfig.market_calculator_fundsList,
		method : 'GET',
		pars: {},
		sfn: function(data) {
			if(data.success) {
				let list = data.list;
				//填充数据
				createList(list);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}
function createList(list) {
	if(!list || typeof(list) == 'undefined') {
		return;
	}
	let htmlArr = [];
	let htmlArr2 = [];
	for(let i = 0;i < list.length;i++){
		let xpro = list[i];
		let name = xpro.name;
		htmlArr[i] = getHtmlByList(xpro);
		htmlArr2[i] = '<li>' + name + '</li>';
	}
	let htmlCodes = htmlArr.join("");
	let htmlCodes2 = htmlArr2.join("");
	$(".valuation-table").append(htmlCodes);
	$(".valuation-ul").append(htmlCodes2);
}
function getHtmlByList(xpro) {
	let fundnum = xpro.fundnum;
	let total = xpro.total;
	let change = xpro.change;
	let totalcap = xpro.totalcap;
	let accrate = xpro.accrate;
	let changesta = xpro.changesta;
	if (changesta != null && changesta != '') {
		changesta = changesta + '%';
	}
	let htmlArr=[
	'<div class="valuation-table-tr">',
		'<div class="valuation-table-td">' + fundnum + '</div>',
		'<div class="valuation-table-td">' + total + '万</div>',
		'<div class="valuation-table-td">' + change + '</div>',
		'<div class="valuation-table-td">' + totalcap + '亿</div>',
		'<div class="valuation-table-td other">' + accrate + '%</div>',
		'<div class="valuation-table-td other">' + changesta + '</div>',
	'</div>'
	];
	return htmlArr.join("");
}

function wechatShare() {
	let lineLink;
	let from = $$.getUrlParam("from");
	if(from == null) {
		lineLink = location.href.split('#')[0];
	} else {
		lineLink = location.href.split('?')[0];
		window.location.href = lineLink;
	}
	weChatJSTool.share({
		_imgUrl: $Constant.shareLogo,
		_lineLink: lineLink,
		_shareTitle: '每日基金重仓股排行榜',
		_descContent: '福利多多，快来一起领钱吧~',
		_sfn: function () {
			console.log("成功注册分享链接：" + lineLink);
		},
		_cfn: function () {
		},
		_ffn: function () {
			console.log("失败注册分享链接：" + lineLink);
		}
	});
}
