/**
 * 玩转小白介绍页 JS
 * @Author 吴成林
 * @Date 2020-9-22 18:34:22
 */
window.onload = function() {
    countAction('xb_6011');
    $$.changeVersion();

    /**
     * 数据存储中心
     */
    const PAGE_STATE = {
        memberId: null,             // 登录用户ID
        teamData: null,             // 用户团队数据
        memberStatus: {             // 用户参数
            mtype: null,
            userStatus: null,
            licenseId: null,
            licenseRegTime: null,
            licenseIssueTime: null,
            licenseIsSubmit: null,
        },

    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        //-- 绑定事件
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        /*viewHeight = window.innerHeight || document.documentElement.clientHeight;    //-- 浏览器高度
        let length = $('.amusingXiaoBaiBg').height();
        console.log(length);
        $('.banner1').css({"top":length*0.536+"px", "height":length*0.1925+"px"});*/
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 去选择模板 - 开启店铺
        $(".addXiaoBaiText").on("click", function(){
            if ($$.checkLogin()){
                member_Detailspage();           //-- 用户信息
            } else{
                $$.confirmLogin();
            }
        });

    }

    //-- 获取登录用户信息
    function member_Detailspage() {
        if ($$.checkLogin()) {
            $$.request({
                url: UrlConfig.member_Detailspage,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success && data.datas) {
                        const {id, userStatus, mtype, licenseId} = data.datas;
                        PAGE_STATE.memberStatus.userStatus = userStatus;
                        PAGE_STATE.memberStatus.mtype = mtype;
                        PAGE_STATE.memberStatus.licenseId = licenseId;
                        PAGE_STATE.memberId = id;

                        detailsPageMemberDetail();      //-- 获取用户执业编号状态
                    }
                }
            });
        }
    }

    //-- 获取用户执业编号状态
    function detailsPageMemberDetail()  {
        $$.request({
            url: UrlConfig.memberdetail_detailsPageMemberDetail,
            sfn: function(data){
                if (data.success) {
                    const {licenseRegTime, licenseIssueTime, licenseIsSubmit} = data.datas;
                    PAGE_STATE.memberStatus.licenseRegTime = licenseRegTime;
                    PAGE_STATE.memberStatus.licenseIssueTime = licenseIssueTime;
                    PAGE_STATE.memberStatus.licenseIsSubmit = licenseIsSubmit;

                    gotoMyTeam();                   //-- 用户团队信息
                }
            }
        });
    }

    //-- 根据会员id查询团员信息
    function gotoMyTeam(){
        $$.request({
            url: UrlConfig.market_teammember_getTeamMemberByLogin,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.teamData = data;

                    checkIsTeamLeader();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 玩转小白 判断提示
    function checkIsTeamLeader() {
        if(!$$.checkLogin()){
            ShawHandler.confirmLogin();
            return;
        }

        let {teamStatus, teamMemberStatus, teamMemberId, mType, teamId} = PAGE_STATE.teamData;
        let {mtype, userStatus, licenseId, licenseRegTime, licenseIssueTime, licenseIsSubmit} = PAGE_STATE.memberStatus;
        let url = "teams/index";
        let params = {};

        if (mtype != 4 && userStatus != 2){             //你是经纪人
            createConfirm('请先实名认证成为经纪人','实名认证',function() {
                $$.push('my/professionalCertification');
            });
            return;
        } else if (!$$.isValidObj(licenseId)){
            $$.layerToast('您还没有执业认证编号，详情请联系客服~');
            return;
        } else if (!$$.isValidObj(licenseRegTime) || !$$.isValidObj(licenseIssueTime) || licenseIsSubmit != 1){
            $$.layerToast('您的执业认证编号审核处理中，详情请联系客服~');
            return;
        }else if ($$.isValidObj(teamId)) {
            params.teamId = teamId;
            if (teamStatus === 0 || teamStatus === 1) {
                url = "teams/addDetails";
            } else if (teamStatus === 2) {
                url = "teams/colonel";
                if (mType === 2) {
                    url = "teams/clustering";
                }
            }
        } else {
            if (teamMemberStatus === 2) {
                url = 'teams/notpass';
            } else if (teamMemberStatus === 0) {
                if (teamMemberId) {
                    url = 'teams/application';
                    params.teamMemberId = teamMemberId;
                }
            }
        }
        $$.push(url,params);
    }

    //-- 提示 公用弹窗
    function createConfirm(title,onOkLabel,onOk) {
        $$.confirm({
            title: title,
            onOkLabel: onOkLabel,
            onCancelLabel: '取消',
            onOk: onOk
        });
    }
}
