
/**
 * 首页
 * @Author 肖家添
 * @Date 2019/8/30 10:06
 */

window.onload = function(){

    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2019/8/29 16:35
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2019/8/29 16:37
     */
    function pageInit(){
        //-- 微信自动登录
        if($WeChat.isWx()){
            //-- 获取当前时间戳
            let timestamp = new Date().getTime();
            //-- 获取用户spendID
            const weChatUserManualExit = localStorage.getItem($Constant.weChatUserManualExitKey);
            if(!$$.isValidObj(weChatUserManualExit)){
                getSpenID();        //-- 微信授权登录
            } else {
                const days = timestamp - weChatUserManualExit;
                const day = Math.ceil(days / (1000 * 60));  //-- 间隔分钟
                if (day > 30){
                    getSpenID();    //-- 微信授权登录
                }
            }
        }

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

        //-- 加载首页数据
        findHomeData();

        //话题PK
        topicPK();

        //-- 995大礼包
        giftPacks();

        //-- 用户登录状态下的消息中心最新消息提示
        if($$.checkLogin()){
            informationCue();
        }
    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2019/9/3 15:27
     */
    function bindEvent() {

        /**弹窗关闭按钮**/
        $('.close,.plank,.space').click(()=>{
            $('.pop-up').remove();
        });

        /**跳转到新人礼包详情页面**/
        $('.get').click(()=>{
            $$.push('my/newGiftBag');
        });

        //-- 文章详情
        $(".hotTopicContent").on("click", "li", function(){
            const id = $(this).attr("key");
            try {
                countAction('xb_23', null);
            } catch (error) {
                console.log(error);
            }
            $$.push('know/articleDetails',{"id":encodeURI(encodeURI(id))});
        });

        //-- 专题详情
        $(".hotTopicContent").on("click", ".notice", function(){
            const id = $(this).attr("key");
            //$$.push("know/specialTopicDetail", {id});
            try {
                countAction('xb_24', null);
            } catch (error) {
                console.log(error);
            }
            $$.push('product/specialDetails',{"id":encodeURI(encodeURI(id))});
        });

        $("#umember").on("click", function(){
            $$.loading();
            $$.request({
                url: UrlConfig.member_memberUpdateOld,
                sfn: function(data){
                    $$.closeLoading();
                    if (data.success){
                        $$.alert("迁移成功~~~")
                    }
                }
            });
        });
        $("#uaccoun").on("click", function(){
            $$.loading();
            $$.request({
                url: UrlConfig.member_memberAccountUpdateOld,
                sfn: function(data){
                    $$.closeLoading();
                    if (data.success){
                        $$.alert("迁移成功~~~");
                    }
                }
            });
        });
        $("#ubankCard").on("click", function(){
            $$.loading();
            $$.request({
                url: UrlConfig.member_bankCardUpdateOld,
                sfn: function(data){
                    $$.closeLoading();
                    if (data.success){
                        $$.alert("迁移成功~~~");
                    }
                }
            });
        });

        //-- 在线 一对一咨询
        $(".onlineConsulting").on("click", function(){
            $$.push('my/onlineConsulting/consultInsuranceSpecialist');
        });
    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2019/9/26 17:43
     */
    function initPageState(){

        //-- 跳转自动绑定
        $$.staticPushAutoBind();
        member_Detailspage();

        //-- 清理HTML注释
        $$.clearHTMLNotes();

    }

    /**
     * 加载首页数据
     * @Author 肖家添
     * @Date 2019/8/30 10:10
     */
    function findHomeData(){
        //-- 本地缓存
        const cacheKey = "WX_HOME_DATA";

        try{
            let cacheData = localStorage.getItem(cacheKey);
            const hasCache = $$.isValidObj(cacheData);
            if(hasCache){
                cacheData = JSON.parse(cacheData);

                console.log("缓存有效，缓存数据绑定开始");

                sfn(cacheData);
            }

            //-- 匹配后台数据更新
            $$.request({
                url: UrlConfig.mobile_homeData,
                sfn: function(data){
                    if(hasCache && (JSON.stringify(cacheData) == JSON.stringify(data) || data.key == cacheData.key)){
                        return;
                    }

                    console.log("缓存失效，后台数据更新开始");

                    sfn(data);
                }
            });
            //-- 首页数据请求回调
            function sfn(data){
                if(data.success){
                    localStorage.setItem(cacheKey, JSON.stringify(data));
                    const { banner, hotProductData, article } = data;
                    $$.request({
                        url: UrlConfig.mobile_hotTopic,
                        loading: true,
                        sfn: function (data) {
                            $$.closeLoading();
                            if (data.success) {
                                bindBannerView(banner);
                                bindHotProductView(hotProductData);
                                bindArticleView(article,data.datas);
                            } else {
                                $$.layerToast(data.msg);
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });
                }
            }
        }catch (e) {
            //-- 防止响应的数据集自身就存在问题
            localStorage.removeItem(cacheKey);
        }
    }

    /**
     * 绑定Banner图
     * @Author 肖家添
     * @Date 2019/8/30 10:40
     */
    function bindBannerView(data){
        let html = "";

        data.forEach((item) => {
            const url = item.picUrl;

            if(!$$.isValidObj(url)){
                console.error(`发现错误！id=${item.id}的轮播图地址为空！`);
                return;
            }
            html += `
                <div class="swiper-slide" data-action="${item.adUrl}">
                    <img src="${$$.imageUrlCompatible(url)}">
                </div>
            `;
        });

        //-- 轮播图点击事件
        $(".banner-container>.swiper-wrapper").html(html).find(".swiper-slide").click(function () {
            const action = $(this).attr("data-action");
            if($$.isValidObj(action)){
                //数据统计
                try {
                    countAction('xb_11', null);
                } catch (error) {
                    console.log(error);
                }
                location.href = action;
            }
        });

        //-- 初始化轮播组件
        new Swiper (".banner-container", {
            loop: true,
            autoplay: {
                delay: 1000 * 3,
                stopOnLastSlide: false,
                disableOnInteraction: true,
            }
        });
    }

    /**
     * 绑定热门产品视图
     * @Author 肖家添
     * @Date 2019/9/1 21:10
     */
    function bindHotProductView(data){

        const classNames = ["P0001", "P0002", "P0003", "P0004", "P0005"];

        classNames.forEach((item) => {
            const bindData = data[item];

            if($$.isValidObj(bindData)){
                const html = ``
                    + `<img src="${bindData.coverUrl}" data-action="${bindData.action}" alt="">`
                    + `<span class="centerText">${bindData.title == null ? "" : bindData.title}</span>`;

                $(`.${item}`).html(html).off().click(function(){
                    let action = $(this).children("img").attr("data-action");
                    if($$.isValidObj(action)){
                        action = action.split("-");
                        if(action.length == 2){
                            //数据统计
                            try {
                                countAction('xb_20', null);
                            } catch (error) {
                                console.log(error);
                            }
                            $$.push("product/productDetail", {
                                productId: action[0],
                                sellId: action[1],
                            });
                        }
                    }
                });
            }
        });
    }

    /**
     * 绑定文章视图
     * @Author 肖家添
     * @Date 2019/10/18 12:25
     */
    function bindArticleView(articleData, subjectData){
        if(!$$.isValidObj(articleData)) return;
        let html = "";
        let subjectDataI = 0;
        let subjectDataLength=0;
        if (subjectData.length>0){
            subjectDataLength=subjectData.length;
        }

        for (let i=0;i<articleData.length;i++){
            // <li location-href="know/articleDetails" location-params='{"id": ${articleData[i].articleId}}'>
            html += `
                    <li key="${articleData[i].articleId}">
                   
                        <div class="left">
                            <h4>${articleData[i].articleTitle}</h4>
                            <div class="label flex-start">
                                <span class="title overflow" style="-webkit-line-clamp: 1">${articleData[i].articleBeUser}</span>
                                <span class="watchIcon">${articleData[i].ecount}</span>
                                <span class="goodsIcon">${articleData[i].browseCount}</span>
                            </div>
                        </div>
                        <div class="right">
                            <img src="${articleData[i].articleCover}" alt="">
                        </div>
                    </li>
                `;


            if (i > 0 && (i+1) % 2 == 0){
                if (subjectDataI<subjectDataLength){
                    const subjectItem = subjectData[subjectDataI];
                    const { id, name, title } = subjectItem;
                    html += `
                        <div class="notice" key="${id}">
                            <span class="btn">${name}</span>
                            <span class="title">${title}</span>
                        </div>
                    `;
                }
                subjectDataI++;

            }
        }



        //let subjectDataI = 0;
        /*for(let i = 0; i < 5; i++){
            const item = articleData[i];

            if($$.isValidObj(item)){
                const { articleId, articleTitle, articleBeUser, articleCover, fabulousCount, browseCount } = item;
                html += `
                    <li location-href="know/articleDetails" location-params='{"id": ${articleId}}'>
                        <div class="left">
                            <h4>${articleTitle}</h4>
                            <div class="label">
                                <span class="title">${articleBeUser}</span>
                                <span class="watchIcon">${fabulousCount}</span>
                                <span class="goodsIcon">${browseCount}</span>
                            </div>
                        </div>
                        <div class="right">
                            <img src="${articleCover}" alt="">
                        </div>
                    </li>
                `;
            }

            if(i > 0 && (i+1) % 2 == 0){
                console.log(subjectDataI);
                const subjectItem = subjectData[subjectDataI];
                console.log(subjectItem)
                subjectDataI++;
                if(!$$.isValidObj(subjectItem)) {return};
                const { id, name, title } = subjectItem;
                html += `
                    <div class="notice" key="${id}">
                        <span class="btn">${name}</span>
                        <span class="title">${title}</span>
                    </div>
                `;
            }

        }*/

        $(".hotTopicContent").html(html);
        //-- 绑定自动跳转事件
        $$.staticPushAutoBind();
    }

    /**
     * 新人礼包
     * @Author 吴成林
     * @Date 2020/03/11 19:47
     */
    function getIsNewMan(){
        $$.request({
            url: UrlConfig.market_mobileCoupon_setNewbieActivitiesRedis,
            pars:{
                stateType: 10001
            },
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if(data.success){
                        $('.pop-up').show();
                    }else{
                        $('.pop-up').hide();
                    }
                }
            }
        });
    }

    /**
     * 描述信息：话题PK
     * @author 覃创斌
     * @date 2019/10/28
     */
    function topicPK() {
        //-- 最高层
        let zIndex = 998;
        //-- 循环层
        let loop = 998;
        //-- 计算
        let count = 1;

        $$.request({
            url: UrlConfig.debate_getWapDebateList,
            loading: true,
            pars:{},
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let html = "";

                    if (data.datas) {
                        for (let i = 0; i < data.datas.length; i++) {
                            const { id, title, negativeSide, positiveSide } = data.datas[i];
                            html += `
                                <div class="unitLayer" style="z-index:${zIndex - i}">
                                    <div class="topic">
                                        <h4 id="debateTitle" location-href="topicPK/topicPKUnselectedDetail" location-params='{"debateId": ${id}}'>${title}</h4>
                                        <div class="card">
                                            <div class="btn pei-left">
                                                <div class="text textLeft" onclick="vote(${id},1,0)">${negativeSide}</div>
                                            </div>
                                            <div class="btn pei-right">
                                                <div class="text textRight" onclick="vote(${id},0,1)">${positiveSide}</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                        }
                        loop = zIndex - data.datas.length;
                    }
                    $(".topicPK_unit").append(html);

                    let unitLayerHeight = $(".unitLayer").height();
                    $(".topicPK_unit").css("height", unitLayerHeight);

                    //-- 跳转自动绑定
                    $$.staticPushAutoBind();

                    slide(zIndex,loop,count);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 话题PK 滑动
    function slide(zIndex,loop,count) {
        let photoSwipe={
            /* 当前对象 */
            this: "",
            /*元素位置*/
            _x_start:0,
            _y_start:0,
            _x_move:0,
            _y_move:0,
            _x_end:0,
            _y_end:0,
            top_val:0,
            left_val:0,
            /*当前下标*/
            index:0,
            /*是否允许动画*/
            run:true,
            /*移动动画*/
            animateMove:function (el,val) {
                if(!this.run){
                    return;
                }
                this.run=false;

                /*CSS3动画方式*/
                el.css({"transform":"translate3d("+doc_width*val+"px,"+photoSwipe.top_val*2.2+"px,0px)","transition-duration":"0.3s"});
                //-- 重新设置层级
                el.css("z-index", loop);
                loop = loop-count;
                let moveTime=setTimeout(function () {
                    //el.remove();

                    el.css("display", "none");
                    photoSwipe.animateReset(el);
                    photoSwipe.run=true;
                },300);
            },
            /*复位动画*/
            animateReset:function (el) {
                /*CSS3动画方式*/
                el.css({"transform":"translate3d(0px,0px,0px)","transition-duration":"0.3s"});
                let resetTime=setTimeout(function () {
                    el.css("transition-duration","0s");
                    el.css("display", "block");
                },500);
            }
        };
        //-- 浏览器当前窗口可视区域宽度和高度
        var doc_width=$(window).width(),doc_height=$(window).height();

        //-- 点击、移动、结束 触摸事件
        $(".unitLayer").on({
            touchstart: function (e) {
                photoSwipe.this = $(this);

                let _touch = e.originalEvent.targetTouches[0];
                photoSwipe._x_start= _touch.pageX;
                photoSwipe._y_start= _touch.pageY;

                let act_el = $(this);
                photoSwipe.run = false;
            },
            touchmove: function (e) {
                e.preventDefault();

                let _touch = e.originalEvent.targetTouches[0];
                photoSwipe._x_move= _touch.pageX;
                photoSwipe._y_move= _touch.pageY;

                let act_el = $(this);
                photoSwipe.top_val=parseFloat(photoSwipe._y_move)-parseFloat(photoSwipe._y_start);
                photoSwipe.left_val=parseFloat(photoSwipe._x_move)-parseFloat(photoSwipe._x_start);

                act_el.css({"transform":"translate3d("+photoSwipe.left_val+"px,"+photoSwipe.top_val+"px,0px)","transition-duration":"0s"});
                photoSwipe.run = true;
            },
            touchend: function (e) {
                let _touch = e.originalEvent.changedTouches[0];
                photoSwipe._x_end= _touch.pageX;
                photoSwipe._y_end= _touch.pageY;

                let act_el = $(this);
                if(photoSwipe.left_val>0 && photoSwipe.left_val>doc_width/2-doc_width/4.5){
                    photoSwipe.animateMove(act_el,1);
                }else if(photoSwipe.left_val<0 && photoSwipe.left_val<-doc_width/2+doc_width/4.5){
                    photoSwipe.animateMove(act_el,-1);
                }else {
                    photoSwipe.animateReset(act_el);
                }
            }
        });
    }

    function member_Detailspage() {
        if ($$.checkLogin()) {
            $$.request({
                url: UrlConfig.member_Detailspage,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success && data.datas) {

                        //-- 新人礼包
                        getIsNewMan();

                        //-- 获取当前用户的VIP信息
                        getVipData();

                        //-- 权限控制
                        // if (data.datas.id === 'jgIl4Ijb7dQ=' || data.datas.id === 'SnpDEWwOGMQ=') {
                        //     //getVipData();
                        //     $(".onlineConsulting").show();
                        // } else {
                        //     $(".onlineConsulting").hide();
                        // }
                    }
                }
            });
        }
    }

    /**
     * 页面授权 获取微信用户opanID
     */
    function getSpenID(){
        //-- 根据weChatOpenId查询用户状态 {有：自动登录，没有：用户授权获取用户微信消息保存并去注册}
        const weChatOpenId = $$.getUrlParam("weChatOpenId");
        if($$.isValidObj(weChatOpenId)){
            $$.request({
                url: UrlConfig.member_weixinbase_matchingOpenId,
                pars:{
                    openId:weChatOpenId
                },
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        if(data.datas.totalCount === 0){
                            //-- 微信页面授权，不存在OpenId跳转注册页面
                            weChatAuthorize();
                        }else{
                            //-- 自动登录后，保存token和memberId，清除手动退出登录的Key
                            const token = data.datas.responseEntity.body[ShawHandler.constant.tokenKey];

                            if(ShawHandler.isValidObj(token)){
                                localStorage.setItem(ShawHandler.constant.tokenKey, token);
                            }
                            localStorage.removeItem($Constant.weChatUserManualExitKey);
                        }
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
            return;
        }
        //-- 用户未登录，静默授权获取openID
        if (!$$.checkLogin()){
            ShawHandler.request({
                url: UrlConfig.weChat_authorize,
                pars: {
                    authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10001,
                    returnUrl: "newIndex.html",
                    businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_4
                },
                loading: true,
                sfn: function(data){
                    ShawHandler.closeLoading();
                    if(data.success){
                        location.href = data.datas;
                    }else {
                        ShawHandler.alert(data.msg);
                    }
                }
            });
        }

        //-- 微信页面授权，不存在OpenId跳转注册页面
        function weChatAuthorize() {
            ShawHandler.request({
                url: UrlConfig.weChat_authorize,
                pars: {
                    authType: ShawHandler.constant.weChatAuthorizeType.TYPE_10002,
                    returnUrl: "login/register.html",
                    businessType: ShawHandler.constant.weChatAuthorizeBusinessType.WX_AUTHORIZE_2,
                },
                loading: true,
                sfn: function(data){
                    ShawHandler.closeLoading();
                    if(data.success){
                        location.href = data.datas;
                    }else {
                        ShawHandler.alert(data.msg);
                    }
                }
            });
        }
    }

    /**
     * 用户登录状态下的消息中心最新消息提示
     */
    function informationCue(){
        //提示状态
        let prompt = true;
        //提示未读消息总数
        let unreadSum = 0;

        /* 获取系统和活动信息未读消息 */
        $$.request({
            url: UrlConfig.sysbase_msg_wxlist,
            pars: {
                prompt:prompt
            },
            method: "POST",
            sfn: function (data) {
                if(data.success){
                    unreadSum = unreadSum + data.datas;
                    feedback(unreadSum);
                } else {
                    $$.layerToast(data.msg);
                }
            }
        });

        function feedback(unreadSum){
            /* 获取意见回复未读消息 */
            $$.request({
                url: UrlConfig.feedback_getOpinionReplyList,
                pars: {
                    prompt:prompt
                },
                method: "POST",
                sfn: function (data) {
                    if(data.success){
                        unreadSum = unreadSum + data.datas;
                        if(unreadSum>0){
                            $(".unreadSum").show().text(unreadSum>99?99:unreadSum);
                        }
                    } else {
                        $$.layerToast(data.msg);
                    }
                }
            });
        }
    }
};
/**
 * 描述信息：投票
 * @author 覃创斌
 * @date 2019/10/25
 */
function vote(id,choice,type) {
    if ($$.checkLogin()){
        countAction("xb_3018");
        $$.request({
            url: UrlConfig.debatevote_insert,
            loading: true,
            pars:{
                debateId:id,
                voteSide:choice
            },
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (data.vote){
                        if (type == 0){
                            $$.push("topicPK/topicPKSelectedDetail",{pei:'left',debateId:id});
                        }else {
                            $$.push("topicPK/topicPKSelectedDetail",{pei:'right',debateId:id});
                        }
                    }else {
                        if (data.list[0].voteSide == 0){
                            $$.push("topicPK/topicPKSelectedDetail",{pei:'right',debateId:id});
                        }else {
                            $$.push("topicPK/topicPKSelectedDetail",{pei:'left',debateId:id});
                        }
                    }


                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }else {
        $$.gotoLogin()
    }

}

//-- 995大礼包
function giftPacks(){
    $(".giftPacks").on("click", function () {
        $('.giftPacksPopup').show();
    });

    //-- 关闭领取
    $(".giftPacksClose").on("click", function () {
        $('.giftPacksPopup').hide();
    });

    //-- 一键领取
    $(".giftPacksReceive").on("click", function () {
        $('.popupContent').hide();
        $('.popupList').show();
    });

    //-- 关闭兑换
    $(".popupClose").on("click", function () {
        $('.giftPacksPopup').hide();
        layer.open({
            content:
                `<div class="popup">
					<div class="popupMessage">优惠卷已存放在积分商城，可前往积分商城兑换~</div>
				</div>`
        });
    });

    //-- 兑换 => 积分商城
    $(".exchange").on("click", function () {
        $$.request({
            url: UrlConfig.checkIn_mailejifen_login,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    window.location.href = data.url;
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    });
}

//-- 获取当前用户的VIP信息
function getVipData() {
    $$.request({
        url: UrlConfig.member_memberVip_getVipData,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                if (data.vipType == 0 || data.vipType == 1){
                    $(".onlineConsulting").show();
                } else if (data.vipType ==2){
                    $(".onlineConsulting").hide();
                }
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}