/**
 *  JS
 * @Author 吴成林
 * @Date
 */
window.onload = function() {
    $$.changeVersion();

    /**
     * 数据存储中心
     */
    const PAGE_STATE = {
        templateType: 1,                // 样式类型
        memberId: null,                 // 用户ID
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){

    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 选择版式
        $('.templateList li').on('click', function () {
            $(this).find('.radioButton').addClass('selected');
            $(this).siblings().find('.radioButton').removeClass('selected');

            let templateType = $(this).attr('data-type');
            PAGE_STATE.templateType = templateType;
        });

        //-- 马上开店
        $('.openAShop').on('click', function () {
            member_Detailspage();       // 会员详情
        });

    }

    //-- 会员详情
    function member_Detailspage() {
        if(!$$.checkLogin()){
            ShawHandler.confirmLogin();
            return;
        }
        $$.request({
            url: UrlConfig.member_Detailspage,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.memberId = data.datas.id;
                    openAShop();
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 马上开店
    function openAShop() {
        let type = parseInt(PAGE_STATE.templateType);
        $$.request({
            url: UrlConfig.management_userShopMainInfo_save,
            pars: {
                "memberId": PAGE_STATE.memberId,
                "styleType": type-1,                   // 店铺风格类型
            },
            requestBody: true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    type == 1 || type == 2 ? type = 1 : type -= 1;
                    $$.push('index/productShop/myStore'+type);
                } else {
                    $$.layerToast(data.msg);
                    setTimeout(function(){
                        $$.closeLoading();
                        myStore();
                    }, 1000);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 我的微店
    function myStore() {
        $$.request({
            url: UrlConfig.management_userShopMainInfo_getUserShopMainList,
            pars: {
                "memberId": PAGE_STATE.memberId,
            },
            requestBody: true,
            sfn: function (data) {
                if (data.success) {
                    const {styleType} = data.data[0];
                    let type = styleType == 0 || styleType == 1 ? 1 : styleType;
                    $$.confirm({
                        title: "前往店铺？",
                        onOkLabel: "确定",
                        onCancelLabel: "取消",
                        onOk: function () {
                            $$.push('index/productShop/myStore'+type);
                        },
                        onCancel: function () {
                            $$.push('newIndex');
                        }
                    });
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
