/**
 * 店铺介绍 JS
 * @Author 吴成林
 * @Date 2020-9-12 20:10:59
 */
window.onload = function() {
    countAction("xb_6006");
    $$.changeVersion();

    /**
     * 数据存储中心
     */
    const PAGE_STATE = {
        memberId: null,             // 登录用户ID
        memberStatus: {             // 用户参数
            mtype: null,
            userStatus: null,
            licenseId: null,
            licenseRegTime: null,
            licenseIssueTime: null,
            licenseIsSubmit: null,
        },
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        viewHeight = window.innerHeight || document.documentElement.clientHeight;    //-- 浏览器高度
        let length = $('.storeBg').height();
        $('.openAShop').css({"top":length*0.84+"px", "height":length*0.055+"px"});
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 去选择模板 - 开启店铺
        $(".openAShop").on("click", function(){
            if ($$.checkLogin()){
                member_Detailspage();           //-- 用户信息
            } else{
                $$.confirmLogin();
            }
        });
    }

    //-- 获取登录用户信息
    function member_Detailspage() {
        if ($$.checkLogin()) {
            $$.request({
                url: UrlConfig.member_Detailspage,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success && data.datas) {
                        const {id, userStatus, mtype, licenseId} = data.datas;
                        PAGE_STATE.memberStatus.userStatus = userStatus;
                        PAGE_STATE.memberStatus.mtype = mtype;
                        PAGE_STATE.memberStatus.licenseId = licenseId;
                        PAGE_STATE.memberId = id;

                        detailsPageMemberDetail();      //-- 获取用户执业编号状态
                    }
                }
            });
        }
    }

    //-- 获取用户执业编号状态
    function detailsPageMemberDetail()  {
        $$.request({
            url: UrlConfig.memberdetail_detailsPageMemberDetail,
            sfn: function(data){
                if (data.success) {
                    const {licenseRegTime, licenseIssueTime, licenseIsSubmit} = data.datas;
                    PAGE_STATE.memberStatus.licenseRegTime = licenseRegTime;
                    PAGE_STATE.memberStatus.licenseIssueTime = licenseIssueTime;
                    PAGE_STATE.memberStatus.licenseIsSubmit = licenseIsSubmit;

                    myStore();
                }
            }
        });
    }

    //-- 我的微店
    function myStore() {
        if(!$$.checkLogin()){
            $$.confirmLogin();
            return;
        }

        const {mtype, userStatus, licenseId, licenseRegTime, licenseIssueTime, licenseIsSubmit} = PAGE_STATE.memberStatus;

        if (mtype != 4 && userStatus != 2){             //你是经纪人
            createConfirm('请先实名认证成为经纪人','实名认证',function() {
                $$.push('my/professionalCertification');
            });
            return;
        } else if (!$$.isValidObj(licenseId)){
            $$.layerToast('您还没有执业认证编号，详情请联系客服~');
        } else if (!$$.isValidObj(licenseRegTime) || !$$.isValidObj(licenseIssueTime) || licenseIsSubmit != 1){
            $$.layerToast('您的执业认证编号审核处理中，详情请联系客服~');
            return;
        }else {
            $$.request({
                url: UrlConfig.management_userShopMainInfo_getUserShopMainList,
                pars: {
                    "memberId": PAGE_STATE.memberId,
                },
                requestBody: true,
                loading: true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        if (data.data.length == 0){
                            $$.push('index/productShop/storeStylesChoose');
                        } else{
                            const {styleType} = data.data[0];
                            if (styleType == -1) {
                                $$.push('index/productShop/storeStylesChoose');
                                return;
                            }
                            let type = styleType == 0 || styleType == 1 ? 1 : styleType;
                            $$.push('index/productShop/myStore'+type);
                        }
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        }
    }

    //-- 提示 公用弹窗
    function createConfirm(title,onOkLabel,onOk) {
        $$.confirm({
            title: title,
            onOkLabel: onOkLabel,
            onCancelLabel: '取消',
            onOk: onOk
        });
    }
}
