/**
 * 我的微店 - 模板1、模板2 JS
 * @Author 吴成林
 * @Date 2020-9-5 13:15:42
 */

/**
 * 分页参数
 * @Author 肖家添
 * @Date 2019/8/22 15:09
 */

(function(){
    $$.loaderRes({
        scripts: [
            "js/tool/qrcode/qrcode.js",
            "js/tool/qrcode/utf.js",
            "js/tool/qrcode/jquery.qrcode.js",
        ]
    });
})();
let pagingData = {
    _pageSize: 10,
    _current: 1,
    _total: 0,
};

window.onload = function() {
    $$.changeVersion();

    /**
     * 数据存储中心
     */
    const PAGE_STATE = {
        shopId: null,                               // 店铺ID
        templateType: 0,                            // 样式类型
        memberId: null,                             // 用户ID
        productList: [],                            // 页面显示的产品列表（productType：0【首推产品】 1【产品列表】）
        productListState: false,                    // 页面显示的产品列表状态
        productListName: [],                        // 修改显示的产品列表
        _productType: 0,                            // 0-主打产品,1-列表产品
        _preferredSelectedProductId: null,          // 一对一选择产品id
        _preferredSelectedProductName: null,        // 一对一选择产品名字
        _preferredProductId: null,                  // 一对一产品 店铺id
        _preferredProductProductId: null,           // 一对一产品 原id
        _selectedSum: 0,                            // 产品列表总数（最多20）
        _selectedProductList: {},                   // 选择产品列表
        _productList: {},                           // 添加产品返回列表
        addProductState: false,                     // 是否添加产品状态
        displayOrder: 0,                            // 展示顺序（0：首推和产品列表，1~n: 一对一产品）
        wholeportState: false,                      // 开启编辑层的状态
        _terminal: 7,                               // 产品端口
        _share: null,                               // 分享
        _shareState: false,                         // 分享状态
        shareQrCodeImage: null,                     // 店铺二维码
        shareToken:null                             // 分享Token
    };

    const shareDatums= {
        url: '',
        image: $Constant.shareLogo,
        title: "小白的小店",
        content: "这是我的小店，快来看看这些适合你的产品吧！"
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){

        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        PAGE_STATE.memberId = $$.getUrlParam('memberId');
        PAGE_STATE._share = $$.getUrlParam('share');

        //-- 初始化页面
        dataLoading();

        //-- 绑定事件
        eventBinding();

    }

    /**
     * 数据加载
     */
    function dataLoading(){
        if (PAGE_STATE._share == 'true'){
            if ($$.isValidObj(PAGE_STATE.memberId)){
                PAGE_STATE._shareState = true;

                //-- 设置访客页面状态
                setSharePageState();

                myStore();
                //-- 微信分享
                weChatShare();

                //-- 加载二维码
                (function(){
                    const shareQrCodeId = "shareQrCode";
                    if(!PAGE_STATE.shareQrCodeImage){
                        const ele = $(`#${shareQrCodeId}`);
                        ele.qrcode({
                            text: getShareLink(),
                            render : "canvas",                                  // 设置渲染方式，有table和canvas
                            background : "#ffffff",                             // 二维码的后景色
                            foreground : "#000000",                             // 二维码的前景色
                            width: 200,
                            height: 200,
                            src: "../../../images/product/detail/03.png"
                        });
                    }
                })();
            } else{
                //-- 打开登录页面，登录完成会跳转回当前页面
                $$.gotoLogin();
            }
        } else {
            member_Detailspage();
        }

        //-- 加载险种分类
        findInsuranceType();

        //-- 清理HTML注释
        $$.clearHTMLNotes();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 点击阴影层关闭
        $(".shadow").on("click", function(){
            if (PAGE_STATE.addProductState) window.location.reload();
            if ($(this).parent('div').hasClass('prompt'))  $('.prompt').hide();
            if ($(this).parent('div').hasClass('addProductPrompt')) $('.addProductPrompt').hide();
        });

        //-- 编辑店铺名
        $('.shopName').on('click', function () {
            if (PAGE_STATE._shareState) return false;
            $('.prompt').show().find('.promptTitle').html('请输入你的店铺名称');
            let html = `<input id="shopName" type="text" maxlength="12" placeholder="限12字内" /><div class="save">保存</div>`;
            $('.prompt .promptContent').html(html);

            //-- 保存
            $('.save').on('click', function () {
                let title = $(this).siblings('#shopName').val().trim();

                if (title != ''){
                    updateUserShop(title);
                    $('.prompt').hide();
                } else {
                    $$.layerToast('店铺名不能为空~');
                    $(this).siblings('#shopName').val('');
                }
            });
        });

        //-- 编辑推荐产品
        $('.wholeportRecommended').on('click', function () {
            PAGE_STATE.wholeportState = true;
            $('.preferredRecommended').click();
        });

        //-- 编辑首选产品
        $('.preferredRecommended, .products1, .products2, .products3, .products4').on('click', function () {
            let id = $(this).attr('data-id');
            let productId = $(this).attr('data-productid');
            let sellId = $(this).attr('data-sellId');
            let name = $(this).attr('data-name');
            let displayOrder = $(this).attr('data-displayOrder');
            let title = $(this).children('span').attr("data-title");

            if (!$$.isValidObj(id) || title == '首选推荐—点击编辑' || title == '点击新增') title = '';

            PAGE_STATE._preferredProductId = id;
            PAGE_STATE._preferredSelectedProductName = name;
            PAGE_STATE._preferredProductProductId = productId;

            if ($$.isValidObj(productId) && $$.isValidObj(sellId) && !PAGE_STATE.wholeportState){
                $$.push("product/productDetail", {productId, sellId, terminal: PAGE_STATE._terminal, beShareToken: PAGE_STATE.shareToken});
            } else{
                if (PAGE_STATE._shareState) return false;
                if ('0,1'.includes(PAGE_STATE.templateType)){
                    PAGE_STATE.displayOrder = 0;
                    $('.prompt').show().find('.promptTitle').html('首推产品');
                } else{
                    if ($$.isValidObj(displayOrder)){
                        PAGE_STATE.displayOrder = parseInt(displayOrder);
                        $('.prompt').show().find('.promptTitle').html('新增产品');
                    } else{
                        PAGE_STATE.displayOrder = 0;
                        $('.prompt').show().find('.promptTitle').html('首推产品');
                    }
                }
            }

            let html = `<div class="flex-start">
                            <span class="leftName">请输入封面标语：</span>
                            <input id="recommendName" type="text" maxlength="12" placeholder="限12字内" />
                        </div>
                        <div class="flex-start">
                            <span class="leftName">请挑选保险产品：</span>
                            <div class="space-around rightOption">
                                <div class="addProduct">添加</div>
                                <div class="reset">重置</div>
                            </div>
                        </div>
                        <div class="selectedProduct">${$$.isValidObj(name) ? name : ``}</div>
                        <div class="space-between bottomOption">
                            <div class="cancel">取消</div>
                            <div class="submit">提交</div>
                        </div>`;
            $('.prompt .promptContent').html(html);
            $('#recommendName').val(title);

            //-- 添加
            $('.rightOption .addProduct').on('click', function (e) {
                e.stopPropagation();
                PAGE_STATE._productType = 0;

                pagingData._current = 1;
                pagingData._pageSize = 10;
                pagingData._total = 0;
                $(".content>.list").html('');

                findInsuranceInfo(true, true, null, true);  //-- 加载产品库
                $('.addProductPrompt').show();
            });

            //-- 重置
            $('.reset').on('click', function () {
                const {shopId, _preferredProductId, _preferredProductProductId} = PAGE_STATE;
                if (!$$.isValidObj(_preferredProductProductId)) return;

                let params = {shopId, productId: _preferredProductProductId};
                if ($$.isValidObj(_preferredProductId)) params['id'] = parseInt(_preferredProductId);
                let operatingState = 1;

                //-- 排序值，无：首推产品，有：一对一产品
                $$.isValidObj(displayOrder) ? updateUserShopProduct(1, 1, parseInt(displayOrder),0, operatingState, params) : updateUserShopProduct(1, 0, 0,0, operatingState, params);

                $('.selectedProduct').text('');
                PAGE_STATE._preferredSelectedProductId = null;
                PAGE_STATE._preferredSelectedProductName = null;
            });

            //-- 提交
            $('.submit').on('click', function () {
                let title = $('#recommendName').val();
                const {shopId, _preferredProductId} = PAGE_STATE;
                let params = {shopId, title};
                if ($$.isValidObj(_preferredProductId)) params['id'] = parseInt(_preferredProductId);
                let operatingState = 0;

                //-- 排序值，无：首推产品，有：一对一产品
                $$.isValidObj(displayOrder) ? updateUserShopProduct(1, 1, parseInt(displayOrder),0, operatingState, params) : updateUserShopProduct(1,0, 0,0, operatingState, params);

            });

            //-- 取消
            $('.cancel').on('click', function () {
                if (PAGE_STATE.addProductState) window.location.reload();
                $('.prompt').hide();
            });
        });

        //-- 编辑 新增产品
        $(".empty .addProduct, .wholeport").on('click', function(){
            if (PAGE_STATE._shareState) return false;
            $('.prompt').show().find('.promptTitle').html('新增产品');

            let html = `<div class="flex-start">
                            <span class="leftName">请挑选保险产品：</span>
                            <div class="space-around rightOption">
                                <div class="addProduct">添加</div>
                                <div class="reset">重置</div>
                            </div>
                        </div>
                        <div class="selectedProduct">
                            <ul class="selectedProductList">
                                ${selectedProductLists()}
                            </ul>
                        </div>
                        <div class="space-between bottomOption">
                            <div class="cancel">取消</div>
                            <div class="submit">提交</div>
                        </div>`;
            $('.prompt .promptContent').addClass('recommend').html(html);

            //-- 添加
            $('.rightOption .addProduct').on('click', function (e) {
                e.stopPropagation();
                PAGE_STATE._productType = 1;

                pagingData._current = 1;
                pagingData._pageSize = 10;
                pagingData._total = 0;
                $(".content>.list").html('');
                findInsuranceInfo(true, true, null, true);  //-- 加载产品库
                $('.addProductPrompt').show();
            });

            //-- 重置
            $('.reset').on('click', function () {
                const {_productList} = PAGE_STATE;
                let operatingState = 1;
                if (Object.keys(_productList).length > 0){
                    for (let i in _productList){
                        updateUserShopProduct(0, 1, 0, 0, operatingState,{id: _productList[i], shopId: PAGE_STATE.shopId});
                    }

                    $('.selectedProduct .selectedProductList').html('');
                    PAGE_STATE._selectedSum = 0;
                    PAGE_STATE._selectedProductList = {};
                    PAGE_STATE._productList = {};
                }
            });

            //-- 提交
            $('.submit').on('click', function () {
                window.location.reload();
            });

            //-- 取消
            $('.cancel').on('click', function () {
                if (PAGE_STATE.addProductState) window.location.reload();
                $('.prompt').hide();
            });

            //-- 下架
            $('.fromTheShelves').on('click', function () {
                let id = $(this).parent('li').attr('data-id');
                let operatingState = 2;
                updateUserShopProduct(0, 1, 0,1, operatingState,{id: id, shopId: PAGE_STATE.shopId});
            });
        });

        //-- 开启编辑点击层
        $(".wholeportPopup").on("click", function () {
            if (PAGE_STATE._shareState) return false;
            if ($(".clickLayer").is(":hidden")) {
                $(".clickLayer").show();
                PAGE_STATE.wholeportState = true;
            } else{
                $(".clickLayer").hide();
                PAGE_STATE.wholeportState = false;
            }
        });

        //-- 点击编辑层
        $(".clickLayer").on("click", function (e) {
            e.stopPropagation();
            if (PAGE_STATE._shareState) return false;
            $(this).parent().click();
        });

        //-- 显示/隐藏 险种分类
        $(".selectWrapper>span:first-child").off().on("click", function (e) {
            e.stopPropagation();

            $("#searchWrap").toggleClass("show");
        });

        //-- 点击视窗关闭 险种分类
        document.onclick = function () {
            $("#searchWrap").removeClass("show");
        };

        //-- 选中 险种分类
        $("#searchCon").off().on("click", ".search-tit", function () {
            $(".search-tit").removeClass("choose-search");
            $(this).addClass('choose-search');
            $(".select").text($(this).text());
            $("#searchWrap").removeClass("show");

            pagingData._current = 1;
            pagingData._pageSize = 10;
            pagingData._total = 0;$(".content>.list").html('');
            $(".content>.list").html('');
            findInsuranceInfo(true, true);
        });

        //-- 页面滚动事件监听
        $('.content').scroll(function () {
            if ($('.content').scrollTop() == $('.content').prop('scrollHeight') - $('.content').prop('offsetHeight')) {
                let { _current, _pageSize, _total } = pagingData;

                //-- 总页数
                const sumPageNum = Math.ceil(_total / _pageSize);

                if(_current >= sumPageNum){
                    return;
                }

                if($(".pageLoading").size() > 0){
                    return;
                }

                pagingData._current++;

                $(".content>.list").append(`<p class="pageLoading" style="text-align: center;font-size: 14px;margin: 15px 0px;">加载中...</p>`);
                findInsuranceInfo(false, false, function(){
                    $(".pageLoading").remove();
                }, true);
            }
        });

        //-- 搜索
        $(".searchIcon").off().click(function(){
            findInsuranceInfo(true, true);
        });

        //-- 搜索内容输入监听
        $Listener.inputValListener(".search", function(e){
            const thisVal = $(e).val();

            if($$.isValidObj(thisVal)){
                $(".searchIcon").stop().fadeIn();
            }else if($(".content .list li").size() > 0 && !$(e).is(":focus")){
                $(".searchIcon").stop().fadeOut();
            }
        });

        //-- 搜索表单
        $("#searchForm").submit(function(){
            $(".searchIcon").click();
            return false;
        });

        //-- 确定 选择产品
        $(".confirm").on('click', function(){
            addProductList();
        });

        //-- 切换模板
        $(".switchTemplate").on('click', function(){
            if (PAGE_STATE._shareState) return false;
            $$.confirm({
                title: "切换模板将导致您的上架产品全部清空，需要再次添加，确定切换模板？",
                onOk: function () {
                    resetProductList();
                }
            });
        });

        //-- 分享
        $Listener.onTap(".share", () => {
            shareHandler();
        });

        //-- 分享二维码
        $(".shareOfQrCode").unbind("click").click(function(){
            if(!PAGE_STATE.shareQrCodeImage){
                const base64 = $(`#shareQrCode`).find("canvas")[0].toDataURL('image/jpeg');
                PAGE_STATE.shareQrCodeImage = base64;
            }
            layer.open({
                area:"200px",
                content:
                    `<div class="popupContent">
						<div class="question">
						    <div style="font-size: 17px;color: #333333;font-weight: bold;margin-bottom: 10px;">店铺二维码</div>
							<img src="${PAGE_STATE.shareQrCodeImage}" style="height:200px;width:200px;margin:0 auto;" />
							<span style="display: inline-block;padding-top: 15px">长按识别二维码保存</span>
						</div>
					</div>`
            });
        });
    }

    //-- 加载新增产品弹窗列表
    function selectedProductLists() {
        let html = ``;
        const {_productList} = PAGE_STATE;
        if (Object.keys(_productList).length < 1) return html;

        for (let i in _productList){
            html += `<li class="space-between" data-id="${_productList[i]}">
                                <span>${i}</span>
                                <span class="fromTheShelves">下架</span>
                            </li>`;
        }
        return html;
    }

    //-- 会员详情
    function member_Detailspage() {
        if($$.checkLogin()){
            $$.request({
                url: UrlConfig.member_Detailspage,
                loading: true,
                sfn: function (data) {
                    if (data.success) {
                        const {id, rname, imgPath} = data.datas;
                        PAGE_STATE.memberId = id;
                        if ($$.isValidObj(rname)) shareDatums.title = rname+"的小店";
                        if ($$.isValidObj(imgPath)) shareDatums.image = imgPath;

                        myStore();

                        let _lineLink = window.location.href.split("?")[0];
                        _lineLink += $$.jsonToUrlParams({
                            share: true,
                            memberId: id
                        });
                        shareDatums.url = _lineLink;
                        //-- 微信分享
                        weChatShare();

                        //-- 加载二维码
                        (function(){
                            const shareQrCodeId = "shareQrCode";
                            if(!PAGE_STATE.shareQrCodeImage){
                                const ele = $(`#${shareQrCodeId}`);
                                ele.qrcode({
                                    text: getShareLink(),
                                    render : "canvas",                                  // 设置渲染方式，有table和canvas
                                    background : "#ffffff",                             // 二维码的后景色
                                    foreground : "#000000",                             // 二维码的前景色
                                    width: 200,
                                    height: 200,
                                    src: "../../../images/product/detail/03.png"
                                });
                            }
                        })();
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        } else{
            //-- 打开登录页面，登录完成会跳转回当前页面
            $$.gotoLogin();
        }
    }

    //-- 我的微店
    function myStore() {
        $$.request({
            url: UrlConfig.management_userShopMainInfo_getUserShopMainList,
            pars: {
                "memberId": PAGE_STATE.memberId,
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (Object.keys(data).length < 1) {
                        $$.push('newIndex');
                        $$.alert('店主暂未开店或者已注销店铺~', function () {
                            $$.push('newIndex');
                        });
                    }

                    const {rid, title, phone, styleType, productList, productListName, terminal,shareToken} = data.data[0];
                    PAGE_STATE.templateType = styleType;
                    let countActionId = 'xb_6007';
                    switch (styleType) {
                        case 2:
                            countActionId = 'xb_6008';
                            break;
                        case 3:
                            countActionId = 'xb_6009';
                            break;
                        case 4:
                            countActionId = 'xb_6010';
                            break;
                    }
                    countAction(countActionId);
                    PAGE_STATE.terminal = terminal;
                    PAGE_STATE.shareToken = shareToken;
                    let type = $('.wrapper').attr('data-type');
                    if (!type.includes(styleType.toString())){
                        $$.alert('该店铺链接已失效，请联系店主获取最新店铺链接~', function () {
                            $$.push('newIndex');
                        });
                    }

                    for (let i in productListName){
                        const {id, name, productType} = productListName[i];
                        if (productType == 1){
                            PAGE_STATE._productList[name] = id;
                        }
                    }

                    if (PAGE_STATE.addProductState){
                        $('.addProductPrompt').hide();
                        $('.selectedProductList').html(selectedProductLists());

                        //-- 下架
                        $('.fromTheShelves').on('click', function () {
                            let id = $(this).parent('li').attr('data-id');
                            let operatingState = 2;
                            updateUserShopProduct(0, 1, 0,1, operatingState,{id: id, shopId: PAGE_STATE.shopId});
                        });
                    } else{
                        PAGE_STATE.shopId = rid;

                        $('.shopName').html(title);
                        $('.contactOwner span').html(phone);

                        switch (styleType) {
                            case 0:{
                                $('.preferredRecommended').css('background', 'url("../../../images/home/newIndex/store/storeStyles-1-bg.png") no-repeat center /100% 100%');
                                break;
                            }
                            case 1:{
                                $('.productsList2').css('display', 'flex');
                                $('.productsList1').hide();
                                $('.preferredRecommended').css('background', 'url("../../../images/home/newIndex/store/storeStyles-2-bg.png") no-repeat center /100% 100%');
                                break;
                            }
                            case 2:{
                                $('.preferredRecommended').css('background', 'url("../../../images/home/newIndex/store/storeStyles-3-0.png") no-repeat center /100% 100%');
                                break;
                            }
                            case 3:{
                                $('.preferredRecommended').css('background', 'url("../../../images/home/newIndex/store/storeStyles-4-0.png") no-repeat center /100% 100%');
                                break;
                            }
                        }

                        if (productList.length == 0){
                            $('.empty').show();
                            if (PAGE_STATE._shareState){
                                $('.addProduct').hide();
                                $('.emptyPrompt').html('店家暂无添加产品');
                            }
                        } else{
                            PAGE_STATE.productList = productList;
                            loadStoreInfo(styleType, productList);
                        }
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });

        //-- 加载店铺产品详情
        function loadStoreInfo(styleType, list) {
            let html = ``;
            for (let i in list){
                const {productType, name, title, productId, sellId, rpid, listShowCover, type, introduce, displayOrder} = list[i];
                if (productType == 0){
                    $('.preferredRecommended').attr({'data-id': rpid, 'data-productId': productId, 'data-sellId': $$.isValidObj(sellId) ? sellId[0].sellId : '', 'data-name': name});
                    if ($$.isValidObj(title) || $$.isValidObj(productId)) $('.preferredRecommended').children('span').text($$.isValidObj(title) ? title : name).attr('data-title', title);
                } else{
                    PAGE_STATE.productListState = true;
                    if (styleType == 0){
                        html += `<li class="space-between" data-id="${rpid}" data-productId="${productId}" data-sellId="${$$.isValidObj(sellId) ? sellId[0].sellId : ''}" data-name="${name}">
                                    <img src="${listShowCover}" alt="暂无图片">
                                    <div>
                                        <div class="topicTitle overflow">${name}</div>
                                        <div class="insuranceTypeList">
                                            ${$$.isValidObj(type) ? `<span>${type}</span>` : `<span style="background: #FFFFFF"></span>`}
                                        </div>
                                        <div class="introduce overflow">${introduce}</div>
                                    </div>
                                </li>`;
                    } else if (styleType == 1){
                        html += `<li data-id="${rpid}" data-productId="${productId}" data-sellId="${$$.isValidObj(sellId) ? sellId[0].sellId : ''}" data-name="${name}">
                                    <img src="${listShowCover}" alt="暂无图片">
                                    <div>
                                        <div class="topicTitle overflow">${name}</div>
                                        <div class="introduce overflow" style="margin-top: 6px">${introduce}</div>
                                    </div>
                                </li>`;
                    } else if (styleType == 2 || styleType == 3){
                        $(`.products${displayOrder}`).attr({'data-id': rpid, 'data-productId': productId, 'data-sellId': $$.isValidObj(sellId) ? sellId[0].sellId : '', 'data-name': name});
                        if ($$.isValidObj(title) || $$.isValidObj(productId)) $(`.products${displayOrder}`).children('span').text($$.isValidObj(title) ? title : name).attr('data-title', title);
                    }
                }
            }
            if (styleType == 0) $('.productsList1').html(html);
            if (styleType == 1) $('.productsList2').html(html);

            if (!PAGE_STATE.productListState) {
                $('.empty').show();
                if (PAGE_STATE._shareState){
                    $('.addProduct').hide();
                    $('.emptyPrompt').html('店家暂无添加产品');
                }
            }

            //-- 点击 - 产品详情
            $(".productsList1 li, .productsList2 li").on("click", function(){
                let productId = $(this).attr('data-productid');
                let sellId = $(this).attr('data-sellId');
                $$.push("product/productDetail", {productId, sellId, terminal: PAGE_STATE._terminal, beShareToken: PAGE_STATE.shareToken});
            });
        }
    }

    /**
     * 获取险种分类
     * @Author 吴成林
     * @Date 2020-9-8 09:59:47
     */
    function findInsuranceType(){
        $$.request({
            url: UrlConfig.insuranceType_data,
            method: "GET",
            sfn: function(data){
                if(data.success){
                    bindInsuranceTypeElement(data.datas);
                }else{
                    $$.layerToast(`获取险种分类失败！[${data.msg}]`);
                }
            }
        });

        /**
         * 绑定险种元素
         * @Author 吴成林
         * @Date 2020-9-8 14:53:36
         */
        function bindInsuranceTypeElement(data){
            $("#searchCon>li:gt(0)").off().remove();
            let html = "";

            if($$.isValidObj(data)){
                data.forEach((item) => {
                    let insuranceTypeList = [0, 1, 3, 4, 19, 24];
                    if(insuranceTypeList.indexOf(item.id) == -1) return;
                    html += `
                        <li>
                            <a href="javascript:;" class="search-tit" data-id="${item.id}">${item.type}</a>
                        </li>                        
                    `;
                });
            }

            $("#searchCon").append(html);
        }
    }

    /**
     * 获取产品库
     * @Author 吴成林
     * @Date 2020-9-8 14:53:26
     */
    function findInsuranceInfo(loading = true, clearList = false, overCallback, isPageLoad = false){
        let params = JSON.parse(JSON.stringify(pagingData));
        let { insuranceType } = PAGE_STATE;

        //-- params handler
        (function(){
            //-- 险种分类
            const insuranceTypeId = $(".search-tit.choose-search").attr("data-id");
            if(insuranceTypeId == 19 || insuranceTypeId == 20){
                params.insuranceType = 2;
            }else{
                if($$.isValidObj(insuranceTypeId)){
                    params["insuranceTypeId"] = insuranceTypeId;
                }else{
                    //-- 险种类型, [1: 个人险, 2: 企业险]
                    if(isPageLoad)
                        params.insuranceType = insuranceType;
                }
            }

            //-- 产品库名称
            const insuranceInfoName = $(".search").val();
            if($$.isValidObj(insuranceInfoName)){
                params["insuranceInfoName"] = insuranceInfoName;
            }

            if(clearList){
                pagingData._current = 1;
                params._current = 1;
            }
        })();

        $$.request({
            url: UrlConfig.insuranceInfo_data,
            loading: loading,
            pars: params,
            sfn: function(data){
                $$.closeLoading();
                if(data.success){
                    const { list, pagination } = data.datas;

                    bindInsuranceInfoElement(list, pagination);
                }else{
                    $$.errorHandler(`获取产品失败！[${data.msg}]`);
                }
            }
        });

        /**
         * 绑定保险产品元素
         * @Author 吴成林
         * @Date 2020-9-8 14:53:22
         */
        function bindInsuranceInfoElement(list, pagination){
            try{
                //-- paging handler
                (function(){
                    pagingData._current = pagination.current;
                    pagingData._pageSize = pagination.pageSize;
                    pagingData._total = pagination.total;
                })();

                //-- html handler
                (function(){
                    let html = "";
                    if($$.isValidObj(list)){
                        $$.hideNoResultView();

                        list.forEach((item) => {

                            const {labelList } = item;

                            //-- product labels handler start
                            let labelsHtml = "";
                            if($$.isValidObj(labelList)){
                                labelList.forEach((item) => {
                                    const { labelName } = item;
                                    labelsHtml += `<span>${labelName}</span>`;
                                });
                            }
                            //-- product labels handler end

                            const {id, name, insuranceInfoId, ageType, sellMoney, tiMoney} = item;
                            html += `<li data-id="${insuranceInfoId}">
                                        <div class="unselected"></div>
                                        <div>
                                            <div class="productName">${name}${(insuranceInfoId === 100155 || insuranceInfoId === 100153) ? (ageType === 1 ? "（成年版）" : "（未成年版）") : ''}</div>
                                            <div class="bottom space-between">
                                                <p class="price">${parseFloat($$.changeIsNilVal(sellMoney, 0)).toFixed(2)}元起</p>
                                                <p class="makeProfits">立赚${$$.changeIsNilVal(tiMoney, 0)}%</p>
                                                ${true ? `` : `<p class="viewDetails" data-productId="${insuranceInfoId}" data-sellId="${id}">查看详情</p>`}
                                            </div>
                                        </div>
                                    </li>`;
                        });
                    }else if(list.length <= 0){
                        $$.showNoResultView({
                            msg: "搜索不到该产品"
                        });
                    }

                    if(clearList){
                        $(".content>.list").html(html);
                    }else{
                        $(".content>.list").append(html);
                    }

                    $(".viewDetails").on("click", function(e){
                        e.stopPropagation();
                        let productId = $(this).attr('data-productid');
                        let sellId = $(this).attr('data-sellId');
                        $$.push("product/productDetail", {productId, sellId, terminal: PAGE_STATE._terminal});
                    });

                    //-- 选择产品
                    $(".content .list li").off().click(function () {
                        let id = $(this).attr('data-id');
                        let name = $(this).find('.productName').text();
                        let selectedType = $(this).children('div:first').hasClass('unselected');

                        if (PAGE_STATE._productType == 0){
                            if (selectedType){
                                $(this).children("div:first").addClass("selected").removeClass("unselected");
                                PAGE_STATE._preferredSelectedProductId = id;
                                PAGE_STATE._preferredSelectedProductName = name;
                                PAGE_STATE._preferredProductProductId = id;
                            } else {
                                $(this).children("div:first").addClass("unselected").removeClass("selected");
                                PAGE_STATE._preferredSelectedProductId = null;
                                PAGE_STATE._preferredSelectedProductName = null;
                                PAGE_STATE._preferredProductProductId = null;
                            }
                            $(this).siblings('li').children("div:nth-child(1)").addClass("unselected").removeClass("selected");
                        } else{
                            if (selectedType){
                                PAGE_STATE._selectedSum++;
                                if (PAGE_STATE._selectedSum > 20){   //-- 产品 最多可选20个
                                    PAGE_STATE._selectedSum = 20;
                                    $$.layerToast("产品最多可选20个~");
                                } else {
                                    PAGE_STATE._selectedProductList[name] = id;
                                    $(this).children("div:first").removeClass("unselected").addClass("selected");
                                }
                            } else {
                                PAGE_STATE._selectedSum--;
                                delete PAGE_STATE._selectedProductList[name];
                                $(this).children("div:first").removeClass("selected").addClass("unselected");
                            }
                        }
                    });
                })();
            }catch (e) {
                console.error(e);
            }finally {
                $$.closeLoading();
                $$.clearHTMLNotes();

                if(overCallback) overCallback();
            }
        }
    }

    /**
     * 修改店铺名称（title）、修改店铺类型（styleType = -1）
     * @Author 吴成林
     * @Date 2020-9-8 14:53:26
     */
    function updateUserShop(title, styleType = null) {
        $$.request({
            url: UrlConfig.management_userShopMainInfo_updateUserShop,
            pars: {
                id: PAGE_STATE.shopId,
                title: title,
                styleType: styleType,
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (styleType == -1){
                        $$.push('index/productShop/storeStylesChoose');
                    } else {
                        $$.alert('修改店铺名称成功~', function () {
                            window.location.reload();
                        });
                    }
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 添加产品列表
     * @Author 吴成林
     * @Date 2020-9-8 14:53:26
     */
    function addProductList() {
        let idList = [];
        const {_preferredSelectedProductId, _preferredSelectedProductName, _selectedProductList} = PAGE_STATE;
        if (PAGE_STATE._productType == 0){
            if (!$$.isValidObj(_preferredSelectedProductId)) {
                $$.layerToast('请选择最少一个产品');
                return false;
            }
            $('.selectedProduct').text(_preferredSelectedProductName);
            idList.push(_preferredSelectedProductId);
        } else {
            if (Object.keys(_selectedProductList).length < 1) {
                $$.layerToast('请选择最少一个产品');
                return false;
            }
            for (let i in _selectedProductList){
                idList.push(_selectedProductList[i]);
            }
        }

        const {shopId, _productType, displayOrder} = PAGE_STATE;
        let productType = parseInt(PAGE_STATE.displayOrder) == 0 ? PAGE_STATE._productType : 1;
        $$.request({
            url: UrlConfig.management_userShopProductInfo_save,
            pars: {
                "shopId": shopId,
                "productId": idList.join(','),                          // 选择的产品id
                "productType": productType,                             // 0-主打产品,1-列表产品
                "displayOrder": parseInt(displayOrder),
                "isenabled": 1
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $$.layerToast("添加产品成功");

                    PAGE_STATE.addProductState = true;
                    PAGE_STATE._selectedProductList = {};
                    PAGE_STATE._productList = {};
                    myStore();
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 重置店铺全部产品
     * @Author 吴成林
     * @Date 2020-9-8 14:53:26
     */
    function resetProductList() {
        $$.request({
            url: UrlConfig.management_userShopProductInfo_resetUserShopProduct,
            pars: {
                "shopId": PAGE_STATE.shopId,
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                if (data.success) {
                    updateUserShop(null, -1);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 修改产品
     * @Author 吴成林
     * @Date 2020-9-8 14:53:26
     */
    function updateUserShopProduct(isenabled= 1, productType= 0, displayOrder= 0, promptState = 0, operatingState = 0, ...params) {
        $$.request({
            url: UrlConfig.management_userShopProductInfo_updateUserShopProduct,
            pars: {
                isenabled,
                productType,
                displayOrder,
                ...params[0],
            },
            loading: true,
            requestBody: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    //-- operatingState [0: 提交、1：重置、 2：下架、]
                    let prompt = '已重置';
                    switch (operatingState) {
                        case 0:{
                            $$.layerToast('修改成功');
                            setTimeout(function () {
                                window.location.reload();
                            }, 1000);
                            break;
                        }
                        case 1:{
                            $$.layerToast(prompt);
                            break;
                        }
                        case 2:{
                            prompt = '已下架';
                            $(`.selectedProductList li[data-id=${params[0].id}]`).remove();
                            $$.layerToast(prompt);
                            break;
                        }
                    }
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 微信分享
     * @Author 吴成林
     * @Date 2020-9-14 16:12:06
     */
    function weChatShare(){
        if (!$WeChat.isWx() && !PAGE_APP) return;
        const { url, image, title, content } = shareDatums;
        weChatJSTool.share({
            _imgUrl: image,
            _lineLink: url,
            _shareTitle: title,
            _descContent: content,
            _sfn: function () { }
        });
    }

    /**
     * 分享处理(APP和H5)
     * @Author 吴成林
     * @Date 2020-9-14 17:02:46
     */
    function shareHandler(){
        if(PAGE_APP){
            //-- APP
            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            //-- 分享
            $$.showShareView('点击右上角，分享店铺给好友~');
        }
    }

    //-- 访客页面状态
    function setSharePageState() {
        $('.wholeport').hide();
        $('.wholeportRecommended').hide();
        $('.switchTemplate').hide();
        $('.wholeportPopup').hide();

        if ($('.shopName').html() == '请编辑您的店铺名') $('.shopName').html('');
        let preferredRecommendedId = $('.preferredRecommended').attr('data-id');
        let products1Id = $('.products1').attr('data-id');
        let products2Id = $('.products2').attr('data-id');
        let products3Id = $('.products3').attr('data-id');
        let products4Id = $('.products4').attr('data-id');

        if (!$$.isValidObj(preferredRecommendedId)) $('.preferredRecommended').children('span').html('店家暂未添加推荐产品');
        if (!$$.isValidObj(products1Id)) $('.products1').children('span').html('店家暂未添加产品');
        if (!$$.isValidObj(products2Id)) $('.products2').children('span').html('店家暂未添加产品');
        if (!$$.isValidObj(products3Id)) $('.products3').children('span').html('店家暂未添加产品');
        if (!$$.isValidObj(products4Id)) $('.products4').children('span').html('店家暂未添加产品');
    }

    //-- 获取分享链接
    function getShareLink(){
        let linkUrl = window.location.href.split("?")[0];
        linkUrl += $$.jsonToUrlParams({
            share: true,
            memberId: PAGE_STATE.memberId
        });
        return linkUrl;
    }

};
