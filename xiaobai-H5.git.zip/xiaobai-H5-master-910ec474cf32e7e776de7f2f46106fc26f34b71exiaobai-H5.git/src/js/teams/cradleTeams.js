//获取当前年份
let myDate = new Date();
let year = myDate.getFullYear(); //获取当前年
let mon = myDate.getMonth() + 1; //获取当前月
mon = mon < 10 ? '0' + mon : mon;
let yearsMonth = year + "-" + mon; //年-月
let finishTime = "2019-12";

let teamId = 0; //团队ID

window.onload = function() {

	$(".model_1>.date>.time").text(yearsMonth);

	teamLoad();
};

//获取育成团截止时间的团队列表
function modelLoadYuChengTeamNumber(month) {
	//获取当前年-月
	if(month !== "") {
		yearsMonth = month;
	}
	/* 获取育成团截止时间的团队列表 */
	$$.request({
		url: UrlConfig.market_teamsubsidy_getAffiliateTeamList,
		pars: {
			teamId: teamId,
			yearsMonth: yearsMonth,
		},
		requestBody: true,
		loading: true,
		sfn: function(data) {
			$$.closeLoading();
			if(data.success) {
				console.log(data);

				//加载页面内容
				modelLoad(data);
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function(data) {
			$$.errorHandler();
		}
	});
}

function modelLoad(data) {
	$('.model_2').html("");
	let html = "";
	if(data.datas.length !== 0) {
		for(let i in data.datas){
			html +=
			`<div class="team">
				<div class="listTeam">
					<div class="portrait">
						<img src="${data.datas[i].flagPath}" />
					</div>
					<div class="msg">
						<div class="teamName">${data.datas[i].tname}</div>
						<div class="teamDate">2019-9-27</div>
					</div>
					<div class="teamNumber">
						<div class="peopleNumber">
							<div class="left">人数:</div>
							<div class="right">
								<div>${data.datas[i].teamMemberCount}</div>
							</div>
						</div>
						<div class="issueNumber">
							<div class="left">出单数:</div>
							<div class="right">
								<div>${data.datas[i].ocount}</div>
							</div>
						</div>
						<div class="premium">
							<div class="left">保费(元):</div>
							<div class="right">
								<div>${data.datas[i].teamSaleAmount > 9999 ?(((data.datas[i].teamSaleAmount%100)/10000+'万')):(data.datas[i].teamSaleAmount)}</div>
							</div>
						</div>
					</div>
				</div>
			</div>`;
			$('.model_2').append(html);
		}
	}

	//加载育成团队总数
	getTeamsLength();
}

function getTeamsLength() {
	let length = $('.team').length;
	$('.count').text(length)
}
function teamLoad() {
	/* 从加团页面传值 */
	teamId = decodeURIComponent($$.getUrlParam("teamId"));
	$$.request({
		url: UrlConfig.market_team_wx_show,
		pars:{
			teamId:teamId,
		},
		requestBody:true,
		loading: true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				finishTime = data.finishTime + "-01";

				//获取育成团截止时间的团队列表
				modelLoadYuChengTeamNumber(month = "");

				timeBtn();
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}
function timeBtn() {
	$('.time').click(() => {
		let yearsMonth = year + "-" + mon + "-01";	//年-月-日
		weui.datePicker({
			id: 1,
			start: finishTime,
			depth: 2,
			end: yearsMonth,
			onConfirm: function(result) {
				let month = String(result[1].value);
				if(month.length === 1) {
					month = month.padStart(2, "0"); //字符串补全
				}
				let time = result[0] + "-" + month;
				$('.model_1>.date>.time').html(time + `<div class="across"></div>`);

				modelLoadYuChengTeamNumber(time);
			}
		})
	});
}
