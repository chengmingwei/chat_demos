﻿let value = '';
let cityDatum = new Array();
let provinceDatum = new Array();
let pageTotal = 0;
let teamCount = 0;
let currentPage = 1;
let pageSize = 10;
let queryType = 0;
let provinceId = '';
let cityId = '';
let teamName = '';
$(() => {

    /*加载页面*/
    htmlLoad();

    /*选择省份*/
    $("#province").click(function () {
        $(this).children(".vertical").css("background-color", "#FF7B5F");
        $(".recommend").children(".vertical").css("background-color", "white");
        $(".city").children(".vertical").css("background-color", "white");
        const dataSource = provinceAddr();
        weui.picker(dataSource, {
            // defaultValue: dataSource[0].value,
            onConfirm: function (result) {
                value = result[0].label;
                if (result[0].label.length > 3) {
                    $("#province").html(result[0].label.substring(0, 3) + "..." + `<div class="vertical" style='background-color: #FF7B5F'></div>`);
                } else {
                    $("#province").html(result[0].label + `<div class="vertical" style='background-color: #FF7B5F'></div>`);
                }
                console.log(result[0]);
                queryType = 1;
                provinceId = result[0].label;
                currentPage = 1;
                htmlLoad();
                return result[0];
            }
        });
    });


    /*选择市区*/
    $("#city").click(function () {
        $(this).children(".vertical").css("background-color", "#FF7B5F");
        $(".recommend").children(".vertical").css("background-color", "white");
        $(".province").children(".vertical").css("background-color", "white");
        cityAddr();
        weui.picker(cityDatum, {
            className: 'custom-classname',
            container: 'body',
            defaultValue: [0],
            onConfirm: function (result) {
                if (result[0].label.length > 3) {
                    $("#city").html(result[0].label.substring(0, 3) + "..." + `<div class="vertical" style='background-color: #FF7B5F'></div>`);
                } else {
                    $("#city").html(result[0].label + `<div class="vertical" style='background-color: #FF7B5F'></div>`);
                }
                console.log(result[0]);
                queryType = 2;
                cityId = result[0].label;
                currentPage = 1;
                htmlLoad();
                return result[0];
            }
        });
    });


    /*点击推荐*/
    $(".recommend").click(function () {
        $(this).children(".vertical").css("background-color", "#FF7B5F");
        $(".province").children(".vertical").css("background-color", "white");
        $(".city").children(".vertical").css("background-color", "white");
        queryType = 0;
        currentPage = 1;
        htmlLoad();
    });


    /*屏幕滚动事件*/
    $(window).scroll(() => {
        if ($(window).scrollTop() === $(document).height() - $(window).height()) {
        	if (currentPage < pageTotal) {
	            if ($(".more").size() > 0) {
	                return;
	            }
	            $(".content>.list").append(`<div class="more">下拉加载更多<img src="../../images/teams/join/down.png" /></div>`);
	            currentPage = currentPage + 1;
	            htmlLoad(() => {
	                $(".more").remove();
	            });
        	}
            return;
        }
    });

	$('.submit').on('click',() => {
		teamName = $('#teamName').val();
		queryType = 3;
		currentPage = 1;
		htmlLoad();
	});
});


/*遍历输出*/
function teamList(dataList) {
    let list = [];
    $$.hideNoResultView("html");
    if (dataList != null && dataList.length > 0) {
        for (let i = 0; i < dataList.length; i++) {
            let team = dataList[i];
            let id = team.id;
            let flagPath = team.flagPath;
            if (flagPath == null || flagPath === '') {
                flagPath = '../../images/product/person1.png';
            }
            let tname = team.tname;
            let memberCount = team.memberCount;
            let memberCountHtml = [];
            if (memberCount < 10) {
                memberCount = 10 - memberCount;
                memberCountHtml = [
                    "<div class='teamNumber'>成团还差",
                    "<p class='number'>" + memberCount + "人</p>",
                    "</div>"];
            } else {
                memberCountHtml = [
                    "<div class='teamNumber'>拥有团员",
                    "<p class='number'>" + memberCount + "人</p>",
                    "</div>"];
            }
            list[i] = [
                "<li id='teamId" + id + "'>",
                "<div class='portrait'>",
                "<img src='" + flagPath + "' />",
                "</div>",
                "<div class='teamName'>" + tname + "</div>",
                memberCountHtml.join(''),
                "<div class='join'>",
                "<div>",
                "<p>加团</p>",
                "</div>",
                "</div>",
                "</li>"].join('');
        }
    } else {
        $$.showNoResultView({
            parentJqSelector: "html",
            msg: "暂无相关团队",
        });
    }
    return list;
}


/*页面加载函数*/
function htmlLoad(callback) {
	let pars = {
		currentPage:currentPage,
    	pageSize:pageSize
	};
	switch (queryType){
		case 1:
			pars.provinceId = provinceId;
			break;
		case 2:
			pars.provinceId = provinceId;
			pars.cityId = cityId;
			break;
		case 3:
		    if ($$.isValidObj(teamName)) {
                pars.teamName = teamName;
            }
			break;
	}
	$$.request({
        url: UrlConfig.market_team_wx_teamListOfNotFullMember,
        loading: true,
        pars:pars,
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	let list = data.datas.list;
            	let pagination = data.datas.pagination;
            	currentPage = pagination.current;
            	pageSize = pagination.pageSize;
            	teamCount = pagination.total;
            	pageTotal = Math.ceil(teamCount / pageSize);
            	setTimeout(teamListHtml(teamList(list),callback), 100);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

/*隔行变色*/
function changeColor() {
    let temp = $(".list>li").length;
    for (let i = 0; i < temp; i++) {
        if (i % 2 != 0) {
            $(".list>li:eq(" + i + ")").css("background-color", "#f3f4f8")
        }
    }
}


/*截取字符串的长度并转换*/
function changeStringLength() {
    let temp = $(".list>li").length;
    let value = "";
    for (let i = 0; i < temp; i++) {
        value = $(".list>li:eq(" + i + ")>.teamName").html();
        if (value.length > 6) {
            value = value.substring(0, 6) + "...";
        }
        $(".list>li:eq(" + i + ")>.teamName").html(value);
    }
    return value;
}


/*获取省份数据*/
function provinceAddr() {
    provinceDatum = [];
    chinaArea.forEach((item, index) => {
        provinceDatum.push({
            label: item.label,
            value: item.value
        });
    });
    return provinceDatum;
}


/*获取市区数据*/
function cityAddr() {
    if (value !== '') {
        for (const item of chinaArea) {
            const valueOfItem = item.label;
            if (value === valueOfItem) {
                const children = item.children;
                cityDatum = [];
                children.forEach((item, value) => {
                    cityDatum.push({
                        label: item.label,
                        value: item.value
                    });
                });
                return;
            }
        }
    }
    $("#province").click();
}

function teamListHtml(teamList,callback){
	if (currentPage === 1) {
		$('.list').html('');
	}
    $('.list').append(teamList);
    /*隔行变色*/
    changeColor();
    changeStringLength();
    let contentMarginTop = parseFloat($('.content').css('marginTop').replace('px', ''));
    let windowHeight = $(window).height();
    let bodyHeight = windowHeight - contentMarginTop;
    $('body').height(bodyHeight);
    if (callback) callback();

    $('.content>.list>li').off().click(function() {
        let teamId = $(this).attr('id');
    	teamId = teamId.replace('teamId','');
        $$.push('teams/addDetails',{
        	isMember:false,
        	teamId:teamId
        });
        return false;
    });

    /*点击按钮申请变成不可申请*/
    $('.list>li>div:last-child').off().click(function() {
    	let teamId = $(this).parent().attr('id');
    	teamId = teamId.replace('teamId','');
        $('.list>li>div:last-child>div>p').css('background-color', 'silver');
        joinTeam(teamId);
        return false;
    });
}
function joinTeam(teamId){
	$$.request({
        url: UrlConfig.market_teammember_joinTeam,
        loading: true,
        pars:{
        	teamId:teamId
        },
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	let contentHtmlArr = [
		        '<div class="application">',
		        	'<div class="ok">',
		        		'<img src = "../../images/teams/join/OK.png" />',
		        	'</div>',
		        	'<div class="msg">你的加团申请已经发送成功',
		        		'<br />请等候团长验证',
		        	'</div>',
		        '</div>'];
		        layer.open({
		            skin: '.demo',
		            type: 1,
		            content:contentHtmlArr.join(''),
		            end: () => {
		            	let teamMemberId = data.teamMemberId;
		                $$.push('teams/application',{teamMemberId:teamMemberId});
		            }
		        });
            } else {
                let msg = data.msg;
                if (msg === 'notBroker') {
                    let userStatus = data.userStatus;
                    if (userStatus === 0 || userStatus === 3) {
                        $$.confirm({
                            title: '您还不符合加团条件，请先进行执业认证~',
                            onOk: () => $$.push('my/professionalCertification')
                        });
                    } else if (userStatus === 1) {
                        $$.layerToast('您的执业认证未审核，认证通过后才可加团呢~');
                    }
                }
                else if (msg === 'isJoin') {
                    $$.layerToast('你已经申请或加入一个团了');
                } else {
                    $$.layerToast(msg);
                }
            	$('.list>li>div:last-child>div>p').css('background-color', '#FF7B5F');
            }
        },
        ffn: function (data) {
            $$.errorHandler();
            $('.list>li>div:last-child>div>p').css('background-color', '#FF7B5F');
        }
    });
}
