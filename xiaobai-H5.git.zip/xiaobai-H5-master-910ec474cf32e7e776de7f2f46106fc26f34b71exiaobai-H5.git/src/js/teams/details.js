
let provinceValue = '';
let cityValue = '';
let cityDatum = new Array();
let provinceDatum = new Array();

window.onload = function () {
    $$.changeVersion();
    $('.creatSubmit').click(()=>{
        let teamName = $('.teamName > .right > input').val().trim();
        let teamSlogan = $('.teamSlogan > .right > input').val().trim();
        let teamSynopsis = $('.teamSynopsis > .right > textarea').val().trim();
        let province = $('.province > div').text();
        let city = $('.city > div').text();
        let flagPath = $('#flagPath').attr('src');

        if(teamName.length > 10){
            //weui.topTips("团队名字请输入在10个字符以内",2000)
            $$.layerToast("团队名字请输入在10个字符以内");
            //$('.teamName > .right > input').val("");
        }else if(teamSlogan.length > 15){
            //weui.topTips("团队口号请输入在15个字符以内",2000)
            $$.layerToast("团队口号请输入在15个字符以内");
            //$('.teamSlogan > .right > input').val("");
        }else if(teamSynopsis.length > 30){
            //weui.topTips("团队简介请输入在30个字符以内",2000)
            $$.layerToast("团队简介请输入在30个字符以内");
            //$('.teamSynopsis > .right > textarea').val("");
        }else if(teamName.length === 0 || teamSlogan.length === 0 || teamSynopsis.length === 0){
            //weui.topTips("不能为空",2000)
            $$.layerToast("输入内容不能为空");
        }else if(province === "省份" || city === "市区"){
            //weui.topTips("请选择省市",2000)
            $$.layerToast("请选择省市");
        }else if(flagPath == null || flagPath === '') {
        	$$.layerToast("请上传队标");
        }else{
        	uploadFlag();
        }


    });

    /*选择省份*/
    $(".province").click(function () {
        const dataSource = provinceAddr();
        weui.picker(dataSource, {
            // defaultValue: dataSource[0].value,
            onConfirm: function (result) {
                provinceValue = result[0].label;
                $(".province>div").text(result[0].label).css("color","black");
                cityAddr();
            }
        });
    });


    /*选择市区*/
    $(".city").click(function () {
        cityAddr();
        weui.picker(cityDatum, {
            className: 'custom-classname',
            container: 'body',
            defaultValue: [0],
            onConfirm: function (result) {
            	cityValue = result[0].label;
                $(".city>div").text(result[0].label).css("color","black");
                return result[0].label;
            }
        });
    });


    /*上传队标*/
    $('.photo').click(()=>{
    	$('#flagFile').click();
    });
    $('#flagFile').change(()=>{
    	let file=$('#flagFile')[0].files[0];
    	//文件类型
    	let fileType=file.type;
    	let type=getFileType(fileType);
    	//文件大小
    	let fileSize=(file.size/ 1024).toFixed(2);
    	if(type!=="jpg"&&type!=="gif"&&type!=="jpeg"&&type!=="png"){
    		$$.layerToast('请上传图片');
    		return false;
    	}
    	if(fileSize>10240){//定义不能超过10MB
    		$$.layerToast('请上传不超过10M的图片');
    		return false;
    	}
    	lrz(file).then(function (resultObj) {
			$('#flagPath').attr("src",resultObj.base64);
            flagPathBtn();
		});
    });
    loadTeam();
    $('#parentTeamId').val($$.getUrlParam("parentTeamId"));
};



/*获取省份数据*/
function provinceAddr() {
    provinceDatum = [];
    chinaArea.forEach((item, index) => {
        provinceDatum.push({
            label: item.label,
            value: item.value
        });
    });
    return provinceDatum;
}


/*获取市区数据*/
function cityAddr() {
    if (provinceValue !== 0) {
        for (const item of chinaArea) {
            const valueOfItem = item.label;
            if (provinceValue === valueOfItem) {
                const children = item.children;
                cityDatum = [];
                children.forEach((item, value) => {
                    cityDatum.push({
                        label: item.label,
                        value: item.value
                    });
                });
                cityValue = cityDatum[0].label;
                $(".city>div").text(cityDatum[0].label).css("color","black");
                return;
            }
        }
    }else {
    	$(".province").click();
    }
}
function creatSubmit() {
    let teamId = $('#teamId').val();
    let teamName = $('.teamName > .right > input').val().trim();
    let teamSlogan = $('.teamSlogan > .right > input').val().trim();
    let teamSynopsis = $('.teamSynopsis > .right > textarea').val().trim();
    let teamAnnouncement = $('.teamAnnouncement > .right > textarea').val().trim();
    let flagPath = $('#flagPath').attr('src');
    const parentTeamId = $('#parentTeamId').val();
	$$.request({
        url: UrlConfig.market_team_wx_save,
        loading: true,
        pars:{
        	teamName:teamName,
        	teamSlogan:teamSlogan,
        	teamSynopsis:teamSynopsis,
        	provinceValue:provinceValue,
        	cityValue:cityValue,
        	flagPath:flagPath,
            teamAnnouncement:teamAnnouncement,
            teamId:teamId,
            basePath:$$.getBasePath(),
            parentTeamId:parentTeamId
        },
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let isUpdate = data.isUpdate;
                if (isUpdate) {
                    window.history.back();
                } else {
                    let teamId = data.teamId;
                    window.location.replace('succeed.html?teamId=' + teamId);
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function getFileType(filePath) {
	let startIndex=filePath.lastIndexOf("/");
	if(startIndex!==-1){
		return filePath.substring(startIndex+1,filePath.length).toLowerCase();
	}else {
		return "";
	}
}
function uploadFlag(){
	let file = $('#flagFile')[0].files[0];
	if (file) {
        let formData = new window.FormData();
        formData.append('file', file);
        formData.append('formType', '50');
        $$.request({
            url: UrlConfig.upload_attachment_upload,
            loading: true,
            pars:formData,
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $('#flagPath').attr('src',data.datas.filePath);
                    creatSubmit();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    } else {
        creatSubmit();
    }
}
function loadTeam() {
    let teamId = $$.getUrlParam("teamId");
    if (teamId != null && teamId !== '') {
        $('.creatSubmit').html('保存');
        $$.request({
            url: UrlConfig.market_team_wx_show,
            pars:{
                teamId:teamId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    console.log(data);
                    let teamName = data.teamName;
                    let flagPath = data.flagPath;
                    let slogan = data.slogan;
                    let synopsis = data.synopsis;
                    provinceValue = data.provinceId;
                    cityValue = data.cityId;
                    let xstatus = data.xstatus;
                    if (xstatus === 2) {
                        let remark = data.remark;
                        $('.teamAnnouncement > .right > textarea').val(remark);
                        $('.teamAnnouncement').show();
                    }
                    $('#teamId').val(teamId);
                    $('.teamName > .right > input').val(teamName);
                    $('.teamSlogan > .right > input').val(slogan);
                    $('.teamSynopsis > .right > textarea').val(synopsis);
                    $('#flagPath').attr('src',flagPath);
                    flagPathBtn();
                    $(".province>div").text(provinceValue).css("color","black");
                    $(".city>div").text(cityValue).css("color","black");
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
}

function flagPathBtn() {
    $('#flagPath').css('display','block');
    $('.upload').css('display','none');
    $('#flagPath').off('click');
    $('#flagPath').on('click',function(){
        $('#flagFile').click();
    });
}
