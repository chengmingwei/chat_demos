//获取当前年份
let myDate = new Date();
let year = myDate.getFullYear(); //获取当前年
let mon = myDate.getMonth() + 1; //获取当前月
mon = mon < 10 ? '0' + mon : mon;
let yearsMonth = year + "-" + mon;	//年-月

let userId = 0; //用户ID
let teamId = 0;	//团队ID
let mtype = 0;	//团队成员类型
let imgPath = "";	//团队成员头像
let memberId = 0;	//团队成员ID
let rname = "";	//团队成员名称
let orderPayMoney = 0;	//团队成员保费（元）
let orderCount = 0;	//团队成员出单数
let ranking = [];
let finishTime = "2019-12";

window.onload = function () {
    countAction('xb_6013');
	$$.changeVersion();
	$(".selectDate span").text(yearsMonth);

	teamLoad();
};
/* 根据时间获取团队订单排行榜列表 */
function getTeamMemberRankList(month,finishTime){
	//获取当前年-月
    if(month !== ""){
    	yearsMonth = month;
    }
	$$.request({
        url: UrlConfig.market_teammember_wx_getTeamMemberRankList,
        pars:{
        	teamId:teamId,
        	yearsMonth:yearsMonth,
			finishTime:finishTime
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	console.log(data);

            	$('.model_2>ul').html("");
            	for (let i in data.datas) {
					imgPath = data.datas[i].imgPath;
					mtype = data.datas[i].mtype;
					memberId = data.datas[i].memberId;
					rname = $$.isValidObj(data.datas[i].rname)?data.datas[i].rname:data.datas[i].account;
					orderPayMoney = data.datas[i].orderPayMoney > 9999 ?(((data.datas[i].orderPayMoney%100)/10000+'万')):(data.datas[i].orderPayMoney);
					orderCount = data.datas[i].orderCount;
					if (data.datas[i].finishTime) finishTime = data.datas[i].finishTime.substring(0,7);

					if(Number(i) < data.datas.length){
						if("userId" in data.datas[i]){
							userId = data.datas[i].userId;
							//加载数据
							modelLoad(i,userId);

						}else{
							//加载数据
							modelLoad(i);
						}
					}
				}

				//隔行变色
				changeColor();

            	//刷新排名
            	for (const i in ranking) {
					if(ranking[i] === 1){
						let x1 = $(".model_2>ul li:eq("+(i)+")>div:eq(0) div");
						x1.removeClass("mySequence").addClass("mySequence_1");
						x1.text("");
					}else if(ranking[i] === 2){
						let x2 = $(".model_2>ul li:eq("+(i)+")>div:eq(0) div");
						x2.removeClass("mySequence").addClass("mySequence_2");
						x2.text("");
					}else if(ranking[i] === 3){
						let x3 = $(".model_2>ul li:eq("+(i)+")>div:eq(0) div");
						x3.removeClass("mySequence").addClass("mySequence_3");
						x3.text("");
					}else{
						let x = $(".model_2>ul li:eq("+(i)+")>div:eq(0) div");
						x.text(ranking[i]);
					}
				}
            } else {
            	$$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

/*模块2页面加载函数*/
function modelLoad(i,userId) {
	i = Number(i) + 1;
    let html = "";
       	html += `<li><div class="ranking"><div class="mySequence">${i}</div></div>`;
        html += `<div class="myPortrait">`;
        if (imgPath === undefined || imgPath === ""){
			html += `<img src="../../images/teams/addDetails/horse.png" />`;
		}else {
			html += `<img src="${imgPath}" />`;
		}

        html += `</div>`;
        if(mtype === 1){
            html += `<div class="myName_1">`;
        }else{
            html += `<div class="myName">`;
        }

        html +=
			`${rname}</div>
				<div class="myNumber">${orderCount}</div>
				<div class="myPremium">${orderPayMoney}</div>
            </li>`;
    $('.model_2>ul').append(html);

    let x = i-1;
	let orderPayMoneys = 0;
	if(x >= 1){
		//-- 前一位的保费
		orderPayMoneys = $(".model_2>ul li:eq("+(x-1)+")"+" .myPremium").text();
		//排名数组的最后一位
		let y = ranking[ranking.length-1];

		//-- 如果当前保费和前一个保费相同，当前排名跟前一排名就相同
		if(Number(orderPayMoneys) === Number(orderPayMoney)){
    		let html = $(".model_2>ul li:eq("+(x-1)+")>div:eq(0)").html();
    		$(".model_2>ul li:eq("+(x)+")>div:eq(0)").html(html);

    		ranking.push(y);
    	}else{
    		ranking.push(y+1);
    	}

	}else{
		ranking.push(i);
	}
	//-- 当前用户排名和业绩
	if(userId !== undefined){
		let y = ranking[ranking.length-1];
		$(".myRanking>.msg span").text(y);
		$(".myPerformance>.msg").text(orderPayMoney);
	}
}

/*隔行变色*/
function changeColor() {
    const temp = $(".list_1>li").length;
    for (let i = 0; i < temp; i++) {
        if (i % 2 !== 0) {
            $(".list_1>li:eq(" + i + ")").css("background-color", "#f3f4f8");
        }
    }
}
function teamLoad() {
	/* 从加团页面传值 */
	teamId = decodeURIComponent($$.getUrlParam("teamId"));
	$$.request({
		url: UrlConfig.market_team_wx_show,
		pars:{
			teamId:teamId,
		},
		requestBody:true,
		loading: true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				finishTime = data.finishTime+"-01";

				//加载数据
				getTeamMemberRankList("",null);

				//时间 点击绑定事件
				selectDateBtn();

				//总排行榜 点击绑定事件
				allRankingBtn();
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}
//时间 点击绑定事件
function selectDateBtn() {
	$('.selectDate').click(function () {
		let yearsMonth = year + "-" + mon + "-01";	//年-月-日
		weui.datePicker({
			depth : 2,
			start: finishTime,
			end : yearsMonth,
			onConfirm: function(result){
				$('.selectDate').css('color','rgb(255, 131, 107)');
				$('.selectDate').children('.across').css('background-color','rgb(255, 131, 107)');
				$('.allRanking').css('color', '#000');
				$('.allRanking').children('.across').css('background-color','white');

				let month = String(result[1].value);
				if(month.length === 1){
					month = month.padStart(2,"0");	//字符串补全
				}
				let time = result[0] +"-"+ month;
				$('.selectDate').html(time+`<div class="across"></div>`);

				ranking.length = 0;
				getTeamMemberRankList(time,null);
			}
		});
	});
}
//总排行榜 点击绑定事件
function allRankingBtn() {
	$('.allRanking').click(function () {
		$(this).css('color','rgb(255, 131, 107)');
		$(this).children('.across').css('background-color', 'rgb(255, 131, 107)');
		$('.selectDate').css('color', '#000');
		$('.selectDate').children('.across').css('background-color', 'white');

		ranking.length = 0;
		getTeamMemberRankList(null,finishTime);
	});
}
