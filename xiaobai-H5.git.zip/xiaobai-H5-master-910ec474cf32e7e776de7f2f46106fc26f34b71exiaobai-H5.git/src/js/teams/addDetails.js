window.onload = function () {
	$$.changeVersion();
	//数据统计
	try {
		countAction('xb_73', null);
		countAction("xb_2076");
	} catch (error) {
		console.log(error);
	}
	let isPageHide = false;
	window.addEventListener('pageshow', function () {
		if (isPageHide) {
			window.location.reload();
		}
	});
	window.addEventListener('pagehide', function () {
		isPageHide = true;
	});

	/*点击团队规则*/
	$(".rule").click(() =>{
		$$.push('teams/rule',{page:1});
	});

    /*加载页面*/
    modelLoad();
};

/*模块2页面加载函数*/
function teamList(list,inTeam) {
	let html = [];
	if (list && typeof(list) != 'undefined') {
		for (let i = 0; i < list.length; i++) {
			html[i] = teamMemberHtml(list[i],i,inTeam);
		}
	}
	$('.model_2>ul').html(html.join(''));
}
function teamMemberHtml(xpro,i,inTeam) {
	let mTypeClass = '';
	if (xpro.mType === 1) {
		mTypeClass = ' leader';
	}
	let imgPath = xpro.imgPath;
	if (imgPath == null || imgPath === '' || typeof(imgPath) == 'undefined') {
		imgPath = '../../images/teams/addDetails/horse.png';
	}
	let isNewHtml = [];
	if(inTeam === 1 && xpro.newMember){
		isNewHtml = [
			'<div class="new">',
				'<img src="../../images/teams/addDetails/new.png" />',
			'</div>'];
	}
	const memberName = xpro.memberName;
	let inTeamClass = '';
	if (inTeam === 1) {
		inTeamClass = ' leader';
	}
	let sexImg = '../../images/teams/addDetails/man.png';
	if (xpro.sex === 2) {
		sexImg = '../../images/teams/addDetails/woman.png';
	}
	const createTime = xpro.createTime;
	let html = [
		'<li>',
			'<div class="serial' + mTypeClass + '">' + (i + 1) + '</div>',
			'<div class="portrait">',
				'<img src="' + imgPath + '" />',
				isNewHtml.join(''),
			'</div>',
			'<div class="individual">' + memberName + '</div>',
			'<div class="sex' + inTeamClass + '">',
				'<img src="' + sexImg + '" />',
			'</div>',
			'<div class="date' + inTeamClass + '">' + createTime + '</div>',
		'</li>'];
	return html.join('');
}
function modelLoad(){
	/*从加团页面传值*/
	let teamId = $$.getUrlParam("teamId");
    $$.request({
        url: UrlConfig.market_team_wx_show,
        pars:{
        	teamId:teamId
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                console.log(data);

				//团队基本信息
				teamBaseData(teamId,data);

				teamList(data.teamMemberList,data.inTeam);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
/*点击邀请*/
function inviteBtn(teamId){
    teamWeChatShare(teamId);
    $('.invite,.share_small').click(() => {
    	teamShare(teamId);
    });
}
function joinBtn(teamId){
    $('.join').click(() => {
		$$.request({
	        url: UrlConfig.market_teammember_joinTeam,
	        loading: true,
	        pars:{
	        	teamId:teamId
	        },
	        requestBody:true,
	        sfn: function (data) {
	            $$.closeLoading();
	            if (data.success) {
	            	let contentHtmlArr = [
			        '<div class="application">',
			        	'<div class="ok">',
			        		'<img src = "../../images/teams/join/OK.png" />',
			        	'</div>',
			        	'<div class="msg">你的加团申请已经发送成功',
			        		'<br />请等候团长验证',
			        	'</div>',
			        '</div>'];
			        layer.open({
			            skin: '.demo',
			            type: 1,
			            content:contentHtmlArr.join(''),
			            end: () => {
			            	let teamMemberId = data.teamMemberId;
			                $$.push('teams/application',{teamMemberId:teamMemberId});
			            }
			        });
	            } else {
	                let msg = data.msg;
                    if (msg == 'notBroker') {
                        let userStatus = data.userStatus;
                        if (userStatus == 0 || userStatus == 3) {
                            $$.confirm({
                                title: '您还不符合加团条件，请先进行执业认证~',
                                onOk: () => $$.push('my/professionalCertification')
                            });
                        } else if (userStatus == 1) {
                            $$.layerToast('您的执业认证未审核，认证通过后才可加团呢~');
                        }
                    }
                    else if (msg == 'isJoin') {
                        $$.layerToast('你已经申请或加入一个团了');
                    } else {
                        $$.layerToast(msg);
                    }
	            }
	        },
	        ffn: function (data) {
	            $$.errorHandler();
	        }
	    });
    });
}
function teamBaseData(teamId,data) {
	const teamName = data.teamName;
	$('#teamNameText').html(teamName);
	let flagPath = data.flagPath;
	if((flagPath==null)||(flagPath==="")) {
		flagPath = '../../images/teams/addDetails/member.png';	//会员头像
	}
	$('.flagPath').attr('src',flagPath);
	const slogan = data.slogan;	//口号
	$('.slogan_1 .character').html(slogan);
	const synopsis = data.synopsis;	//简介
	$('.slogan_2 .character').html(synopsis);
	const teamMemberList = data.teamMemberList;	//团队成员集合
	const allMemberLength = teamMemberList.length;	//总人数
	$('.allMemberLength').html(allMemberLength + '人');
	if (allMemberLength < 3) {
		const residueMemberLength = 3 - allMemberLength;
		$('.residueMemberLength').html(residueMemberLength + '人');
	} else {
		$('.lackMember .vertical').hide();
		$('.allMember .vertical').addClass('isFull');
	}
	const provinceId = data.provinceId;	//省
	const cityId = data.cityId;	//市
	$('.addr > div').html(provinceId + cityId);
	const inTeam = data.inTeam;//0：不是本团/未加团；1：团长；2：团员
	if(inTeam === 1 || inTeam === 2){
		$('.msgs').css('display','inline-block');
		const msgCall = data.msgCall;
		if (msgCall) {
			$('.circle').show();
		}
		$('.list_1').show();
		$('.number > .invite').show();
		$('.number > .join').hide();
		//进入消息
		$('.msgs').on('click',() =>{
			$$.push('teams/msg',{
				teamMemberId:data.teamMemberId
			});
		});
		//点击邀请
		inviteBtn(teamId);
		if (inTeam === 1) {
			$('.model_1 .synopsis,.slogan_1 .title,.slogan_2 .title,.model_1 .number').addClass('leader');
			$('.number > .invite > div').html('马上邀请');
			$('.flagPath,#teamNameText').click(()=>{
				$$.push('teams/details',{teamId:teamId});
			});
		} else if (inTeam === 2) {
			// $('.list_1 .contact').show();
		}
	} else {
		/*点击团队加入*/
		joinBtn(teamId);
	}
}
