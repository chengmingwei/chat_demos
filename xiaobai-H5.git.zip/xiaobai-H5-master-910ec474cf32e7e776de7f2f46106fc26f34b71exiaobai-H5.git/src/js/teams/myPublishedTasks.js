/**
 * 我发布的任务 JS
 * @Author 吴成林
 * @Date 2020-2-22 20:43:14
 */
window.onload = function() {
    const PAGE_STATE = {
        teamId:decodeURIComponent($$.getUrlParam("teamId")),//团队ID
        value:decodeURIComponent($$.getUrlParam("value")),//团队ID
        taskType:1,
        whetherVIP: false,                  // 是否是VIP
    };

    if (PAGE_STATE.value == 2){
        $('#activity').children(".underframe").addClass('weui-bar__item_on');
        $('#activity').siblings('.weui-bar__item_on').children(".underframe").removeClass('weui-bar__item_on');

        $('#activity').addClass('weui-bar__item_on').siblings('.weui-bar__item_on').removeClass('weui-bar__item_on');
        $($('#activity').attr("href")).show().siblings('.weui-tab__content').hide();
        PAGE_STATE.taskType = parseInt($('#activity').attr('data-id'));
        dataLoading();
    } else{
        dataLoading();
    }

    eventBinding();


    /**
     * 数据加载
     */
    function dataLoading(){
        let url = UrlConfig.market_teamsalestarget_wx_listByTeamId;
        if (PAGE_STATE.taskType === 2) {
            url = UrlConfig.market_teamactivitynotice_wx_listByTeamId;
        }
        $$.request({
            url: url,
            loading: true,
            pars:{
                teamId:PAGE_STATE.teamId
            },
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    createList(data.list);
                    eventBinding2();
                    $('.countdown .font12').each(function () {
                        const _this = $(this);
                        const timeEl = _this.children('.letter-spacing');
                       if (!_this.hasClass('close')) {
                           let time = timeEl.attr('time');
                           timer(parseInt(time),timeEl);
                       }
                    });
                    getVipData();
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        $('.releaseTask').on('click',function () {
            if (!PAGE_STATE.whetherVIP) {
                $$.confirm({
                    title: "使用此功能需先开通团长功能包，点击确认即前往开通！",
                    onOkLabel: "确认",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
                return;
            }
            window.location.replace('releaseTask.html?teamId=' + PAGE_STATE.teamId);
        });
        //-- 主题切换
        $('.weui-navbar__item').on('click', function () {
            $(this).children(".underframe").addClass('weui-bar__item_on');
            $(this).siblings('.weui-bar__item_on').children(".underframe").removeClass('weui-bar__item_on');

            $(this).addClass('weui-bar__item_on').siblings('.weui-bar__item_on').removeClass('weui-bar__item_on');
            $($(this).attr("href")).show().siblings('.weui-tab__content').hide();
            PAGE_STATE.taskType = parseInt($(this).attr('data-id'));
            dataLoading();
        });
    }

    function eventBinding2() {
        //-- 销售目标完成情况/活动通知报名情况
        $(".saleTarget,.activityTarget").off().on("click", function () {
            let taskId = $(this).attr('id');
            if (PAGE_STATE.taskType === 1) {
                taskId = taskId.replace('st_','');
            } else {
                taskId = taskId.replace('an_','');
            }
            $$.push("teams/taskAchievement", {
                taskType: PAGE_STATE.taskType,
                taskId: taskId,
            });
        });

        //-- 销售目标/活动通知查看详情
        $(".saleTargetContentDetail,.activityTargetContentDetail").off().on("click", function (e) {
            let taskId = $(this).parents('.unit').attr('id');
            if (PAGE_STATE.taskType === 1) {
                taskId = taskId.replace('st_','');
            } else {
                taskId = taskId.replace('an_','');
            }
            $$.push("teams/viewTaskDetails", {
                taskType: PAGE_STATE.taskType,
                taskId: taskId,
            });
            e.stopPropagation();
        });
    }

    function createList(list) {
        let htmlArr = [];
        if(list && typeof(list) != 'undefined' && list.length > 0) {
            for(let i = 0;i < list.length;i++){
                let xpro = list[i];
                if (PAGE_STATE.taskType === 2) {
                    htmlArr[i] = getHtmlByList2(xpro);
                } else {
                    htmlArr[i] = getHtmlByList(xpro);
                }
            }
            $('.noTask').css('display','none');
        } else {
            $('.noTask').css('display','flex');
            let noTaskText = '暂无任务';
            if (PAGE_STATE.taskType === 2) {
                noTaskText = '暂无通知';
            }
            $('.noTask > div > span').html(noTaskText);
        }
        let htmlCodes = htmlArr.join("");
        $("#tab" + PAGE_STATE.taskType + " .unitList").html(htmlCodes);
    }

    function getHtmlByList(xpro) {
        let id = xpro.id;
        let title = xpro.title;
        let startTime = xpro.startTime;
        let endTime = xpro.endTime;
        let memberCount = xpro.memberCount;
        let notTake = xpro.notTake;
        let notComplete = xpro.notComplete;
        let complete = xpro.complete;
        let littleTime = xpro.littleTime;
        let isStart = xpro.isStart;
        let isEnd = xpro.isEnd;
        let createTime = xpro.createTime;
        let littleTimeCloseClass = ' close';
        let status = '未开始';
        if (isStart === 1) {
            status = '进行中';
            littleTimeCloseClass = '';
        }
        if (isEnd === 1) {
            status = '已结束';
            littleTimeCloseClass = ' close';
        }
        let htmlArr=[
            '<li class="unit saleTarget" id="st_' + id + '">',
                '<div class="unitContent">',
                    '<div class="saleTargetImg"></div>',
                    '<div class="unitTitle">' + title + '</div>',
                    '<div class="contentTime font12">',
                        '<span>' + startTime + '</span>至<span>' + endTime + '</span>',
                    '</div>',
                    '<div class="space-around tasksState">',
                        '<div>',
                            '<div>未接收</div>',
                            '<div>',
                                '<span class="complete">' + notTake + '</span>',
                                '<span class="tasksSum">/' + memberCount + '</span>',
                            '</div>',
                        '</div>',
                        '<div>',
                            '<div>未完成</div>',
                            '<div>',
                                '<span class="complete">' + notComplete + '</span>',
                                '<span class="tasksSum">/' + memberCount + '</span>',
                            '</div>',
                        '</div>',
                        '<div>',
                            '<div>已完成</div>',
                            '<div>',
                                '<span class="complete">' + complete + '</span>',
                                '<span class="tasksSum">/' + memberCount + '</span>',
                            '</div>',
                        '</div>',
                    '</div>',
                    '<div class="countdown space-between">',
                        '<div class="font12' + littleTimeCloseClass + '">',
                            '<span>距离结束时间：</span>',
                            '<span class="letter-spacing" time="' + littleTime + '"></span>',
                        '</div>',
                        '<div>' + status + '</div>',
                    '</div>',
                    '<div class="saleTargetContentDetail space-between">',
                        '<span>查看任务详情</span>',
                        '<img src="../../images/teams/task/contentDetail.png" />',
                    '</div>',
                '</div>',
                '<div class="unitTime font12">' + createTime + '</div>',
            '</li>'];
        return htmlArr.join("");
    }

    function getHtmlByList2(xpro) {
        let id = xpro.id;
        let title = xpro.title;
        let startTime = xpro.startTime;
        let endTime = xpro.endTime;
        let memberCount = xpro.memberCount;
        let notTake = xpro.notTake;
        let isTake = xpro.isTake;
        let littleTime = xpro.littleTime;
        let isStart = xpro.isStart;
        let isEnd = xpro.isEnd;
        let createTime = xpro.createTime;
        let littleTimeCloseClass = ' close';
        let status = '未开始';
        if (isStart === 1) {
            status = '进行中';
            littleTimeCloseClass = '';
        }
        if (isEnd === 1) {
            status = '已结束';
            littleTimeCloseClass = ' close';
        }
        let htmlArr=[
            '<li class="unit activityTarget" id="an_' + id + '">',
                '<div class="unitContent">',
                    '<div class="activityTargetImg"></div>',
                    '<div class="unitTitle">' + title + '</div>',
                    '<div class="contentTime font12">',
                        '<span>' + startTime + '</span>至<span>' + endTime + '</span>',
                    '</div>',
                    '<div class="space-around tasksState">',
                        '<div>',
                            '<div>未接收</div>',
                            '<div>',
                                '<span class="complete">' + notTake + '</span>',
                                '<span class="tasksSum">/' + memberCount + '</span>',
                            '</div>',
                        '</div>',
                        '<div>',
                            '<div>已报名</div>',
                            '<div>',
                                '<span class="complete">' + isTake + '</span>',
                                '<span class="tasksSum">/' + memberCount + '</span>',
                            '</div>',
                        '</div>',
                    '</div>',
                    '<div class="countdown space-between">',
                        '<div class="font12' + littleTimeCloseClass + '">',
                            '<span>距离结束时间：</span>',
                            '<span class="letter-spacing" time="' + littleTime + '"></span>',
                        '</div>',
                        '<div>' + status + '</div>',
                    '</div>',
                    '<div class="activityTargetContentDetail space-between">',
                        '<span>查看活动详情</span>',
                        '<img src="../../images/teams/task/contentDetail.png" />',
                    '</div>',
                '</div>',
                '<div class="unitTime font12">' + createTime + '</div>',
            '</li>'
        ];
        return htmlArr.join("");
    }

    function timer(intDiff,timeEl){
        window.setInterval(function(){
            let day=0,
                hour=0,
                minute=0,
                second=0;//时间默认值
            if(intDiff > 0){
                day = Math.floor(intDiff / (60 * 60 * 24));
                hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
                minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
                second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
            }
            if (hour <= 9) hour = '0' + hour;
            if (minute <= 9) minute = '0' + minute;
            if (second <= 9) second = '0' + second;
            timeEl.html(day + '天' + hour + ':' + minute + ':' + second);
            intDiff--;
        }, 1000);
    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType === 2;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};
