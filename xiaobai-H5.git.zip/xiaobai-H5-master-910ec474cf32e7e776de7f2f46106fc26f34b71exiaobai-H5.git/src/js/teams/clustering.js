//获取当前年份
let myDate = new Date();
let year = myDate.getFullYear(); //获取当前年
let mon = myDate.getMonth() + 1; //获取当前月
mon = mon < 10 ? '0' + mon : mon;

let status = true;	//加入团队一次加载状态
let yearsMonth = year + "-" + mon;	//年-月

window.onload = function () {
    $$.changeVersion();

    //数据统计
    try {
        countAction('xb_73', null);
        countAction("xb_2076");
    } catch (error) {
        console.log(error);
    }
    let isPageHide = false;
    window.addEventListener('pageshow', function () {
        if (isPageHide) {
            window.location.reload();
        }
    });
    window.addEventListener('pagehide', function () {
        isPageHide = true;
    });
    /*点击团队规则*/
    $(".rule").click(() =>{
        $$.push('teams/rule',{page:1});
    });

    $('.teamMsg .time > div').html(yearsMonth);

    /* 团长发布任务 - 弹出层 */
    let newTask = false;      // 是否有新任务
    if (newTask){
        $('.taskPopup').show();
    }
    $(".taskClose").on("click", function () {
        $('.taskPopup').hide();
    });
    $(".view").on("click", function () {
        let taskId = 0;
        $('.taskPopup').hide();
        $$.push("teams/viewTaskConfirm", {
            taskType: 0,        // 0-销售目标，1-活动目标
            taskState: 1,       // 0-未接受，1-已接受，2-已提交, 3-已完成（销售目标0/1/2/3, 活动目标0/3）
            id: taskId,         // 任务id
        });
    });

	/* 加载页面top */
    modelLoad();

};

//文字横向滚动
function scrollImgLeft() {
    const speed = 50;//初始化速度 也就是字体的整体滚动速度
    const MyMar = null;//初始化一个变量为空 用来存放获取到的文本内容
    let scroll_begin = $("#scroll_begin");//获取滚动的开头id
    let scroll_end = $("#scroll_end");//获取滚动的结束id
    let scroll_div = $("#scroll_div");//获取整体的开头id

    if(scroll_begin.width() > scroll_div.width()){
        scroll_end.html(scroll_begin.html());//滚动的是html内部的内容,原生知识!
    }
    //定义一个方法
    function Marquee() {
        if (scroll_end[0].offsetWidth - scroll_div[0].scrollLeft <= 0)
            scroll_div[0].scrollLeft -= scroll_begin[0].offsetWidth;
        else
            scroll_div[0].scrollLeft++;
    }
    setInterval(Marquee, speed);

}

/* 加载页面 */
function modelLoad(){
    /* 从加团页面传值 */
    let teamId = decodeURIComponent($$.getUrlParam("teamId"));
	/* 加载团队信息 */
    $$.request({
        url: UrlConfig.market_team_wx_show,
        pars:{
        	teamId:teamId
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                //团队基本信息
                teamBaseData(teamId,data);

                let finishTime = data.finishTime;//成团时间

                //点击邀请
                inviteBtn(teamId);

                //-- 加载团队出单数、总保费（元）
                getTeamCount(teamId,finishTime);

                /* 加载团队信息 */
                modelLoadTeamInformation(teamId,"");

                //点击本团团队信息的时间
                teamMsgTimeBtn(teamId,finishTime);

                $('.more > div').click(()=>{
                    $$.push("teams/particular",{teamId: teamId,finishTime: finishTime});
                });

                $('.addCount').click(()=>{
                    $$.push("teams/addMember",{teamId: teamId});
                });

                if (!data.hasMyChildrenTeam) {
                    //创建子团团队
                    $('.creatTeams').show().click(()=>{
                        $$.push("teams/details",{
                            parentTeamId:teamId
                        });
                        $('.creatTeams').hide();
                    });
                }

                //如果页面内容加载失败，跳转error异常页面
                /*let model_1 = $(".model_1").html();
                let model_2 = $(".model_2").html();
                if((model_1 === null || model_1.length === 0) && (model_2 === null || model_2.length === 0)){
                    let error = 1;
                    $$.push("error/error",params = {error});
                }*/
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });



}

//-- 加载团队出单数、总保费（元）
function getTeamCount(teamId,finishTime) {
    $$.request({
        url: UrlConfig.market_teammember_wx_getTeamCount,
        pars:{
            teamId:teamId,
            finishTime:finishTime
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let orderNumber = data.datas.orderNumber;	//出单数
                $('.orderNumber').html(orderNumber);
                let payMoney = data.datas.payMoney > 9999 ?(((data.datas.payMoney%100)/10000+'万')):(data.datas.payMoney);	//总保费
                $('.payMoney').html(payMoney);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

//获取 某月份 新增团员总数
function modelLoadTeamInformation(teamId,month){
	//获取当前年-月
    if(month === ""){
        month = yearsMonth;
    }
    /* 获取 某月份 新增团员总数 和 总保费（元） */
	$$.request({
        url: UrlConfig.market_teammember_wx_getTeamInformation,
        pars:{
        	teamId:teamId,
        	yearsMonth:month
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                //本团新增人数
                let teamCount = data.datas.teamCount;
				let grossPremium = data.datas.grossPremium;

                $(".teamCount").text(teamCount);
                $(".grossPremium").text(grossPremium);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function teamMsgTimeBtn(teamId,finishTime) {
    let start,end;
    /*点击本团团队信息的时间*/
	$('.teamMsg>.time').click(() => {
        finishTime.length == 7 ? start = finishTime+"-01":finishTime;
        yearsMonth.length == 7 ? end = yearsMonth+"-01":yearsMonth;
        weui.datePicker({
            id: 1,
            start: start,
            depth : 2,
            end : end,
            onConfirm:function(result){
                let month = String(result[1].value);
                if(month.length === 1){
                	month = month.padStart(2,"0");	//字符串补全
                }
                let time = result[0] +"-"+ month;
                $('.teamMsg>.time>div').text(time);

                modelLoadTeamInformation(teamId,time);
            }
        })
    });
}

/*点击邀请*/
function inviteBtn(teamId){
    teamWeChatShare(teamId);
    $('.invite,.share_small').click(() => {
    	teamShare(teamId);
    });
}

function teamBaseData(teamId,data) {
    let teamName = data.teamName;
    $('#teamNameText').html(teamName);
    let flagPath = data.flagPath;
    if((flagPath==null)||(flagPath==="")) {
        flagPath = '../../images/teams/addDetails/member.png';	//会员头像
    }
    $('.flagPath').attr('src',flagPath);
    let slogan = data.slogan;	//口号
    $('.slogan_1 .character').html(slogan);
    let synopsis = data.synopsis;	//简介
    $('.slogan_2 .character').html(synopsis);
    let teamMemberList = data.teamMemberList;	//团队成员集合
    //let headcount = teamMemberList.length;	//总人数
    //$('.headcount').html(headcount);
    let provinceId = data.provinceId;	//省
    let cityId = data.cityId;	//市
    $('.addr > div').html(provinceId + cityId);
    let msgCall = data.msgCall;
    if (msgCall) {
        $('.circle').show();
    }
    let remark = data.remark;	//团队公告
    $('.remark').html(remark);

    //文字横向滚动
    scrollImgLeft();

    //进入消息
    $('.msg').on('click',() =>{
        $$.push('teams/msg',{
            teamMemberId:data.teamMemberId
        });
    });

    taskRemind(data);
}
function taskRemind(data) {
    const taskTotal = data.taskTotal;
    if (taskTotal > 0) {
        const taskType = data.taskType;
        const taskTitle = data.taskTitle;
        let taskTip = taskTotal + '个任务/通知';
        if (taskType === 1) {
            taskTip = taskTotal + '个任务';
        } else if (taskType === 2) {
            taskTip = taskTotal + '个通知';
        }
        if (taskTotal === 1) {
            $('.taskPopup .taskDetails .taskContent').html(taskTitle);
        }
        $('.taskPopup .taskDetails  > div > span').html(taskTip);

        $('.taskPopup .view').on('click',function () {
            if (taskTotal === 1) {
                const taskMemberId = data.taskMemberId;
                $$.push('teams/viewTaskConfirm',{
                    taskType:taskType,
                    taskMemberId:taskMemberId
                });
            } else {
                $$.push('teams/msg',{
                    teamMemberId:data.teamMemberId
                });
            }
        });
        $('.taskPopup').show();
    }
}
