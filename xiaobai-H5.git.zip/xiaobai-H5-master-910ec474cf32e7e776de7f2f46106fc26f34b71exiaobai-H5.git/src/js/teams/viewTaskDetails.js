/**
 * 查看团队任务详情 JS
 * @Author 吴成林
 * @Date 2020-2-24 14:20:25
 */

window.onload = function() {
    const PAGE_STATE = {
        taskType: parseInt(decodeURIComponent($$.getUrlParam("taskType"))),// 1-销售目标，2-活动通知
        taskId: decodeURIComponent($$.getUrlParam("taskId"))// 任务id
    };
    PAGE_STATE.taskType = $$.isValidObj(PAGE_STATE.taskType) ? PAGE_STATE.taskType : 1;
    dataLoading();

    /**
     * 数据加载
     */
    function dataLoading(){
        let url = UrlConfig.market_teamsalestarget_wx_getDetailsByTaskId;
        if (PAGE_STATE.taskType === 1) {
            $(".activityTarget").css("display","none");
        } else {
            $(".saleTarget").css("display","none");
            url = UrlConfig.market_teamactivitynotice_wx_getDetailsByTaskId;
            $('.titleName').html('活动主题');
            $('.explainedName').html('活动说明');
            $('.viewDetailsTitle > span').html('活动通知');
            $('.viewDetailsTitle > img').attr('src','../../images/teams/task/activityType.png');
            $('.closeTask').html('关闭活动');
        }
        $$.request({
            url: url,
            loading: true,
            pars:{
                taskId:PAGE_STATE.taskId
            },
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    $('.title').html(data["title"]);
                    $('.startTime').html(data["startTime"]);
                    $('.endTime').html(data["endTime"]);
                    $('.explained').html(data["explained"]);

                    //-- 是否 - 推送通知
                    if (data["isRemind"] === 0){
                        $(".switch").css("background-color","#999999");
                        $(".switch").children("div").removeClass("switchNo").addClass("switchYes");
                    }
                    $('.selectedNumberText').html(data["selectedNumberText"]);
                    const picList = [data["pic1"],data["pic2"],data["pic3"]];
                    for (let i = 0; i < picList.length; i++) {
                        const pic = picList[i];
                        if ($$.isValidObj(pic)) {
                            $('.uploadingImg').append('<img src="' + pic + '" />');
                        }
                    }
                    const isenabled = data['isenabled'];
                    if (isenabled === 1) {
                        closeTaskBtn();
                    } else {
                        const closeTaskBtn = $(".closeTask");
                        closeTaskBtn.css('background-color','#999999');
                        if (isenabled === 0) {
                            closeTaskBtn.html('已关闭');
                        } else if (isenabled === -1) {
                            closeTaskBtn.html('已删除');
                        }
                    }
                    if (PAGE_STATE.taskType === 1) {
                        let numberVal = data["huo4ke4ren2shu4"];
                        let numberEl = $('#huo4ke4ren2shu4');
                        let unit = '人';
                        setTargetNumber(numberVal,numberEl,unit);
                        numberVal = data["xiao1shou4ye4ji4"];
                        numberEl = $('#xiao1shou4ye4ji4');
                        unit = '元';
                        setTargetNumber(numberVal,numberEl,unit);
                        numberVal = data["cheng2jiao1ding4dan1"];
                        numberEl = $('#cheng2jiao1ding4dan1');
                        unit = '单';
                        setTargetNumber(numberVal,numberEl,unit);
                        numberVal = data["fa1zhan3tuan2yuan2"];
                        numberEl = $('#fa1zhan3tuan2yuan2');
                        unit = '人';
                        setTargetNumber(numberVal,numberEl,unit);
                    } else {
                        let address = data["address"];
                        if ($$.isValidObj(address)) {
                            $('#address').html(address);
                        } else {
                            $('#address').parent().hide();
                        }
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    function closeTaskBtn(){

        //-- 关闭任务/关闭活动
        $(".closeTask").off().on("click", function(){
            $$.confirm({
                title: "确定要关闭吗？",
                onOkLabel: "确定",
                onCancelLabel: "取消",
                onOk: function(){
                    //-- 确认处理
                    let url = UrlConfig.market_teamsalestarget_wx_enabled;
                    if (PAGE_STATE.taskType === 2) {
                        url = UrlConfig.market_teamactivitynotice_wx_enabled;
                    }
                    $$.request({
                        url: url,
                        loading: true,
                        pars:{
                            taskId:PAGE_STATE.taskId,
                            isenabled:0
                        },
                        requestBody:true,
                        sfn: function (data) {
                            $$.closeLoading();
                            if (data.success) {
                                const closeTaskBtn = $(".closeTask");
                                closeTaskBtn.css('background-color','#999999');
                                closeTaskBtn.html('已关闭');
                                closeTaskBtn.off();
                            }
                        },
                        ffn: function (data) {
                            $$.errorHandler();
                        }
                    });
                }
            });
        });
    }

    function tranNumber(num, point = 0) {
        let numStr = parseInt(num).toString();

        // 万以内直接返回
        if (numStr.length < 5) {
            return num;
        }
        //大于8位数是亿
        else if (numStr.length > 8) {
            let decimal = numStr.substring(numStr.length - 8, numStr.length - 8 + point);
            return parseFloat(parseInt(num / 100000000) + '.' + decimal) + '亿';
        }
        //大于4位数是万 (以1W分割 1W以下全部显示)
        else if (numStr.length > 4) {
            let decimal = numStr.substring(numStr.length - 4, numStr.length - 4 + point);
            return parseFloat(parseInt(num / 10000) + '.' + decimal) + '万';
        }
    }

    function setTargetNumber(numberVal,numberEl,unit) {
        if (numberVal > 0) {
            numberVal = tranNumber(numberVal);
            numberEl.html(numberVal + ' ' + unit);
        } else {
            numberEl.parent().hide();
        }
    }
};
