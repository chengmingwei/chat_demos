/**
 * 任务完成情况/活动报名情况 JS
 * @Author 吴成林
 * @Date 2020-2-22 20:43:14
 */

window.onload = function() {
    const PAGE_STATE = {
        taskType: parseInt(decodeURIComponent($$.getUrlParam("taskType"))),// 1-销售目标，2-活动通知
        taskId: decodeURIComponent($$.getUrlParam("taskId")),// 任务id
    };
    PAGE_STATE.taskType = $$.isValidObj(PAGE_STATE.taskType) ? PAGE_STATE.taskType : 1;
    if (PAGE_STATE.taskType === 2) {
        $('title').text('活动报名情况');
        $('.weui-navbar__item[data-id=2] .navName').html('已参加 ');
        $('.weui-navbar__item[data-id=3]').hide();
    }
    dataLoading();
    eventBinding();

    /**
     * 数据加载
     */
    function dataLoading(){
        let url = UrlConfig.market_teamsalestargetmemberlist_wx_getStatusByTaskId;
        if (PAGE_STATE.taskType === 2) {
            url = UrlConfig.market_teamactivitynoticememberlist_wx_getStatusByTaskId;
        }
        $$.request({
            url: url,
            loading: true,
            pars:{
                taskId:PAGE_STATE.taskId
            },
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    if (PAGE_STATE.taskType === 2) {
                        PAGE_STATE['list1'] = data.notTakeList;
                        PAGE_STATE['list2'] = data.isTakeList;
                    } else {
                        PAGE_STATE['list1'] = data.notTakeList;
                        PAGE_STATE['list2'] = data.notCompleteList;
                        PAGE_STATE['list3'] = data.completeList;
                    }
                    $('.weui-navbar__item').each(function (index) {
                        const list = PAGE_STATE['list' + (index + 1)];
                        if (list) {
                            $(this).find('.sum').html('(' + list.length + ')');
                        }
                    });
                    createList(PAGE_STATE['list1'],1);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 主题切换
        $('.weui-navbar__item').on('click', function () {
            $(this).children(".underframe").addClass('weui-bar__item_on');
            $(this).siblings('.weui-bar__item_on').children(".underframe").removeClass('weui-bar__item_on');

            $(this).addClass('weui-bar__item_on').siblings('.weui-bar__item_on').removeClass('weui-bar__item_on');
            const listType = parseInt($(this).attr('data-id'));
            createList(PAGE_STATE['list' + listType],listType);
        });
    }
    function createList(list,listType) {
        let htmlArr = [];
        if(list && typeof(list) != 'undefined') {
            for(let i = 0;i < list.length;i++){
                let xpro = list[i];
                htmlArr[i] = getHtmlByList(xpro,listType,i);
            }
        }
        $('.weui-tab__panel .list').html(htmlArr.join(''));
    }
    function getHtmlByList(xpro,listType,i) {
        let rname = xpro.rname;
        if (!$$.isValidObj(rname)) {
            rname = xpro.account;
        }
        let imgPath = xpro.imgPath;
        if (!$$.isValidObj(imgPath)) {
            imgPath = '../../images/my/defaultImg.png';
        }
        let rankingHtml = '';
        let completeTimeHtml = [];
        let taskSchedule = '';
        if (PAGE_STATE.taskType === 1 && listType !== 1) {
            if (listType === 3) {
                rankingHtml = '<div class="ranking">' + (i + 1) + '</div>';
            }
            const useTime = xpro.useTime;
            if (useTime) {
                completeTimeHtml = [
                    '<div class="font12">',
                        '<span>完成时间：</span>',
                        '<span>' + timer(useTime) + '</span>',
                    '</div>'];
            }
            taskSchedule = '<div class="taskSchedule">' + taskScheduleHtml(xpro) + '</div>';
        }
        let htmlArr=[
            '<li class="taskUnit flex-start">',
                rankingHtml,
                '<div class="taskContent">',
                    '<div class="taskTitle space-between">',
                        '<div>',
                            '<img src="' + imgPath + '" class="iconImg" />',
                            '<span class="overflow">' + rname + '</span>',
                        '</div>',
                        completeTimeHtml.join(''),
                    '</div>',
                    taskSchedule,
                '</div>',
            '</li>'];
        return htmlArr.join('');
    }
    function taskScheduleHtml(xpro) {
        const taskScheduleName = ['获客人数','销售业绩','成交订单','发展团员'];
        const taskScheduleUnit = ['人','元','单','人'];
        let taskScheduleData = [];
        for (let i = 0; i < taskScheduleName.length;i++) {
            const no = i + 1;
            const all = xpro['numberAll' + no];
            if (all !== '0') {
                taskScheduleData.push({
                    name:taskScheduleName[i],
                    number:xpro['number' + no],
                    all:all,
                    percent:xpro['percent' + no],
                    exceed:xpro['exceed' + no],
                    unit:taskScheduleUnit[i]
                });
            }
        }
        let htmlArr = [];
        for (let i = 0; i < taskScheduleData.length; i++) {
            if (taskScheduleData[i].all) {
                const exceedHtml = taskScheduleData[i].exceed ? '<span>（超额完成）</span>' : '';
                let htmlArr2 = [
                    '<div>',
                        '<div>',
                            '<span>' + taskScheduleData[i].name + '</span>',
                            '<div>',
                                exceedHtml,
                                '<span class="themeColor">' + tranNumber(taskScheduleData[i].number) + '</span>/<span>' + tranNumber(taskScheduleData[i].all) + '</span>' + taskScheduleData[i].unit,
                            '</div>',
                        '</div>',
                        '<div class="pmgressbar">',
                            '<div class="completed" style="width: ' + taskScheduleData[i].percent + '%"></div>',
                        '</div>',
                    '</div>'];
                htmlArr.push(htmlArr2.join(''));
            }

        }
        return htmlArr.join('');
    }

    function timer(intDiff){
        let day=0,
        hour=0,
        minute=0;//时间默认值
        if(intDiff > 0){
            day = Math.floor(intDiff / (60 * 60 * 24));
            hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
            minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
        }
        if (hour <= 9) hour = '0' + hour;
        if (minute <= 9) minute = '0' + minute;
        return day + '天' + hour + '小时' + minute + '分';
    }

    function tranNumber(num, point = 2) {
        if (!$$.isValidObj(num)) {
            num = 0;
        }
        let numStr = parseInt(num).toString();

        // 万以内直接返回
        if (numStr.length < 5) {
            return num;
        }
        //大于8位数是亿
        else if (numStr.length > 8) {
            let decimal = numStr.substring(numStr.length - 8, numStr.length - 8 + point);
            return parseFloat(parseInt(num / 100000000) + '.' + decimal) + '亿';
        }
        //大于4位数是万 (以1W分割 1W以下全部显示)
        else if (numStr.length > 4) {
            let decimal = numStr.substring(numStr.length - 4, numStr.length - 4 + point);
            return parseFloat(parseInt(num / 10000) + '.' + decimal) + '万';
        }
    }
};
