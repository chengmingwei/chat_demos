let myScroll;
const PAGE_STATE = {
    shareDatums: {
        url: "",
        image: $Constant.shareLogo,
        title: "快来加入我的团队，一起成长吧",
        content: '沧海横流,英雄本色!问鼎夺冠,还当数你我他!'
    }
};

function teamWeChatShare(teamId) {
    if (!$WeChat.isWx() && !PAGE_APP) {
        return;
    }

    let lineLink = $$.getFullHost() + '/src/pages/teams/linkJoin.html';
    lineLink += $$.jsonToUrlParams({
        teamId:teamId
    });

    PAGE_STATE.shareDatums.url = lineLink;      //-- 保存分享参数

    weChatJSTool.share({
        _imgUrl: $Constant.shareLogo,
        _lineLink: lineLink,
        _shareTitle: '快来加入我的团队，一起成长吧',
        _descContent: '沧海横流,英雄本色!问鼎夺冠,还当数你我他!',
        _sfn: function () {
            console.log("成功注册分享链接：" + lineLink);
        },
        _cfn: function () {
        },
        _ffn: function () {
            console.log("失败注册分享链接：" + lineLink);
        }
    });
}
function touchmoveBtn() {
    document.addEventListener('touchmove', function (e) {
        e.preventDefault();
    }, isPassive() ? {
        capture: false,
        passive: false
    } : false);
}

function shareMainContent() {
    let contentHtmlArr = [
        '<div class="share">',
        // '<div class="history">',
        //     '<img src="../../images/teams/addDetails/history.png" />',
        //     '<div>历史邀请好友</div>',
        // '</div>',
        '<div class="face">',
        '<img src="../../images/teams/addDetails/face.png" />',
        '<div>面对面邀请</div>',
        '</div>',
        '<div class="wechat">',
        '<img src="../../images/teams/addDetails/wechat.png" />',
        '<div>微信邀请</div>',
        '</div>',
        '<div class="link">',
        '<img src="../../images/teams/addDetails/link.png" />',
        '<div>复制邀请链接</div>',
        '</div>',
        '</div>'];
    return contentHtmlArr.join('');
}

function teamShare(teamId) {
    touchmoveBtn();
    layer.open({
        type: 1,
        content: shareMainContent(),
        skin: 'footer',
        success: (layero, index) => {
            console.log(layero);
            /*点击面对面邀请*/
            faceBtn(teamId);
            /*点击历史邀请好友*/
            // historyBtn(teamId);
            /*点击复制邀请链接*/
            linkBtn(teamId);
            /*点击微信邀请*/
            weChatBtn();
        }
    });
}
function linkBtn(teamId) {
    $('.link').on('click', function () {
        let lineLink = $$.getFullHost() + '/src/pages/teams/linkJoin.html';
        lineLink += $$.jsonToUrlParams({
            teamId:teamId
        });
        shareLink(lineLink);
    });
}
function historyBtn(teamId) {
    $('.history').on('click', function () {
        shareHistory(teamId);
    });
}
function faceBtn(teamId) {
    $('.face').on('click', function () {
        $$.push('teams/inviteFriends', {teamId: teamId});
    });
}
function weChatBtn() {
    //点击分享
    $('.wechat').on('click', function () {
        if(PAGE_APP){
            //-- APP
            const { shareDatums } = PAGE_STATE;

            const params = {bussType: 10001, ...shareDatums};
            $$.postAPP(10002, params);
        }else{
            layer.closeAll();
            $$.showShareView();
            return false;
        }
    });
}

function list() {

    let content = "";


    content +=
        `
<div id="list">
    <div id="header">
        <div>历史邀请</div>
        <div>选中：<div class="count">0人</div></div>
        <div class="all" style="color: rgb(255, 112, 82)">全选</div>
    </div>
        <div id="wrapper">
        <div id="scroller">
        <ul>`;

    for (let i = 0; i < 41; i++) {
        content +=
            `<li>
            <div>
                <div></div>    
            </div>
            <div>
                <img src="../../images/teams/addDetails/horse.png "/>
            </div>
            <div>前端小哥哥</div>
            
            <!--用户ID-->
            <div style="display: none"></div>
        </li>`;
    }

    content +=
        `</ul>
        </div>
    </div>

    <div id="footer">
        <div class="allShare">一键邀请</div>
    </div>
        </div>`;

    return content;

}


function changeCheck() {
    $('#scroller > ul > li > div:nth-of-type(1) > div').on('click', function () {
        if ($(this).hasClass('change') == false) {
            $(this).addClass('change');
        } else {
            $(this).removeClass('change');
        }
        $('.count').text(numberCount())
    })
}


function selectAll() {
    $('.all').click(() => {
        $('#scroller > ul > li > div:nth-of-type(1) > div').addClass('change')
        $('.count').text(numberCount());
    })
}


function numberCount() {
    let count = 0;
    let temp = $('#scroller > ul > li > div:nth-of-type(1) > div').length;
    for (let i = 0; i < temp; i++) {
        if ($('#scroller > ul > li > div:nth-of-type(1) > div:eq(' + i + ')').hasClass('change') === true) {
            count++;
        }
    }
    return count;
}


/*加载*/
function loaded() {
    myScroll = new IScroll('#wrapper', {bounceEasing: 'elastic', bounceTime: 500});
}


/*判断*/
function isPassive() {
    let supportsPassiveOption = false;
    try {
        addEventListener("test", null, Object.defineProperty({}, 'passive', {
            get: function () {
                supportsPassiveOption = true;
            }
        }));
    } catch (e) {
    }
    return supportsPassiveOption;
}

function shareLink(url) {
    let tag = document.createElement('input');
    tag.setAttribute('id', 'cp_input');
    tag.value = url;
    document.getElementsByTagName('body')[0].appendChild(tag);
    document.getElementById('cp_input').select();
    document.execCommand('copy');
    document.getElementById('cp_input').remove();
    $$.layerToast('复制成功');
}

function shareHistory(teamId) {
    layer.closeAll();
    layer.open({
        type: 1,
        content: list(),
        skin: 'footer',

    });
    /*加载和点击*/
    loaded();
    changeCheck();
    selectAll();
    $('.count').text(numberCount());
}
