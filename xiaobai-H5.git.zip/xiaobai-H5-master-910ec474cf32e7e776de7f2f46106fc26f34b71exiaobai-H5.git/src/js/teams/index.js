window.onload = function () {
	$$.changeVersion();
    /*点击规则进行跳转*/
	$(".joinrule").click(function(){
		pushRule(1);
	});

	$(".creatrule").click(function(){
		pushRule(2);
	});
	$(".join").click(function(){
		countAction("xb_2073");
        const gotoUrl = 'join.html';
        checkOrder(gotoUrl);
	});
	$(".creat").click(function(){
		countAction("xb_2074");
        const gotoUrl = 'details.html';
        checkOrder(gotoUrl);
	});
};
function pushRule(page){
	$$.push('teams/rule',{page:page});
}
function checkOrder(gotoUrl){
    $$.request({
        url: UrlConfig.market_teammember_checkOrder,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
         if (data.success) {
            	window.location.replace(gotoUrl);
         } else {
             $$.layerToast('需要成功出单1张');
         }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
