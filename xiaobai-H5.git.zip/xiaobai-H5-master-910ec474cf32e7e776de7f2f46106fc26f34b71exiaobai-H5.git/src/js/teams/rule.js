$(function(){


	/*获取url的带参值*/
	function GetRequest() {
             var url = location.search; //获取url中"?"符后的字串
             var theRequest = new Object();
             if (url.indexOf("?") != -1) {
                 var str = url.substr(1);
                 strs = str.split("&");
                 for(var i = 0; i < strs.length; i ++) {
                     theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
                 }
             }
             return theRequest;
    }


	/*返回当前参的多个对象*/
	function getfont(font,temp){
		var fonts = $("."+font+":eq("+temp+")");
		return fonts;
	}


	function setHeight(text,font,color){
		/*获取li的对象*/
		var li = $("[class *= '"+text+"']>ul>li");
		/*获取number的对象*/
		var number = "number";
		for(var i=0;i<li.length;i++){
			var temp = (getfont(font,i).height()-25)/2;
			getfont(number,i).css({"bottom":""+temp+"px"})
		}
		changeColor(text,font,color)
		changeNumberHeight(text,font)
	}


	/*隔行变色  */
	function changeColor(text,title,color){
		var temp = $("[class *= "+text+"]").length;
		for(var i = 1;i<=temp;i++){
			var font1 = $("."+text+""+i+">ul>li").length;
			for(var j = 0;j<font1;j++){
				var font2 = $("."+text+""+i+">ul>li>."+title+":eq("+j+")")
				if(j%2 != 0)
					font2.css("background-color",""+color+"")
			}
		}
	}


	/*计算序号之间的长度*/
	function changeNumberHeight(text,font){
		var temp = $("[class *= "+text+"]").length;
		for(var i = 1;i<temp+1;i++){
			var font1 = $("."+text+""+i+">ul>li").length;
			for(var j = 0;j<font1;j++){
				var before = $("."+text+""+i+">ul>li:eq("+(j-1)+")>.number>div").offset().top-25;
				var now = $("."+text+""+i+">ul>li:eq("+j+")>.number>div").offset().top-25;
				var height = ($("."+text+""+i+">ul>li:eq("+j+")>."+font+"").height()+10)/2;
				var distance = now - before;
				if(j != 0){
					$("."+text+""+i+">ul>li:eq("+j+")>.vertical").css({"top" : ""+now-height+"px","height":""+distance+"px"});
				}
			}
		}
	}



	function page1(){


		$(".join").css("color","indianred")
		$(".join>div").css("background-color","indianred")
		$(".join").siblings().css("color","black")
		$(".creat>div").css("background-color","white")
		$(".captain>div").css("background-color","white")


		$(".show").html(
			"<div class='jstep1'></div>"+
	    	"<div class='jtext1'><span class='jfont'>用户已注"+
	    	"册并进行资质认证，且用户已在平台"+
	    	"上成功出单1张</span></div>"+
			"<div class='jstep2'></div>"+
			"<div class='jtext2'><span class='jfont'>自主添加，"+
			"通过搜索团队名称进入团队或进入我的团队页面，"+
			"选择进入团队，或者通过团长二维码、"+
			"链接邀请进入团队</span></div>"+
			"<div class='jstep3'></div>"+
			"<div class='jtext3'><span class='jfont'>您将不是一个人在战斗，"+
			"是大家在一起为一个共同的目标而努力，这就是团队的意义！</span></div>");
	}

	function page2(){


		$(".creat").css("color","royalblue")
		$(".creat>div").css("background-color","royalblue")
		$(".creat").siblings().css("color","black")
		$(".join>div").css("background-color","white")
		$(".captain>div").css("background-color","white")


		$(".show").html(
			"<div class='cstep1'></div>"+
			"<div class='ctext1'>"+
				"<ul>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'>"+
							"<div>1</div>"+
						"</div>"+
						"<div class='cfont'>用户已注册并进行资质认证</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>2</div></div>"+
						"<div class='cfont'>用户已在平台上成功出单1张</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>3</div></div>"+
						"<div class='cfont'>邀请10个好友注册并进行资质认证</div>"+
					"</li>"+
				"</ul>"+
			"</div>"+
			"<div class='cstep2'></div>"+
			"<div class='ctext2'>"+
				"<ul>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>1</div></div>"+
						"<div class='cfont'>赠送价值240元测评大礼包</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>2</div></div>"+
						"<div class='cfont'>已成为团长的用户可根据成长值积分划分为六个等级，团长按照相对应等级获取相对应团长管理津贴</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>3</div></div>"+
						"<div class='cfont'>享有线下职场服务</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>4</div></div>"+
						"<div class='cfont'>免费享用平台全部展业文宣资料及团长管理功能</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>5</div></div>"+
						"<div class='cfont'>线下定期举办沙龙活动可按照成长值等级获取相应邀请客户名额</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>6</div></div>"+
						"<div class='cfont'>线下定期针对团员举办名师讲课，针对行业专业知识，销售技巧等进行专业指导</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>7</div></div>"+
						"<div class='cfont'>生日祝福（生日当天成交可领取小白保险生日专属大礼包）</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>8</div></div>"+
						"<div class='cfont'>享受小白保险为您提供的专属客服服务</li>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>9</div></div>"+
						"<div class='cfont'>线上专家在线一对一咨询</div>"+
					"</li>"+

				"</ul>"+
			"</div>"+
			"<div class='cstep3'></div>"+
			"<div class='ctext3'>"+
				"<ul>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>1</div></div>"+
						"<div class='cfont'>邀请新人必须注册并进行资质认证</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>2</div></div>"+
						"<div class='cfont'>团长级别分为六个级别，每月月底进行业绩核算，业绩核算根据当月完成的交易额对应的团队管理津贴级别进行核算</div>"+
					"</li>"+
				"</ul>"+
				"</div>"
		)
		$('.number>div').css('color','royalblue')
		//6以下分辨率不兼容
		setHeight("ctext","cfont","#E1E6F8")
	}

	function page3(){


		$(".captain").css("color","darkgreen")
		$(".captain>div").css("background-color","darkgreen")
		$(".captain").siblings().css("color","black")
		$(".join>div").css("background-color","white")
		$(".creat>div").css("background-color","white")


		$(".show").html(


			"<div class='pstep1'></div>"+
			"<div class='pstep2'></div>"+
			"<div class='ptext1'>"+
				"<ul>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>1</div></div>"+
						"<div class='pfont'>管理津贴在用户成为团队长后次月开始生效计算，津贴按月度统计，次月月底发放</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>2</div></div>"+
						"<div class='pfont'>津贴展示为当季月实时数据，如跨月退保，则各项数据将可能发生变化，请以当时发放数据为准</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>3</div></div>"+
						"<div class='pfont'>出单的团友必须完成资质认证</div>"+
					"</li>"+
				"</ul>"+
			"</div>"+
			"<div class='pstep3'></div>"+
			"<div class='ptext2'>"+
				"<ul>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>1</div></div>"+
						"<div class='pfont'>团员育成：你的团员成为团长完成团要求定义为育成</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>2</div></div>"+
						"<div class='pfont'>团员晋升团长必须重新组建的团队中完成资质认证人数达3人，成功在平台上出单1张</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>3</div></div>"+
						"<div class='pfont'>育成的团队长个人成交额算入原本团队内，育成团队团员全体保费将视为育成津贴，作为育成津贴基数进行核算</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>4</div></div>"+
						"<div class='pfont'>育成津贴在你的团友成为团队长并成一级团长下个自然月开始生效计算，津贴按月统次月月底发放</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>5</div></div>"+
						"<div class='pfont'>后计津贴展示为当月实时数据，如跨月退保，则各项数据将可能发生变化，请以当时发放数据为准</div>"+
					"</li>"+
					"<li>"+
						"<div class='vertical'></div>"+
						"<div class='number'><div>6</div></div>"+
						"<div class='pfont'>出单的所有团友必须完成资质认证</div>"+
					"</li>"+
				"</ul>"+
			"</div>"
		)
		$('.number>div').css('color','darkgreen')
		setHeight("ptext","pfont","#e0e6e5")
	}





	/*根据传送的值显示出对应的页面*/
	$(document).ready(function(){



		var page = GetRequest().page;
		switch(page){
			case "1" :
					page1();
				break;
			case "2" :
					page2();
				break;
			case "3":
					page3();
			default:
				page = 1;
		}
	})




	$(".title>ul>li").click(function(){
		var index = $(this).index();
		if(index == 0){
			page1()
		}else if(index ==1){
			page2()
		}else{
			page3()
		}
	})

    countAction("xb_2075");

})
