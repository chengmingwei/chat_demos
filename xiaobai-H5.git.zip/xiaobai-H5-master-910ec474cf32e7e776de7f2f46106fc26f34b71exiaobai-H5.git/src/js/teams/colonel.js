//获取当前年份
let myDate = new Date();
let year = myDate.getFullYear(); //获取当前年
let mon = myDate.getMonth() + 1; //获取当前月
mon = mon < 10 ? '0' + mon : mon;
let yearsMonth = year + "-" + mon;	//年-月
let teamId;

window.onload = function () {
    $$.changeVersion();
    //数据统计
    try {
        countAction('xb_73', null);
        countAction("xb_2076");
    } catch (error) {
        console.log(error);
    }

    /* 从加团页面传值 */
    teamId = decodeURIComponent($$.getUrlParam("teamId"));//团队ID

    let isPageHide = false;
    window.addEventListener('pageshow', function () {
        if (isPageHide) {
            window.location.reload();
        }
    });
    window.addEventListener('pagehide', function () {
        isPageHide = true;
    });
    /*点击团队规则*/
    $(".rule").click(() =>{
        $$.push('teams/rule',{page:1});
    });

    $('.teamMsg .time > div,.cultivate .time > div,.joinTeam .time > div').html(yearsMonth);

    /* 加载页面top */
    modelLoad();


};

//文字横向滚动
function scrollImgLeft() {
    const speed = 50;//初始化速度 也就是字体的整体滚动速度
    const MyMar = null;//初始化一个变量为空 用来存放获取到的文本内容
    let scroll_begin = $("#scroll_begin");//获取滚动的开头id
    let scroll_end = $("#scroll_end");//获取滚动的结束id
    let scroll_div = $("#scroll_div");//获取整体的开头id

    if(scroll_begin.width() > scroll_div.width()){
    	scroll_end.html(scroll_begin.html());//滚动的是html内部的内容,原生知识!
    }
  	//定义一个方法
    function Marquee() {
        if (scroll_end[0].offsetWidth - scroll_div[0].scrollLeft <= 0)
            scroll_div[0].scrollLeft -= scroll_begin[0].offsetWidth;
        else
            scroll_div[0].scrollLeft++;
    }
    setInterval(Marquee, speed);

}

/* 加载页面 */
function modelLoad(){
	/* 加载团队信息 */
    $$.request({
        url: UrlConfig.market_team_wx_show,
        pars:{
        	teamId:teamId,
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                //团队基本信息
                teamBaseData(teamId,data);

                //团队等级
                let nowLv = data.teamLevelCode;
                getTeamLevel(teamId,nowLv);

                let finishTime = data.finishTime;//成团时间

                //点击邀请
                inviteBtn(teamId);

                //-- 加载团队出单数、总保费（元）
                getTeamCount(teamId,finishTime);

                /* 加载团队津贴  type(1、加载全部津贴，2、加载团队信息津贴，3、加载育成团队津贴)*/
                modelLoadSubsidy(teamId,"",1);

                //团队信息
                /* 加载团队信息 */
                modelLoadTeamInformation(teamId,0);

                //点击本团团队信息的时间
                teamMsgTimeBtn(teamId,finishTime);

                /*本团新增人数*/
                $('.addCount').click(()=>{
                    $$.push('teams/addMember',{teamId:teamId});
                });

                //子团育成信息
                const childrenTeamTotal = data.childrenTeamTotal;
                if (childrenTeamTotal > 0) {
                    $('.cultivate,.cultivateCountAndTeamMoney,.verticalLong_3').show();
                    //获取 某月份 新增团员总数
                    modelLoadYuChengTeamNumber(teamId);

                    //点击子团育成团队信息的时间
                    cultivateTimeBtn(teamId,finishTime);

                    /*子团育成团数*/
                    $('.cultivateCount').click(()=>{
                        $$.push('teams/cradleTeams',{teamId:teamId});
                    });
                }
                //父团团队信息
                const parentTeamId = data.parentTeamId;
                if ($$.isValidObj(parentTeamId)) {
                    $('.joinTeam,.addCountAndTeamMoney_2,.verticalLong_4').show();

                    modelLoadTeamInformation(parentTeamId,1);

                    //点击新增人数，跳转用户加入的团员新增页面
                    $('.addCount').click(()=>{
                        $$.push('teams/addMember',{teamId:parentTeamId});
                    });

                    /*点击更多*/
                    $('.more > div').click(() => {
                        $$.push('teams/particular',{teamId:parentTeamId});
                    });

                    //点击父团信息的时间
                    joinTeamTimeBtn(parentTeamId,finishTime);
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });

}

//根据团长等级变换图标
function getTeamLevel(teamId,nowLv) {
    if(nowLv !== "LV.0"){
        $('.teamMsg > .text').css('width' , '22%');
        $('.teamMsg > .teamLevel').html('<img src="../../images/teams/captain/' + nowLv + '.png" />');
        $('.teamMsg > .teamLevel').on('click',function () {
            $$.push('my/commanderLevel',{teamId:teamId});
            return false;
        });
    }
}

//获取 某月份 新增团员总数
function modelLoadTeamInformation(teamId,isParent,month){
	//获取当前年-月
    if(!$$.isValidObj(month)){
    	month = yearsMonth;
    }
    /* 获取 某月份 新增团员总数 和 总保费（元） */
	$$.request({
        url: UrlConfig.market_teammember_wx_getTeamInformation,
        pars:{
            teamId:teamId,
            yearsMonth:month,
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let teamCount = data.datas.teamCount;//本团新增人数
                let grossPremium = data.datas.grossPremium; 	//加入团队某月总保费

                if (isParent === 0) {
                    $(".teamCount").text(teamCount);
                } else {
                    $(".joinTeamCount").text(teamCount);
                    $(".joinGrossPremium").text(grossPremium);
                }
            } else {
                if (isParent === 0) {
                    $$.layerToast(data.msg);
                } else {
                    console.log("用户未加入其它团队~");
                }
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

//获取 某月份 育成团队数
function modelLoadYuChengTeamNumber(teamId,month){
    //获取当前年-月
    if(!$$.isValidObj(month)){
        month = yearsMonth;
    }
    /* 获取 某月份 新增团员总数 和 总保费（元） */
    $$.request({
        url: UrlConfig.market_team_wx_getYuChengTeamNumber,
        pars:{
            teamId:teamId,
            yearsMonth:month,
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                //本团新增人数
                let teamCount = data.datas.teamCount;

                $(".cultivateCountAndTeamMoney>.cultivateCount p").text(teamCount);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

//获取团队总津贴金额、某月团队津贴金额、某月育成团津贴金额
function modelLoadSubsidy(teamId,month,type){
	//获取当前年-月
    if(month === ""){
        month = yearsMonth;
    }

    /* 获取 某月份 团队津贴金额 和 育成团津贴金额 */
	$$.request({
        url: UrlConfig.market_teamsubsidy_getTeamSubsidy,
        pars:{
        	teamId:teamId,
        	yearsMonth:month,
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	let mgrAmount = data.datas.mgrAmount > 9999 ?(((data.datas.mgrAmount%100)/10000+'万')):(data.datas.mgrAmount);		//团队管理津贴
				let mgrSubsidy = data.datas.mgrSubsidy;		//团队管理津贴比例
				let teamSaleAmount = data.datas.teamSaleAmount > 9999 ?(((data.datas.teamSaleAmount%100)/10000+'万')):(data.datas.teamSaleAmount);		//团队保费

        		let rearAmount = data.datas.rearAmount > 9999 ?(((data.datas.rearAmount%100)/10000+'万')):(data.datas.rearAmount);		//育成管理津贴
				let rearSubsidy = data.datas.rearSubsidy;	//育成管理津贴比例
				let rearSaleAmount = data.datas.rearSaleAmount > 9999 ?(((data.datas.rearSaleAmount%100)/10000+'万')):(data.datas.rearSaleAmount);	//育成团队保费

            	if(type === 1){
            		$(".addCountAndTeamMoney>.allowance p").text(mgrAmount);
            		$(".addCountAndTeamMoney>.proportion p").text(mgrSubsidy);
            		$(".addCountAndTeamMoney>.teamMoney p").text(teamSaleAmount);

            		$(".cultivateCountAndTeamMoney>.allowance p").text(rearAmount);
            		$(".cultivateCountAndTeamMoney>.proportion p").text(rearSubsidy);
            		$(".cultivateCountAndTeamMoney>.teamMoney p").text(rearSaleAmount);
            	}else if(type === 2){
            		$(".addCountAndTeamMoney>.allowance p").text(mgrAmount);
            		$(".addCountAndTeamMoney>.proportion p").text(mgrSubsidy);
            		$(".addCountAndTeamMoney>.teamMoney p").text(teamSaleAmount);
            	}else if(type === 3){
            		$(".cultivateCountAndTeamMoney>.allowance p").text(rearAmount);
            		$(".cultivateCountAndTeamMoney>.proportion p").text(rearSubsidy);
            		$(".cultivateCountAndTeamMoney>.teamMoney p").text(rearSaleAmount);
            	}

            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
//根据团长ID获取已加团的团ID查询某月份新增团员列表
function getTeamId(teamId,month){
	//获取当前年-月
    if(!$$.isValidObj(month)){
    	month = yearsMonth;
    }

	$$.request({
        url: UrlConfig.market_teammember_wx_getTeamInformation,
        pars:{
            teamId:teamId,
            yearsMonth:month,
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let joinTeamCount = data.datas.teamCount;	//加入团队新增人数
                let joinGrossPremium = data.datas.grossPremium; 	//加入团队某月总保费

                $(".joinTeamCount").text(joinTeamCount);
                $(".joinGrossPremium").text(joinGrossPremium);
            } else {
            	console.log("用户未加入其它团队~");
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

/*点击邀请*/
function inviteBtn(teamId){
    teamWeChatShare(teamId);
    $('.invite,.share_small').click(() => {
    	teamShare(teamId);
    	countAction("xb_3034");
    });
}

//-- 加载团队出单数、总保费（元）
function getTeamCount(teamId,finishTime) {
    $$.request({
        url: UrlConfig.market_teammember_wx_getTeamCount,
        pars:{
            teamId:teamId,
            finishTime:finishTime
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let orderNumber = data.datas.orderNumber;	//出单数
                $('.orderNumber').html(orderNumber);
                let payMoney = data.datas.payMoney > 9999 ?(((data.datas.payMoney%100)/10000+'万')):(data.datas.payMoney);	//总保费
                $('.payMoney').html(payMoney);
                allowance(teamId);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function allowance(teamId) {
    /* 获取 团队总津贴金额 */
    $$.request({
        url: UrlConfig.market_teamsubsidy_getTeamSubsidy,
        pars:{
            teamId:teamId,
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let amount = data.datas.amount > 9999 ?(((data.datas.amount%100)/10000+'万')):(data.datas.amount);
                $(".allowance > p").text(amount);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function teamMsgTimeBtn(teamId,finishTime) {
    let start,end;
    /*点击本团团队信息的时间*/
    $('.teamMsg>.time').click(() => {
        finishTime.length == 7 ? start = finishTime+"-01":finishTime;
        yearsMonth.length == 7 ? end = yearsMonth+"-01":yearsMonth;
        weui.datePicker({
            id: 1,
            start: start,
            depth : 2,
            end : end,
            onConfirm:function(result){
                let month = String(result[1].value);
                if(month.length === 1){
                    month = month.padStart(2,"0");	//字符串补全
                }
                let time = result[0] +"-"+ month;
                $('.teamMsg>.time>div').text(time);

                modelLoadSubsidy(teamId,time,2);
                modelLoadTeamInformation(teamId,0,time);
            }
        })
    });
}
function cultivateTimeBtn(teamId,finishTime) {
    let start,end;
    /*点击子团育成团队信息的时间*/
    $('.cultivate>.time').click(() => {
        finishTime.length == 7 ? start = finishTime+"-01":finishTime;
        yearsMonth.length == 7 ? end = yearsMonth+"-01":yearsMonth;
        weui.datePicker({
            id: 2,
            start: start,
            depth : 2,
            end : end,
            onConfirm:function(result){
                let month = String(result[1].value);
                if(month.length === 1){
                    month = month.padStart(2,"0");	//字符串补全
                }
                let time = result[0] +"-"+ month;
                $('.cultivate>.time> div').text(time);

                modelLoadSubsidy(teamId,time,3);
                modelLoadYuChengTeamNumber(teamId,time);
            }
        })
    });
}
function joinTeamTimeBtn(teamId,finishTime) {
    let start,end;
    /*点击父团信息的时间*/
    $('.joinTeam > .time').click(() => {
        finishTime.length == 7 ? start = finishTime+"-01":finishTime;
        yearsMonth.length == 7 ? end = yearsMonth+"-01":yearsMonth;
        weui.datePicker({
            id: 3,
            start: start,
            depth : 2,
            end : end,
            onConfirm:function(result){
                let month = String(result[1].value);
                if(month.length === 1){
                    month = month.padStart(2,"0");	//字符串补全
                }
                let time = result[0] +"-"+ month;
                $('.joinTeam>.time> div').text(time);

                modelLoadTeamInformation(teamId,1,time);
            }
        });
    });
}
function teamBaseData(teamId,data) {
    let teamName = data.teamName;
    $('#teamNameText').html(teamName);
    let flagPath = data.flagPath;
    if((flagPath==null)||(flagPath==="")) {
        flagPath = '../../images/teams/addDetails/member.png';	//会员头像
    }
    $('.flagPath').attr('src',flagPath);
    let slogan = data.slogan;	//口号
    $('.slogan_1 .character').html(slogan);
    let synopsis = data.synopsis;	//简介
    $('.slogan_2 .character').html(synopsis);
    let teamMemberList = data.teamMemberList;	//团队成员集合
    let headcount = teamMemberList.length;	//总人数
    $('.headcount').html(headcount);
    let provinceId = data.provinceId;	//省
    let cityId = data.cityId;	//市
    $('.addr > div').html(provinceId + cityId);
    let msgCall = data.msgCall;
    if (msgCall) {
        $('.circle').show();
    }
    let remark = data.remark;	//团队公告
    $('.remark').html(remark);

    //文字横向滚动
    scrollImgLeft();

    /*点击修改团队资料*/
    $('.flagPath,#teamNameText').click(()=>{
        $$.push('teams/details',{teamId:teamId});
    });

    //-- 未开通团长功能包，跳转购买VIP页面
    $(".notOpenServices").click(()=>{
        $$.push('my/purchaseVIP/purchaseVIP');
    });

    //-- 已开通团长功能包，跳转团长看板页面
    $(".openServices").click(()=>{
        $$.push('teams/colonelSeeVersion/colonelSeeVersion',{teamId:teamId});
    });

    //进入消息
    $('.msg').on('click',() =>{
        $$.push('teams/msg',{
            teamMemberId:data.teamMemberId
        });
    });

    /* 我的团队 */
    $('.myTeam div').click(() => {
        $$.push('teams/particular',{teamId:teamId});
    });

    // 获取当前用户的VIP信息
    getVipData(data.hasTask);
    taskRemind(data);

}

function taskRemind(data) {
    const taskTotal = data.taskTotal;
    if (taskTotal > 0) {
        const taskType = data.taskType;
        const taskTitle = data.taskTitle;
        let taskTip = taskTotal + '个任务/通知';
        if (taskType === 1) {
            taskTip = taskTotal + '个任务';
        } else if (taskType === 2) {
            taskTip = taskTotal + '个通知';
        }
        if (taskTotal === 1) {
            $('.taskPopup .taskDetails .taskContent').html(taskTitle);
        }
        $('.taskPopup .taskDetails  > div > span').html(taskTip);

        $('.taskPopup .view').on('click',function () {
            if (taskTotal === 1) {
                const taskMemberId = data.taskMemberId;
                $$.push('teams/viewTaskConfirm',{
                    taskType:taskType,
                    taskMemberId:taskMemberId
                });
            } else {
                $$.push('teams/msg',{
                    teamMemberId:data.teamMemberId
                });
            }
        });
        $('.taskPopup').show();
    }
}

//-- 获取当前用户的VIP信息
function getVipData(hasTask) {
    $$.request({
        url: UrlConfig.member_memberVip_getVipData,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                if (data.vipType === 0 || data.vipType === 1){
                    $(".notOpenServices").show();
                } else if (data.vipType === 2){
                    $(".openServices").show();
                }

                $('.compile').show().click(()=>{
                    if (data.vipType === 0 || data.vipType === 1){
                        popup("使用此功能需开通团长加速包");
                    } else if (data.vipType === 2){
                        if (hasTask) {
                            $$.push('teams/myPublishedTasks',{teamId:teamId});
                        } else {//第一次发布任务
                            $$.push('teams/releaseTask',{teamId:teamId});
                        }
                    }
                });
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}


//-- 弹窗 - 跳转购买VIP页面
function popup(title) {
    $$.confirm({
        title: title,
        onOkLabel: "去开通",
        onCancelLabel: "取消",
        onOk: function () {
            $$.push('my/purchaseVIP/purchaseVIP');
        }
    });
}
