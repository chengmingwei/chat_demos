let intDiff = parseInt(60*60*24*2);//倒计时总秒数量
function timer(intDiff){
    window.setInterval(function(){
    let day=0,
        hour=0,
        minute=0,
        second=0;//时间默认值
    if(intDiff > 0){
        day = Math.floor(intDiff / (60 * 60 * 24));
        hour = Math.floor(intDiff / (60 * 60)) - (day * 24);
        minute = Math.floor(intDiff / 60) - (day * 24 * 60) - (hour * 60);
        second = Math.floor(intDiff) - (day * 24 * 60 * 60) - (hour * 60 * 60) - (minute * 60);
    }
    if (hour <= 9) hour = '0' + hour;
    if (minute <= 9) minute = '0' + minute;
    if (second <= 9) second = '0' + second;
    $('.day').html(day);
    $('.hour').html(hour);
    $('.minute').html(minute);
    $('.second').html(second);
    intDiff--;
    }, 1000);
}

$(function(){
    //数据统计
    try {
        countAction('xb_73', null);
        countAction("xb_2076");
    } catch (error) {
        console.log(error);
    }
    const teamMemberId = decodeURIComponent($$.getUrlParam("teamMemberId"));
    applyLittleTime(teamMemberId);

    $('.model_4>div').click(function(){
    	$$.push('teams/rule',{page:2});
    });

});
function applyLittleTime(teamMemberId){
	$$.request({
        url: UrlConfig.market_teammember_wx_applyLittleTime,
        loading: true,
        pars:{teamMemberId:teamMemberId},
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	intDiff = data.littleTime;
            	timer(intDiff);
			    $('.submit').css('display','block').click(function(){
			    	cancelApply(teamMemberId);
			    });
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function cancelApply(teamMemberId){
	$$.request({
        url: UrlConfig.market_teammember_wx_cancelApply,
        loading: true,
        pars:{teamMemberId:teamMemberId},
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	$$.push('teams/join');
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
