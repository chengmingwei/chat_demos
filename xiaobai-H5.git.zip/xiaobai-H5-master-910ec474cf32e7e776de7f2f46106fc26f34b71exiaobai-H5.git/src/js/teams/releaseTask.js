const PAGE_STATE = {
    teamId:null,
    mainInputId:'salesTarget',
    pageSize:20,
    currentPage:1,
    total:0,
    memberList:{
        salesTarget:[],
        activityNotice:[]
    },
    isRemind:{
        salesTarget:1,
        activityNotice:1
    },
    selectedLength:0
};
window.onload = function () {
    $$.changeVersion();
    PAGE_STATE.teamId = decodeURIComponent($$.getUrlParam("teamId"));//团队ID
    $('.taskType .select > div > span').on('click',function () {
        $('.taskType .select > div > span').removeClass('checked');
        $(this).addClass('checked');
        let taskType = $(this).attr('id');
        taskType = taskType.replace('taskType','');
        if (taskType === '1'){
            $('#salesTarget').addClass('open');
            $('#activityNotice').removeClass('open');
            $(".save>div").text("发布任务").attr("data-value", 1);
        } else {
            $('#salesTarget').removeClass('open');
            $('#activityNotice').addClass('open');
            $(".save>div").text("发布活动").attr("data-value", 2);
        }
        PAGE_STATE.mainInputId = $('.mainInput.open').attr('id');
    });
    $('.mainInput .time .inputDiv > input').on("click",function () {
        const _this = $(this);
        weui.datePicker({
            id: 'date1',
            className: 'expect_date_picker',
            start: new Date(),
            onConfirm:function(result){
                let yue = String(result[1].value);
                yue = yue < 10 ? '0' + yue : yue;
                let ri = String(result[2].value);
                ri = ri < 10 ? '0' + ri : ri;
                let date = result[0].value +"-"+ yue + '-' + ri;
                // 二级调用：时间
                $('.expect_date_picker .weui-picker').on('animationend webkitAnimationEnd', function() {
                    if (date == localTime()){
                        let myDate = new Date();
                        let hours = myDate.getHours()
                        show_expect_time_picker(_this, date ,hours);
                    } else {
                        show_expect_time_picker(_this, date);
                    }
                });
            }
        })
    });
    /**----- 市区定位  事件绑定 ----**/
    $(".downtown").on("click",function() {
        /* 需要用地图选点，市区只获取省、市、区，其他地址信息保存到详细地址栏 */
        let point;
        console.log('downtown1');
        // 获取微信地理位置
        weChatJSTool.getLocation(function (res) {
            let longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
            let latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
            console.log(longitude);
            console.log(latitude);
            console.log('downtown2');


            //创建点坐标
            point = new BMap.Point(longitude, latitude);
            //根据微信地理位置转换百度详细地址
            locations(point,"");
        });
        console.log('downtown3');

    });
    $('.mainInput .picture > div').on("click",function () {
        $(this).find('input')[0].click();
    });
    $('.mainInput .picture > div > input').on('change',function () {
        const _this = $(this);
        let file=_this[0].files[0];
        //文件类型
        let fileType=file.type;
        let type=getFileType(fileType);
        //文件大小
        let fileSize=(file.size/ 1024).toFixed(2);
        if(type!=="jpg"&&type!=="gif"&&type!=="jpeg"&&type!=="png"){
            $$.layerToast('请上传图片');
            return false;
        }
        if(fileSize>10240){//定义不能超过10MB
            $$.layerToast('请上传不超过10M的图片');
            return false;
        }
        lrz(file).then(function (resultObj) {
            _this.siblings('img').attr("src",resultObj.base64);
            _this.siblings('img').css('display','block');
            _this.siblings('.btn').css('display','none');
        });
    });

    //--
    $('.mainInput .selectMember span.btn').on('click',function () {
        PAGE_STATE.currentPage = 1;
        $(".addPopup").show();
        openPopList();
    });

    //-- 是否 - 推送通知
    $(".mainInput .isRemind .switch").on("click", function(){
        const _this = $(this);
        let isRemind = PAGE_STATE.isRemind[PAGE_STATE.mainInputId];
        if (isRemind === 1) {
            _this.removeClass('yes');
            isRemind = 0;
        } else {
            _this.addClass('yes');
            isRemind = 1;
        }
        PAGE_STATE.isRemind[PAGE_STATE.mainInputId] = isRemind;
    });

    //-- 取消
    $('.cancel').on('click',function () {
        $(".addPopup").hide();
    });

    //-- 确认
    $('.complete').on('click',function () {
        let idArr = [];
        let rname1st = '';
        $('.eachUser .choose.yes').each(function () {
            let id = $(this).parents('.eachUser').attr('id');
            id = id.replace('teamMemberId_','');
            idArr.push(id);
            if (idArr.length === 1) {
                rname1st = $(this).parents('.eachUser').find('.userInfo > span').html();
            }
        });
        const idArrLength = idArr.length;
        const mainInputId = PAGE_STATE.mainInputId;
        PAGE_STATE.memberList[mainInputId] = idArr;
        const selectMember = $('#' + mainInputId + ' .selectMember span.btn');
        let selectMemberText = '';
        if (idArrLength > 0) {
            selectMemberText = '全部团员（' + PAGE_STATE.total + '人）';
            selectMember.addClass('hasMember');
            if (PAGE_STATE.total > idArrLength) {
                selectMemberText = rname1st + '等' + idArrLength + '人'
            }
        } else {
            selectMemberText = '添加';
            selectMember.removeClass('hasMember');
        }
        selectMember.html(selectMemberText);
        $(".addPopup").hide();
    });

    $('.save > div').on('click',function () {
        checkValid();
    });
};

//-- 选择小时
function show_expect_time_picker(_this, date, value = 0) {
    let hours = [];
    for (let i = value; i< 24; i++) {
        let hours_item = {};
        hours_item.label = i + '时';
        hours_item.value = i;
        hours.push(hours_item);
    }
    weui.picker(hours, {
        defaultValue: [value],
        onConfirm: function(result) {
            let hour = result[0].label;
            let expect_date = date + ' ' + hour;
            _this.val(expect_date);
        },
        id: 'time1'
    });
}

/* 获取GPS定位wgs84（经度,纬度）转换百度 坐标BD09 加载地图*/
function locations(point,search){
    // 创建地图实例
    let map = new BMap.Map("map");
    //地图初始化
    map.centerAndZoom(point, 15);
    console.log('downtown4');
    //坐标转换完之后的回调函数
    const translateCallback = function (data){
        if(data.status === 0) {

            console.log('downtown5');
            //开启加载层
            $$.loading();
            //获取坐标位置的省市并返回
            let geoc = new BMap.Geocoder();
            geoc.getLocation(data.points[0], function(rs){
                console.log('downtown6');
                let addComp = rs.addressComponents;
                let detailedAddress = addComp.province + addComp.city + addComp.district + addComp.street + addComp.streetNumber;

                $('.mainInput .address > textarea').val(detailedAddress);
                $$.closeLoading();
            });
        }
    };
    console.log('downtown7');
    //GPS坐标wgs84 转 百度 坐标BD09
    setTimeout(function(){
        console.log('downtown8');
        let convertor = new BMap.Convertor();
        let pointArr = [];
        pointArr.push(point);
        convertor.translate(pointArr, 1, 5, translateCallback);
        console.log('downtown9');

    }, 1000);
}
function getFileType(filePath) {
    let startIndex=filePath.lastIndexOf("/");
    if(startIndex!==-1){
        return filePath.substring(startIndex+1,filePath.length).toLowerCase();
    }else {
        return "";
    }
}
function checkValid() {
    let taskType = $('.taskType .select > div > span.checked').attr('id');
    taskType = taskType.replace('taskType','');
    let taskTypeStr = '#' + PAGE_STATE.mainInputId;
    let param = {teamId:PAGE_STATE.teamId};
    let saveUrl = UrlConfig.market_teamsalestarget_wx_save;
    if (taskType === '1'){
        param['huo4ke4ren2shu4'] = $('#huo4ke4ren2shu4').val();
        param['xiao1shou4ye4ji4'] = $('#xiao1shou4ye4ji4').val();
        param['cheng2jiao1ding4dan1'] = $('#cheng2jiao1ding4dan1').val();
        param['fa1zhan3tuan2yuan2'] = $('#fa1zhan3tuan2yuan2').val();
    } else {
        saveUrl = UrlConfig.market_teamactivitynotice_wx_save;
        param['address'] = $('#address').val();
    }
    param['title'] = $(taskTypeStr + ' .title > input').val();
    let msg = '';
    if (!$$.isValidObj(param['title'])) {
        msg = '任务标题';
        if (taskType === '2') {
            msg = '活动主题';
        }
        $$.layerToast(msg + '不能为空');
    } else {
        let timeArr = [];
        $(taskTypeStr + ' .time .inputDiv > input').each(function () {
            const timeVal = $(this).val();
            if ($$.isValidObj(timeVal)) {
                timeArr.push(timeVal);
            }
        });
        param['time'] = timeArr;
        if (timeArr.length < 2) {
            $$.layerToast('开始时间和结束时间不能为空');
        } else {
            if (taskType === '1' && (!$$.isValidObj(param['huo4ke4ren2shu4']) &&
                !$$.isValidObj(param['xiao1shou4ye4ji4']) &&
                !$$.isValidObj(param['cheng2jiao1ding4dan1']) &&
                !$$.isValidObj(param['fa1zhan3tuan2yuan2']))) {
                $$.layerToast('获客人数、销售业绩、成交订单、发展团员，这些至少填写一项');
            } else {
                param['explain'] = $(taskTypeStr + ' .explain > textarea').val();
                if (!$$.isValidObj(param['explain'])) {
                    msg = '任务说明';
                    if (taskType === '2') {
                        msg = '活动说明';
                    }
                    $$.layerToast(msg + '不能为空');
                } else {
                    let picArr = [];
                    $(taskTypeStr + ' .picture > div').each(function () {
                        if ($$.isValidObj($(this).children('img').attr('src'))) {
                            picArr.push($(this).children('input')[0].files[0]);
                        }
                    });
                    param['picListFile'] = picArr;
                    if (picArr.length === 0) {
                        $$.layerToast('图片至少上传一张');
                    } else {
                        param['memberList'] = PAGE_STATE.memberList[PAGE_STATE.mainInputId];
                        if (param['memberList'].length === 0) {
                            $$.layerToast('请选择发布对象');
                        } else {
                            param['isRemind'] = PAGE_STATE.isRemind[PAGE_STATE.mainInputId];
                            console.log(param);
                            picUpload(param,saveUrl);
                        }
                    }
                }
            }
        }
    }
}
function picUpload(param,saveUrl) {
    param['picListPath'] = [];
    loopFileUpload(param,saveUrl,0);
}
function loopFileUpload(param,saveUrl,i) {
    const file = param['picListFile'][i];
    if (file) {
        i = i + 1;
        let formData = new window.FormData();
        formData.append('file', file);
        formData.append('formType', '50');
        $$.request({
            url: UrlConfig.upload_attachment_upload,
            loading: true,
            pars:formData,
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    param['picListPath'].push(data.datas.filePath);
                    i = i + 1;
                    loopFileUpload(param,saveUrl,i);
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    } else {
        creatSubmit(param, saveUrl);
    }
}
function creatSubmit(param, saveUrl) {
    console.log(saveUrl);
    console.log(param);
    $$.request({
        url: saveUrl,
        loading: true,
        pars:param,
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                let value = parseInt($(".save>div").attr("data-value"));
                window.location.replace('myPublishedTasks.html?teamId=' + PAGE_STATE.teamId +'&value=' + value);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function openPopList() {
    $$.request({
        url: UrlConfig.market_teammember_pageListByTesk,
        loading: true,
        pars:{
            currentPage:PAGE_STATE.currentPage,
            pageSize:PAGE_STATE.pageSize,
            teamId:PAGE_STATE.teamId,
            selectedList:PAGE_STATE.memberList[PAGE_STATE.mainInputId]
        },
        requestBody:true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                createList(data.list);
                PAGE_STATE.total = data.total;
                PAGE_STATE.currentPage = PAGE_STATE.currentPage + 1;
                PAGE_STATE.selectedLength = PAGE_STATE.memberList[PAGE_STATE.mainInputId].length;
                $('.addPopup .addPopupTop > span .total').html(PAGE_STATE.total);
                $('.addPopup .addPopupTop > span .selected').html(PAGE_STATE.selectedLength);
                //-- 选择
                $('.eachUser').off().on('click',function () {
                    const choose = $(this).children('.choose');
                    if (choose.hasClass("yes")){
                        choose.removeClass('yes');
                        PAGE_STATE.selectedLength = PAGE_STATE.selectedLength - 1;
                    } else {
                        choose.addClass('yes');
                        PAGE_STATE.selectedLength = PAGE_STATE.selectedLength + 1;
                    }
                    $('.addPopup .addPopupTop > span .selected').html(PAGE_STATE.selectedLength);
                    if (PAGE_STATE.selectedLength === $('.choose').length) {
                        $('.selectAll').html('取消全选').addClass('yes');
                    } else {
                        $('.selectAll').html('全选').removeClass('yes');
                    }
                });

                //-- 全选/取消全选
                $('.selectAll').html('全选').removeClass("yes").off().on('click',function () {
                    if ($(this).hasClass('yes')) {
                        $(this).html('全选').removeClass("yes");
                        $('.choose').removeClass("yes");
                        PAGE_STATE.selectedLength = 0;
                    } else {
                        $(this).html('取消全选').addClass('yes');
                        PAGE_STATE.selectedLength = $('.choose').addClass('yes').length;
                    }
                    $('.addPopup .addPopupTop > span .selected').html(PAGE_STATE.selectedLength);
                });
                $('.loadMore').off();
                if (PAGE_STATE.total > $('.eachUser .choose').length) {
                    //-- 点击加载更多
                    $('.loadMore').on('click',function () {
                        openPopList();
                    });
                } else {
                    $('.loadMore').html('—☟ 到底了 ☟—');
                }
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function createList(list) {
    if (PAGE_STATE.currentPage === 1) {
        $(".userList > ul").html('');
    }
    if(list && typeof(list) != 'undefined') {
        let htmlArr = [];
        for(let i = 0;i < list.length;i++){
            let xpro = list[i];
            htmlArr[i] = getHtmlByList(xpro);
        }
        let htmlCodes = htmlArr.join("");
        $(".userList > ul").append(htmlCodes);
    }
}
function getHtmlByList(xpro) {
    let rname = xpro.rname;
    let sex = xpro.sex;
    let imgPath = xpro.imgPath;
    let id = xpro.id;
    let selected = xpro.selected;
    id = 'teamMemberId_' + id;
    if (!$$.isValidObj(rname)) {
        rname = xpro.account;
    }
    if (!$$.isValidObj(imgPath)) {
        imgPath = '../../images/my/defaultImg.png';
    }
    let sexStr = 'man';
    if (sex === 2) {
        sexStr = 'woman';
    }
    let selectedClass = '';
    if (selected === 1) {
        selectedClass = ' yes';
    }
    let htmlArr=[
        '<li class="space-between eachUser" id="' + id + '">',
            '<div class="userInfo">',
                '<img src="' + imgPath + '" class="iconImg" />',
                '<span>' + rname + '</span>',
                '<img src="../../images/teams/addDetails/' + sexStr + '.png" class="sex" />',
            '</div>',
            '<div class="choose' + selectedClass + '"></div>',
        '</li>'
    ];
    return htmlArr.join("");
}

//-- 获取当前时间
function localTime(){
    let myDate = new Date();
    let year = myDate.getFullYear();                                                        //获取当前年
    let mon = myDate.getMonth()+1<10 ? "0"+(myDate.getMonth()+1) : (myDate.getMonth()+1);   //获取当前月
    let date = myDate.getDate()<10 ? "0"+myDate.getDate() : myDate.getDate();               //获取当前日
    let h = myDate.getHours()<10 ? "0"+myDate.getHours() : myDate.getHours();               //获取当前小时数(0-23)
    let m = myDate.getMinutes()<10 ? "0"+myDate.getMinutes() : myDate.getMinutes();         //获取当前分钟数(0-59)
    let s = myDate.getSeconds()<10 ? "0"+myDate.getSeconds() : myDate.getSeconds();         //获取当前秒

    let now = year+"-"+mon+"-"+date;	//当前时间 (2019.10.08)
    //let now = h+":"+m+":"+s;	        //当前时间 (12:00:00)

    return now;
}