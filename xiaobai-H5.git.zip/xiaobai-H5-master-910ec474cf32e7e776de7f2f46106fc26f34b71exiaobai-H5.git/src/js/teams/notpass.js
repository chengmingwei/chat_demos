$(function(){
    //数据统计
    try {
        countAction('xb_73', null);
        countAction("xb_2076");
    } catch (error) {
        console.log(error);
    }
    
    $('.submit').click(function(){
    	$$.push('teams/join');
    });
    
    $('.model_5>div').click(function(){
    	$$.push('teams/rule',{page:2});
    });
    
});