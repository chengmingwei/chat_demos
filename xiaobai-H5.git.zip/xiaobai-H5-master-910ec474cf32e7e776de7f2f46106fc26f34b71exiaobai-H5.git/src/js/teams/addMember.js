let myDate = new Date();
let year = myDate.getFullYear(); //获取当前年
let mon = myDate.getMonth() + 1; //获取当前月
mon = mon < 10 ? '0' + mon : mon;
let yearsMonth = year + "-" + mon;	//年-月
window.onload = function () {
    $$.changeVersion();
    $('.model_1 .date .time').html(yearsMonth);
    teamLoad();
};

//加载团员列表数据
function dataLoadContent(teamId,month){
	/* 获取 某月份 新增团员列表 */
    //获取当前年-月
    if(month === ""){
        month = yearsMonth;
    }
	$$.request({
        url: UrlConfig.market_teammember_wx_getNewMembersList,
        pars:{
        	teamId:teamId,
        	yearsMonth:month
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
            	console.log(data);
            	$('.model_1 .count').html(data.datas.length);
            	$('.model_2').html("");
                for (let i in data.datas) {
					//加载数据
			    	modelLoadTwo(data.datas, i);
				}

            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}

function modelLoadTwo(datas, i){
    let createTime = transformTime(datas[i].createTime);
    let rname = datas[i].rname;
    let imgPath = datas[i].imgPath === "null" ? ("../../images/my/smallLogo.png"):(datas[i].imgPath);
    let payMoney = datas[i].payMoney > 9999 ?(((datas[i].payMoney%100)/10000+'万')):(datas[i].payMoney);
    let orderNumber = datas[i].orderNumber;
	let htmlList = `<div class="team">
				<div class="listTeam">
					<div class="portrait">
						<img src="${imgPath}" />
					</div>
					<div class="msg">
						<div class="teamName">${rname}</div>
						<div class="teamDate">${createTime}</div>
					</div>
					<div class="teamNumber">
						<div class="issueNumber">
							<div class="left">出单数:</div>
							<div class="right">
								<div>${orderNumber}</div>
							</div>
						</div>
						<div class="premium">
							<div class="left">保费(元):</div>
							<div class="right">
								<div>${payMoney}</div>
							</div>
						</div>
					</div>
				</div>
			</div>`;
	$('.model_2').append(htmlList);
}

function transformTime(times){
    let timearr = times.replace(" ", ":").replace(/\:/g, "-").split("-");
    let timestr = ""+timearr[0]+"-" + timearr[1] + "-" + timearr[2];
    return timestr;
}

function teamLoad() {
    /* 从加团页面传值 */
    let teamId = decodeURIComponent($$.getUrlParam("teamId"));
    $$.request({
        url: UrlConfig.market_team_wx_show,
        pars:{
            teamId:teamId,
        },
        requestBody:true,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
            if (data.success) {
                const finishTime = data.finishTime + "-01";
                //加载团员列表数据
                dataLoadContent(teamId,'');

                timeBtn(teamId,finishTime);
            } else {
                $$.layerToast(data.msg);
            }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
function timeBtn(teamId,finishTime) {
    $('.time').click(() => {
        let end = yearsMonth + "-" + "01";	//年-月-日
        weui.datePicker({
            id: 1,
            start: finishTime,
            depth : 2,
            end : end,
            onConfirm: function(result) {
                let month = String(result[1].value);
                if(month.length === 1){
                    month = month.padStart(2,"0");	//字符串补全
                }
                let time = result[0] +"-"+ month;
                $('.model_1 .date .time').text(time);

                dataLoadContent(teamId, time);
            }
        });
    });
}
