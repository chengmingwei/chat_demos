/**
 * 查看团队任务 JS
 * @Author 吴成林
 * @Date 2020-2-24 14:20:25
 */
window.onload = function() {
    const PAGE_STATE = {
        taskType: parseInt(decodeURIComponent($$.getUrlParam("taskType"))),// 1-销售目标，2-活动通知
        taskMemberId: decodeURIComponent($$.getUrlParam("taskMemberId")),// 任务id
        task:{},
        taskMember:{}
    };
    PAGE_STATE.taskType = $$.isValidObj(PAGE_STATE.taskType) ? PAGE_STATE.taskType : 1;
    dataLoading();

    /**
     * 数据加载
     */
    function dataLoading(){
        let url = UrlConfig.market_teamsalestargetmemberlist_wx_getDetailsByTaskMemberId;
        if (PAGE_STATE.taskType === 1) {
            $(".activityTarget").css("display","none");
        } else {
            $(".saleTarget").css("display","none");
            url = UrlConfig.market_teamactivitynoticememberlist_wx_getDetailsByTaskMemberId;
            $('.titleName').html('活动主题');
            $('.explainedName').html('活动说明');
            $('.viewDetailsTitle > span').html('活动通知');
            $('.viewDetailsTitle > img').attr('src','../../images/teams/task/activityType.png');
            $('.confirmation .later').html('不参加活动');
            $('.confirmation .confirm').html('确认报名');
        }
        $$.request({
            url: url,
            loading: true,
            pars:{
                taskMemberId:PAGE_STATE.taskMemberId
            },
            requestBody:true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.task = data.task;
                    PAGE_STATE.taskMember = data.taskMember;
                    $('.title').html(data.task["title"]);
                    $('.startTime').html(data.task["startTime"]);
                    $('.endTime').html(data.task["endTime"]);
                    $('.explained').html(data.task["explained"]);
                    const picList = [data.task["pic1"],data.task["pic2"],data.task["pic3"]];
                    for (let i = 0; i < picList.length; i++) {
                        const pic = picList[i];
                        if ($$.isValidObj(pic)) {
                            $('.uploadingImg').append('<img src="' + pic + '" />');
                        }
                    }
                    if (PAGE_STATE.taskType === 1) {
                        let numberVal = data.task["huo4ke4ren2shu4"];
                        let numberEl = $('#huo4ke4ren2shu4');
                        let unit = '人';
                        setTargetNumber(numberVal,numberEl,unit);
                        numberVal = data.task["xiao1shou4ye4ji4"];
                        numberEl = $('#xiao1shou4ye4ji4');
                        unit = '元';
                        setTargetNumber(numberVal,numberEl,unit);
                        numberVal = data.task["cheng2jiao1ding4dan1"];
                        numberEl = $('#cheng2jiao1ding4dan1');
                        unit = '单';
                        setTargetNumber(numberVal,numberEl,unit);
                        numberVal = data.task["fa1zhan3tuan2yuan2"];
                        numberEl = $('#fa1zhan3tuan2yuan2');
                        unit = '人';
                        setTargetNumber(numberVal,numberEl,unit);
                    } else {
                        let address = data.task["address"];
                        if ($$.isValidObj(address)) {
                            $('#address').html(address);
                        } else {
                            $('#address').parent().hide();
                        }
                    }
                    if (data.taskMember['takeTime']) {
                        $('.confirmation').hide();
                    } else {
                        if (data.task['isStart'] && !data.task['isEnd']) {
                            confirmationBtn();
                        } else if (data.task['isEnd']) {
                            $('.confirmation').hide();
                        }
                    }
                    if (PAGE_STATE.taskType === 1) {
                        if (data.taskMember['completeStatus'] === 0) {
                            if (data.taskMember['takeTime'] && data.task['isStart'] && !data.task['isEnd']) {
                                $('.saleCase').removeClass('hidden');
                                saleCaseBtn();
                            }
                        } else {
                            let numberVal = data.taskMember["huo4ke4ren2shu4"];
                            let numberEl = $('#huo4ke4ren2shu4');
                            let unit = '人';
                            setTargetNumber(numberVal,numberEl,unit);
                            numberVal = data.taskMember["xiao1shou4ye4ji4"];
                            numberEl = $('#xiao1shou4ye4ji4');
                            unit = '元';
                            setTargetNumber(numberVal,numberEl,unit);
                            numberVal = data.taskMember["cheng2jiao1ding4dan1"];
                            numberEl = $('#cheng2jiao1ding4dan1');
                            unit = '单';
                            setTargetNumber(numberVal,numberEl,unit);
                            numberVal = data.taskMember["fa1zhan3tuan2yuan2"];
                            numberEl = $('#fa1zhan3tuan2yuan2');
                            unit = '人';
                            setTargetNumber(numberVal,numberEl,unit);
                        }
                    }
                } else {
                    $$.layerToast(data.msg);
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定EBECED
     */
    function confirmationBtn(){
        //-- 返回
        $(".confirmation .later").on("click", function () {
            window.history.back();
        });
        //-- 参加
        $(".confirmation .confirm").on("click", function () {
            let url = UrlConfig.market_teamsalestargetmemberlist_wx_isTake;
            if (PAGE_STATE.taskType === 2) {
                url = UrlConfig.market_teamactivitynoticememberlist_wx_isTake;
            }
            $$.request({
                url: url,
                loading: true,
                pars:{
                    taskMemberId:PAGE_STATE.taskMemberId
                },
                requestBody:true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        if (PAGE_STATE.taskType === 1) {
                            $('.saleCase').removeClass('hidden');
                            saleCaseBtn();
                        } else {
                            $$.layerToast('报名成功');
                        }
                        $('.confirmation').hide();
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        });
    }
    function saleCaseBtn() {
        //-- 销售 填写完成情况
        $(".saleCase").on("click", function () {
            $(this).addClass("hidden");

            let targetVal = PAGE_STATE.task['huo4ke4ren2shu4'];
            let nowVal = PAGE_STATE.taskMember['huo4ke4ren2shu4'];
            let numberEl = $("#huo4ke4ren2shu4");
            saleCaseTargetNumber(targetVal,nowVal,numberEl);
            targetVal = PAGE_STATE.task['xiao1shou4ye4ji4'];
            nowVal = PAGE_STATE.taskMember['xiao1shou4ye4ji4'];
            numberEl = $("#xiao1shou4ye4ji4");
            saleCaseTargetNumber(targetVal,nowVal,numberEl);
            targetVal = PAGE_STATE.task['cheng2jiao1ding4dan1'];
            nowVal = PAGE_STATE.taskMember['cheng2jiao1ding4dan1'];
            numberEl = $("#cheng2jiao1ding4dan1");
            saleCaseTargetNumber(targetVal,nowVal,numberEl);
            targetVal = PAGE_STATE.task['fa1zhan3tuan2yuan2'];
            nowVal = PAGE_STATE.taskMember['fa1zhan3tuan2yuan2'];
            numberEl = $("#fa1zhan3tuan2yuan2");
            saleCaseTargetNumber(targetVal,nowVal,numberEl);
            $(".confirmSubmit").removeClass("hidden");
            $(".prompt").removeClass("hidden");
            confirmSubmitBtn();
        });
    }

    function confirmSubmitBtn() {
        //-- 活动 确认提交
        $(".confirmSubmit").on("click", function () {
            $$.request({
                url: UrlConfig.market_teamsalestargetmemberlist_wx_saveNowVal,
                loading: true,
                pars:{
                    taskMemberId:PAGE_STATE.taskMemberId,
                    huo4ke4ren2shu4:getNowVal('huo4ke4ren2shu4'),
                    xiao1shou4ye4ji4:getNowVal('xiao1shou4ye4ji4'),
                    cheng2jiao1ding4dan1:getNowVal('cheng2jiao1ding4dan1'),
                    fa1zhan3tuan2yuan2:getNowVal('fa1zhan3tuan2yuan2')
                },
                requestBody:true,
                sfn: function (data) {
                    $$.closeLoading();
                    if (data.success) {
                        $$.alert("提交成功");
                        $(".confirmSubmit").addClass("hidden");
                        $(".prompt").addClass("hidden");
                        let targetVal = PAGE_STATE.task['huo4ke4ren2shu4'];
                        let numberEl = $("#huo4ke4ren2shu4");
                        let unit = '人';
                        confirmSubmitNowNumber(targetVal,numberEl,unit);
                        targetVal = PAGE_STATE.task['xiao1shou4ye4ji4'];
                        numberEl = $("#xiao1shou4ye4ji4");
                        unit = '元';
                        confirmSubmitNowNumber(targetVal,numberEl,unit);
                        targetVal = PAGE_STATE.task['cheng2jiao1ding4dan1'];
                        numberEl = $("#cheng2jiao1ding4dan1");
                        unit = '单';
                        confirmSubmitNowNumber(targetVal,numberEl,unit);
                        targetVal = PAGE_STATE.task['fa1zhan3tuan2yuan2'];
                        numberEl = $("#fa1zhan3tuan2yuan2");
                        unit = '人';
                        confirmSubmitNowNumber(targetVal,numberEl,unit);
                    } else {
                        $$.layerToast(data.msg);
                    }
                },
                ffn: function (data) {
                    $$.errorHandler();
                }
            });
        });
    }

    function tranNumber(num, point = 2) {
        if (!$$.isValidObj(num)) {
            num = 0;
        }
        let numStr = parseInt(num).toString();

        // 万以内直接返回
        if (numStr.length < 5) {
            return num;
        }
        //大于8位数是亿
        else if (numStr.length > 8) {
            let decimal = numStr.substring(numStr.length - 8, numStr.length - 8 + point);
            return parseFloat(parseInt(num / 100000000) + '.' + decimal) + '亿';
        }
        //大于4位数是万 (以1W分割 1W以下全部显示)
        else if (numStr.length > 4) {
            let decimal = numStr.substring(numStr.length - 4, numStr.length - 4 + point);
            return parseFloat(parseInt(num / 10000) + '.' + decimal) + '万';
        }
    }

    function setTargetNumber(numberVal,numberEl,unit) {
        if (numberVal > 0) {
            numberVal = tranNumber(numberVal);
            numberEl.html(numberVal + ' ' + unit);
        } else {
            numberEl.parent().hide();
        }
    }

    function saleCaseTargetNumber(targetVal,nowVal,numberEl) {
        if (targetVal > 0) {
            targetVal = tranNumber(targetVal);
            numberEl.hide();
            const fillTarget = numberEl.siblings('.fillTarget');
            fillTarget.removeClass("hidden");
            fillTarget.children('input').val(nowVal);
            fillTarget.find('> span > span').html(' /' + targetVal);
        }
    }

    function confirmSubmitNowNumber(targetVal,numberEl,unit) {
        if (targetVal > 0) {
            numberEl.show();
            const fillTarget = numberEl.siblings('.fillTarget');
            fillTarget.addClass("hidden");
            let inputVal = fillTarget.children('input').val();
            inputVal = tranNumber(inputVal);
            numberEl.html( inputVal + ' ' + unit);
        }
    }

    function getNowVal(numberElIdName) {
        const inputEl = $('#' + numberElIdName).siblings('.fillTarget').children('input');
        let val = inputEl.val();
        if ($$.isValidObj(val)) {
            const valIndexOfNumber = val.indexOf('.');
            if (valIndexOfNumber > -1) {
                val = val.substring(0,valIndexOfNumber + 3);
            }
        } else {
            val = 0;
        }
        val = parseFloat(val);
        inputEl.val(val);
        return val;
    }
};
