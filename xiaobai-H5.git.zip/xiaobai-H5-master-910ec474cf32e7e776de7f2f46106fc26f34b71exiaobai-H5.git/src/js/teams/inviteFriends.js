 window.onload = function () {
	 $$.changeVersion();
	getQRCode();
}
function changeSize(){
	let div = $('.bg2');
	let callback = function(){
		let div2 = $('.qrCode');
		let callback2 = function(){
			changeImageHeight(div2);
		};
		let top = 80 / 1157 * 100;
		div2.css('top',top + '%');
		changeImageWidth(div2,callback2);
	};
	changeImageHeight(div,callback);
}
function changeImageHeight(div,callback){
	var imgUrl = div.css('background-image');
	imgUrl = imgUrl.replace('url("','');
	imgUrl = imgUrl.replace('")','');
	$('<img />').attr('src',imgUrl).on('load',function(){
		let width = this.width;
		let height = this.height;
		let divWidth = div.innerWidth();
		if (div.hasClass('bg2')) {
			divWidth = $('body').innerWidth();
		}
		let divHeight = divWidth * height / width;
		div.css('height',divHeight);
		if (div.hasClass('bg2')) {
			$('body').css('min-height',divHeight);
			let bodyHeight = $('body').innerHeight();
			let finalHeight = bodyHeight;
			if (bodyHeight < divHeight) {
				finalHeight = divHeight;
			}
			$('body').css('background-size','100% ' + finalHeight + 'px');
		} else if (div.hasClass('qrCode')) {
			let padding = 32 / width * div.innerWidth();
			div.css('padding',padding);
		}
		if (callback) {
			setTimeout(callback, 200);
		}
	});
}
function changeImageWidth(div,callback){
	var imgUrl = div.css('background-image');
	imgUrl = imgUrl.replace('url("','');
	imgUrl = imgUrl.replace('")','');
	$('<img />').attr('src',imgUrl).on('load',function(){
		let width = this.width;
		let height = this.height;
		let divWidth = width / 750;
		divWidth = $('body').innerWidth() * divWidth;
		div.css('width',divWidth);
		if (div.hasClass('qrCode')) {
			let leftValue = divWidth / 2;
			leftValue = leftValue / $('body').innerWidth() * 100;
			leftValue = 50 - leftValue;
			div.css('left',leftValue + '%');
		}
		if (callback) {
			setTimeout(callback, 200);
		}
	});
}
function getQRCode() {
	let teamId = $$.getUrlParam("teamId");
	$$.request({
		url: UrlConfig.market_team_wx_getQRCode,
		loading: true,
		pars:{
			teamId:teamId,
			basePath:$$.getBasePath()
		},
		requestBody:true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				$('.qrCode img').attr('src',data.qrCodePath);
			} else {
				$$.layerToast(data.msg);
			}
			changeSize();
			window.onorientationchange = function() {
				setTimeout(changeSize, 200);
			};
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}
