const PAGE_STATE = {
	applyList:[],
	msgList:[],
	st_taskList:[],
	an_taskList:[],
};
window.onload = function () {
	$$.changeVersion();
	getMsgList();
	countAction("xb_2077");
};
function getMsgList(){
	$$.request({
		url: UrlConfig.market_teammember_wx_getMsgList,
		loading: true,
		pars:{
			teamMemberId:decodeURIComponent($$.getUrlParam("teamMemberId"))
		},
		requestBody:true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				$('.nav').html('');
				PAGE_STATE.msgList = data.msgList;
				buildMsg();
				PAGE_STATE.applyList = data.applyList;
				if (PAGE_STATE.applyList) {
					$('#tab2').css('display','flex');
				}
				PAGE_STATE.st_taskList = data.st_taskList;
				PAGE_STATE.an_taskList = data.an_taskList;
				msgTypeBtn();
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}
function buildApply() {
	const applyList = PAGE_STATE.applyList;
	let htmlArr = [];
	if (applyList != null && typeof (applyList) != 'undefined') {
		for (let i = 0;i < applyList.length;i++){
			let xpro = applyList[i];
			htmlArr[i] = [
				'<div id="teamMemberId_' + xpro.teamMemberId + '">',
					'<div class="left">',
						'<div class="title orangeBg">申请</div>',
					'</div>',
					'<div class="right">',
						'<div class="top">',
							'<div class="text">' + xpro.memberName + '</div>',
							'<div class="time">' + xpro.createTime + '</div>',
						'</div>',
						'<div class="bottom">',
							'<div class="btnList">',
								'<div class="btn orangeBg applyAdopt">通过</div>',
								'<div class="btn applyRefuse">拒绝</div>',
							'</div>',
						'</div>',
					'</div>',
				'</div>'].join('');
		}
		$('.nav').html(htmlArr.join(''));
		$('.applyAdopt').on('click',function(){
			let btn = $(this);
			let xstatus = 1;
			applySentence(btn,xstatus);
		});
		$('.applyRefuse').on('click',function(){
			let btn = $(this);
			let xstatus = 2;
			applySentence(btn,xstatus);
		});
	}
}
function applySentence(btn,xstatus){
	let btnText = btn.html();
	let teamMemberId = btn.parent().parent().parent().parent().attr('id');
	teamMemberId = teamMemberId.replace('teamMemberId_','');
	$$.request({
		url: UrlConfig.market_teammember_wx_applySentence,
		loading: true,
		pars:{
			teamMemberId:teamMemberId,
			xstatus:xstatus
		},
		requestBody:true,
		sfn: function (data) {
			$$.closeLoading();
			if (data.success) {
				let newBtn = '<div class="btn greyBg">已' + btnText + '</div>';
				btn.parent().html(newBtn);
			} else {
				$$.layerToast(data.msg);
			}
		},
		ffn: function (data) {
			$$.errorHandler();
		}
	});
}
function buildMsg() {
	const msgList = PAGE_STATE.msgList;
	let htmlArr = [];
	if (msgList != null && typeof (msgList) != 'undefined') {
		for (let i = 0; i < msgList.length; i++) {
			let xpro = msgList[i];
			let titleType = xpro.titleType;
			let titleClass = '';
			let titleText = '';
			let callBackHtml = [];
			switch (titleType) {
				case 1:
					titleClass = ' orangeBg';
					titleText = '申请';
					break;
				case 2:
					titleClass = ' violetBg';
					titleText = '申请';
					callBackHtml = [
					'<div class="btnList">',
						// '<div class="btn callLeader">联系团长</div>',
					'</div>'];
					break;
				case 3:
					titleClass = ' violetBg';
					titleText = '申请';
					break;
			}
			htmlArr[i] = [
				'<div id="msg' + xpro.id + '">',
					'<div class="left">',
						'<div class="title' + titleClass + '">' + titleText + '</div>',
					'</div>',
					'<div class="right">',
						'<div class="top">',
							'<div class="text">' + xpro.content + '</div>',
							'<div class="time">' + xpro.createTime + '</div>',
						'</div>',
						'<div class="bottom">',
							callBackHtml.join(''),
						'</div>',
					'</div>',
				'</div>'].join('');
		}
		$('.nav').html(htmlArr.join(''));
	}
}
function msgTypeBtn() {
	$('.msgType > div').on('click',function () {
		$('.msgType > div').removeClass('checked');
		$(this).addClass('checked');
		$('.nav').html('');
		const tabId = $(this).attr('id');
		switch (tabId) {
			case 'tab2':
				buildApply();
				break;
			case 'tab3':
				build_task(1);
				break;
			case 'tab4':
				build_task(2);
				break;
			default:
				buildMsg();
				break;
		}
	});
}
function build_task(taskType) {
    let title = '任务';
	let taskList = PAGE_STATE.st_taskList;
	if (taskType === 2) {
		taskList = PAGE_STATE.an_taskList;
        title = '活动';
	}
	let htmlArr = [];
	if (taskList != null && typeof (taskList) != 'undefined') {
		for (let i = 0; i < taskList.length; i++) {
			let xpro = taskList[i];
			const takeTime = xpro.takeTime;
			let btnText = '未开始';
			let btnColor = ' greyBg';
			if (taskType === 1) {
				const completeStatus = xpro.completeStatus;
				if (xpro.isStart) {
					btnText = '待处理';
					btnColor = ' orangeBg';
				}
				if (takeTime) {
					btnText = '已参与';
				}
				if (completeStatus === 1) {
					btnText = '已处理';
					btnColor = ' greyBg';
				}
				if (completeStatus === 2) {
					btnText = '已完成';
					btnColor = ' greyBg';
				}
				if (xpro.isEnd) {
					btnText = '已结束';
					btnColor = ' greyBg';
				}
			} else {
				btnText = '未参与';
				btnColor = ' orangeBg';
				if (takeTime) {
					btnText = '已参与';
				}
				if (xpro.isEnd) {
					btnText = '已结束';
					btnColor = ' greyBg';
				}
			}
			htmlArr[i] = [
				'<div id="taskMemberId_' + xpro.id + '">',
					'<div class="left">',
						'<div class="title">' + title + '</div>',
					'</div>',
					'<div class="right">',
						'<div class="top">',
							'<div class="text">' + xpro.title + '</div>',
							'<div class="time">' + xpro.createTime + '</div>',
						'</div>',
						'<div class="bottom">',
							'<div class="btnList">',
								'<div class="btn' + btnColor + '">' + btnText + '</div>',
							'</div>',
						'</div>',
					'</div>',
				'</div>'].join('');
		}
		$('.nav').html(htmlArr.join(''));
		$('.nav > div').on('click',function () {
			let stTaskMemberId = $(this).attr('id');
			stTaskMemberId = stTaskMemberId.replace('taskMemberId_','');
			$$.push('teams/viewTaskConfirm',{
				taskMemberId:stTaskMemberId,
				taskType:taskType
			});
		});
	}
}
