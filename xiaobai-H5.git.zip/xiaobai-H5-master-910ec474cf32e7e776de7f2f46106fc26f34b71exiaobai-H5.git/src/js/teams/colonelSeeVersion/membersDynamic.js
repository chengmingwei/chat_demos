/**
 * 团员动态 JS
 * @Author 吴成林
 * @Date 2020-3-19 14:32:48
 */
let teamId = '';
let title = '';
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        /* 从我的页面传值 */
        teamId = decodeURIComponent($$.getUrlParam("teamId"));                                                  // 团队ID
        title = decodeURIComponent($$.getUrlParam("title")).replace("(元)","");          // 页面title标题
        $$.isValidObj(title) ? $("title").text(title):$("title").text("团员动态");
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){

    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 点击统计标题
        $(".statisticsTime>div").on("click", function() {
            $(this).addClass("selectTime").siblings().removeClass("selectTime");
        });

    }
}