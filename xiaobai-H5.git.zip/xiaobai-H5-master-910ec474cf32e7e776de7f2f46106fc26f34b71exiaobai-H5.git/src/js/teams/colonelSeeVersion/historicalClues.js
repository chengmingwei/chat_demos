/**
 * 历史线索 JS
 * @Author 吴成林
 * @Date 2020-3-19 14:32:48
 */
let teamId = '';            // 团队ID
let listData = {
    1:[],                   // 累计
    2:[],                   // 近7天
    3:[],                   // 近15天
    4:[],                   // 近30天
}                           // 数据列表
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        /* 从我的页面传值 */
        teamId = decodeURIComponent($$.getUrlParam("teamId"));//团队ID
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
        loadData();
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 统计标题
        $(".statistics>div").on("click", function() {
            $(this).addClass("selectTitle").siblings().removeClass("selectTitle");
            let value = parseInt($(this).attr("data-value"));
            membersDynamic(listData[value]);
        });

        //-- 跳转分享记录
        $(".shareContent td").on("click", function() {
            let title = $(this).children("div:nth-child(2)").text();
            $$.push('teams/colonelSeeVersion/shareStatistics',{teamId:teamId, title:encodeURI(encodeURI(title))});
        });

    }

    //-- 后台数据加载
    function loadData() {
        let teamId = $$.getUrlParam("teamId");
        $$.request({
            url: UrlConfig.market_getTeamDynamicList,
            pars:{
                teamId:teamId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if ($$.isValidObj(data.getTeamDynamicList)) listData[1] = data.getTeamDynamicList;
                if ($$.isValidObj(data.getTeamDynamicSevenDays)) listData[2] = data.getTeamDynamicSevenDays;
                if ($$.isValidObj(data.getTeamChildAmountThirtyDays)) listData[3] = data.getTeamChildAmountThirtyDays;
                if ($$.isValidObj(data.getTeamDynamicThirtyDays)) listData[4] = data.getTeamDynamicThirtyDays;

                membersDynamic(listData[1]);
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 团员动态
    function membersDynamic(data, length = 5) {
        $('.initialize').text(0);
        for (let i = 0; i < length; i++) {
            if ($$.isValidObj(data[i])) {
                $(".unit-"+data[i].type).text(data[i].count);
            }
        }
    }
}