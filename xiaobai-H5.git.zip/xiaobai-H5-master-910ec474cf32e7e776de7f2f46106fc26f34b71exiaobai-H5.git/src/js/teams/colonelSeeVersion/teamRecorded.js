/**
 * 团队记录 JS
 * @Author 吴成林
 * @Date 2020-3-19 14:32:48
 */
let teamId = '';            // 团队ID
let title = '';             // 页面title标题
let units = '';             // 页面单位
let lineChartDataList = {   // 线图表数据列表
    1: [0, 0, 0, 0, 0, 0, 0],
    2: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    3: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
};
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        teamId = decodeURIComponent($$.getUrlParam("teamId"));        // 团队ID 参数
        title = decodeURIComponent($$.getUrlParam("title"));          // 页面title标题 参数
        units = decodeURIComponent($$.getUrlParam("units"));          // 页面单位 参数
        $(".units").text(units);
        $$.isValidObj(title) ? $("title").text(title):$("title").text("团队记录");
        let leftTitle = $('.leftTitle');
        let rightTitle = $('.rightTitle');
        switch (title) {
            case "新增团员": {
                leftTitle.text("当前团员");
                rightTitle.text("今日新增");
                getTeamNewMemberThirtyDays();
                break;
            }
            case "新增子团": {
                leftTitle.text("当前子团");
                rightTitle.text("今日新增");
                getTeamChildTeamThirtyDays();
                break;
            }
            case "团队保费": {
                leftTitle.text("当前团队保费");
                rightTitle.text("今日保费");
                getTeamAmountThirtyDays()
                break;
            }
            case "子团保费": {
                leftTitle.text("当前子团保费");
                rightTitle.text("今日保费");
                getTeamChildAmountThirtyDays()
                break;
            }
        }

        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){

    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 统计时间
        $(".statisticsTime>div").on("click", function() {
            $(this).addClass("selectTime").siblings().removeClass("selectTime");
            let time = parseInt($(this).attr("data-time"));
            let value = parseInt($(this).attr("data-value"));
            let timeArray = conversionTime(time, 1);
            setEcharts(timeArray, value);
        });


    }

    /**
     * 生成折线图
     * timeArray
     * value 1：天，2：月，3：年
     */
    function setEcharts(timeArray, value) {
        let type = 'category';
        let length = lineChartDataList[value].length;
        for (let i = 0; i < length; i++) {
            let content = parseInt(lineChartDataList[value][i]);
            if (content > 3) type = 'value';
        }
        // 基于准备好的dom，初始化echarts实例
        let myChart = echarts.init(document.getElementById('main'));
        window.onresize = myChart.resize;
        // 绘制图表
        let option = {
            tooltip: {},
            grid: {
                left: '16%',
                top: '5%',
                width: '80%',
                height: '65%',
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                axisLabel:{
                    rotate: 50,
                    textStyle: {
                        color: '#666666',
                    },
                    fontSize: 10,
                },
                data: timeArray,
            },
            yAxis: {
                type: type,
                axisLabel:{
                    textStyle: {
                        color: '#666666',
                    },
                    fontSize: 10,
                    formatter: function (params) {
                        if (units == "元"){
                            return params>10000?params/10000+'万元':params+'元';
                        } else{
                            return params>10000?params/10000+'万人':params+'人';
                        }
                    }
                },
                data: [0, 1, 2, 3, 4],
            },
            dataZoom: [{
                type: 'inside',
                start: 0,
                end: 100,
                maxValueSpan: 15,
            }, {
                start: 0,
                end: 100,
                handleIcon: 'M10.7,11.9v-1.3H9.3v1.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4v1.3h1.3v-1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                handleSize: '80%',
                handleStyle: {
                    color: '#fff',
                    shadowBlur: 3,
                    shadowColor: 'rgba(0, 0, 0, 0.6)',
                    shadowOffsetX: 2,
                    shadowOffsetY: 2
                }
            }],
            series: [{
                data: lineChartDataList[value],
                type: 'line',
                symbol: 'circle',
                symbolSize: 10,
                lineStyle: {
                    normal: {
                        color: "#ff9a9a",
                        width: 1,
                    }
                },
                itemStyle: {
                    normal: {
                        color: "#ff7052",
                    }
                },
                tooltip: {
                    trigger:  'item',
                },
            }],

        };

        myChart.setOption(option);
    };

    /**
     * 根据参数获取近n天，近n月，近n年的时间（此方法只返回一个值）
     * value n值
     * state 1：天，2：月，3：年
     */
    function conversionTime(value, state) {
        let map = [];
        for (let i = 0; i < value; i++) {
            let now = new Date;
            let exportTime = "";
            switch (state) {
                case 1: {
                    now.setDate(now.getDate() - i);
                    let year = now.getFullYear();
                    let month = convert(now.getMonth() + 1);
                    let day = convert(now.getDate());
                    exportTime = year + '-' + month + '-' + day;
                    break;
                }
                case 2: {
                    now.setMonth(now.getMonth() - i);
                    let year = now.getFullYear();
                    let month = convert(now.getMonth() + 1);
                    exportTime = year + '-' + month;
                    break;
                }
                case 3: {
                    now.setFullYear(now.getFullYear() - i);
                    let year = now.getFullYear();
                    exportTime = year;
                    break;
                }
            }
            map[i] = exportTime;
        }
        return map;

        function convert(s) {
            return s < 10 ? '0' + s : s;
        };
    };

    //-- 后台数据转换保存map列表
    function dataTransformation(datas) {
        let j = 0;
        for (let i = datas.length-1; i >= 0; i--) {
            let values = datas[i].number;
            if (i < 15){
                lineChartDataList[3][j] = values;
            } else if (i < 23){
                lineChartDataList[2][j] = values;
                lineChartDataList[3][j] = values;
            } else{
                lineChartDataList[1][j] = values;
                lineChartDataList[2][j] = values;
                lineChartDataList[3][j] = values;
            }
            j++;
        }
        console.log(lineChartDataList);
        let timeArray = conversionTime(7, 1);
        setEcharts(timeArray, 1);                 // 生成折线图
        $(".rightText").text(datas[29].number);         // 今日数据
    }

    //-- 新增团员
    function getTeamNewMemberThirtyDays() {
        $$.request({
            url: UrlConfig.market_getTeamNewMemberThirtyDays,
            pars:{
                teamId:teamId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                $(".leftText").text(data.getCurrentTotalTeam.count);
                dataTransformation(data.getTeamNewMemberThirtyDays);
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 新增子团
    function getTeamChildTeamThirtyDays() {
        $$.request({
            url: UrlConfig.market_getTeamChildTeamThirtyDays,
            pars:{
                teamId:teamId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                $(".leftText").text(data.getCurrentTotalChild.count);
                dataTransformation(data.getTeamChildTeamThirtyDays);
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 团队保费
    function getTeamAmountThirtyDays() {
        $$.request({
            url: UrlConfig.market_getTeamAmountThirtyDays,
            pars:{
                teamId:teamId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if ($$.isValidObj(data.getCurrentTotalTeamAmount)) $(".leftText").text(data.getCurrentTotalTeamAmount.count);
                dataTransformation(data.getTeamAmountThirtyDays);
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 子团保费
    function getTeamChildAmountThirtyDays() {
        $$.request({
            url: UrlConfig.market_getTeamChildAmountThirtyDays,
            pars:{
                teamId:teamId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                console.log(data);
                if ($$.isValidObj(data.getCurrentTotalChildAmount)) $(".leftText").text(data.getCurrentTotalChildAmount.count);
                dataTransformation(data.getTeamChildAmountThirtyDays);
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
}