/**
 * 团长看板 JS
 * @Author 吴成林
 * @Date 2020-3-19 14:32:48
 */
const PAGE_STATE = {
    whetherVIP: false,                  // 是否是VIP
};
let teamId = '';            // 团队ID
let lineChartDataList = {       // 线图表数据列表
    1: {
        1: [0, 0, 0],
        2: [0, 0, 0, 0, 0, 0],
        3: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    },
    2: {
        1: [0, 0, 0],
        2: [0, 0, 0, 0, 0, 0],
        3: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    },
    3: {
        1: [0, 0, 0],
        2: [0, 0, 0, 0, 0, 0],
        3: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    },
    4: {
        1: [0, 0, 0],
        2: [0, 0, 0, 0, 0, 0],
        3: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    },
};

window.onload = function() {
    countAction('xb_6012');
    pageLoader();
    loadData();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        /* 从我的页面传值 */
        teamId = decodeURIComponent($$.getUrlParam("teamId"));//团队ID
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();

    }

    /**
     * 数据加载
     */
    function dataLoading(){
        loadData();

        //-- 当前时间（时:分:秒）
        localTime();

    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        /* 团队排行榜 */
        $('.rankList').on("click", function() {
            $$.push('teams/particular',{teamId:teamId});
        });

        /* 历史线索 */
        $('.historicalClues').on("click", function() {
            if (!PAGE_STATE.whetherVIP) {
                $$.confirm({
                    title: "使用此功能需先开通团长功能包，点击确认即前往开通！",
                    onOkLabel: "确认",
                    onCancelLabel: "取消",
                    onOk: function () {
                        $$.push('my/purchaseVIP/purchaseVIP');
                    }
                });
                return;
            }
            $$.push('teams/colonelSeeVersion/historicalClues',{teamId:teamId});
        });

        /* 历史线索 */
        $('.teamStatusTodayContent>div').on("click", function() {
            let title = $(this).attr("data-title");
            let units = $(this).attr("data-units");
            $$.push('teams/colonelSeeVersion/teamRecorded',{
                teamId:teamId,
                title:encodeURI(encodeURI(title)),
                units:encodeURI(encodeURI(units)),
            });
        });

        //-- 团员动态
        $(".membersDynamicContent>div").on("click", function() {
            let title = $(this).attr("data-title");
            //$$.push('teams/colonelSeeVersion/membersDynamic',{teamId:teamId, title:encodeURI(encodeURI(title))});
        });

        //-- 统计标题
        $(".statisticsListTitle>div").on("click", function() {
            $(this).addClass("selectTitle").siblings().removeClass("selectTitle");
            $(".statisticsListTime>div:nth-child(1)").addClass("selectTime").siblings().removeClass("selectTime");
            let selectTime = $(".statisticsListTime>div.selectTime").text();
            let selectTitle = $(this).attr("data-title");
            $(".statisticsTitle").text(selectTime+selectTitle);

            selectTitle = selectTitle.substring(5,6);
            let titleValue = $(this).attr("data-value");        // 第n个标题
            let timeArray = conversionTime(3, 2);   // 计算日期
            setEcharts(timeArray, titleValue, 1);         // 生成折线图

            statisticsCount(parseInt(titleValue), selectTitle);           // 统计总数
        });



        //-- 统计时间
        $(".statisticsListTime>div").on("click", function() {
            $(this).addClass("selectTime").siblings().removeClass("selectTime");
            let selectTime = $(this).text();
            let selectTitle = $(".statisticsListTitle>div.selectTitle").attr("data-title");
            $(".statisticsTitle").text(selectTime+selectTitle);

            let titleValue = $('.statisticsListTitle>div.selectTitle').attr("data-value");        // 第n个标题
            let value = parseInt($(this).attr("data-value"));
            let time = 3;
            switch (value) {
                case 1: {
                    time = 3;
                    break;
                }
                case 2: {
                    time = 6;
                    break;
                }
                case 3: {
                    time = 12;
                    break;
                }
            }
            let timeArray = conversionTime(time, 2);        // 计算日期
            setEcharts(timeArray, titleValue, value);             // 生成折线图

            selectTitle = selectTitle.substring(5,6);
            statisticsCount(parseInt(titleValue), selectTitle, value, time);      // 统计总数
        });

    }

    /**
     * 生成折线图
     * timeArray
     * value 1：天，2：月，3：年
     */
    function setEcharts(timeArray, titleValue, value) {
        let selectTitle = $(".statisticsListTitle>div.selectTitle").attr("data-title");
        selectTitle = selectTitle.substring(5,6);

        $(".sometimeStatistics>div:nth-child(1)").text(timeArray[0]);
        $(".sometimeStatistics>div:nth-child(2)").text(lineChartDataList[titleValue][value][0]+selectTitle);

        let type = 'category';
        let length = lineChartDataList[titleValue][value].length;
        for (let i = 0; i < length; i++) {
            let content = parseInt(lineChartDataList[titleValue][value][i]);
            if (content > 3) type = 'value';
        }
        // 基于准备好的dom，初始化echarts实例
        let myChart = echarts.init(document.getElementById('main'));
        window.onresize = myChart.resize;
        // 绘制图表
        let option = {
            tooltip: {},
            grid: {
                left: '18%',
                top: '10%',
                width: '80%',
                height: '65%',
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                axisLabel:{
                    rotate: timeArray.length>3?50:30,
                    textStyle: {
                        color: '#666666',
                    },
                    fontSize: 10,
                },
                data: timeArray,
            },
            yAxis: {
                type: type,
                axisLabel:{
                    textStyle: {
                        color: '#666666',
                    },
                    fontSize: 10,
                    formatter: function (params) {
                        if (selectTitle == "元"){
                            return params>10000?params/10000+'万元':params+'元';
                        } else{
                            return params>10000?params/10000+'万人':params+'人';
                        }
                    }
                },
                data: [0, 1, 2, 3, 4]
            },
            series: [{
                data: lineChartDataList[titleValue][value],
                type: 'line',
                symbol: 'circle',
                symbolSize: 10,
                lineStyle: {
                    normal: {
                        color: "#ff9a9a",
                        width: 1,
                    }
                },
                itemStyle: {
                    normal: {
                        color: "#ff7052",
                    }
                },
                tooltip: {
                    trigger:  'item',
                    formatter: function (params) {
                        let marker = params.marker;
                        let name = params.name;
                        let data = params.data;
                        $(".sometimeStatistics>div:nth-child(1)").text(name);
                        $(".sometimeStatistics>div:nth-child(2)").text(data+selectTitle);
                        return marker + name + " " + data+selectTitle;
                    }
                },
            }],

        };

        myChart.setOption(option);
    }

    /**
     * 根据参数获取近n天，近n月，近n年的时间（此方法只返回一个值）
     * value n值
     * state 1：天，2：月，3：年
     */
    function conversionTime(value, state) {
        let map = [];
        for (let i = 0; i < value; i++) {
            let now = new Date;
            let exportTime = "";
            switch (state) {
                case 1: {
                    now.setDate(now.getDate() - i);
                    let year = now.getFullYear();
                    let month = convert(now.getMonth() + 1);
                    let day = convert(now.getDate());
                    exportTime = year + '-' + month + '-' + day;
                    break;
                }
                case 2: {
                    now.setMonth(now.getMonth() - i);
                    let year = now.getFullYear();
                    let month = convert(now.getMonth() + 1);
                    exportTime = year + '-' + month;
                    break;
                }
                case 3: {
                    now.setFullYear(now.getFullYear() - i);
                    let year = now.getFullYear();
                    exportTime = year;
                    break;
                }
            }
            map[i] = exportTime;
        }
        return map;

        function convert(s) {
            return s < 10 ? '0' + s : s;
        }
    }

    /**
     * 根据后台数据 加载数据内容
     * data 后台数据
     * ps: 后台根据标题拿到12个月的存在数据，数据结构参考模拟数据分为4个一级目录（1,2,3,4），内容为{2020-03:100，2020-01:500}（时间：数据）
     *
     */
    function loadData() {
        let teamId = $$.getUrlParam("teamId");
        $$.request({
            url: UrlConfig.market_loadTeamKanBan,
            pars:{
                teamId:teamId
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                let getSubsidyYear = data.getSubsidyYear;           // 累计津贴 近一年的数据
                let getSaleAmountYear = data.getSaleAmountYear;     // 累计保费 近一年的数据
                let getNewMemberYear = data.getNewMemberYear;       // 新增团员 近一年的数据
                let getChildTeamYear = data.getChildTeamYear;       // 新增子团 近一年的数据
                dataTransformation(getSubsidyYear, 1);
                dataTransformation(getSaleAmountYear, 2);
                dataTransformation(getNewMemberYear, 3);
                dataTransformation(getChildTeamYear, 4);

                statisticsCount();                                  // 初始化统计总数
                teamStatusToday(data);                              // 今日团情数据加载
                membersDynamic(data.getTeamDynamicList);            // 团员状态

                let timeArray = conversionTime(3, 2);
                setEcharts(timeArray, 1, 1);         // 生成折线图
                getVipData();
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    //-- 后台数据转换保存map列表
    function dataTransformation(datas, indexes) {
        for (let i = 0; i < datas.length; i++) {
            let a = datas[i];
            let values = 0;
            if (indexes == 1 || indexes == 2){
                values = a.teamSaleAmount;
            } else if (indexes == 3 || indexes == 4){
                values = a.number;
            }

            if (i < 3){
                lineChartDataList[indexes][1][i] = values;
                lineChartDataList[indexes][2][i] = values;
                lineChartDataList[indexes][3][i] = values;
            } else if (i < 6){
                lineChartDataList[indexes][2][i] = values;
                lineChartDataList[indexes][3][i] = values;
            } else{
                lineChartDataList[indexes][3][i] = values;
            }

        }
    }

    //-- 获取当前时间
    function localTime(){
        let myDate = new Date();
        let year = myDate.getFullYear();                                                        //获取当前年
        let mon = myDate.getMonth()+1<10 ? "0"+(myDate.getMonth()+1) : (myDate.getMonth()+1);   //获取当前月
        let date = myDate.getDate()<10 ? "0"+myDate.getDate() : myDate.getDate();               //获取当前日
        let h = myDate.getHours()<10 ? "0"+myDate.getHours() : myDate.getHours();               //获取当前小时数(0-23)
        let m = myDate.getMinutes()<10 ? "0"+myDate.getMinutes() : myDate.getMinutes();         //获取当前分钟数(0-59)
        let s = myDate.getSeconds()<10 ? "0"+myDate.getSeconds() : myDate.getSeconds();         //获取当前秒

        //let now = year+"."+mon+"."+date;	//当前时间 (2019.10.08)
        let now = h+":"+m+":"+s;	        //当前时间 (12:00:00)
        $('.currentTime').text(now);

        return myDate;
    }

    //-- 根据标题和时间统计总数
    function statisticsCount(titleValue=1, selectTitle="元", value=1, time=3){
        let count = 0;
        for (let i = 0; i < time; i++) {
            count += lineChartDataList[titleValue][value][i];
        }
        $('.statisticsQuantity').text(count+selectTitle);
    }

    //-- 今日团情
    function teamStatusToday(data){
        // 新增团员
        let getNewMemberToday = data.getNewMemberToday;
        $('.newMemberToday>.number').text(getNewMemberToday.number);
        if (getNewMemberToday.newMember != 0) {
            $('.newMemberToday>.remain').hide();
            $('.newMemberToday>.growth').show();
            $('.newMemberToday .newMember').text(getNewMemberToday.newMember);
        }

        // 新增子团
        let getChildTeamToday = data.getChildTeamToday;
        $('.childTeamToday>.number').text(getChildTeamToday.number);
        if (getChildTeamToday.newChildMember != 0) {
            $('.childTeamToday>.remain').hide();
            $('.childTeamToday>.growth').show();
            $('.childTeamToday .newChildMember').text(getChildTeamToday.newChildMember);
        }

        // 团队保费 - 子团保费
        let getTeamAmountAndChildAmountToday = data.getTeamAmountAndChildAmountToday;
        $('.teamPremium>.teamSaleAmount').text(getTeamAmountAndChildAmountToday.teamSaleAmount);
        if (getTeamAmountAndChildAmountToday.teamPer != 0) {
            $('.teamPremium>.remain').hide();
            $('.teamPremium>.growth').show();
            $('.teamPremium .teamPer').text(getTeamAmountAndChildAmountToday.teamPer);
        }

        $('.childTeamPremium>.rearSaleAmount').text(getTeamAmountAndChildAmountToday.rearSaleAmount);
        if (getTeamAmountAndChildAmountToday.rearPer != 0) {
            $('.childTeamPremium>.remain').hide();
            $('.childTeamPremium>.growth').show();
            $('.childTeamPremium .rearPer').text(getTeamAmountAndChildAmountToday.rearPer);
        }
    }

    //-- 团员动态
    function membersDynamic(data) {
        if ($$.isValidObj(data)){
            for (let i = 0; i < data.length; i++) {
                $(".unit-"+data[i].type).text(data[i].count);
            }
        }
    }

    //-- 获取当前用户的VIP信息
    function getVipData() {
        $$.request({
            url: UrlConfig.member_memberVip_getVipData,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    PAGE_STATE.whetherVIP = data.vipType === 2;
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }
};












