/**
 * 团员分享统计 JS
 * @Author 吴成林
 * @Date 2020-3-19 14:32:48
 */
let teamId = '';
let title = '';
let type = 1;
window.onload = function() {
    pageLoader();
    $$.changeVersion();
    /**
     * 页面加载对必要的参数作处理
     */
    function pageLoader(){
        /* 从我的页面传值 */
        teamId = decodeURIComponent($$.getUrlParam("teamId"));                                                  // 团队ID
        title = decodeURIComponent($$.getUrlParam("title"));          // 页面title标题
        $$.isValidObj(title) ? $("title").text(title):$("title").text("团员动态");
        pageInit();
    }

    /**
     * 页面初始化加载
     */
    function pageInit(){
        dataLoading();

        eventBinding();
    }

    /**
     * 数据加载
     */
    function dataLoading(){
          if (title == "分享素材库"){
              type = 1;
          } else if (title == "分享名片"){
              type = 2;
          }  else if (title == "分享资讯"){
              type = 3;
          } else if (title == "分享产品"){
              type = 4;
          } else if (title == "分享课堂"){
              type = 5;
          }
        $$.request({
            url: UrlConfig.shareRecord_getTeamShareList,
            pars:{
                teamId:teamId,
                type:type
            },
            requestBody:true,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.datas.length > 0){
                    let dataHtml = "";
                    for (let i = 0; i < data.datas.length; i++) {
                        dataHtml += `<li class="space-between">
                                        <div class="flex-start">
                                            <img src="` + (data.datas[i].imgPath != undefined ? data.datas[i].imgPath :"../../../images/my/mituLogo.png")+`" class="userPhoto">
                                            <span>`+ (data.datas[i].rname != undefined ? data.datas[i].rname : data.datas[i].account)+`</span>
                                        </div>
                                        <div class="flex-start">
                                            <img src="../../../images/teams/colonelSeeVersion/colonelSeeVersion-share.png" class="share">
                                            <span class="fontThemeColor">`+data.datas[i].count+`</span>
                                        </div>
                                    </li>`;

                    }
                    $("#number").html(data.datas.length)
                    $("#dataList").html(dataHtml)
                }else {
                    $$.showNoResultView("暂无数据");
                    $("#info").hide()
                }
            },
            ffn: function (data) {
                $$.errorHandler();
            }
        });
    }

    /**
     * 事件绑定
     */
    function eventBinding(){
        //-- 点击统计标题
        $(".statisticsTime>div").on("click", function() {
            $(this).addClass("selectTime").siblings().removeClass("selectTime");
        });

    }
}