window.onload = function(){
    let teamId = $$.getUrlParam("teamId");
    teamWeChatShare(teamId);
    $('.invite').click(() => {
        teamShare(teamId);
    });
};
