window.onload = function () {
    $$.changeVersion();
    $(".joinrule").click(function(){
        pushRule(1);
    });
    $(".join").click(function(){
        member_Detailspage();
    });
};

function pushRule(page){
    $$.push('teams/rule',{page:page});
}


function member_Detailspage() {
    if ($$.checkLogin()) {
        $$.request({
            url: UrlConfig.member_Detailspage,
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    let userStatus = data.datas.userStatus;
                    let mtype = data.datas.mtype;
                    if (userStatus === 2 && mtype === 4) {
                        checkOrder();
                    } else {
                        if (userStatus === 0 || userStatus === 3) {
                            $$.confirm({
                                title: '您还不符合加团条件，请先进行执业认证~',
                                onOk: () => $$.push('my/professionalCertification')
                            });
                        } else if (userStatus === 1) {
                            $$.layerToast('您的执业认证未审核，认证通过后才可加团呢~');
                        }
                    }
                }
            }
        });
    } else {
        $$.confirmLogin();
    }
}
function checkOrder(){
    $$.request({
        url: UrlConfig.market_teammember_checkOrder,
        loading: true,
        sfn: function (data) {
            $$.closeLoading();
         if (data.success) {
                let teamId = $$.getUrlParam("teamId");
                $$.push('teams/addDetails',{
                    teamId:teamId
                });
         } else {
             $$.layerToast('需要成功出单1张');
         }
        },
        ffn: function (data) {
            $$.errorHandler();
        }
    });
}
