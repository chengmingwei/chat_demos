

/**
 * 领航达人 JS
 * @Author 肖家添
 * @Date 2020/9/11 15:26
 */


window.onload = function(){
    countAction("xb_6000");

    /**
     * 数据存储中心
     * @Author 肖家添
     * @Date 2020/9/11 15:26
     */
    const PAGE_STATE = {
        id: null,
        commentType: 5,
        beComment: null
    };

    pageLoader();

    /**
     * 页面加载对必要的参数作处理
     * @Author 肖家添
     * @Date 2020/9/11 15:26
     */
    function pageLoader(){

        PAGE_STATE.id = $$.getUrlParam("id");
        $$.validPageParams(PAGE_STATE.id, "newIndex");

        //-- 页面初始化
        pageInit();

    }

    /**
     * 绑定事件及页面初始化处理
     * @Author 肖家添
     * @Date 2020/9/11 15:26
     */
    function pageInit() {

        //-- 绑定事件
        bindEvent();

        //-- 初始化页面
        initPageState();

    }

    /**
     * 绑定事件
     * @Author 肖家添
     * @Date 2020/9/11 15:26
     */
    function bindEvent() {

        //-- 我要评论
        $Listener.onTap(".doComment", (e) => {
            PAGE_STATE.beComment = null;
            openCommentModel();
        });

        //-- Model close function
        $Listener.onTap(".model .model-mask, .model .model-close", (e) => {
            const close = (e) => {
                const parent = e.parent();
                if(!parent.hasClass("model")){
                    close(parent);
                    return;
                }
                parent.stop().fadeOut();
            };
            const that = $(e);
            close(that);
        });

        //-- 分享
        $Listener.onTap(".share", () => {
            $$.showShareView();
        });

        //-- 提交评论
        $Listener.onTap("#commentModel .model-submit", (e) => {
            const content = $("#commentModel textarea").val();
            doComment(content);
        });

    }

    /**
     * 初始化页面参数
     * @Author 肖家添
     * @Date 2020/9/11 15:27
     */
    function initPageState(){

        //-- 查询详情
        findDetail();

        //-- 查询评论
        findComments();

        //-- 微信分享
        weChatShare();

        //-- 清理HTML注释
        $$.clearHTMLNotes();
    }

    /**
     * 查询达人详情
     * @Author 肖家添
     * @Date 2020/9/13 12:25
     */
    function findDetail(){
        const { id } = PAGE_STATE;
        $$.request({
            url: UrlConfig.member_userNavInfo_getUserNav,
            pars: { id },
            loading: true,
            requestBody: true,
            sfn: function(data){
                $$.closeLoading();
                if(data.success){
                    responseHandler(data.data);
                }else{
                    $$.alert("数据加载失败，请重试！");
                }
            }
        });

        function responseHandler(datum){
            const { contentURL } = datum;

            $(".content").html(contentURL);
        }
    }

    /**
     * 查询评论数据
     * @Author 肖家添
     * @Date 2020/9/13 16:09
     */
    function findComments(){
        const { id, commentType } = PAGE_STATE;
        $$.request({
            url: UrlConfig.member_evaluation_getEvaluationListByObjectId,
            pars: { objectId: id, type: commentType },
            requestBody: true,
            sfn: function(data){
                if(data.success){
                    responseHandler(data.datas);
                }
            }
        });

        function responseHandler(datum){
            const elements = datum.map(item => {
                const { id, allEvaluationChildList } = item;
                function buildItem(item){
                    let { id, imgPath, rname, createTime, evaluationContent, giveLike, topCommentId, toRname, isMyPraise } = item;
                    const userImage = $$.changeIsNilVal(imgPath, $Constant.memberDefaultImagePath);
                    topCommentId = $$.changeIsNilVal(topCommentId, id);
                    return `
                        <div class="comment-item-body" data-datums='${JSON.stringify({rname, parentCommentId: id, topCommentId})}'>
                            <div>
                                <div class="comment-user-img" style="background: url('${userImage}') no-repeat center center /100% 100%;">
                                </div>
                                <div>
                                    <div>${rname}</div>
                                    <div>${toRname ? `回复 <span class="systemColor">${toRname}</span>` : `回复于${createTime}`} </div>
                                </div>
                            </div>
                            <div class="comment-content">
                                <div>${$$.changeIsNilVal(evaluationContent, "")}</div>
                                <div data-id="${id}" class="${isMyPraise ? 'active' : ''}">
                                    <img src="../../images/pilot/01.png" class="img_active" />
                                    <img src="../../images/pilot/02.png" class="img_normal" />
                                    <div class="like">${giveLike < 9999 ? giveLike : '9999+'}</div>
                                </div>
                            </div>
                        </div>
                    `;
                }
                const children = allEvaluationChildList.map(item => {
                    return buildItem(item);
                }).join("");
                const childrenSize = allEvaluationChildList.length;
                const commentHadOpen = localStorage.getItem(`XB_PILOT_${id}`) === "true";
                return `
                    <div class="comment-item" data-id="${id}">
                        ${buildItem(item)}
                        <div class="comment-item-reply-open ${commentHadOpen ? 'active' : !commentHadOpen || childrenSize > 5 ? '' : 'active'}">
                            <div class="comment-item-reply">
                                ${children}
                            </div>
                            <div class="tips" style="display: ${childrenSize <= 0 ? 'none' : 'block'}">
                                <span>
                                    <span class="line">一</span>
                                    <span class="open">展开</span>
                                    <span class="close" hidden>收起</span>
                                    <span>${childrenSize} 条回复</span>
                                    <span class="arrow"></span>
                                </span>
                            </div>
                        </div>
                    </div>
                `;
            }).join("");
            $(".comment-list").html(elements);

            //-- 评论展开回复
            $Listener.onTap(".comment-item-reply-open>.tips", (e) => {
                const parent = $(e).parent(),
                    className = "active",
                    commentId = parent.parent().attr("data-id");
                parent.toggleClass(className);
                localStorage.setItem(`XB_PILOT_${commentId}`, parent.hasClass(className));
            });

            //-- 评论
            $Listener.onTap(".comment-item-body", (e) => {
                PAGE_STATE.beComment = $(e);
                let datums = PAGE_STATE.beComment.attr("data-datums");
                const { rname } = JSON.parse(datums);
                openCommentModel(`回复 ${$$.changeIsNilVal(rname, '')}：/我要评论`);
            });

            //-- 点赞
            $Listener.onTap(".comment-item-body .comment-content>div:last-child", (e) => {
                event.stopPropagation();
                const that = $(e);
                giveLike(that, that.attr("data-id"));
            });
        }
    }

    /**
     * 评论
     * @Author 肖家添
     * @Date 2020/9/13 16:14
     */
    function doComment(content = ""){
        if(!$$.isValidObj(content)) $$.throwTips("请填写评论~");
        const { id, commentType, beComment } = PAGE_STATE;
        let otherParams = {};
        if(beComment){
            let datums = beComment.attr("data-datums");
            const { parentCommentId, topCommentId } = JSON.parse(datums);
            otherParams = { id: parentCommentId, topCommentId };
        }
        $$.request({
            url: UrlConfig.member_evaluation_evaluationInsert,
            pars: {
                evaluationContent: content,
                isAnonymous: 0,
                objectID: id,
                type: commentType,
                ...otherParams
            },
            requestBody: true,
            loading: true,
            sfn: function(data){
                $$.closeLoading();
                if(data.success){
                    $(".model .model-close").click();
                    findComments();
                }else{
                    $$.alert(`评论失败, 请重试！(${data.msg})`);
                }
            }
        });
    }

    /**
     * 打开评论窗口
     * @Author 肖家添
     * @Date 2020/9/13 18:12
     */
    function openCommentModel(placeholder = "/我要评论"){
        checkLogin();

        const model = $("#commentModel");
        model.find("textarea").html("").val("").text("").attr("placeholder", placeholder);
        model.stop().fadeIn();
    }

    /**
     * 点赞
     * @Author 肖家添
     * @Date 2020/9/13 21:28
     */
    function giveLike(that, id){
        checkLogin();

        $$.request({
            url: UrlConfig.praisestatistic_save,
            pars: {
                type: 15,
                objectId: id
            },
            requestBody: true,
            method: "POST",
            loading: true,
            sfn: function (data) {
                $$.closeLoading();
                if (data.success) {
                    const likeEle = that.find(".like");
                    let giveLike = parseInt(likeEle.html());
                    if (data.delete){
                        giveLike--;
                        $$.layerToast("取消点赞！");
                        that.removeClass("active");
                    }else {
                        giveLike++;
                        $$.layerToast("点赞成功！");
                        that.addClass("active");
                    }
                    if(giveLike < 0) giveLike = 0;
                    if(giveLike > 9999) giveLike = "9999+";
                    likeEle.html(giveLike);

                    $$.request({
                        url: UrlConfig.evaluation_updateGiveLike,
                        pars: {
                            "id": id,
                            "giveLike": giveLike
                        },
                        sfn: function (data) {}
                    });

                } else {
                    $$.layerToast(`${data.msg}`);
                }
            }
        });
    }

    /**
     * 检查登录
     * @Author 肖家添
     * @Date 2020/9/13 21:28
     */
    function checkLogin(){
        const hadLogin = $$.checkLogin();
        if(!hadLogin){
            $$.confirmLogin();
            $$.throw();
        }
    }

    /**
     * 微信分享
     * @Author 肖家添
     * @Date 2020/9/13 21:27
     */
    function weChatShare(){
        if (!$WeChat.isWx() && !PAGE_APP) return;
        const url = window.location.href;
        weChatJSTool.share({
            _imgUrl: $Constant.shareLogo,
            _lineLink: url,
            _shareTitle: "领航达人",
            _descContent: "领航达人",
            _sfn: function () { }
        });
    }
};
